------------------------------------------------------------------------------------
-- mp_dl_pre
------------------------------------------------------------------------------------
function mp_dl_pre.doaskjob(n,l,w)
	local _f,a,b,c
	alias.resetidle()
	dl.asktimes=dl.asktimes+1
	if dl.asktimes>30  then 
		dl.asktimes=0
		if dl.loopnpc~=nil and dl.loopnpc>0 then
			if dl.jobnpc=="范骅" and mpLimited.mpexp<6800 then	dl.jobnpc="巴天石";run("s;w");roomno_now=180;dl.asknum=1
			elseif dl.jobnpc=="巴天石" then	dl.jobnpc="华赫艮";run("e;s");roomno_now=181;dl.asknum=1
			elseif dl.jobnpc=="华赫艮" then	dl.jobnpc="范骅";run("n;n");roomno_now=182;dl.asknum=1
			else dl.asktimes=0
			end
		end
	end
	if findstring(w[0],"我这里现在没什么要紧的事情") then
		--if havefj>0 or pdfjsj()<20 then 
		if havefj>0 then
			alias.startworkflow()
		else
			dl.asknum_now=dl.asknum_now+1
			if roomno_now==181 then 
				if dl.asknum>1 and dl.asknum>=dl.asknum_now and dl.asknum_now>1 then
					run("ask hua hegen "..dl.asknum_now.." about 治安")
				else
					run("ask hua hegen about 治安")
					if dl.asknum_now>=dl.asknum then
						dl.asknum_now=0
					end
				end
			elseif roomno_now==180 then	
				if dl.asknum>1 and dl.asknum>=dl.asknum_now and dl.asknum_now>1 then
					run("ask ba tianshi "..dl.asknum_now.." about 治安")
				else
					run("ask ba tianshi about 治安")
					if dl.asknum_now>=dl.asknum then
						dl.asknum_now=0
					end
				end
			elseif roomno_now==182 then 
				if dl.asknum>1 and dl.asknum>=dl.asknum_now and dl.asknum_now>1 then
					run("ask fan ye "..dl.asknum_now.." about 治安")
				else
					run("ask fan ye about 治安")
					if dl.asknum_now>=dl.asknum then
						dl.asknum_now=0
					end
				end
			else 
				alias.flytonpc(dl.jobnpc) 
			end
		end
	elseif findstring(w[0],"和我大理素无瓜葛","轻轻地拍了拍你的头","似乎想对你说些什么") then
		do_dl_job=0
		alias.startworkflow()
	elseif findstring(w[0],"你先把你手头的活干完吧") then
		dl.needquit=1
		alias.flytoid(177)
	elseif findstring(w[0],"北方","北面","北部","乌弄城","剑川") then
		print("任务在北部")
		dl.search="n|ne|e|w|n|s|sw|nw|sw|w|w|s|sd|se|su|wd|n|w|enter|out|e|n|nu|n|e|e|ne|nd|n|nu|nu|nd|su|eu|eu|wd|s|n|n|s|wd|sd|sd|s|su|se|s"
		dl.searchroom=169
		closeclass("mp_dl_pre")
		openclass("mp_dl_start")
		dl.searchjs=0
		alias.flytoid(169)
	elseif findstring(w[0],"东方","东面","东部","阳宗镇","星云湖畔","步雄部","罗伽甸","滇池","沿池堤岸") then
		print("任务在东部")
		dl.search="sw|w|wu|wd|nu|eu|e|n|enter|out|s|eu|eu|n|nu|n|s|sd|s|e|se|e|s|u|d|n|e|ne|eu|ed|ne|e|u|d|w|sw|su|nd|sw|su|sd|ed|s|eu|wd|n|e|w|n|w|u|d|e|s|wu|nu|nd|ne|wu|wd|sw|w|w"
		dl.searchroom=251
		closeclass("mp_dl_pre")
		openclass("mp_dl_start")
		dl.searchjs=0
		alias.flytoid(251)
	elseif findstring(w[0],"南面","南方","南部","喜州城","妃丽湖","鲁望镇","武定镇","河西镇","龙口城") then
		print("任务在南部")
		dl.search="s|s|s|e|w|sw|sw|s|n|n|s|w|u|d|e|ne|ne|s|eu|e|w|s|n|n|u|u|d|d|s|wd|se|se|nw|s|w|e|nw|sw|ne|se|n|nw|n|n|n|n"
		dl.searchroom=143
		closeclass("mp_dl_pre")
		openclass("mp_dl_start")
		dl.searchjs=0
		alias.flytoid(143)
	elseif findstring(w[0],"西方","西面","西部","巴的甸","蜜纳甸","碧罗雪山","泸水沿岸","易溪部","阿头部","镇雄","葛鲁城") then
		print("任务在西部")
		dl.search="wu|wu|wu|wd|wd|n|w|enter|out|e|n|se|nw|nu|n|e|e|ne|sw|w|w|s|sd|s|s|s|s|wu|w|e|ed|se|s|n|ne|wu|n|eu|sd|sw|se|ed|wu|nw|ne|nu|ed|ed|ed"
		dl.searchroom=171
		closeclass("mp_dl_pre")
		openclass("mp_dl_start")
		dl.searchjs=0
		alias.flytoid(171)
	elseif findstring(w[0],"中方","中面","中部","黑龙岭","石刻经幢","金汁河畔","大叠水瀑布") then
		print("任务在中部")
		dl.search="sd|sd|se|eu|e|n|enter|out|s|eu|eu|n|nu|n|s|sd|s|e|se|e|s|u|d|n|e|ne|eu|ed|wu|wd|sw|w|w|sw|w|wu|wd|sd|nw|n|enter|out|s|se|s|nw|wd|eu|se|se|s|n|nw|n|nu|nu|nw|nu|nu"
		dl.searchroom=231
		closeclass("mp_dl_pre")
		openclass("mp_dl_start")
		dl.searchjs=0
		alias.flytoid(231)
	end
end
function mp_dl_pre.dosomething1(n,l,w)
	local _f,a,b,c
		a,b,c=string.find(l,"(%S+)位大理国司马 范骅%(Fan ye%)")
		if c~=nil then
			dl.asknum=ctonum(c)
		end
		a,b,c=string.find(l,"  (%S+)位大理国司空 巴天石%(Ba tianshi%)")
		if c~=nil then
			dl.asknum=ctonum(c)
		end
		a,b,c=string.find(l,"  (%S+)位大理国司徒 华赫艮%(Hua hegen%)")
		if c~=nil then
			dl.asknum=ctonum(c)
		end
		a,b,c=string.find(l,"有一天，你踩着七色云彩来迎娶『(.+)』")
		if c~=nil then
			if findstring(c,"范骅") then run("ask fan ye about 治安");dl.asktimes=0
			elseif findstring(c,"巴天石") then run("ask ba tianshi about 治安");dl.asktimes=0
			elseif findstring(c,"华赫艮") then run("ask hua hegen about 治安");dl.asktimes=0
			elseif findstring(c,"段陉") then
				run("give "..dl.zeiid.." to duan xing;ask duan xing about 功劳;ask duan xing about 升职;drop gongji biao")
				--alias.checkexp("mp")
			end
			return
		end
		if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
			alias.resetidle()
			dl.asknum=1
			alias.flytoid(179)
		elseif not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			alias.resetidle()
			if dl.needquit>0 then alias.flytoid(177) else alias.flytonpc(dl.jobnpc) end
		elseif findstring(l,"数码世界，数字地图，179就是这里！") then
			alias.resetidle()
			dl.zeiid=""
			if dl.needquit>0 then
				alias.flytoid(177)
			else
				alias.dz(set_neili)
			end
		elseif findstring(l,"数码世界，数字地图，177就是这里！") then
			alias.resetidle()
			dl.needquit=0
			stat.quiting=0
			openclass("quit")
		elseif findstring(l,"对方不接受这样东西。") then 
			alias.resetidle()
			run("uset brief")
			dl.needquit=1 
		elseif findstring(l,"^你给段陉一位.+。") then
			dl.findzei=0
			if dl.reget_zhongjian>0 then 
				print("去"..dl.arrest_room.."捡重剑")
				alias.flytoid(dl.arrest_room)
			else
				alias.gg()
				alias.checkexp("mp")				
			end
		elseif findstring(l,"重剑对你而言太重了") then 
			dl.reget_zhongjian=1
		elseif findstring(l,"你忙着呢，你等会儿在问话吧。") then
			alias.resetidle()
			wait.make(function()
			_f=function()
				if roomno_now==181 then run("ask hua hegen about 治安")
				elseif roomno_now==180 then	run("ask ba tianshi about 治安")
				elseif roomno_now==182 then run("ask fan ye about 治安")
				end
			end
			wait.time(1);_f()
			end)
		elseif findstring(l,"你目前还没有任何为 checkexpover=mp 的变量设定。") then
			alias.resetidle()
			if add.exp>10 and mpLimited.MarkExp<me["menpaiLimited"] then mpLimited.MarkExp=tonumber(me["menpaiLimited"]) end
			if add.exp<10 or mpLimited.mpexp>=me["menpaiLimited"] then
				mpJobLimited=1
				print("统计到的arrest上限为："..mpLimited.mpexp)
				mpLimited.MarkExp=mpLimited.mpexp
				if mpLimited.MarkTime<(os.time()-3600) then
					if de_bug>0 then print("到arrest时间却仍然busy，推迟2分钟") end
					mpLimited.MarkTime=tonumber(os.time()-3600+120)
				end
			end
			--alias.checkbusy("arrest")
			if havefj>0 or dl.dohuajiangwork~=1 or me.menpai~="dl" then alias.startworkflow()
			else
				closeclass("mp_dl_pre")
				openclass("mp_dl_work")
				closeclass("mp_dl_dowork")
				alias.flytoid(289)
			end
		elseif findstring(l,"这里没有 [hua hegen|ba tianshi|fan ye]+ 这个人。","对方正忙着呢，你等会儿在问话吧。","但是很显然的，[华赫艮|巴天石|范骅]+现在的状况没有办法给你任何答覆。") then 
			--roomno_now=0
			dl.asktimes=0
			if dl.jobnpc=="范骅" then	dl.jobnpc="巴天石"
			elseif dl.jobnpc=="巴天石" then	dl.jobnpc="华赫艮"
			elseif dl.jobnpc=="华赫艮" then	dl.jobnpc="范骅"
			end
			alias.flytonpc(dl.jobnpc)
		end
		if findstring(l,"数码世界，数字地图，"..tostring(dl.arrest_room).."就是这里！") then
			--run("get zhongjian")
			alias.gg()
			wait.make(function()
				_f=function() alias.checkexp("mp") end
				wait.time(1);_f()
			end)
		end
end
------------------------------------------------------------------------------------
-- mp_dl_start
------------------------------------------------------------------------------------
function mp_dl_start.dosomething1(n,l,w)
	local _f,_tb,a,b,c,d,e,f
	wait.make(function()
		if findstring(l,"你目前还没有任何为 search=yes 的变量设定。") then
			alias.resetidle()
			if dl.err~=nil and dl.err>5 then 
				alias.flytoid(dl.searchroom)
			else
				if dl.findzei~=nil and dl.findzei>0 then
					run(mpyun..";arrest "..dl.zeiid..";ask "..dl.zeiid.." about 治安;set checkzei=yes")
					alias.yjl()
				else
					_tb=Split(dl.search,"|")
					if tonumber(dl.searchid)>tonumber(#_tb) then 
						dl.searchid=1
						dl.searchjs=dl.searchjs+1
						if dl.searchjs>20 then 
							closeclass("mp_dl_start")
							openclass("mp_dl_pre")
							dl.needquit=1
							alias.flytoid(177)
						end
					end
					run(_tb[dl.searchid])
					dl.searchid=dl.searchid+1
					run("set search=yes")
				end
			end
			return
		end
		if not isopen("kill") and findstring(l,".+回答你：没找到哇!") then
			if dl.fishing~=nil and dl.fishing~="" then
				run("tell "..dl['fishing'].." "..always['where'].." "..dl['zeiid'])
			else
				run("tell "..dummy['id'].." "..always['where'].." "..dl['zeiid'])
			end
		end
		if findstring(l,".+对著"..dl.zeiname.."喝道：「臭贼！今日不是你死就是我活！」") then
			run(mpyun..";arrest "..dl.zeiid)
		end
		a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
		if c~=nil and (tonumber(c)==143 or tonumber(c)==169 or tonumber(c)==171 or tonumber(c)==231 or tonumber(c)==251) then
			alias.resetidle()
			dl.findzei=0
			dl.searchid=1
			dl.err=0
			dl.arresttime=0
			alias.dz(set_neili_job)
		end
		if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			alias.resetidle()
			alias.uw()
			run("wield chain;set search=yes")
		end
		if findstring(l,"你目前还没有任何为 checkzei=yes 的变量设定。") then
			alias.resetidle()
			if (dl.findzei==nil or dl.findzei==0) or (dl.err~=nil and dl.err>5) then 
				run("set search=yes")
			else
				if dl.findzei~=nil and dl.findzei<2 then
					-- run("fight "..dl.zeiid..";halt")
					--_tb=Split(mpyun,"|")
					--for k,v in ipairs(_tb) do run(v) end
					_f=function() run(mpyun..";arrest "..dl.zeiid..";set checkzei=yes") end
					wait.time(2);_f()
				end
			end
		end
		if dl.arresttime~=nil and dl.arresttime~=0 and os.time()>(dl.arresttime+30) then
			alias.resetidle()
			dl.arresttime=os.time()
			run("fight "..dl.zeiid..";halt")
		end
		if findstring(l,"看起来老虎想杀死你！") then
			run("halt")
		end
		a,b,c,d,e,f=string.find(l,"(%S+) (%S+)%((%w+) (%w+)%)")
		if c~=nil and d~=nil and e~=nil and f~=nil then
			if dl.findzei==nil or dl.findzei==0 and string.find("帮匪|草寇|盗匪|盗贼|盗贼王|地痞|独行盗|恶霸|流寇|流氓|流氓头|路霸|毛贼|蒙面客|强盗|强盗头|抢匪|山大王|山贼|山贼头|山寨大王|土匪|土匪头|无赖|小贼|一品堂杀手|贼头",d) then
				dl.findzei=1
				dl.zeiname=d
				dl.zeiid=string.lower(e).." "..string.lower(f)
			end
		end
		if findstring(l,"你喝道：大胆！竟敢在本官面前行抢！走！见官去！","你高喊一声：大理境内休得撒野！走！跟我见官去！","你喝道：可恶！竟敢在此调戏良家妇女！跟我回去见官！") then
			alias.resetidle()
			alias.count_qiankun()
			check_battleidle=0
			no_get=0  --重置尝试背贼次数
			dl.findzei=2
			dl.arresttime=0
			openclass("kill")
			openclass("kill_pfm")
			closeclass("kill_run")
			AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
			SetTimerOption("kill_timer", "group", "kill")
			pfmid=1
			reyun=1
			rekill=0
			wieldweapon=1
			dl.reget_zhongjian=0
			runaway=false
			npcfaint=false
			killRunSuccess=false
			killaction=""
			killid=dl.zeiid
			killname=dl.zeiname
			killskill=mpweapon
			killpfm=mppfm
			killyun=mpyun
			killjiali=mpjiali
			killjiajin=mpjiajin
			if dl.fishing~=nil and dl.fishing~="" then
				run("whisper "..dl['fishing'].." 回去吧 thank you;tell "..dl['fishing'].." 回去吧 thank you")
			else
				run("whisper "..dummy['id'].." 回去吧 thank you;tell "..dummy['id'].." 回去吧 thank you")
			end
			run("unwield chain;unset no_parry;yield no;jiali "..killjiali..";jiajin "..killjiajin)
			_tb=Split(killpfm,"|")
			if findstring(_tb[pfmid],"leidong") then run("perform leidong") end
			if findstring(_tb[pfmid],"jingang") then run("perform jingang") end
		end
		if findstring(l,"你目前还没有任何为 busyover=killover 的变量设定。","对方还没有完全昏迷，先等等吧。") then
			alias.resetidle()
			_f=function() for i=1,3,1 do run("h;get "..dl.zeiid.." "..i) end end
			wait.time(1);_f()
		end
		if findstring(l,"你将"..dl.zeiname.."扶了起来背在背上。") then
			alias.resetidle()
			closeclass("mp_dl_start")
			openclass("mp_dl_pre")
			alias.flytonpc("段陉")
		end
		if findstring(l,"你只觉得手中.+把持不定，脱手飞出！","你只觉虎口一热，.+顿时脱手而出","你.+臂麻木，哐当一声，.+掉到了地上。") then
			run("halt;get chain")
			if dl.findzei<2 then run("wield chain") end
		end
		if findstring(l,"人家没在惹事生非，你锁捕不了") then
			dl.findzei=1
			dl.err=1
		end
		if findstring(l,"这里并无此人！","这个方向没有出路。","你拿什么套？") then
			if dl.err==nil then dl.err=0 end
			dl.err=dl.err+1
		end
		if findstring(l,"此人已经交给其他官员处理","这不是活物","这里没有.+这个人。") then
			dl.findzei=0
		end
		if findstring(l,"你在臂力上先天禀赋不足，点穴反受其害！","你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑","你哼了一声，问.+道：「你会唱“十八摸”罢？唱一曲来听听。」") then
			alias.resetidle()
			alias.close_kill()
			dl.needquit=1
			closeclass("mp_dl_start")
			openclass("mp_dl_pre")
			alias.flytoid(179)
		end
		a,b,c=string.find(l,"[> ]*"..dl.zeiname.."(.+)")
		if c~=nil and dl.findzei>1 then
			alias.resetidle()
			if findstring(c,"跌在地上昏了过去") then
				alias.close_kill()
				run("halt")
				alias.checkbusy("killover")
			end
			if findstring(c,"挣扎了几下就死了") then
				no_get=0
				alias.resetidle()
				alias.close_kill()
				run("unwield chain;yun recover")
				dl.needquit=1
				closeclass("mp_dl_start")
				openclass("mp_dl_pre")
				alias.flytoid(179)
			end
			if findstring(c,"对你而言太重了") then
				if no_get==nil then no_get=0 else no_get=no_get+1 end
				for i=1,3,1 do run("get all from "..dl.zeiid.." "..i) end
				if no_get<2 then
					alias.gg()
					run("get chain;get huachu;get tengjia")
					--for i=1,3,1 do run("get "..dl.zeiid.." "..i) end
				elseif (me.menpai=="dl" or me.shen<hp.exp/5) and dl.jobnpc=="范骅" then
					no_get=0
					run("jiajin basic")
					if #always.bei==1 and always["bei"][1]=="六脉神剑" or #always.bei==2 and (always["bei"][1]=="六脉神剑" or always["bei"][2]=="六脉神剑") then
						run("jiali "..killjiali)
					else
						run("jiali 0")
					end
					run("kill "..dl.zeiid)
				else 
					print("尝试了"..no_get.."次，还是背不动")
					no_get=0
					alias.close_kill()
					run("unwield chain")
					dl.needquit=1
					closeclass("mp_dl_start")
					openclass("mp_dl_pre")
					alias.flytoid(179)
				end
			end
		elseif c~=nil and dl.findzei>0 then
		    if findstring(c,"急匆匆地走了") then
				no_get=0
				alias.resetidle()
				alias.close_kill()
				run("unwield chain;yun recover")
				dl.needquit=1
				closeclass("mp_dl_start")
				openclass("mp_dl_pre")
				alias.flytoid(179)
			end   
		end
	end)
end
function mp_dl_start.dosomething2(n,l,w)
	local _f,_tb,a,b,c
	--wait.make(function()
		a,b,c=string.find(w[0],"你向"..dl.zeiname.."打听有关「治安」的消息。\n"..dl.zeiname.."+(.+)")
		if c~=nil and findstring(c,"大理是个好地方","「嘿嘿嘿」奸笑了几声") then
			dl.findzei=1
			dl.arresttime=os.time()
			run("unset brief;follow "..dl.zeiid)
			if mpjf~=nil and mpjf~="" then alias.jf(mpjf) end
			if dl.fishing~=nil and dl.fishing~="" then
				run("tell "..dl['fishing'].." "..always['where'].." "..dl['zeiid'])
			else
				run("tell "..dummy['id'].." "..always['where'].." "..dl['zeiid'])
			end
		end
		if c~=nil and findstring(c,"大理的风景怡人","「呵呵呵」地笑了几声","无可奉告","没听说过","睁大眼睛望着你","这我可不清楚","你问的事我实在没有印象","你在说外国话吧","你说什么鸟语","我也能假装会说外国话") then
			dl.findzei=0
		end
	--end)
end
--function mp_dl_start.dosomething3(n,l,w)
	--local _f,_tb,a,b,c,d
	--wait.make(function()
	--	if findstring(l,"你向"..dl.zeiname.."打听有关「治安」的消息。\n"..dl.zeiname.."「嘿嘿嘿」奸笑了几声。\n"..dl.zeiname.."说道：大理是个好地方，我都流连忘返啦，嘿嘿") then
	--		dl.findzei=1
	--		run("follow "..dl.zeiid)
	--	end
	--	if findstring(l,"你向"..dl.zeiname.."打听有关「治安」的消息。\n"..dl.zeiname.."「呵呵呵」地笑了几声。\n"..dl.zeiname.."说道：大理的风景怡人，治安方面还算可以。") then
	--		dl.findzei=0
	--	end
	--end)
--end
------------------------------------------------------------------------------------
-- mp_dl_work
------------------------------------------------------------------------------------
function mp_dl_work.dosomething1(n,l,w)
	local _f,a,b,c
	wait.make(function()	
		if findstring(l,"你目前还没有任何为 busyover=work 的变量设定。") then
		alias.resetidle()
			if havefj>0 or dl.worked>0 then
				run("get all")
				alias.flytonpc("何红药")
			else run("ask huajiang about check;ask huajiang about 干活") end
		end
		if not isopen("dealwith_sellyao") and findstring(l,"有一天，你踩着七色云彩来迎娶『何红药』") then
			alias.resetidle()
			if hp.neili<(hp.maxneili*95/100) then alias.checkdrugbusy("da xueteng") end
			alias.checkitems()
		end
		if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
			alias.resetidle()
			alias.startworkflow()
		end
		if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			alias.resetidle()
			if dl.dohuajiangwork>0 then
				print("开始种花")
				run("find huachu")
				alias.flytoid(200)
			else
				--alias.checkbusy("work")
				alias.startworkflow()
				print("dali结束")
			end
		end
		if findstring(l,"你从泥里挖出一个大血藤") then
			have.xueteng=have.xueteng+1
		end
		if findstring(l,"你丢下一棵大血藤","你吃下一.+大血藤","你给.+大血藤") then
			have.xueteng=have.xueteng-1
		end
		if findstring(l,"你从泥里挖出一个当归") then
			have.danggui=have.danggui+1
		end
		if findstring(l,"你丢下一棵当归") then
			have.danggui=have.danggui-1
		end
		if findstring(l,"你忙着呢，你等会儿在问话吧。") then
			alias.resetidle()
			_f=function() run("ask huajiang about check;ask huajiang about 干活") end
			wait.time(2);_f()
		end
		if findstring(l,"数码世界，数字地图，200就是这里！") then
			alias.resetidle()
			if havefj>0 then alias.startworkflow()
			else run("ask huajiang about check;ask huajiang about 干活") end
		end
		if findstring(l,"数码世界，数字地图，289就是这里！") then
			alias.resetidle()
			dl.worked=0
			_f=function() run("open door;enter;drop huachu;remove all;give tengjia to gu ducheng;set no_accept 0;ask gu ducheng about 藤甲;set no_accept 1;wear all") end
			wait.time(2);_f()
			Simulate("你目前还没有任何为 dazuo=over 的变量设定。")
			--alias.dz(100)
		end
		end)
end
function mp_dl_work.dosomething2(n,l,w)
		if findstring(w[0],"花匠对你点点头，满意地说：“够了，够了，今天的活就干到这里吧。\n花匠对你竖起大拇指：“你如此勤勉，有朝一日必成一个大花匠。") then
			alias.resetidle()
			closeclass("mp_dl_dowork")
			alias.checkbusy("work")
		end
		if findstring(w[0],"你向花匠打听有关「干活」的消息。\n花匠说道：您干了不少活了") then
			alias.resetidle()
			dl.worked=1
			alias.checkbusy("work")
		end
		if findstring(w[0],"你向花匠打听有关「干活」的消息。\n花匠说道：好极了。我这里正需要人手修整园子，你帮我除草松土吧。","你向花匠打听有关「干活」的消息。\n花匠说道：你先把手头的活干完再说吧。") then
			alias.uw()
			run("wield huachu")
			openclass("mp_dl_dowork")
		end
end
function mp_dl_work.dosomething3(n,l,w)
		a,b,c=string.find(w[0],"你向花匠打听有关「check」的消息。\n花匠对着你点了点头。\n花匠说道：到目前为止你一共做了(%d+)个任务！")
		if c~=nil then
			dl.workcs=tonumber(c)
		end
	
end
------------------------------------------------------------------------------------
-- mp_dl_dowork
------------------------------------------------------------------------------------
function mp_dl_dowork.timer()
	alias.resetidle()
	if have.xueteng+have.danggui==0 then 
		run("work")
	else
		if have.xueteng>0 then 
			if hp.neili<(hp.maxneili*95/100) then alias.checkdrugbusy("da xueteng") end
			if dummy.xueteng_dm~=nil and dummy.xueteng_dm~="" then run("give "..dummy.xueteng_dm.." da xueteng") end
			run("drop da xueteng")
		end
		if have.danggui>0 then run("drop dang gui") end --身上有当归或者大血藤将不会挖到任何东西
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function mp_dl.update()
	local _tb,_tb2,_tb3
	AddTimer("mp_dl_dowork_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_dl_dowork.timer")
	SetTimerOption("mp_dl_dowork_timer", "group", "mp_dl_dowork")
	closeclass("mp_dl_dowork")
	
	_tb={
		"有一天，你踩着七色云彩来迎娶『(.+)』",
		"你目前还没有任何为 dealwithitems=over 的变量设定。",
		"你目前还没有任何为 dazuo=over 的变量设定。",
		"数码世界，数字地图，179就是这里！",
		"数码世界，数字地图，177就是这里！",
		"数码世界，数字地图，.+就是这里！",
		"对方不接受这样东西。",
		"重剑对你而言太重了",
		"你给段陉一位.+。",
		"你忙着呢，你等会儿在问话吧。",
		"对方正忙着呢，你等会儿在问话吧。",
		"但是很显然的，.+现在的状况没有办法给你任何答覆。",
		"你目前还没有任何为 checkexpover=mp 的变量设定。",
		"这里没有 [hua hegen|ba tianshi|fan ye]+ 这个人。",
		"和我大理素无瓜葛",
		"轻轻地拍了拍你的头",
		"似乎想对你说些什么",
		"你先把你手头的活干完吧",
		"我这里现在没什么要紧的事情",
		"  .+位大理国司马 范骅\\(Fan ye\\)",
		"  .+位大理国司空 巴天石\\(Ba tianshi\\)",
		"  .+位大理国司徒 华赫艮\\(Hua hegen\\)",
		}
	local  mp_dl_pre_triggerlist={
		{name="mp_dl_pre_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_dl_pre.dosomething1(n,l,w)  end,},
	      -- {name="mp_dl_pre_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_dl_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_dl_pre_triggerlist) do
		addtri(v.name,v.regexp,"mp_dl_pre",v.script,v.line)
	end
	local  mp_dl_pre_m_triggerlist={
	       {name="mp_dl_pre_m_dosth1",line=2,regexp=linktri("你向(范骅|巴天石|华赫艮)+打听有关「治安」的消息。\\n(.+)\\Z"),script=function(n,l,w)    mp_dl_pre.doaskjob(n,l,w)  end,},
	}
	for k,v in pairs(mp_dl_pre_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_dl_pre",v.script,v.line)
	end
	closeclass("mp_dl_pre")
	
	_tb={
		".+回答你：没找到哇!",
		".+对著.+喝道：「臭贼！今日不是你死就是我活！」",
		"数码世界，数字地图，.+就是这里！",
		"你目前还没有任何为 .+ 的变量设定。",
		"看起来老虎想杀死你！", --被老虎拦路
		"  \\S+ \\S+\\(\\w+ \\w+\\)", --抓取贼的信息
		--".- -\- \\%w", --房间描述
		"你喝道：大胆！竟敢在本官面前行抢！走！见官去！","你高喊一声：大理境内休得撒野！走！跟我见官去！","你喝道：可恶！竟敢在此调戏良家妇女！跟我回去见官！",
		"对方还没有完全昏迷，先等等吧。",
		"你将.+扶了起来背在背上。",
		"你只觉得手中.+把持不定，脱手飞出！","你只觉虎口一热，.+顿时脱手而出","你.+臂麻木，哐当一声，.+掉到了地上。",
		"人家没在惹事生非，你锁捕不了",
		"这里并无此人！","这个方向没有出路。","你拿什么套？",
		"此人已经交给其他官员处理","这不是活物","这里没有.+这个人。",
		"你在臂力上先天禀赋不足，点穴反受其害！","你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑","你哼了一声，问.+道：「你会唱“十八摸”罢？唱一曲来听听。」",
		".+跌在地上昏了过去",".+挣扎了几下就死了",".+急匆匆地走了",".+对你而言太重了",
	}
	local  mp_dl_start_triggerlist={
	       {name="mp_dl_start_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_dl_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_dl_start_triggerlist) do
		addtri(v.name,v.regexp,"mp_dl_start",v.script,v.line)
	end
	local  mp_dl_start_m_triggerlist={
	       {name="mp_dl_start_m_dosth1",line=2,regexp=linktri("你向.+打听有关「治安」的消息。\\n(.+)\\Z"),script=function(n,l,w)    mp_dl_start.dosomething2(n,l,w)  end,},
	      -- {name="mp_dl_start_m_dosth2",line=3,regexp="^(> > > |> > |> |)你向.+打听有关「治安」的消息。\\n(.+)\\n(.+)\\Z",script=function(n,l,w)    mp_dl_start.dosomething3(n,l,w)  end,},
	}
	for k,v in pairs(mp_dl_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_dl_start",v.script,v.line)
	end
	closeclass("mp_dl_start")
	
	_tb={
	"你目前还没有任何为 busyover=work 的变量设定。",
	"有一天，你踩着七色云彩来迎娶『何红药』",
	"你目前还没有任何为 dealwithitems=over 的变量设定。",
	"你目前还没有任何为 dazuo=over 的变量设定。",
	"你从泥里挖出一个大血藤",
	"你丢下一棵大血藤","你吃下一.+大血藤","你给.+大血藤",
	"你从泥里挖出一个当归",
	"你丢下一棵当归",
	"你忙着呢，你等会儿在问话吧。",
	"数码世界，数字地图，.+就是这里！",
	"你目前还没有任何为 dazuo=over 的变量设定。",
	}
	_tb2={
		"你向花匠打听有关「干活」的消息。\\n(.+)\\Z",
		"花匠对你点点头，满意地说：“够了，够了，今天的活就干到这里吧。\\n(.+)\\Z",
	}
	_tb3={
		"你向花匠打听有关「check」的消息。\\n花匠对着你点了点头。\\n(.+)\\Z",
	}
	local  mp_dl_work_triggerlist={
	       {name="mp_dl_work_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_dl_work.dosomething1(n,l,w)  end,},
		   
	}
	for k,v in pairs(mp_dl_work_triggerlist) do
		addtri(v.name,v.regexp,"mp_dl_work",v.script,v.line)
	end
	local  mp_dl_work_triggerlist={
		   {name="mp_dl_work_dosth2",line=2,regexp=linktri(_tb2),script=function(n,l,w)    mp_dl_work.dosomething2(n,l,w)  end,},
	       {name="mp_dl_work_dosth3",line=3,regexp=linktri(_tb3),script=function(n,l,w)    mp_dl_work.dosomething3(n,l,w)  end,},
	}
	for k,v in pairs(mp_dl_work_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_dl_work",v.script,v.line)
	end
	closeclass("mp_dl_work")
	
	
--[[	_tb={
			"你身上没有这样东西",
			"你身行向后一跃",
			".+领教壮士的高招",
			".+在下只好奉陪",
			"你正忙着呢",
			"你现在不忙",
			"人家没在惹事生非，你锁捕不了！",
			"你已.+了。",
			".+说道：我这里现在没什么要紧的事情，.+请先回去休息吧。",
			}
	addtri("mp_dl_watch_gag_dosth1",linktri(_tb),"mp_dl_watch","")
	SetTriggerOption("mp_dl_watch_gag_dosth1","omit_from_output",1)]]
end
mp_dl.update()
