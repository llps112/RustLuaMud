--[[
所有变量统一在这个文件声明，请勿在其他脚本中声明变量。
--@hhy 2016年11月16日
]]
---------always.lua

-- 首先设置随机种子（通常只在程序开始时调用一次）
math.randomseed(os.time())

always={}
always.bei={} --收集激发的空手功夫
always.sleeptimes=0  --统计两次睡觉的间隔
always.xxblow=0	--星宿吹笛是否有火
--always.liuhuang=0	--硫磺基数
always_daytime={}
always_hp={}
always_skills={}
always_chkmj={}
always_watch={}
always_items={}
watch_death={}
de_bug=0
if me==nil then me={} end
me.fjmasternick=""
me.xtbl=0
me.bl=0
mpJobLimited=0
tunanum=0
sheid=1
st=0
rekill=0
killname=""
pfmid=1
wieldweapon=0
getweapon=0
dropweapon=0
gpszeikou=""
gpserrnum=0
flytoareastartid=0
daytime=true
daytimes=2
songjingtime=0
guanyuntime=false
chaobaitime=0
reEnableSkills=0
idle=0
yunbusy=0
killaction=""
nextJobGodazuobase=0
deathroomno=0
deathjob=""
pxj_needget_yyc=0  --pxj是否到顶，要吃阴阳草
yinyangcao_time=1201  --阴阳草采摘时间
yinyangcao_num=0   --身上的阴阳草的数量
wuhuaguo_num=0	   --无花果
kuihuafen_num=0	   --葵花粉

burnnpc={}

wx={
	taiji=0,
	zhixin=0,
}

workflowState={
	attempts=0,		--统计调用alias.startworkflow()函数的次数
	maxAttempts=100,--短时间内调用alias.startworkflow()函数的次数限制，达到后停止工作，防止死机
}	
stat={
	havedu=0,
	--drugbusy=0,
	drugbusy=os.time()+3602,  --上线一小时之内不乱吃药
	cmbuff=os.time()+3602,  --吃冲脉丹的时间
	jinchuangyao=os.time(),
	addexp=0,
	avgall=0,
	avgfj=0,
	avgmp=0,
	avgbeg1=0,
	avgbeg2=0,
	avgftb=0,
	avgyb=0,
	avgwar=0,
	avgdeath=0,
	countdeath=0,
	leidong=0,
	sanhua=0,
	liuhe=0,
	cross=0,
	yixing=0,
	needwar=0,
	need_jinhua=0,
	use_jinhua=false,
	--jianmang=0,
	suxin=0,
	haveyyz=0,
	reverse=0,
	powerup=0,
	quiting=0,
	zixia=0,
	daxiao=0,
	fengyun=0,
	tiandi=0,
	zhixin=0,
	huntianup=0,
	shengang=0,
	xuanyin=0,
	heji=0,
	longxiang=0,
	jingang=0,
	jinzhongzhao=0,
	qiankun=0,
}
count={
	fj=0,
	mp=0,
	ftb=0,
	yb=0,
	death=0,
	lifesave=0,
}
hp={
	thpot=0,
	maxneili=0,
	exp=0,
	maxqi=0,
	water=0,
	jiajin=0,
	jingli=0,
	qi=0,
	neili=0,
	healthqi=0,
	jing=0,
	pot=0,
	healthjing=0,
	maxwater=0,
	food=0,
	maxjing=0,
	maxfood=0,
	maxpot=0,
	maxjingli=0,
}
mark={
	sTime=os.time(),
	setexp=1,
}
jifa={}
list={}
pk={}
add={
	exp=0,
	yudi=0,
}
have={}
have.items=0 --身上物品在总数
have.gold=0
have.silver=0
have.coin=0
have.jian=0
have.xiao=0
have.dao=0
have.dan=0
have.jcy=0
have.fire=0
have.jiudai=0
have.budai=0
have.he=1
have.jinhe=0
have.chain=0
have.armor=1
have.bagua=0
have.ji=0
have.xinfa=1
have.szjing=0
have.jyzj=0
have.cstlnj=0
have.lxj=0
have.staff=0
have.ling=0
have.jinhua=0
have.shengzi=0
have.guaishe=0
have.whip=0
have.club=0
have.yaodai=1
have.fuling=0
have.zhongjian=0
have.xuantiejian=0
have.jingyao=0
have.canye=0
have.stick=0
have.stick_zhu=0
have.stick_tong=0
have.stick_huangzhu=0
have.heshouwu=0
have.yufengjiang=0
have.chuanbei=0
have.shengdi=0
have.jinyinhua=0
have.jugeng=0
have.huanglian=0
have.gouzhizi=0
have.faling=0
have.lubo=0
have.kulouguan=0
have.rentoulian=0
have.lun=0
have.syguan=0
have.bi=0
have.tyl=0
have.xueteng=0
have.danggui=0
have.swjing=0
have.suyouguan=0
have.chaoxue=0 --朝靴
have.toukui=0 --头盔
have.zhangxinding=0 --掌心钉
have.bichuan=0 --□臂钏(Bi chuan)
have.diamondring=0 --钻石戒指
have.diamondnecklace=0 --钻石项链
have.diamondearring=0 --钻石耳环
have.tongmaidan=0 --紫金通脉丹
addneili={
	dahuandan=0,
	putizi=0,
	dazuo=0,
	fj=0,
}
mpLimited={
	type="",
	MarkTime=0,
	MarkExp=0,
	mpexp=0,
	beg1=0, --丐帮统计
	beg2=0, --丐帮统计
	MarkTimebeg1=0,
	MarkTimebeg2=0,
	arrest=0, --大理抓贼统计
	MarkTimearrest=0,
	-- stat=0,
}
skillslist={
	literate={lvl=0,},
	cuff={lvl=0,},
	["kongming-quan"]={lvl=0,},
}
idle_emote={
	"set idle 18mo",
	"set idle accuse",
	"set idle admire2",
	"set idle alien",
	"set idle anniversary",
	"set idle away",
	"set idle boring",
	"set idle breakup",
	"set idle bully",
	"set idle candy2",
	"set idle careful",
	"set idle cool1",
	"set idle corpse'",
	"set idle dontgo",
	"set idle drug",
	"set idle flirt2",
	"set idle followme2",
	"set idle fuze",
	"set idle handkiss2",
	"set idle haose",
	"set idle hate",
	}
---------------check.lua
checki={}
dealwith_bi={}
dealwith_bian={}
dealwith_chain={}
dealwith_dao={}
dealwith_xs={}
dealwith_fuling={}
dealwith_gold={}
dealwith_canye={}
dealwith_jinhua={}
dealwith_gun={}
dealwith_he={}
dealwith_ji={}
dealwith_jian={}
dealwith_jiudai={}
dealwith_sellyao={}
dealwith_shengzi={}
dealwith_staff={}
dealwith_stick={}
dealwith_yaodai={}
dealwith_tyl={}
check_exp={}
check_items={}
-----------------------chongmai.lua
chongmai={}
chongmai_pre={}
chongmai_start={}
chongmai_watch={}

cm={
	mai=0,
	chong=0,
	havebuff=1,
	doing=0,
	mengzhu=0,
	setmz=0,
	fightmz=0,
	mzname="",
	mzdeath=0,
	lifesave=0,
	getdan=0,
}
qugold={
	num=0,
	success=0,
}
----------common.lua
common={}
login={}
login.time=os.time()
accessing=0
conn_count=0
eating={}
checkbusy={}

buyinwan={}
addxyzq={}
xuan={}
bidu={}
cure={}
boat={}
boat_yell={}
dazuo={}
dazuo_resetidle={}
fang={}
liaoshang={}
qudu={}
quit={}
quitdis={}
shizhe={}
tongmai={}
yinyun={}
safego=""
boatDirection="enter"
----------dummy.lua
dm={
	id="",
	place="",
	zeiid="",
	liaoshangtimes=0,
	throwtimes=0,
	lifesavetimes=0,
	saveroom=0
}
keep={}
--------fj.lua
havenot_luohanzhen=0 --默认过了罗汉阵
fjexp=0
havefj=0
fjzone=""
fjroom=""
fjarea=""
fjroomid=0
fj={}
fj_close={}
fj_pre={}
fj_start={}
fj_escape={}
fj_other={}
fj_watch={}
fjfinished=0
if fjwaittime==nil then fjwaittime=0 end
if fjend==nil then fjend=0 end
if gxd.me==nil then gxd.me=0 end
if gxd.mp==nil then gxd.mp=0 end
--------ftb.lua
ftb={}
ftb_pre={}
ftb_ask={}
ftb_start={}
ftb_watch={}
ftbfail_table={}	--存储搜索失败的地点
ftbnpc_table={}		--存储找到的NPC，避免重复ask
ftbarea_table={}	--存储ftb地点，包括“该处靠近”
ftbarea_times=0
ftbsearcherr=0
ftbfail=0
ftbnum=0
ftbareanum=0
ftbroom=""
ftbzone=""
ftbnpcabandon=0
if ftbselectnpc==nil then ftbselectnpc={} end
-------gps.lua
roomno_now=0
gps={}
gps.room_where=false --当处于重复房间时，用周围房间定位的开关
flytoid=0
gps_start={}
gps_watch={}
gps_dealwith={}
gps_99guai={}
gps_climbxy={}
gps_dl_fsg={}
gps_em_killjm={}
gps_lsd_back={}
gps_lsd_go={}
gps_nanyang={}
gps_qzh_mcx={}
gps_qzh_sl={}
gps_qzh_xmdq={}
gps_sgy_sd={}
gps_sl_gate={}
gps_sl_sl={}
gps_slh={}
gps_thd_back={}
gps_thd_go={}
gps_thd_ms={}
gps_thd_sg={}
gps_thd_thl={}
gps_thrownpc={}
gps_waitrelease={}
gps_xxmap={}
gps_xydcy={}
gps_xydcy_sl={}
gps_yz_lts={}
gps_yz_ym={}
gps_yztd_1_2={}
gps_yztd_2_1={}
gps_yztd_2_3={}
gps_yztd_3_2={}
gps_zhou={}
gps_zeikou={}

gps_cmd=""
gps_cmd_dest=nil
gps_cmd_zone=nil
gps_cmd_num=nil
GPS={
	End=true,
}
checkmove={
	NotGPSMove=true,
}
MathstepNum={
	next=0,
}
aliasStepNum={
	turnleft=1,
	enterguan=1,
	gumuenter=1,
	tsthsup=1,
	tsthsdown=1,
	askwangn=3,
	askwangsd=3,
	btssmqy=3,
	byjybykt=3,
	ccdmkz=2,
	clbdmclbdt=3,
	clbxtclbws=3,
	clbydclbss=3,
	dladfxy=2,
	dmkzcc=2,
	emhcazdemhcagc=3,
	emjld99guai=24,
	emqfa99guai=24,
	enterdong=2,
	enterpicture=1,
	fengqy=2,
	findway=2,
	gbkilljian=3,
	gbmdcenter=4,
	gbmddgc=2,
	gbmdemcp=2,
	gbmdqzhtdm=2,
	gbmdsc=2,
	gbmdslcf=2,
	gbmdtdm=2,
	gbmdtfw=3,
	gbmdxssl=2,
	gbqzlgbtdm=8,
	guohe=2,
	gyzguohe=3,
	gyzdmqy=3,
	gyzdmqy2=3,
	hsdlhssy=3,
	hshyhszl=3,
	hslwjggk=2,
	hslwchsbqf=3,
	hslwchskt=3,
	hspthsdlgf=3,
	hspthsqs=3,
	hspthsxlgf=3,
	hsptxy=2,
	hsxlhscf=3,
	hsxslhsxz=3,
	hsxypt=3,
	hylxydsm=13,
	hztyjdmqsl=3,
	kldsmhks=3,
	kljssk=3,
	klmlmsj=3,
	knockqz=3,
	leave9ld=2,
	lmbjxy=3,
	lsddytgk=4,
	lzbmcf=4,
	lzdjjfjjfdy=3,
	movegang=2,
	nantianyuhuang=3,
	nxsback=2,
	nxsjump=2,
	nycjnynm=2,
	followhudie=1,
	greethu=2,
	opendoorup=2,
	opendoordown=3,
	opendooreast=3,
	opendoornorth=3,
	opendoorne=3,
	opendoornw=3,
	opendoorsouth=3,
	opendoorse=3,
	opendoorsw=2,
	opendoorwest=2,
	opengatesouth=2,
	openzhumeneast=3,
	openzhumenwest=3,
	qcqzsm=2,
	qcsdw=4,
	qldtht=3,
	qlmgdcyyc=16,
	qlqtfsd=3,
	qlxtdl=3,
	qlycmgdcy=19,
	qzcjgcjg3l=3,
	qzhmsnt=3,
	qzhntms=3,
	qzjyqc=7,
	qzlcmcx=2,
	qzlsgxm=2,
	qzqcjy=7,
	qzqcxy=7,
	qzsmqc=8,
	qzsmqzqc=2,
	qzsmxy=7,
	qztjqzyxd=3,
	qzxmlsg=2,
	qzxyclimbdown=1,
	qzxyclimbup=1,
	qzxyqc=7,
	sdwqc=4,
	sgysdsgyyd=11,
	sgyydsgymd=3,
	sgyydsgysd=4,
	slcsfzl=3,
	slgatesl=1,
	slgcslsmd=1,
	slhdaslhxa=2,
	slqfdslzl=3,
	slqypslsj=11,
	slssj=3,
	slslslsl=1,
	slsslslqyp=10,
	slzlsldmd=15,
	tgklsddy=5,
	thddms=1,
	thdhtzs=1,
	thdthlxj=1,
	thdthlsc=1,
	thjsslx=2,
	thxzdd=7,
	tsysdxxgg1=1,
	wdhdzlwddxzl=3,
	wdhdzlwdhy=3,
	wdhdzlwdxxzl=3,
	wdxymwdsj=3,
	wdyzgwdbl=3,
	xsclxsdd=3,
	xsjgyxshy=3,
	xssmxsdgc=3,
	xxgg1tsysd=1,
	xxgg1xxgg2=1,
	xxgg2xxgg1=1,
	xxsdxxxyd=3,
	xxyptdmyptdy=3,
	xxyptdtyptms=3,
	xxyptdydyq=3,
	xxysdxxh=3,
	xxysdxxxw=3,
	xyqzsm=6,
	xydcysl=2,
	xydcy1xydcy2=2,
	xydsmhyl=15,
	xydsmsczl=15,
	yellzhou=1,
	ynfslynfxj=3,
	yzhyyzwf=2,
	yzjwslyzjwxf=13,
	yzjwxfyzjwsl=14,
	yzsclknshp=3,
	yztd1yztd2=1,
	yztd2yztd1=1,
	yztd2yztd3=1,
	yztd3yztd2=1,
	yzxlyzxsq=3,
	yzymymzt=2,
	zsthdht=1,
	pressstone=2,
	tangcoffin=1,
	yunbt=0,
	yunem=0,
}
----------gps_lib.lua
yun_check=false
yun_is_ok=true
xkxGPS={
	EntranceCondition="condition is null",
	EndRoomEntrance="",
	EndRoomName="",
	currRoomNo=0,
	guohe_search={},	--用来存储需要过河的房间,
}
Room_table={}	--用来导入房间信息数据库
Entrance_table={} --用来导入房间连接数据库
-------------kill.lua
kill={}
kill_run={}
kill_pfm={}
killid=""
check_battleidle=0
--------michen_alias.lua
alias={}
skillslist={}
master_skillslist={}
avg={}
godie_exp=0
sum={
	fj=0,
	mp=0,
	ftb=0,
	yb=0,
	death=0,
	war=0,
	beg1=0,
	beg2=0,
	xxlingpai=0, --星宿SB给令牌的经验
	arrest=0,
	burnnpc=0, --雪山超度任务
	lifesave=0,
}
avgcount={
	fj=0,
	mp=0,
	ftb=0,
	yb=0,
	death=0,
	lifesave=0,
}
-----michen_config.lua
require "InfoBox"
infobtn={
	win=nil,
}
-----------michen_mp_bt.lua
mp_bt={}
mp_bt_pre={}
mp_bt_start={}
mp_bt_watch={}
xy={}
xy.findxy=0
xy.roomno=0
xy.name=""
xy.id=""
xy.xyLimited=0
xy.limitedResume=0
xy.biteLimited=0
xy.xyexp=0
xy.checkfirstbite=0
xy.npchy=0
----------michen_mp_dl.lua
mp_dl={}
mp_dl_pre={}
mp_dl_watch={}
mp_dl_work={}
mp_dl_start={}
mp_dl_dowork={}

dl.needquit=0
dl.worked=0
dl.zeiid=""
dl.zeiname=""
dl.findzei=0
dl.asknum=1
dl.asknum_now=0
dl.need_qiankun=0
dl.arrest_room=0
dl.reget_zhongjian=0
-------michen_mp_em.lua
mp_em={}
mp_em_pre={}
mp_em_start={}
mp_em_watch={}

if per==nil then per={} end
per.findnpc=0
--------michen_mp_gb.lua
mp_gb={}
mp_gb_watch={}
mp_gb_pre={}
mp_gb_gold={}
mp_gb_gold_fujia={}
mp_gb_gold_owner={}
mp_gb_gold_robber={}
mp_gb_gold_ti={}
gold.num=0
gold.place=""
gold.ip={}
gold.givegold={}
gold.searchTimes=1
gold.a=""
gold.friend={}
gold.block=0
gb={
Limited1=0, --讨饭1任务上限标记
Lted1=0, --讨饭1是否到达过上限标记
Limited2=0, --讨饭2任务上限标记
Lted2=0, --讨饭2是否到达过上限标记
needchongmai=0,
}
fujiaidList="zhang gui|zhang gui|da caizhu|fu jia|gui furen|hao shen|zhubao shang"
fujiaNameList="茶庄掌柜|绸缎庄掌柜|大财主|富贾|贵妇人|豪绅|珠宝商"
goldidList="ma nao|shui jing|yu shi|zhen zhu|zuan shi|fei cui|hetian yu"
goldNameList="玛瑙|水晶|玉石|珍珠|钻石|翡翠|和田玉"

goldqzh={
	roomName="土地庙|土地庙|后渚港|后渚港|港口路|港口路|清净寺|清净寺|学堂|施琅将军府|济世堂老店|城隍庙|阿拉伯宅区|顺济桥|顺济桥|顺济桥|市舶司|市舶司|市舶司|安海港",
	roomNo="80|80|78|78|77|77|48|48|83|84|4|15|47|61|61|61|62|62|62|67",
	askName="小流氓|地痞|水师士兵|挑夫|苦力|日本浪人|回回|回回|欧阳詹|武将|王通治|庙祝|阿拉伯商人|武将|官兵|官兵|武将|官兵|官兵|苦力",
	askid="punk|dipi|shuishi bing|tiao fu|ku li|lang ren|huihui|huihui 2|ouyang zhan|wu jiang|wang tongzhi|miao zhu|alabo shangren|wu jiang|guan bing|guan bing 2|wu jiang|guan bing|guan bing 2|ku li",
}
golddl={
	roomName="北门|北门|北门|北门|定安府|定安府|定安府|法堂|法堂|法堂|药铺|薛记成衣铺|石铺|中心广场|太和居|太和居二楼|太和居二楼|太和居二楼|太和居二楼|王府大门：|王府大门：|王府大门：|王府大门：|前院|前院|前院|玉虚观|客店|五华楼大门|镇雄|下关城|太和城",
	roomNo="171|171|171|285|285|285|292|292|292|282|283|284|208|279|280|280|280|280|177|177|177|177|178|178|178|226|324|313|158|168|293",
	askName="士兵|士兵|士兵|武将|傅思归|副将|副将|段陉|摆夷判官|总管|何红药|薛老板|石匠|江湖艺人|店小二|宋老板|歌女|歌女|歌女|褚万里|锦衣卫士|黄衣卫士|黄衣卫士|崔百泉|小厮子|小厮子|刀白凤|店小二|素衣卫士|牧羊女|台夷商贩|士兵",
	askid="shi bing|shi bing 2|shi bing 3|wu jiang|fu shigui|fu jiang|fu jiang 2|duan xing|pan guan|zong guan|he hongyao|xue laoban|shi jiang|jianghu yiren|xiao er|song laoban|ge nu|ge nu 2|ge nu 3|chu wanli|wei shi|wei shi 2|wei shi 3|cui baiquan|xiao si|xiao si 2|dao baifeng|xiao er|wei shi|muyang nu|shang fan|bing",
}
--大理整理到府衙前厅
goldfs={ --整理完毕
	roomName="戚家大院|戚家大院|麻溪铺|佛山镇街|佛山镇街|英雄会馆|英雄楼|英雄楼|英雄楼|烧饼油条铺|英雄典当|林间道|林间道",
	roomNo="627|627|626|102|100|103|105|106|106|109|111|113|113",
	askName="戚长发|戚芳|潇湘子|女孩|家丁|凤一鸣|凤七|瘦商人|胖商人|王老汉|老朝奉|张朝唐|张康",
	askid="qi changfa|qi fang|xiaoxiang zi|girl|jia ding|feng yiming|feng qi|shou shangren|pang shangren|wang laohan|lao chaofeng|zhang chaotang|zhang kang",
}
goldhz={ --整理完毕
	roomName="青石大道|青石大道|灵隐寺|大雄宝殿|飞来峰|法镜寺|法镜寺|法净寺|法净寺|法喜寺|法喜寺|青石大道|钱塘江畔|牛家村|牛家村|酒店|海堤|海堤|盐田|海神庙|青石大道|青石大道|玉泉书院|青石大道|青石大道|青石大道|宝石山|龙门镖局",
	roomNo="1126|1127|1128|1131|1132|1138|1138|1140|1140|1142|1142|1156|1158|1277|1277|1278|1264|1264|1265|1266|1169|1169|1171|1202|1202|1201|1212|1247",
	askName="帮众|帮众|知客僧|枯木禅师|帮众|小沙弥|进香客|小沙弥|进香客|老和尚|进香客|挑夫|剑客|杨铁心|郭啸天|曲三|塘工|塘工|海沙派盐枭|天鹰教众|挑夫|刀客|顾炎武|趟子手|帮众|帮众|帮众|都大锦",
	askid="bangzhong|bangzhong|zhike seng|kumu chanshi|bangzhong|shami|jinxiang ke|shami|jinxiang ke|seng ren|jinxiang ke|tiao fu|jian ke|yang tiexin|guo xiaotian|qu san|tanggong|tanggong 2|yanxiao|jiaozhong|tiao fu|dao ke|gu yanwu|tangzi shou|bangzhong|bangzhong|bangzhong|du dajin",
}
--[[
goldhz={
	roomName="玉泉书院|青石大道|青石大道|青石大道|聚景园|大雄宝殿|法镜寺|山路|铁匠铺|楼外楼|天外天客店|钱塘江畔|牛家村|酒店",
	roomNo="1171|1169|1169|1185|1194|1131|1138|1144|1256|1255|1257|1158|1277|1278",
	askName="顾炎武|挑夫|刀客|刀客|剑客|枯木禅师|小沙弥|采茶女|欧冶子|店小二|店小二|剑客|郭啸天|曲三",
	askid="gu yanwu|tiao fu|dao ke|dao ke|jian ke|kumu|shami|girl|ou yezi|xiao er|xiao er|jian ke|guo xiaotian|qu san",
}]]
------michen_mp_gm.lua
mp_gm={}
mp_gm_pre={}
mp_gm_caimi={}
mp_gm_caimi_t={}
mp_gm_watch={}
mp_gm_job3={}

caimicmd=""
gmjob3time=os.time()
gm_exits=""
gm_exitlist={}
love_enter=""
npcinfo={
	name="",
	id="",
}
havejob3=0
-------michen_mp_hs.lua
mp_hs={}
mp_hs_pre={}
mp_hs_watch={}
mp_hs_start={}

mmr={
	searchlist="s|w|s|s|e|n|ne|se|sw|n|w|n",
	searchroomno="2010|2011|2012|2013|2014|2015|2016|2018|2017|2016|2010|841",
	searchid=3,
	findmmr=0,
	name="",
	id="",
	targetNum=3,
	havenum=1,
	oneexp=149,
	corpseid=-1,
	err=0,
	givenum=0,
}
------michen_mp_mj.lua
mp_mj={}
mp_mj_pre={}
mp_mj_yudi={}
mp_mj_wxq={}
mp_mj_wxqjob={}
mp_mj_tyjob={}
mp_mj_watch={}

mj.haveyd=0
mj.yd_start=0
mj.yd_gap=0
mj.yd1="s|w|nw|wu|sw|se|sd|s|sw|sd|s|sd|sd|se|se|sd|sd|nu|nu|nw|nw|nu|nu|n|nu|nw|n|ne"
mj.yd2="s|w|nw|wu|sw|se|sd|s|sw|sd|s|sd|sd|se|se|nw|nw|nu|wu|w|e|ed|eu|ne|sw|wd|nu|n|nu|nw|n|ne|u|e|w|w|e|nu|w|e|nu|ne|sw|nw|se|nu|se|nw|nw|se|sw|ne|ne|sw|nu|e|s|n|n|s|w|w|s|n|n|s|e|enter|w|n|w"
mj.search=""
mj.searchid=1
mj.err=0
mj.ydnpc=0
mj._ydtp=1900
mj.killid=""
mj.joblist=""
mj.rekill=0
mj.killlist={}
if mj.ydnpckilled==nil then mj.ydnpckilled=0 end

mj.tyjobnpc=""
mj.tyjobnpcid=""
mj.lvl=1
-----michen_mp_qz.lua
mp_qz={}
mp_qz_pre={}
mp_qz_watch={}
mp_qz_start={}
mp_qz_boyao={}
mp_qz_boyao_ti={}

bdz={
	askqiu=0,
	askzhao=0,
	doing=0,
}
qzjob=""
yaoname=""
mpjobLimited_pre=0
--me.quit=1
-------------michen_mp_sl.lua
mp_sl={}
mp_sl_pre={}
mp_sl_start={}
mp_sl_watch={}

fs={
	searchid=5,
	findseng=0,
	searchstep=1,
	searchlist="west|southdown|southdown|southdown|eastdown|southdown|southdown|east",
}
----------michen_mp_th.lua
mp_th={}
mp_th_pre={}
mp_th_start={}
mp_th_watch={}

--havedo=0
yp={
	findyp=0,
	searchjs=0,
	roomnolist="",
	roomnum=1,
	roomno=0,
	name="",
	id="",
	place="",
	goto=0,
	runfail=0,
	refind=0,
	stay_room=0,
	jiading_follow=1,
	npccount=1,  --寻找yapu npc时，用来计数当前房间有多少个重名NPC
	rencount=1, --ren npc计数
	killed=0, --击杀标记
}
-------michen_mp_wd.lua
mp_wd={}
mp_wd_pre={}
mp_wd_start={}
mp_wd_watch={}
-------michen_mp_xs.lua
mp_xs={}
mp_xs_pre={}
mp_xs_npc1={}
mp_xs_npc2={}
mp_xs_start={}
mp_xs_watch={}
mp_xs_lzjob={}
me.suyou=0
mp_xs_start.givecorpse=0
mp_xs_start.fight=0
mp_xs_start.startburn=0
mp_xs_start.waitgive=""

if lzjob==nil then lzjob={} end
lzjob.name=""
lzjob.area=""

burnnpc={
	no=1,
	nl="小姗",
	rl="1026",
	room=0,
	name="",
	id="",
	--corpse=0
}
---------michen_mp_xx.lua
mp_xx={}
mp_xx_pre={}
mp_xx_start={}
mp_xx_watch={}
mp_xx_pre_sandu={}
mp_xx_pre_suck={}
mp_xx_start_catch={}
mp_xx_start_sandu={}
mp_xx_start_search={}
mp_xx_xiulian={}
mp_xx_kmmr={}
suckLimited=0 --化功大法经验上限标记

xx={
	needsandu=0,
	suck=0,
	sucknow=1,
	suckid="",
	suckname="",
	suckroom=0,
	npcname="",
	npcid="",
	bugout=0,
	bugname="",
	bugid="",
	havebug=0,
	lingpaierr=0,
	havelingpai=0,
	gived=0,
}
mmr={
	searchlist="s|w|s|s|e|n|ne|se|sw|n|w|n",
	searchroomno="2010|2011|2012|2013|2014|2015|2016|2018|2017|2016|2010|841",
	searchid=3,
	findmmr=0,
	name="",
	id="",
	targetNum=30,
	havenum=1,
	oneexp=149,
	corpseid=-1,
	err=0,
	givenum=0,
}
xxsuck_list={}
table.insert(xxsuck_list,{suckid="haoshou",suckname="星宿派号手",suckroom=1437})
table.insert(xxsuck_list,{suckid="gushou",suckname="星宿派鼓手",suckroom=1437})
table.insert(xxsuck_list,{suckid="boshou",suckname="星宿派钹手",suckroom=1437})
table.insert(xxsuck_list,{suckid="haoshou",suckname="星宿派号手",suckroom=1435})
table.insert(xxsuck_list,{suckid="gushou",suckname="星宿派鼓手",suckroom=1435})
table.insert(xxsuck_list,{suckid="boshou",suckname="星宿派钹手",suckroom=1435})
table.insert(xxsuck_list,{suckid="haoshou",suckname="星宿派号手",suckroom=1444})
table.insert(xxsuck_list,{suckid="gushou",suckname="星宿派鼓手",suckroom=1444})
table.insert(xxsuck_list,{suckid="boshou",suckname="星宿派钹手",suckroom=1444})
table.insert(xxsuck_list,{suckid="haoshou",suckname="星宿派号手",suckroom=1440})
table.insert(xxsuck_list,{suckid="gushou",suckname="星宿派鼓手",suckroom=1440})
table.insert(xxsuck_list,{suckid="boshou",suckname="星宿派钹手",suckroom=1440})
table.insert(xxsuck_list,{suckid="haoshou",suckname="星宿派号手",suckroom=1441})
table.insert(xxsuck_list,{suckid="gushou",suckname="星宿派鼓手",suckroom=1441})
table.insert(xxsuck_list,{suckid="boshou",suckname="星宿派钹手",suckroom=1441})
table.insert(xxsuck_list,{suckid="boshou",suckname="星宿派钹手",suckroom=1329})
table.insert(xxsuck_list,{suckid="hazakh",suckname="哈萨克",suckroom=1328})
table.insert(xxsuck_list,{suckid="binu",suckname="婢女",suckroom=1327})
table.insert(xxsuck_list,{suckid="woman",suckname="维吾尔族妇女",suckroom=1333})
table.insert(xxsuck_list,{suckid="kid",suckname="小孩",suckroom=1336})
table.insert(xxsuck_list,{suckid="hu",suckname="胡老爷",suckroom=1336})
--table.insert(xxsuck_list,{suckid="li",suckname="李文秀",suckroom=1335})
table.insert(xxsuck_list,{suckid="girl",suckname="锡伯少女",suckroom=1447})
table.insert(xxsuck_list,{suckid="girl",suckname="锡伯少女",suckroom=1447})
table.insert(xxsuck_list,{suckid="sheng",suckname="书生",suckroom=1376})
table.insert(xxsuck_list,{suckid="daotong",suckname="道童",suckroom=1376})
table.insert(xxsuck_list,{suckid="lama",suckname="小喇嘛",suckroom=1376})
table.insert(xxsuck_list,{suckid="ke",suckname="刀客",suckroom=1373})
table.insert(xxsuck_list,{suckid="boy",suckname="牧童",suckroom=939})
table.insert(xxsuck_list,{suckid="boy",suckname="牧童",suckroom=939})
table.insert(xxsuck_list,{suckid="girl",suckname="女孩",suckroom=820})
table.insert(xxsuck_list,{suckid="boy",suckname="男孩",suckroom=820})
table.insert(xxsuck_list,{suckid="man",suckname="穷汉",suckroom=827})
table.insert(xxsuck_list,{suckid="girl",suckname="女孩",suckroom=832})
table.insert(xxsuck_list,{suckid="kid",suckname="小孩",suckroom=813})
table.insert(xxsuck_list,{suckid="kid",suckname="小孩",suckroom=813})
table.insert(xxsuck_list,{suckid="boy",suckname="男孩",suckroom=838})
-----michen_system.lua
require "tprint"
require "wait"
--cmd={
--	nums=0,
--	setnums=20,
--}
------michen_yb.lua
michen_yb={}
michen_yb_pre={}
michen_yb_start={}
michen_yb_watch={}
--setybjob=1
ybLimited=0						-- exp上限与否
ybLimitedMarkTime=0				-- exp上限时间
ybexp=0							-- yb累积exp
function set_yb()
	ybjob={
		ybstatus=0,						-- 运镖状态：1=去取货，2=送货，3=返回
		ybnpcname="",					-- 目标NPC的名字
		ybnpcid="",						-- 目标NPC的ID
		ybroomno=0,						-- 目标房间ID
		ybpath="",						-- 运镖的路径
		ybpathnum=0,					-- 运镖要走的步数
		ybpathnow=1,					-- 当前走到的步数
		ybfx="",						-- 当前要走的方向
		ganche=0,						-- 是否在赶车
		ybfight=0,						-- 是否在战斗中
		needfangqi=0,					-- 是否需要放弃任务
		ybroom=0,						-- 当前走到的房间
		err=0,							-- 车子行走错误，重新定位，寻找路径
		yxnpc="",						-- yun yixing
		yxanimal="",					-- yun yixing
		biaohuo=0,
		ssyb="",
		killlist={},
		waitlimit=0,
		haveyixing=0,				-- 是否有移行buff
		waitnpc=0,
		arrive=0,
		gosaferoom=false,				-- 在去往安全房间停放镖车
	}
end
set_yb()
------qzwd.lua
qzwd={}
qzwd.havezhu=0
qzwd_pre={}
qzwd_start={}
qzwd_watch={}
btxg_attack="|蒙面人|胡人|无量剑弟子|维吾尔族妇女|官兵|帮众|「三头蛟」侯通海|素衣卫士|天鹰教众|海沙派盐枭|无量剑弟子|武馆门丁|武馆学徒|巨人|僧人|武将|采茶女|婢女|歌女|小丫鬟|丫鬟|牧羊人|摆夷女子|旅人|仆人|艺人|商人|小孩|弟子|牧童|男孩|女孩|小男孩|小女孩|回回|侍者|卫士|塘工|刀客|剑客|进香客|樵夫|挑夫|书生|学徒|门丁|小贩|皮货商|西夏兵|武士|小厮子|江湖术士|马五德|胡老爷|教众|流氓|趟子手|张康|庄允城|贾人达|善勇|戚芳|马光佐|高三娘子|范一飞|吕正平|风良|李斧头|邱山风|贝海石|江上游|郭啸天|"
btxg_kill="|小猴子|猴子|老猴子|大马猴|野兔|大狗熊|黑熊|白熊|母狼|小豹子|狐狸|獐子|老虎|山老虎|东北虎|狼|秃鹰|乌鸦|鸭子|斑鸠|麻雀|蜜蜂|小蜜蜂|蜈蚣|苍蝇|毒蛛|沙虫|蝎子|毒蜘蛛|毒蜂|骆驼|白骆驼|矮脚马|白马|川马|大青马|小毛驴|贡马|黑马|红马|黄骠马|骝马|蒙古马|三河马|小马驹|小红马|伊犁马|枣红马|水牛|大黄牛|梅花鹿|野狗|黄羊|山羊|老山羊|野兔|老鼠|小猪|绵羊|大狼狗|"
pobi=0
zhizhunum=1
-----skills.lua
skills={}
skills_xue_cls={}
--skills_ask={}
skills_lian={}
skills_lingwu_cls={}
skills_jingyao={}
if me==nil then me={} end
me.master=""
me.masterid="" 
me.litmaster="" 
me.litmasterid="" 
me.litmasterroom=1020 
me.shijian=0
if me.menpai=="gm" and guanmotime==nil then guanmotime=os.time() end
skillsfull=0 
skills_num=1 
weapon_id=1 
guanmotime=0 
----war.lua
--war={}
war.teamwith={} --自动组队war 成员列表
war.have_vip=0 --队伍中大号的数量，用于参考调整大号数量，避免exp溢出
war.have_vvip=0 --队伍中自己的大号ID数量，用于决断大米是否自动发起war
war.people_dead=0 --本次战斗平民伤亡，超过14会失败
war.checkAward=0 --war奖励检测，出击城外蒙古大营后激活，用于判断是否有人抢开导致失去奖励
war.taishouDead=0 --太守被玩家杀死

WarLimited=0			-- 本周期War获得的exp上限与否
WarLimitedMarkTime=0	-- 本周期第一次War获得exp的标记时间
WarExp=0				-- 本周期War累积Exp
WarTotalExp=0			-- 当天0：00开始，War取得的总Exp
war_pre={}
war_start={}
war_restart={}

--war.place=="东、南、西、北、城内（不守门）、上墙（守门）"
war.path={"e|n|s|s|s|n|n|e|n|s|s|n|e|n|s|s|n|e|su|s|s|u|d|w|nw|sw|wd|n|n|n|n", 
"s|e|w|w|w|e|e|s|e|e|w|w|w|w|w|e|e|e|s|w|e|e|e|s|enter|out|n|w|w|s|wu|nw|sw|w|u|d|n|n|nd|e|e|e|e", 
"w|s|sw|ne|n|w|n|s|s|s|s|n|n|n|w|n|s|s|n|w|nu|n|n|u|d|e|se|ne|ed|s|s|s|s", 
"n|e|w|n|w|e|n|e|w|w|w|w|e|e|e|n|eu|se|ne|e|u|d|s|s|sd|w|w|w|w", 
"e|n|s|s|n|e|n|s|s|n|e|n|s|s|n|w|w|w|s|e|w|w|e|s|e|w|w|e|s|w|e|e|e|s|enter|out|n|w|w|n|n|n|w|s|n|w|n|s|s|n|w|n|s|s|n|e|e|e|n|e|w|n|w|e|n|e|w|w|e",
"e|e|e|e|su|s|s|u|d|w|nw|sw|wd|wu|nw|sw|w|u|d|n|n|nd|nu|n|n|u|d|e|se|ne|ed|eu|se|ne|e|u|d|s|s|sd",
}
if war.place=="东" then	war.path_no=1 
elseif war.place=="南" then	war.path_no=2
elseif war.place=="西" then	war.path_no=3
elseif war.place=="北" then	war.path_no=4
elseif war.place=="城内" then war.path_no=5
else war.path_no=6 end

--[[
if war.place=="东" then	war.path="e|n|s|s|s|n|n|e|n|s|s|n|e|n|s|s|n|e|su|s|s|u|d|w|nw|sw|wd|n|n|n|n" 
elseif war.place=="南" then	war.path="s|e|w|w|w|e|e|s|e|e|w|w|w|w|w|e|e|e|s|w|e|e|e|s|enter|out|n|w|w|s|wu|nw|sw|w|u|d|n|n|nd|e|e|e|e" 
elseif war.place=="西" then	war.path="w|s|sw|ne|n|w|n|s|s|s|s|n|n|n|w|n|s|s|n|w|nu|n|n|u|d|e|se|ne|ed|s|s|s|s" 
elseif war.place=="北" then	war.path="n|e|w|n|w|e|n|e|w|w|w|w|e|e|e|n|eu|se|ne|e|u|d|s|s|sd|w|w|w|w" 
elseif war.place=="城内" then war.path="e|n|s|s|n|e|n|s|s|n|e|n|s|s|n|w|w|w|s|e|w|w|e|s|e|w|w|e|s|w|e|e|e|s|enter|out|n|w|w|n|n|n|w|s|n|w|n|s|s|n|w|n|s|s|n|e|e|e|n|e|w|n|w|e|n|e|w|w|e" 
else war.path="e|e|e|e|su|s|s|u|d|w|nw|sw|wd|wu|nw|sw|w|u|d|n|n|nd|nu|n|n|u|d|e|se|ne|ed|eu|se|ne|e|u|d|s|s|sd" end
]]
function war_update_var()
war.pathys_vip="n|n|n|nw|n|ne"
    war.pathys="n|n|n|ne|n|nw"
war.pathid=1
war.err=0
war.npc=0
war.see_marshal=0
war.waring=0
war.late=0
end
war_update_var()
war.ready=os.time()
-----xinfa.lua
xinfa={}
xf_hs={}
xf_em={}
xf_em_resetidle={}
xf_sl={}
sl_sj={}
sl_zc={}
xf_wd={}
wd_xtjf={}
wd_xtjf_fight={}
xf_mj={}
xf_mj_fight={}
mj_shl={}
mj_shl_fight={}

zuochan=0
zuochan_checkchui=0
zuochan_time=0
---------------------basic_skills.lua
basic_skills={}
