
function mpLimited.stat() --hs专用
	if os.time()>tonumber(mpLimited.MarkTime)+3600 or tonumber(mpLimited.mpexp)<tonumber(mpLimited.MarkExp) then
		return 0
	else
		return 1
	end
end
-- 判断是否需要执行御敌任务
function mj_need_yudi()
    -- 快速失败：不满足基本条件时立即返回
    if me.menpai ~= "mj" then
        return false
    end
    
    -- 检查任务相关条件
    local do_mp_job = workflow.mp > 0
    local do_yudi_job = mj.yudi > 0
    local yudi_job_avalible = mj.haveyd > 0
    local yudi_job_limited = mpJobLimited == 0
    
    -- 所有条件必须同时满足
    return do_mp_job 
           and do_yudi_job 
           and yudi_job_avalible
           and yudi_job_limited
end
------------------------------------------------------------------------------------
-- 根据时间段，决定是否去太守府参加war
------------------------------------------------------------------------------------
function stat.needwar()
    -- 如果模式是"once"且经验超过1000，每天只执行一次
    if war.mod == "once" and WarTotalExp > 1000 then
        return false
    end
    
    -- 检查是否过了准备时间
    if os.time() <= war.ready then
        return false
    end
    
    -- dummy模式随时可执行
    if war.mod == "dummy" then
        return true
    end
    
    -- vip模式检查时间窗口,0:00-1:00如果被卡掉了就上不来了
    if war.mod == "vip" or war.mod == "once" then
        return isInQuitTimeWindow()
    end
    
    return false
end

-- 辅助函数：检查当前时间是否在Quit时间窗口内
function isInQuitTimeWindow()
    local current_hour = tonumber(os.date("%H"))
    local current_minute = tonumber(os.date("%M"))
    
    -- 1:00到22:59之间
    if current_hour >= 1 and current_hour <= 22 then
        return true
    end
    
    -- 23:00到23:50之间
    if current_hour == 23 and current_minute < 50 then
        return true
    end
    
    return false
end
------------------------------------------------------------------------------------
-- always_daytime
------------------------------------------------------------------------------------
function always_daytime.dosomething1(n,l,w,s)
	local col=string.find(l,w[1])
	if not col then
		print("[::always_daytime.dosomething1::]::颜色抓取失败::")
		return
	end
	style=GetStyle(s,col)
	local color=RGBColourToName(style.textcolour)
	if color=="silver" and style["backcolor"]==0 then return end
	if findstring(l,"太阳从东方的地平线升起了。","太阳刚从东方的地平线升起") then
		daytime=true;songjingtime=0;guanyuntime=true;chaobaitime=1
	elseif findstring(l,"已经是午夜了。","夜晚降临了。","夜幕低垂，满天繁星","夜幕笼罩著大地","一轮火红的夕阳正徘徊在西方的地平线上") then
		daytime=false;songjingtime=0;guanyuntime=false;chaobaitime=0
	elseif findstring(l,"傍晚了，太阳的馀晖将西方的天空映成一片火红。","东方的天空中开始出现一丝微曦。","已经是正午了，太阳从你正上方照耀著大地。","太阳开始从西方的天空中慢慢西沉。","太阳正高挂在东方的天空中","太阳正高挂在西方的天空中","现在是正午时分，太阳高挂在你的头顶正上方") then
		daytime=true;songjingtime=0;guanyuntime=false;chaobaitime=1
	elseif findstring(l,"东方的天空已逐渐发白","东方的天空中开始出现一丝微曦。") then
		daytime=true;songjingtime=1;guanyuntime=false;chaobaitime=0
	end
	if findstring(l,"东方的天空已逐渐发白","东方的天空中开始出现一丝微曦。") then daytimes=1
	elseif findstring(l,"太阳从东方的地平线升起了。","太阳刚从东方的地平线升起") then daytimes=2
	elseif findstring(l,"太阳正高挂在东方的天空中") then daytimes=3
	elseif findstring(l,"现在是正午时分，太阳高挂在你的头顶正上方","已经是正午了，太阳从你正上方照耀著大地。") then daytimes=4
	elseif findstring(l,"太阳正高挂在西方的天空中","太阳开始从西方的天空中慢慢西沉。") then daytimes=5
	elseif findstring(l,"一轮火红的夕阳正徘徊在西方的地平线上","傍晚了，太阳的馀晖将西方的天空映成一片火红。") then daytimes=6
	elseif findstring(l,"已经是午夜了。","夜晚降临了。","夜幕低垂，满天繁星","夜幕笼罩著大地") then daytimes=0
	end
end
------------------------------------------------------------------------------------
-- always_hp
------------------------------------------------------------------------------------
function always_hp.dosomething1(n,l,w)
	me["expadd"]=tonumber(w[1])
end
function always_hp.dosomething2(n,l,w)
	me["gold"]=ctonum(w[1])
	if skillslist["literate"]==nil then skillslist["literate"]={} end
	if skillslist["literate"]["lvl"]==nil then skillslist["literate"]["lvl"]=1 end
	if ((me["gold"]>100 and skillslist["literate"]["lvl"]>99 and skillslist["literate"]["lvl"]<500) or (me["gold"]>10 and skillslist["literate"]["lvl"]<100)) and wantxuelit<3 then xuelit=1 else xuelit=0 end
end
function always_items.dosomething1(n,l,w)		
	a,b,_t=string.find(l, "%s*(%S+)棵阴阳草%(Yinyang cao%)")
	if _t~=nil then
		yinyangcao_num=ctonum(_t)
		return
	end
	a,b,_t=string.find(l, "%s*(%S+)钱无花果%(Wuhua guo%)")
	if _t~=nil then
		wuhuaguo_num=ctonum(_t)
		return
	end	
	a,b,_t=string.find(l, "%s*(%S+)钱葵花粉%(Kuihua fen%)")
	if _t~=nil then
		kuihuafen_num=ctonum(_t)
	return
	end	
end
function always_hp.dosomething3(n,l,w)
	me["gold"]=0
	xuelit=0
end
function always_hp.dosomething4(n,l,w)
	hp["jing"]=tonumber(w[2])
	hp["maxjing"]=tonumber(w[3])
	hp["healthjing"]=tonumber(w[4])
	hp["jingli"]=tonumber(w[5])
	hp["maxjingli"]=tonumber(w[6])
	hp["jiajin"]=tonumber(w[7])
end
function always_hp.dosomething5(n,l,w)
	hp["qi"]=tonumber(w[1])
	hp["maxqi"]=tonumber(w[2])
	hp["healthqi"]=tonumber(w[3])
	hp["neili"]=tonumber(w[4])
	hp["maxneili"]=tonumber(w[5])
	hp["jiali"]=tonumber(w[6])
end
function always_hp.dosomething6(n,l,w)
	hp["food"]=tonumber(w[1])
	hp["maxfood"]=tonumber(w[2])
	hp["pot"]=tonumber(w[3])
	hp["maxpot"]=tonumber(w[4])
	if mark["setpot"] then
		mark["pot"]=hp["pot"]
		mark["setpot"]=0
	end
end
function always_hp.dosomething7(n,l,w)
	hp["water"]=tonumber(w[1])
	hp["maxwater"]=tonumber(w[2])
	hp["exp"]=tonumber(w[3])
	if hp["exp"]~=nil and hp["exp"]>=0 then 
	    me["maxlvl"]=math.floor(math.floor((hp["exp"]*10)^(1/3) * 10)/10) 
	end
	if mark["setexp"]>0 then
		mark["exp"]=hp["exp"]
		mark["setexp"]=0
	end  
	if do_dl_job==1 and (hp.exp<30000 or hp.exp>3000000) then do_dl_job=0 end
	if win_title~=nil then
		hp_draw_win()
	end
end
function always_hp.dosomething8(n,l,w)
	me["shen"]=tonumber(w[2])
	setybjob="lin zhennan"
	--if me["shen"]>=0 then setybjob="lin zhennan" else setybjob="zhen xibei" end
end
function always_hp.dosomething9(n,l,w)
	me["menpai"]="none"
	xkxGPS.setEntranceCondition("condition is null")
	if string.find(w[1],"古墓派") then
		me["menpai"]="gm"
		me["fjmaster"]=""
		me["fjmasternick"]="你大爷"
		me["fjmasterid"]=""
		me["fjbaseid"]=0
		me["fjnpcname"]=""
		me["fjnpcid"]=""
		me["menpailingwuid"]=2065
		me["menpaiJobStart"]=2076
		me["menpaiLimited"]=4000
		me["dazuobaseid"]=2077
		me["chongmaiBaseid"]=2077
		me["jingyaoBaseid"]=2077
		me["kitchen"]=0 --厨房吃喝的地方
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"大理段家") then
		me["menpai"]="dl"
		me["fjmaster"]="段正淳"
		me["fjmasternick"]="段王爷"
		me["fjmasterid"]="duan zhengchun"
		me["fjbaseid"]=191
		me["fjnpcname"]="强盗"
		me["fjnpcid"]="qiang dao"
		me["menpailingwuid"]=191
		me["menpaiJobStart"]=286
		me["menpaiLimited"]=7000
		me["dazuobaseid"]=0
		me["chongmaiBaseid"]=1422
		me["jingyaoBaseid"]=191
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"全真教") then
		me["menpai"]="qz"
		me["fjmaster"]="马钰"
		me["fjmasternick"]="掌教马钰"
		me["fjmasterid"]="ma yu"
		me["fjbaseid"]=792
		me["fjnpcname"]="魔教弟子"
		me["fjnpcid"]="mojiao"
		me["menpailingwuid"]=808
		me["menpaiJobStart"]=782
		me["menpaiLimited"]=6000
		me["dazuobaseid"]=785
		me["chongmaiBaseid"]=785
		me["jingyaoBaseid"]=0
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong' or condition='qz') and id<>3247") else xkxGPS.setEntranceCondition("(condition is null or condition='qz')") end
	end
	if string.find(w[1],"武当派") then
		me["menpai"]="wd"
		me["fjmaster"]="张三丰"
		me["fjmasternick"]="掌门人张真人"
		me["fjmasterid"]="zhang sanfeng"
		me["fjbaseid"]=677
		me["fjnpcname"]="蒙古哒子"
		me["fjnpcid"]="dazi"
		me["menpailingwuid"]=687
		me["menpaiJobStart"]=705
		me["menpaiLimited"]=5000
		me["dazuobaseid"]=678
		me["chongmaiBaseid"]=677
		me["jingyaoBaseid"]=678
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"少林派") then
		me["menpai"]="sl"
		me["fjmaster"]="玄慈大师"
		me["fjmasternick"]="玄慈方丈"
		me["fjmasterid"]="xuanci dashi"
		me["fjbaseid"]=1651
		me["fjnpcname"]="强盗"
		me["fjnpcid"]="qiang dao"
		me["menpailingwuid"]=1653
		me["menpaiJobStart"]=1553
		me["menpaiLimited"]=4000
		me["dazuobaseid"]=0
		me["chongmaiBaseid"]=1422
		me["jingyaoBaseid"]=0
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"桃花岛") then
		me["menpai"]="th"
		me["fjmaster"]="陆乘风"
		me["fjmasternick"]="庄主"
		me["fjmasterid"]="lu chengfeng"
		me["fjbaseid"]=1470
		me["fjnpcname"]="强盗"
		me["fjnpcid"]="qiang dao"
		me["menpailingwuid"]=1653
		me["menpaiJobStart"]=1470
		me["menpaiLimited"]=7000
		me["dazuobaseid"]=0
		me["chongmaiBaseid"]=1470
		me["jingyaoBaseid"]=0
		if set_GbSecretWay>0 then 
			if fjroomid==0 and yp.goto>0 then 
				xkxGPS.setEntranceCondition("condition is null")
			else
				xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") 
			end
		end
	end
	if string.find(w[1],"峨嵋派") then
		me["menpai"]="em"
		me["fjmaster"]="灭绝师太"
		me["fjmasternick"]="掌门灭绝师太"
		me["fjmasterid"]="miejue shitai"
		me["fjbaseid"]=372
		me["fjnpcname"]="魔教弟子"
		me["fjnpcid"]="mojiao"
		me["menpailingwuid"]=378
		me["menpaiJobStart"]=per.roomno
		me["menpaiLimited"]=5000
		me["dazuobaseid"]=2052
		me["chongmaiBaseid"]=2052
		--me["jingyaoBaseid"]=2055 --周芷若处，防beg、steal
		me["jingyaoBaseid"]=372 --灭绝师太处
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"华山派") then
		me["menpai"]="hs"
		me["fjmaster"]="岳不群"
		me["fjmasternick"]="岳掌门"
		me["fjmasterid"]="yue buqun"
		me["fjbaseid"]=874
		me["fjnpcname"]="强盗"
		me["fjnpcid"]="qiang dao"
		me["menpailingwuid"]=2019
		me["menpaiJobStart"]=841
		me["menpaiLimited"]=5000
		me["dazuobaseid"]=0
		me["chongmaiBaseid"]=1422
		me["jingyaoBaseid"]=0
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"星宿派") then
		me["menpai"]="xx"
		me["fjmaster"]="丁春秋"
		me["fjmasternick"]="星宿老仙"
		me["fjmasterid"]="ding chunqiu"
		me["fjbaseid"]=1442
		me["fjnpcname"]="江湖侠士"
		me["fjnpcid"]="xiashi"
		me["menpailingwuid"]=2112
		me["menpaiJobStart"]=1442
		me["menpaiLimited"]=6000
		me["dazuobaseid"]=1442
		me["chongmaiBaseid"]=1442
		me["jingyaoBaseid"]=2111
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"白驼山") then
		me["menpai"]="bt"
		me["fjmaster"]="欧阳锋"
		me["fjmasternick"]="欧阳主人"
		me["fjmasterid"]="ouyang feng"
		me["fjbaseid"]=1801
		me["fjnpcname"]="江湖侠士"
		me["fjnpcid"]="xiashi"
		me["menpailingwuid"]=2026
		me["menpaiJobStart"]=1801
		me["menpaiLimited"]=8000
		me["dazuobaseid"]=1801
		me["chongmaiBaseid"]=1801
		me["jingyaoBaseid"]=2026
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"明教") then
		me["menpai"]="mj"
		me["fjmaster"]="杨逍"
		me["fjmasternick"]="光明左使杨逍"
		me["fjmasterid"]="yang xiao"
		me["fjbaseid"]=573
		me["fjnpcname"]="江湖侠士"
		me["fjnpcid"]="xiashi"
		me["menpailingwuid"]=1972
		me["menpaiJobStart"]=573
		me["menpaiLimited"]=13000
		me["dazuobaseid"]=596
		me["chongmaiBaseid"]=596
		me["jingyaoBaseid"]=596
		if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
	end
	if string.find(w[1],"雪山派") or string.find(w[1],"血刀门") or string.find(w[1],"密宗") then
		me["menpai"]="xs"
		me["fjmaster"]="鸠摩智"
		me["fjmasternick"]="大轮明王鸠摩智"
		me["fjmasterid"]="jiumozhi"
		me["fjbaseid"]=436
		me["fjnpcname"]="强盗"
		me["fjnpcid"]="qiang dao"
		me["menpailingwuid"]=1853
		me["menpaiJobStart"]=428
		me["menpaiLimited"]=7000
		me["burnLimited"]=7000
		me["dazuobaseid"]=1853
		me["chongmaiBaseid"]=1853
		me["jingyaoBaseid"]=1853
		if skillslist["lamaism"]~=nil and skillslist["lamaism"]["lvl"]>=150 then 
			if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong' or condition='xs') and id<>3247") end
		else
			if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
		end
	--end
	--if string.find(w[1],"密宗") then 
	--	me["menpai"]="xs" 
	end
	if string.find(w[1],"丐帮") then
		me["menpai"]="gb"
		me["fjmaster"]="洪七公"
		me["fjmasternick"]="洪帮主"
		me["fjmasterid"]="hong qigong"
		me["fjbaseid"]=1121
		me["fjnpcname"]="强盗"
		me["fjnpcid"]="qiang dao"
		me["menpailingwuid"]=1653
		me["menpaiJobStart"]=1116
		me["menpaiLimited"]=15000
		me["dazuobaseid"]=0
		me["chongmaiBaseid"]=2033
		me["jingyaoBaseid"]=0
		xkxGPS.setEntranceCondition("(condition is null or condition='gb' or condition='dong') and id<>3247 and id<>3248")
	end
	--if setting=="dm" then me["menpai"]="dm"
	--else
	--if setting=="keep" then me["menpai"]="keep" 
	--end
	if me["menpai"]=="xs" then mpdrutime=10 
	elseif me["menpai"]=="dl" or do_dl_job==1 then mpdrutime=0
	elseif me["menpai"]=="qz" or me["menpai"]=="th" then mpdrutime=30
	else mpdrutime=0 
	end
	if cm.mengzhu~=nil and cm.mengzhu>0 then me["chongmaiBaseid"]=2059 end
end
function always_hp.dosomething10(n,l,w)
	if me["master"]~=w[1] then me.masterid="" end
	me["master"]=w[1]
	--me.masterid=""
	me["masterroom"]=""
	if me["menpai"]=="mj" then me["master"]=mj.master end
	--if string.find(me["master"],"自学贯通") then me["masterid"]="" end
	if string.find(me["master"],"觉心") then me["masterid"]="juexin" end
	if string.find(me["master"],"鸠摩智") then me["masterid"]="jiumozhi" end
	if string.find(me["master"],"金轮法王") then me["masterid"]="fawang" end
	if string.find(me["master"],"一灯大师") then me["masterid"]="yideng" end
	if string.find(me["master"],"黄药师") then me["masterroom"]=1735;me["masterid"]="huang" end
	if string.find(me["master"],"张三丰") then me["masterid"]="zhang" end
	if string.find(me["master"],"马钰") then me["masterid"]="ma" end
	if string.find(me["master"],"丁春秋") then me["masterid"]="ding" end
	if string.find(me["master"],"欧阳锋") then me["masterid"]="ouyang" end
	if string.find(me["master"],"矮老者") then me["masterid"]="ai" end
	if string.find(me["master"],"高老者") then me["masterid"]="gao" end
	if string.find(me["master"],"洪七公") then me["masterid"]="hong" end
	if string.find(me["master"],"梁长老") then me["masterroom"]=2027 end
	if string.find(me["master"],"风清扬") then
		me["masterid"]="feng"
		if set_GbSecretWay>0 then
			xkxGPS.setEntranceCondition("(condition is null or condition='dong' or condition='feng') and id<>3247")
		else
			xkxGPS.setEntranceCondition("(condition is null or condition='feng')")
		end
	end
	
end
function always_hp.dosomething11(n,l,w)
	if string.find(w[1],"无") then me["quit"]=true else me["quit"]=false end
end
function always_hp.dosomething12(n,l,w)
	if string.find(w[1],"男性") then me["sex"]=true 
	elseif string.find(w[1],"女性") then me["sex"]=false 
	elseif string.find(w[1],"无性") then me["sex"]=true 
	end
end
function always_hp.dosomething13(n,l,w)
	me["charname"]=w[1]
end
function always_hp.dosomething14(n,l,w)
	me["shen"]=0-tonumber(w[1])
	setybjob="zhen xibei"
end
function always_hp.dosomething15(n,l,w)
	me["charid"]=string.lower(w[1])
end
function always_hp.dosomething16(n,l,w)
	local a,b,c
	a,b,c=string.find(l,"你目前有桃花潜能(.+)点。")
	if c~=nil then
		hp.thpot=ctonum(c)
	end
	a,b,c=string.find(l,"你将.+点实际潜能储存为桃花潜能，现在有(.+)点。")
	if c~=nil then
		hp.thpot=ctonum(c)
	end
	a,b,c=string.find(l,"你将.+点桃花潜能转换为实际潜能，还剩下(.+)点。")
	if c~=nil then
		hp.thpot=ctonum(c)
	end
	if findstring(l,"你没有那么多桃花潜能。","你现在没有桃花潜能。") then
		hp.thpot=0
	end
end
function always_hp.dosomething17(n,l,w)
	local a,b,c,d,e,f,_f,_t
	--在线时间：八天二十二小时多 
	_f=0
	f=w[1]
	if findstring(f,"天") then --大于1天
		a,b,c,d=string.find(f,"(.+)天(.+)")
		_f=_f+ctonum(c)*24*60*60
		if d~=nil then f=d end
	end
	if findstring(f,"小时") then --大于1小时
		a,b,c,d=string.find(f,"(.+)小时(.+)")
		_f=_f+ctonum(c)*60*60
		if d~=nil then f=d end
	end
	if findstring(f,"分钟") then --大于1分钟
		a,b,c=string.find(f,"(.+)分钟(.+)")
		_f=_f+ctonum(c)*60
		if d~=nil then f=d end
	end
	if findstring(f,"秒") then
		a,b,c=string.find(f,"(.+)秒")
		_f=_f+ctonum(c)
	end
	me["shijian"]=_f
end
function always_hp.dosomething18(n,l,w)
	me["death"]=tonumber(w[1])
end
------------------------------------------------------------------------------------
-- always_skills
------------------------------------------------------------------------------------
function always_skills.dosomething1(n,l,w)
	me["bl"]=tonumber(w[1])
	me["xtbl"]=tonumber(w[2])
	me["wx"]=tonumber(w[3])
	me["xtwx"]=tonumber(w[4])
end
function always_skills.dosomething2(n,l,w)
	me["gg"]=tonumber(w[1])
	me["xtgg"]=tonumber(w[2])
	me["sf"]=tonumber(w[3])
	me["xtsf"]=tonumber(w[4])
end
function always_skills.dosomething3(n,l,w)
	if findstring(l,"以下是你目前使用中的特殊技能。") then
		jifa={}
	elseif findstring(l,"内功") then
		for k,v in pairs(skillslist) do 
			--if v["name"]==w[1] then jifa["forcename"]=string.gsub(k,"-","");break	end
			if v["name"]==w[1] then jifa["forcename"]=k;break	end
		end
		jifa["force"]=tonumber(w[2])
		hp["maxjiali"]=math.floor(w[2]/2)
	elseif findstring(l,"招架") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["parryname"]=k;break	end
		end
		jifa["parry"]=tonumber(w[2])
	elseif findstring(l,"轻功") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["dodgename"]=k;break	end
		end
		jifa["dodge"]=tonumber(w[2])
	elseif findstring(l,"指法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["fingername"]=k;break end
		end
		jifa["finger"]=tonumber(w[2])
	elseif findstring(l,"掌法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["strikename"]=k;break end
		end
		jifa["strike"]=tonumber(w[2])
	elseif findstring(l,"拳法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["cuffname"]=k;break end
		end
		jifa["cuff"]=tonumber(w[2])
	elseif findstring(l,"剑法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["swordname"]=k;break	end
		end
		jifa["sword"]=tonumber(w[2])
	elseif findstring(l,"刀法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["bladename"]=k;break	end
		end
		jifa["blade"]=tonumber(w[2])
	elseif findstring(l,"棒法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["stickname"]=k;break	end
		end
		jifa["stick"]=tonumber(w[2])
	elseif findstring(l,"杖法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["staffname"]=k;break	end
		end
		jifa["staff"]=tonumber(w[2])
	elseif findstring(l,"锤法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["hammername"]=k;break	end
		end
		jifa["hammer"]=tonumber(w[2])
	elseif findstring(l,"爪法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["clawname"]=k;break	end
		end
		jifa["claw"]=tonumber(w[2])
	elseif findstring(l,"鞭法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["whipname"]=k;break	end
		end
		jifa["whip"]=tonumber(w[2])
	elseif findstring(l,"笔法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["strokename"]=k;break	end
		end
		jifa["stroke"]=tonumber(w[2])
	elseif findstring(l,"手法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["handname"]=k;break	end
		end
		jifa["hand"]=tonumber(w[2])
	elseif findstring(l,"枪法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["pikename"]=k;break	end
		end
		jifa["pike"]=tonumber(w[2])
	elseif findstring(l,"棍法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["clubname"]=k;break	end
		end
		jifa["club"]=tonumber(w[2])
	elseif findstring(l,"钩法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["hookname"]=k;break	end
		end
		jifa["hook"]=tonumber(w[2])
	elseif findstring(l,"腿法") then
		for k,v in pairs(skillslist) do 
			if v["name"]==w[1] then jifa["kickname"]=k;break	end
		end
		jifa["kick"]=tonumber(w[2])
	end
end
function always_skills.dosomething4(n,l,w)
	run("cha;jifa;score")
	if w[2]=="基本毒技" and me.menpai=="xx" and skillslist.poison~=nil and skillslist.poison.lvl>=100 then xx.needsandu=1 end
end
function always_skills.dosomething5(n,l,w)
	if skillslist_get==1 then	--采集技能列表到自己的table
		skillslist[w[3]]={}
		skillslist[w[3]]["name"]=w[2]
		skillslist[w[3]]["lvl"]=tonumber(w[4])
		skillslist[w[3]]["sld"]=tonumber(w[5])
		if master_skillslist~=nil and master_skillslist[w[3]]~=nil and tonumber(me.maxlvl)~=nil and tonumber(w[5])>tonumber((w[4]+1)^2) and tonumber(w[4])<me.maxlvl then	--如果技能练红了，加入学师傅1pot列表
			if tonumber(master_skillslist[w[3]]["lvl"])>tonumber(w[4]) then
				table.insert(skillslist_need_up,w[3])
				--print(w[3])
			end
		end
	elseif skillslist_get==2 then	--采集技能列表到师傅的table
		master_skillslist[w[3]]={}
		master_skillslist[w[3]]["name"]=w[2]
		master_skillslist[w[3]]["lvl"]=tonumber(w[4])
		master_skillslist[w[3]]["sld"]=tonumber(w[5])
	end
end
function always_skills.dosomething6(n,l,w)
	--[[1=""
		2="你"
		3="十四"
		0="你目前所学过的技能：（共十四项技能）"]]
		skillslist_get=0	--不采集技能列表
	if w[2]=="你" then 
		skillslist_get=1	--采集自己的技能列表
		skillslist={}
		skillslist_need_up={}
	elseif w[2]==me.master then
		skillslist_get=2	--采集师傅的技能列表
		if master_skillslist["force"]~=nil then 
			master_skillslist={} 
		end
	end
end
function always_skills.dosomething7(n,l,w)
	--print("dosmthing7")
	local a,b,c,d
	a,b,c,d=string.find(l,"%((%S+)%)%s+%-%s+%S+%s+(%d+)/")
	if c~=nil and d~=nil then
		if findstring(skills_lingwu,c) and skillsfull==1 and c~="force" and c~=jifa.forcename then
			-- 检查是否还有低于最大等级的技能
			if tonumber(d)<tonumber(me.maxlvl) then 
				skillsfull=0 --print("技能增长，恢复领悟") 
			end
		end
	end
end
function always_skills.dosomething8(n,l,w)
	local a,b,c,d
	if findstring(l,"你现在没有组合任何特殊拳术技能。","取消全部技能准备。","以下是你目前组合中的特殊拳术技能。") then
		always.bei={}
	elseif findstring(l,"完成技能准备。") then
		run("bei")
	end
	a,b,c=string.find(l,"..法 %(.+%)   (.+)")
	if c~=nil then 
		--print(c)
		table.insert(always.bei,c)
	end	
end
------------------------------------------------------------------------------------
-- always_watch
------------------------------------------------------------------------------------
function always_watch.resetwar()
	war.ready=os.time()+4500		
	WarTotalExp=0	
end
function always_watch.timer()
	me.drugbusy=0
end
function always_watch.timer1()
	cm.havebuff=0
end
function always_watch.timer10()
	alias.setmpLimitedMark() --每隔10秒，检测一次门派任务上限状态
	workflowState.attempts=0 --每10秒重置alias.startworkflow的调用次数统计
	stat.addexp=sum.all()
	stat.avgall=avg.all()
	stat.avgfj=avg.fj()
	stat.avgmp=avg.mp()
	stat.avgftb=avg.ftb()
	stat.avgyb=avg.yb()
	stat.avgwar=avg.war()
	stat.avgdeath=avg.death()
	stat.countdeath=count.death
	yinyangcao_time=yinyangcao_time+10  --阴阳草的时间+10秒
	alias.atdisconnect()
	-- 心跳包已由引擎层自动处理（服务器静默超过 30 秒自动发送 IAC NOP）
end
function always_watch.timer_log()
	if workflow.notlog==nil or not workflow.notlog then
		if IsLogOpen() then CloseLog() end
		OpenLog("",false)
	else
		CloseLog()
	end
end
packets=0
function always_watch.timer30()
	if idle>0 and resetidle>0 and setting_resetidle>0 then
		if setting~="keep" then
			print("貌似发呆了")
			addlog("发呆了")
			check_battleidle=0
			if yp.goto>0 then yp.goto=0 end --桃花任务过程中意外发呆，重置
		end
		if packets~=0 and packets==GetInfo(204) then
			Disconnect()
			Connect()
		end
		packets=GetInfo(204)
		--cmd.nums=0
		if not IsConnected() and (_G["notconnect"]==nil or _G["notconnect"]==0) then Connect()
		elseif IsConnected() then
			checkmove.NotGPSMove=1
			alias.initialize_trigger()
			if me.menpai=="em" then run("put fuling in yaodai") end
			if me.menpai=="bt" then run("convert she") end
			if isopen("michen_yb_start") then 
				addlog("押镖过程发呆，请检查,ybjob.ybfight:"..ybjob.ybfight.."。")
				ybjob.killlist={}
				ybjob.ybfight=0
				openclass("michen_yb_start_t")
			else	
				alias.startworkflow()
			end
		end
		return
	end
	set_date()
end
function always_watch.timer60()
	--if accessing>0 or conn_count <= 20 then 
	if accessing>0 then 
		--conn_count = conn_count + 1
		print("登陆中，防发呆不生效") 
	else
		--conn_count = 0
		idle = 1
	end
end
function always_watch.timer1d()
	if cm.setmz~=nil and cm.setmz>0 then cm.fightmz=1 else cm.fightmz=0 end
	if cm.havebuff>0 then cm.havebuff=0 end
	
end
function always_watch.dosomething1(n,l,w)
	local _f,_tb,_t,a,b,c,d,e
	if findstring(l,"你吃下一颗大还丹，只觉得体内真力源源滋生，过紫宫，入泥丸") then addneili.dahuandan=addneili.dahuandan+1 
	elseif findstring(l,"你的内力增加了！！") then addneili.dazuo=addneili.dazuo+1 
	elseif findstring(l,"你阴柔之气不足，无法练习更高等级的辟邪剑法。") then
		yinyangcao_num=0
		wuhuaguo_num=0
		kuihuafen_num=0
		pxj_needget_yyc=1 
		run("i")
	elseif findstring(l,"你吃下一棵首乌精，药效立刻通彻肺腑，直达四肢。不仅精力大振，连伤痛也全都感觉不到了。") and have.swjing>0 then
		have.swjing=have.swjing-1
	elseif findstring(l,"随着哨子声，玉笛里突然飞出蓝印印的一点火星，火星陡地熄灭，随即大亮，蓬的一声响，腾向半空，升起有丈许，这才缓缓降落。") then
		always.xxblow=1
	elseif findstring(l,"你把玉笛放到口边，轻轻一吹，只听一阵极尖极细的哨子声远远传了出去。") then
		always.liuhuang=always.liuhuang+1
	elseif findstring(l,"你将一块硫磺放进玉笛。") then
		always.liuhuang=0
	elseif findstring(l,"你吃下一粒补阴丸，只觉得浑身一阵冰凉，一股阴寒之气之丹田串向全身，刹那间阳气锐减，阴气陡增。") then pxj_needget_yyc=0 
	elseif findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。") then always.sleeptimes=os.time() 
	elseif findstring(l,"一个蒙面人向你走了过来，满身的杀气，看来似乎不是易与之辈。") then
		haveshizhe=1
		kill.dokill("shizhe","日月神教使者","shizhe")
	elseif findstring(l,"你捡起一个酥油罐。") then
		have.suyouguan=have.suyouguan+1
	elseif findstring(l,"你从何红药那里买下了一棵首乌精。",".+给你一棵首乌精。") then
		have.swjing=have.swjing+1
	elseif findstring(l,"《玄门内功心法》。") then
		have.xinfa=1
	elseif findstring(l,"你目前还没有任何为 rbt=start 的变量设定。") then
		alias.startworkflow()
	elseif findstring(l,"  重剑%(Zhongjian%)") then
		if dummy.jy~="" then
			run("tell "..dummy.jy.." 速来 "..always.where.."，有一把重剑")
		end
	elseif findstring(l,"目前你身上没有任何东西。") then 
		alias.clearitems()
		run("set checkitems=yes")
	end
	a,b,c=string.find(l,"你身上带着(.+)件物品%(负重.+%)：") 
	if c~=nil then
		if have.yaodai>0 then run("look yaodai") end
		if have.he>0 then run("look he") end
		alias.clearitems()
		have.items=ctonum(c)
		openclass("check_items2")
		run("set checkitems=yes")
	end
	if findstring(l,"你目前还没有任何为 checkitems=yes 的变量设定。") then
		alias.resetidle()
		closeclass("check_items2")
		if isopen("check_items") then 
			if hp.healthjing<75 then alias.flytonpc("何红药")
			elseif have.nousejy==1 then print("去送用不上的精要书");alias.flyto(dummy["jyroom"])
			else closeclass("check_items");alias.dealwithitems()
			end
		end
	end
	a,b,c,d=string.find(l,"【丐帮】(.+)%((%w+)%)：各勘察大队：寒潮将至，请注意保暖。家中安好，勿挂念！")
	if c~=nil and c~=me.charname then 
		d=string.lower(d)
		if gold.friend[c]== nil then gold.friend[c]=d end
		run("tell "..d.." 来电收悉，老家保重")
	end
	a,b,c,d=string.find(l,"[> ]*(.+)%((%w+)%)告诉你：来电收悉，老家保重")
	if c~=nil then
		if gold.friend[c]==nil then gold.friend[c]=d end
	end
	a,b,c=string.find(l,"你的最大内力上升了(%d+)点。")
	if c~=nil then addneili.fj=addneili.fj+tonumber(c) end
	a,b,c=string.find(l,"[> ]*(%S+) %- ")
	if c~=nil then
		always.where=string.gsub(string.gsub(c," ",""),"-","")
		--print(c,always.where)
	end
	a,b,c,d=string.find(l,"您目前 wlmz 的变量设定为： (%d+)")
	if c~=nil then --计算武林盟主的交接时间
		cm.wlmz=c
	end
	a,b,c,d=string.find(l,"[> ]*(%S+) \- (%w+)")
	if c~=nil and d~=nil then
		if isopen("gps_start") then
			checkmove.roomName=c
			checkmove.roomFirstEntrance=d
			checkmove.NotGPSMove=0
		else
			if d==checkmove.roomName and findstring(checkmove.roomFirstEntrance,e) then checkmove.NotGPSMove=0 else checkmove.NotGPSMove=1 end
		end
		if always.where_No==nil then always.where_No=1 else always.where_No=always.where_No+1 end
		always.exit=string.gsub(string.gsub(d," ",""),"-","")
		--print(always.where_No,always.exit)
	end
	if findstring(l,"阿二正盯著你看，不知道打些什么主意。") then
		if have.xueteng~=nil and have.xueteng>0 and setting=="keep" then 
			run("halt")
			for i=1,have.xueteng + 1,1 do run("give er xueteng "..i) end
		elseif setting~="keep" then
			kill.dokill("er","阿二","fang")
		end
	end
	if findstring(l,"方东白正盯著你看，不知道打些什么主意。") then
		if have.xueteng~=nil and have.xueteng>0 and setting=="keep" then  
			run("halt")
			for i=1,have.xueteng + 1,1 do run("give fang xueteng "..i) end
		elseif setting~="keep" then
			kill.dokill("fang","方东白","fang")
		end
	end
	if findstring(l,"阿三正盯著你看，不知道打些什么主意。") then
		if have.xueteng~=nil and have.xueteng>0 and setting=="keep" then  
			run("halt")
			for i=1,have.xueteng + 1,1 do run("give san xueteng "..i) end
		elseif setting~="keep" then
			kill.dokill("san","阿三","fang")
		end
	end
	if findstring(l,"【闲聊】.+%(Mengzhu%)：哈哈哈，到底是长江後浪推前浪，一代新人换旧人！") then
		run("set wlmz "..os.time()+24*3600) --记录武林盟主换人的时间
		run("alias wlmz "..os.date())
	end
	if findstring(l,"你心诚意真地等了良久，突然大地一阵震动，两块试心石分") then
		run("enter;enter;n;kneel cave;enter;use fire;kneel grave;out;w;w;climb up;climb up;move stone")
	end
	if findstring(l,"慢慢地一阵眩晕感传来，你终于又有了知觉....") and setting_resetidle>0 then
		wait.make(function()
			if setting_resetidle>0 then resetidle=1 end
			if workflow.nowjob=="yb" then set_yb() end
			if workflow.nowjob=="death" then
				workflow.nowjob=deathjob
				_f=function()
					openclass("watch_death")
					if me.menpai=="wd" and set_lifesave>0 then run("set check=lifesavehp") else alias.flytoid(deathroomno) end
				end
				wait.time(1);_f()
			else
				if workflow.nowjob=="lifesave" then
					workflow.nowjob=deathjob
					_f=function()
						openclass("watch_death")
						run("set check=lifesavehp")
					end
					wait.time(1);_f()
				else
					if not isopen("liaoshang") then
						alias.resetidle()
						alias.yjl()
						run("yun recover;yun regenerate")
						if me.menpai=="xs" and (tonumber(roomno_now)==422 or tonumber(roomno_now)==425) then
							--print("雪山烧人过程中，晕倒，不在此处处理")
						else
							alias.initialize_trigger()
							ftbnpckilled=0
							havefj=0
							haveshizhe=0
							if me.menpai=="xs" and tonumber(roomno_now)==439 then openclass("mp_xs_npc1");alias.startlianwu()
							--elseif me.menpai=="xs" and (tonumber(roomno_now)==422 or tonumber(roomno_now)==425) then  
							elseif always.where=="监狱" then alias.dz(200)
							else alias.startworkflow() end
						end
					end
				end
			end
		end)
	end
	if findstring(l,"牢门缓缓地开启了") then run("u");alias.startworkflow() end
	if findstring(l,"你双手攀着树枝，实在没闲暇再做其他事。") then run("d");alias.startworkflow() end
	if findstring(l,"只觉一阵腾云驾雾般，你昏昏沉沉地被扔出了监狱！") then alias.startworkflow() end
	if findstring(l,"一道闪电从天降下，直朝你劈去……结果没打中！") then openclass("quit") end
	if findstring(l,"一阵微风吹过，四面景致似乎起了些变化。") then buzhen=false end
	if findstring(l,"风云突变，时代变迁，你已经不是武林盟主了。") then cm.mengzhu=0 end
	if findstring(l,"向你躬身为礼，说道：盟主您老人家好！","向你齐声大喊：盟主万岁，万岁，万万岁！") then cm.mengzhu=1 end
	if findstring(l,"上的兵将再离开吧。") then run("dismiss") end
	if findstring(l,"你使不了那么多法轮。") then run("drop lun;drop lun;get 5 lun") end
	if findstring(l,"你得到一只烤鸭。") then dropya=true end
	if findstring(l,"在寒玉床上要专心打坐！") then run("xiachuang") end
	if findstring(l,"酒袋已经被喝得一滴也不剩了。","酒袋里的清水喝得底朝天了。") then have.water=0 end
	if findstring(l,"你开始感到身体变得冰凉。","随着一阵钻心的疼痛，你开始感到四肢发麻，蛇毒发作了！") then
		run("hp")
		if hp.healthjing<85 or me.menpai=="wd" and jifa["forcename"]=="taiji-shengong" then stat.havedu=1 end
	end
	if findstring(l,"你的伤口发麻，全身僵直，不听使唤，这不是普通的蛇毒！","忽然一阵刺骨的奇寒袭来，你中的星宿掌毒发作了！","你感到呼吸困难，麻木的感觉顺着四肢逐渐上行，蛇毒发作了！") then
		run("hp")
		if skillslist.poison~=nil then
		    if hp.healthjing<80 or (me.menpai=="th" and skillslist.poison.lvl<380) then stat.havedu=1 end
		else
		    stat.havedu=1
		end
	end
	if findstring(l,"没干完活儿就想溜，没门儿！") then
		alias.initialize_trigger()
		openclass("mp_dl")
		openclass("mp_dl_work")
		openclass("mp_dl_dowork")
		alias.uw()
		alias.wi("huachu")
	end
	if findstring(l,"你吃下一丸紫金通脉丹，只觉得头重脚轻，摇摇欲倒，原来服食太急太多，药效适得其反！","你将一丸紫金通脉丹放入口中，闭目凝神，待丹药完全融化，全身骨骼竟然发出啪啪的声响。") then
		alias.resetidle()
		cm.havebuff=1
		stat.cmbuff=os.time()+3602
		stat.drugbusy=os.time()+3602
		ResetTimer("always_watch_timer1d")
	end
	if findstring(l,"紫金通脉丹的药效渐渐散去。") then
		cm.havebuff=0
	end
	if findstring(l,"你吃下一颗大血藤，只觉得肝肠寸断，五脏欲裂，原来服食太多药物，药效适得其反！","你吃下一棵大血藤，顿时血气翻涌血脉膨胀，气力大长。") then
		addneili.dahuandan=addneili.dahuandan+1
		stat.drugbusy=os.time()+720
		print("现在时间："..os.time().."  下次吃药时间："..stat.drugbusy)
	end
	if findstring(l,"你小心翼翼地把一包金创药敷在伤口上") then
		stat.jinchuangyao=os.time()+60
		print("现在时间："..os.time().."  下次吃药时间："..stat.drugbusy)
		have.jcy=have.jcy-1
	end
	if findstring(l,"一个守关鬼卒手执剑戟来到你面前，伸手抓住你项上的「阴司路引」仔细检查着。") then alias.resetidle() end
	if findstring(l,"鬼卒对着你一瞪眼吼道：“你怎么还赖在这里？进去进去！”","地藏王菩萨念道：阿弥陀佛！","突然你感觉到好像有东西在背后对着你的脖子吹气！","但见阴天子把手一招，飘来了牛头马面，架起你就往内殿而去。") then
		alias.resetidle()
		if me.menpai=="wd" and set_lifesave>0 then run("yun lifesave") end
	end
	if findstring(l,"鬼卒将你的「阴司路引」收了起来，伸手指了指关门，好象是叫你进去。") then
		alias.resetidle()
		if me.menpai=="wd" and set_lifesave>0 then run("yun lifesave") end
		run("n;n")
	end
	if findstring(l,"鬼门关 - ") and (workflow.lifesave==nil or workflow.lifesave==0) and setting~="godie" then
		alias.resetidle()
		stat.havedu=0
		stat.haveneiheal=0
		if fjroomid==0 then deathroomno=roomno_now else deathroomno=fjroomid end
		if dummy.laopo~=nil and dummy.laopo~="" then dummy.laopo="" end
		if workflow.nowjob=="yb" then set_yb() end
		-- #if %class( blockpk_start {#add list.pk %concat( " 被杀死"}
		-- #additem DeathList {%concat( %time( yyyy-mm-dd hh:nn:ss, " Job=", @deathjob, %if( @deathjob=fj, %concat( " Room=", @fj.room, " Zone=", @fj.zone, " Roomno=", @fj.roomno, " NPC=", @fj.npc), %concat( " Room=", @deathroomno)))}
		local msg="死亡！！！ Job="..tostring(deathjob)
		if deathjob=="fj" then
			msg=msg.." Room="..tostring(fj.room).." Zone="..tostring(fj.zone).." Roomno="..tostring(fj.roomno).." NPC="..tostring(fj.npc)
		else
			msg=msg.." Room="..tostring(deathroomno)
		end
		addlog(msg)
		alias.initialize_trigger()
		--if jifa.forcename=="xuanyin-zhenqi" then alias.jfhbmz() else Execute("/alias.jf"..me.menpai.."()") end
		run("jiajin basic")
		if #always.bei==1 and always["bei"][1]=="六脉神剑" or #always.bei==2 and (always["bei"][1]=="六脉神剑" or always["bei"][2]=="六脉神剑") then
			run("jiali "..killjiali)
		else
			run("jiali 0")
		end
		deathjob=workflow.nowjob
		workflow.nowjob="death"
		alias.checkexp("death")
		--alias.checkitems()
		if me.menpai=="wd" and set_lifesave>0 then run("yun lifesave") 
		elseif dummy.lifesave~=nil and string.len(dummy.lifesave)>1 and roomno_now>0 and set_lifesave>0 then run("tell "..dummy.lifesave.." 救命"..roomno_now.." thank you") end
	end
	if findstring(l,"江湖各大门派妄想进攻光明顶") then 
		mj.haveyd=1
		mj.yd_gap=os.time()-mj.yd_start
		print("本次御敌间隔"..mj.yd_gap.."秒")
		mj.yd_start=os.time()
		add.yudi=0
		mj.ydnpckilled=0
	end
	if findstring(l,"一批正派弟子已经攻向了") then
			mj.haveyd=1
	end
	if findstring(l,"我明教上下一心，终于成功打退那帮所谓名门正派的进攻") then 
		mj.haveyd=0
		addlog("明教御敌任务总计击退："..mj.ydnpckilled.." 个敌人，获得："..add.yudi.."经验")
		print("御敌完成，这个周期总计击杀"..mj.ydnpckilled.."个敌人，获得["..mpLimited.mpexp.."]经验，花费时间："..tonumber(os.time()-mpLimited.MarkTime)) 
		add.yudi=0
		mj.ydnpckilled=0 
	end
	if findstring(l,"你觉得精气极为不足","你觉得气血严重淤塞","你觉得精神非常不振") then run("yun shougong") end
	if findstring(l,"坐着走？") then run("stand") end
	if findstring(l,"此书乃吾留予后代峨嵋聪慧弟子，") then run("give wenying wuxue jingyao;drop wuxue jingyao") end
	if findstring(l,"你正坐在镖车上呢！") then run("leave che") end
	if findstring(l,"你只觉得“神门穴”上一阵酸麻") then stat.quiting=2;run("score") end
	if findstring(l,"只听得你一声大喝，拳风突然变得猛劲之极，身法却更加飘忽难测！","你身法突然加快，身形更加飘忽","你已在使用雷动九天了","你已在使用逍遥游了！") then stat.leidong=1 end
	if findstring(l,"你双手合十念佛，刹那间四周地动山摇，发出隆隆巨响！","你已经发动了金刚神通！") then stat.jingang=1 end
	if findstring(l,"你运起玄门先天功，内力遍布全身","你已在使用三花聚顶了！") then stat.sanhua=1 end
	if findstring(l,"你的眼前一黑，接著什么也不知道了....") then resetidle=0 end
	if findstring(l,"突然一股强大的力量将你推出秘洞。") then roomno_now=2058;alias.startcm() end
	if findstring(l,"你行大小二庄已久，又恢复了原有精气。") then stat.daxiao=0 end
	if findstring(l,"你屏息静气，交错运行大小二庄，只觉一股暖流出天门，穿地户，沿着全身经脉运行一周，汇入丹田气海。") then stat.daxiao=1 end
	if findstring(l,"你风云行功已久，略觉步履沉重了一些。") then stat.fengyun=0 end
	if findstring(l,"你暗运风云两庄，心思浮云飘空之悠闲缓慢，默想狂风荡地之迅速紧急，") then stat.fengyun=1 end
	if findstring(l,"你只觉得一阵头晕, 眼前只看见五彩斑斓的一片模糊, 原来你中的千蛛万毒手发作了!","你一阵摇晃, 猛提丹田之气却提不上来，结果险些摔倒.","只听你闷哼了一声, 后心已被") then stat.havedu=1 end
	if findstring(l,"你觉得一股冷气从直透心口，全身立时寒战，牙齿互击，格格作响") then 
	    if jifa.forcename=="xuanyin-zhenqi" and skillslist["xuanyin-zhenqi"]["lvl"]>79 then stat.havehbdu=1
		else stat.havedu=1
		end
	end
	if findstring(l,"你并未中寒冰毒！") then stat.havehbdu=0 end
	if findstring(l,"忽然你一阵头晕目眩，你所中的混元无极劲内伤发作了！") then stat.haveneiheal=1 end
	if findstring(l,"你并未受混元无极劲内伤！") then stat.haveneiheal=0 end
	if findstring(l,"一阵酸麻，血气不畅，顿时动弹不得！") then stat.haveyyz=1 end
	if findstring(l,"你见身边怪蛇的鳞片也逐渐恢复为银白色，不得不放慢『蟾蜍步法』。") then stat.heji=0 end
	if findstring(l,"你脚下施展『蟾蜍步法』口中唏嘘之声不断，只见你身边怪蛇身上鳞片发红，游走异常。") then stat.heji=1 end
	if findstring(l,"你只觉真气运转不畅，不得不散去护体真气") then stat.jinzhongzhao=0 end
	if findstring(l,"你正在运用金刚不坏体神功","你双手合十，梵唱之声不绝于耳") then stat.jinzhongzhao=1 end
	if findstring(l,"你的混天气功运行完毕，将内力收回丹田。") then stat.huntianup=0 end
	if findstring(l,"你大喝一声，手中刀光霍霍，招招连环，快如电闪！") then stat.liuhe=1 end
	if findstring(l,"你无法这样做。") and me.menpai=="mj" and mj.lvl>=6 then --修复教主无法连续雷动或金刚
		if jzpfm==nil then jzpfm="" 
		elseif jzpfm=="leidong" then stat.leidong=1;jzpfm=""
		elseif jzpfm=="jingang" then stat.jingang=1;jzpfm=""
		elseif jzpfm=="liuhe" then stat.liuhe=1;jzpfm=""
		end
	end
	if findstring(l,"你的混天气功运行完毕，将内力收回丹田，手上招数也逐渐慢了下来。","你的混天气功运行完毕，将内力缓缓收回丹田。") then stat.liuhe=0 end
	if findstring(l,"你大喝一声.+使出“十字砍”的凌厉刀势。","这正是你成名绝技“十字砍”") then stat.cross=stat.cross+1 end
	if findstring(l,"突然间你双刀交错，“十字砍”已然招毕") then stat.cross=0 end
	if findstring(l,"你微一凝神，运起混天气功，全身骨节发出一阵爆豆般的声响") then stat.huntianup=1 end
	if findstring(l,"你脸上青气大盛.+碧涛玄功已发挥到极致","你正在运用「移形换位」心法") then stat.yixing=1 end
	--if findstring(l,"祗听你手中.+嗡嗡轻响，凝聚其上的青芒缓缓消散。","你手中青刚剑“咯”的一声轻响，附在剑上的青芒已消失得无影无踪。","") then stat.jianmang=0 end
	if findstring(l,"只见你微微一笑，神情安宁，眼中竟似没有他人一样。","你已经在运用素心诀了。")  then stat.suxin=1 end
	if findstring(l,"你只觉真气运转不畅，不得不放慢步法，调息吐纳。") then stat.yixing=0 end
	if findstring(l,"你玉女心经心法渐渐散去，神情逐渐恢复常态。") then stat.suxin=0 end
	if findstring(l,"你缓缓吸了一口气，将内劲收回丹田。") then stat.leidong=0 end	
	if findstring(l,"你缓缓吸了一口气，收回金刚神通，身形又恢复了原状。") then stat.jingang=0 end
	if findstring(l,"你吸了一口气，将内力收回丹田！") then stat.sanhua=0 end
	if findstring(l,"你的龙象之力运行完毕，将内力收回丹田。") then stat.longxiang=0 end
	if findstring(l,"你口中默念大明六字真言，手结摩利支天愤怒印，运起") then stat.longxiang=1 end
	if findstring(l,"只见你的蛤蟆功运行完毕，将内力收回丹田。") then stat.powerup=0 end
	if findstring(l,"只见你蹲在地下，双手弯与肩齐，宛似一只大青蛙般作势相扑，口中发出老牛嘶鸣般的咕咕之声，时歇时作。") then stat.powerup=1 end
	if findstring(l,"你的经脉倒转运行完毕，经脉回复一如往常。") then stat.reverse=0 end
	if findstring(l,"只见你口中叫道「差尔刺呼，哈虎」，忽做头下脚上之形，双手撑地，蹦来蹦去。") then stat.reverse=1 end
	if findstring(l,"缓然收起混天气功将内力纳回丹田。") then stat.shengang=0 end
	if findstring(l,"你凝神默然运功，不一会手上的") then stat.shengang=1 end
	if findstring(l,"你所聚天地之精气已散回天地之间，你又恢复了原有精气。") then stat.tiandi=0 end
	if findstring(l,"你席地而坐，五心向天，运行天地二庄，益气升阳，益阴潜阳，升降反正，天地二气交泰于身，顿觉自己精气上限增加了。") then stat.tiandi=1 end
	if findstring(l,"你脸色转白，身上那股逼人的阴寒之气渐渐消失！") then stat.xuanyin=0 end
	if findstring(l,"只听你嘿嘿嘿几声奸笑，身法变得更加奇诡难测，接着双掌一划，丝丝白气自掌心冒出，") then stat.xuanyin=1 end
	if findstring(l,"你体内已积过多浊气，似乎领悟力又归于寻常。") then stat.zhixin=0 end
	if findstring(l,"你微一凝神，运动之心两庄，去浊气出体外，收清气入心中，只觉灵台清明，领悟力似乎有所增加。") then stat.zhixin=1 end
	if findstring(l,"你吐息呐气，将遍布全身的紫霞真气缓缓散去。") then stat.zixia=0 end
	if findstring(l,"你气凝丹田，运起紫霞神功，脸上紫气大盛。") then stat.zixia=1 end
	if findstring(l,"握在手中","取出白龙剑") then weapon_id=1 end
	if findstring(l,"你终于恢复了一点自信") then set_yb() end
	if findstring(l,"你觉得自己的意识越来越弱，渐渐不省人事了。。。","一股阴冷的浓雾突然出现，很快地包围了你。") then
		workflow.nowjob=deathjob
		resetidle=1
		if me.menpai=="dl" or me.menpai=="mj" then run("drop pao") end
		if me.menpai=="th" then run("drop robe") end
		run("drop cloth")
		run("hp")
		wait.make(function()
			_f=function()
				openclass("watch_death")
				if tonumber(deathroomno)~=nil and tonumber(deathroomno)>0 then alias.flytoid(deathroomno) else alias.startworkflow() end
			end
			wait.time(2);_f()
		end)
	end
	if findstring(l,"一股罡气自丹田涌出，直冲天灵，你痛得几乎晕死过去！") then
		workflow.nowjob="lifesave"
		openclass("watch_death")
	end
	if findstring(l,"你体内聚毒过多，难以继续提高。") then xx.needsandu=1 end
	if findstring(l,"看来该找机会逃跑了...") then
		run("halt")
		alias.yjl()
		run("yun recover")
		if not isopen("kill") then run(safego) end
	end
	if findstring(l,"【队伍会话】.+：集合") then	--一键召唤大米准备war
		if tonumber(war.team)==nil or war.team==0 then
		alias.startwar()
		end
	end
	if not isopen("boat") and findstring(l,"数码世界，数字地图，"..tostring(dummy.xueteng_room).."就是这里！") then
		run("unset no_accept;tell "..dummy.xueteng_dm.." give me xueteng")		
		wait.make(function()
			_f=function()
				run("fu xueteng")
				stat.drugbusy=os.time()+720
				alias.startworkflow()
			end
			wait.time(3);_f()
		end)
	end
end
------------------------------------------------------------------------------------
-- watch_death
------------------------------------------------------------------------------------
function watch_death.dosomething1(n,l,w)
	local a,b,c
	if findstring(l,"你目前还没有任何为 check=lifesavehp 的变量设定。") then
		if hp.healthjing<100 or hp.healthqi<100 then alias.flytonpc("俞岱岩") else run("set check=lifesaveover") end
	end
	if findstring(l,"有一天，你踩着七色云彩来迎娶『俞岱岩』") then
		if hp.healthjing<70 or hp.healthqi>49 then
			run("ask yu about 天王护心丹;fu dan")
		else
			run("ask yu about 白虎夺命丸;fu wan")
		end
		run("hp")
		alias.checkexp("death")
	end
	if findstring(l,"数码世界，数字地图，950就是这里！") then
		closeclass("watch_death")
		run("e;look")
		alias.startworkflow()
	end
	if not isopen("boat") and findstring(l,"数码世界，数字地图，"..tostring(deathroomno).."就是这里！") then
	--a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	--if c~=nil and tonumber(c)==deathroomno then
		run("halt;get all from corpse;get all from corpse 2;get all from corpse 3")
		run("halt;get book;get book;get book;get gold")
		if me.menpai=="dl" or me.menpai=="mj" then run("drop pao")
		elseif me.menpai=="th" then run("drop robe")
		else run("drop cloth") end
		run("wear armor;wear all")
		if me.menpai=="em" or me.menpai=="bt" then run("put fuling in yaodai") end
		alias.flytoid(950)
	end
	if findstring(l,"你目前还没有任何为 checkexpover=death 的变量设定。") then
		alias.resetidle()
		run("set check=lifesaveover")
	end
	if findstring(l,"你目前还没有任何为 check=lifesaveover 的变量设定。") then
		--avgcount.lifesave=avgcount.lifesave+1
		workflow.nowjob=deathjob
		alias.flytoid(deathroomno)
	end
end
function set_date()   --关闭发呆检测时用来防止掉线
	if setting_resetidle==0 and idle>0 then run( idle_emote[math.random(#idle_emote)]) end
end
function always_chkmj.dosomething1(n,l,w)
	--│明教护教法王         大宝剑 (baojian)         │
	local _tb,a,b,c,d,_f
	if findstring(l,me.charname) then
		a,b,c=string.find(l,"│%s*明教(%S+).+│")
		if c~=nil then
			if c=="弟子" then mj.lvl=1
			elseif c=="掌旗使" then mj.lvl=2
			elseif c=="散人" then mj.lvl=3
			elseif c=="护教法王" then mj.lvl=4
			elseif c=="光明使者" then mj.lvl=5
			elseif c=="教主" then mj.lvl=6
			end
		end
	--│天鹰教坛主       丑志怪 (hhyhscc)         │
		a,b,c=string.find(l,"│%s*天鹰教(%S+).+│")
		if c~=nil then
			if c=="弟子" then mj.lvl=1
			elseif c=="坛主" then mj.lvl=2
			elseif c=="散人" then mj.lvl=3
			elseif c=="护教法王" then mj.lvl=4
			elseif c=="光明使者" then mj.lvl=5
			elseif c=="教主" then mj.lvl=6
			end
		end
		--print("mj.lvl:"..mj.lvl)
	elseif findstring(l,"明教任务") then
		a,b,c=string.find(l,"明教任务(.+)")
		if c~=nil and findstring(c,"挑  水") then mj.joblist="挑水"
		elseif c~=nil and findstring(c,"挖地道") then mj.joblist="挖地道"
		elseif c~=nil and findstring(c,"砍  树") then mj.joblist="砍树"
		elseif c~=nil and findstring(c,"采集铁矿") then mj.joblist="挖矿"
		elseif c~=nil and findstring(c,"打造火枪") then mj.joblist="打铁"
		elseif c~=nil and findstring(c,"无") then mj.joblist="" end
		--print("mj.joblist:"..mj.joblist)
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function always.update()
	local _tb
	local  always_daytime_triggerlist={
	       {name="always_daytime_dosth1",regexp="(太阳从东方的地平线升起了。|已经是午夜了。|傍晚了，太阳的馀晖将西方的天空映成一片火红。|东方的天空中开始出现一丝微曦。|已经是正午了，太阳从你正上方照耀著大地。|太阳开始从西方的天空中慢慢西沉。|夜晚降临了。|东方的天空已逐渐发白|东方的天空中开始出现一丝微曦。|太阳刚从东方的地平线升起|太阳正高挂在东方的天空中|太阳正高挂在西方的天空中|现在是正午时分，太阳高挂在你的头顶正上方|夜幕低垂，满天繁星|夜幕笼罩著大地|一轮火红的夕阳正徘徊在西方的地平线上|已经是午夜了。)",script=function(n,l,w,s)    always_daytime.dosomething1(n,l,w,s)  end,},
	}
	for k,v in pairs(always_daytime_triggerlist) do
		addtri(v.name,v.regexp,"always_daytime",v.script)
	end
	openclass("always_daytime")
	_tb={
		"你将.+点实际潜能储存为桃花潜能，现在有(.+)点。",
		"你将.+点桃花潜能转换为实际潜能，还剩下(.+)点。",
		"你目前有桃花潜能(.+)点。",
		"你没有那么多桃花潜能。",
		"你现在没有桃花潜能。",
	}
	local  always_hp_triggerlist={
	       {name="always_hp_dosth1",regexp="\\s+经验增加：(\\d+)\\s+",script=function(n,l,w)    always_hp.dosomething1(n,l,w)  end,},
	       {name="always_hp_dosth2",regexp="\\s+钱庄盈余：(\\S+)两黄金",script=function(n,l,w)    always_hp.dosomething2(n,l,w)  end,},
	       {name="always_hp_dosth3",regexp="\\s+钱庄盈余：(亏空无余|很少)\\s+",script=function(n,l,w)    always_hp.dosomething3(n,l,w)  end,},
	       {name="always_hp_dosth4",regexp=linktri(" 精神：\\s*(\\d+)\\s*/\\s*(\\d+)\\s*\\(\\s*(\\d+)%\\)\\s*精力：\\s*(\\d+)\\s*/\\s*(\\d+)\\s*\\(\\s*\\+\\s*(\\d+)\\)"),script=function(n,l,w)    always_hp.dosomething4(n,l,w)  end,},
	       {name="always_hp_dosth5",regexp="^ 气血：\\s*(\\d+)\\s*/\\s*(\\d+)\\s*\\(\\s*(\\d+)%\\)\\s*内力：\\s*(\\S+)\\s*/\\s*(\\d+)\\s*\\(\\s*\\+\\s*(\\d+)\\)",script=function(n,l,w)    always_hp.dosomething5(n,l,w)  end,},
	       {name="always_hp_dosth6",regexp="^ 食物：\\s*(\\d+)\\s*/\\s*(\\d+)\\s*潜能：\\s*(\\S+)\\s*/\\s*(\\d+)\\s*",script=function(n,l,w)    always_hp.dosomething6(n,l,w)  end,},
	       {name="always_hp_dosth7",regexp="^ 饮水：\\s*(\\d+)\\s*/\\s*(\\d+)\\s*经验：\\s*(\\S+)\\s*",script=function(n,l,w)    always_hp.dosomething7(n,l,w)  end,},
	       {name="always_hp_dosth8",regexp="^│(心静如始|轩辕正气)：(\\d+)",script=function(n,l,w)    always_hp.dosomething8(n,l,w)  end,},
		   {name="always_hp_dosth9",regexp="^│江湖门派：(\\S+)\\s+",script=function(n,l,w)    always_hp.dosomething9(n,l,w)  end,},
	       {name="always_hp_dosth10",regexp="^│授业师父：(\\S+)\\s+",script=function(n,l,w)    always_hp.dosomething10(n,l,w)  end,},
	       {name="always_hp_dosth11",regexp="^│退出限制：(\\S+)",script=function(n,l,w)    always_hp.dosomething11(n,l,w)  end,},
	       {name="always_hp_dosth12",regexp="^│性  别：(\\S+)人类",script=function(n,l,w)    always_hp.dosomething12(n,l,w)  end,},
	       {name="always_hp_dosth13",regexp="^│姓  名：(\\S+)\\s+",script=function(n,l,w)    always_hp.dosomething13(n,l,w)  end,},
		   {name="always_hp_dosth14",regexp="^│妖魔孽气：(\\d+)",script=function(n,l,w)    always_hp.dosomething14(n,l,w)  end,},
	       {name="always_hp_dosth15",regexp="^│英文ID：(\\w+)\\s+",script=function(n,l,w)    always_hp.dosomething15(n,l,w)  end,},
	       {name="always_hp_dosth16",regexp=linktri(_tb),script=function(n,l,w)    always_hp.dosomething16(n,l,w)  end,},
		   --{name="always_hp_dosth17",regexp="\\s+在线时间：(\\S+)天",script=function(n,l,w)    always_hp.dosomething17(n,l,w)  end,},
		   {name="always_hp_dosth17",regexp="^│\\s+在线时间：(\\S+)",script=function(n,l,w)    always_hp.dosomething17(n,l,w)  end,},
		   {name="always_hp_dosth18",regexp="\\s+含恨入土：\.+真\\s*(\\d*)\\s*\\)\\s*",script=function(n,l,w)    always_hp.dosomething18(n,l,w)  end,},
	}
	for k,v in pairs(always_hp_triggerlist) do
		addtri(v.name,v.regexp,"always_hp",v.script)
	end
	openclass("always_hp")
	
	_tb={
		"\\s+(\\S+)棵阴阳草\\(Yinyang cao\\)$",
		"\\s+(\\S+)钱葵花粉\\(Kuihua fen\\)$",
		"\\s+(\\S+)钱无花果\\(Wuhua guo\\)$"
	}
	local  always_items_triggerlist={
	       {name="always_items_dosth1",regexp=linktri(_tb),script=function(n,l,w)    always_items.dosomething1(n,l,w)  end,},
		  --三棵阴阳草(Yinyang cao)
		--	一钱葵花粉(Kuihua fen)
		--	一钱无花果(Wuhua guo)
	}
	for k,v in pairs(always_items_triggerlist) do
		addtri(v.name,v.regexp,"always_items",v.script)
	end
	openclass("always_items")
	
	local  always_skills_triggerlist={
	      -- {name="always_skills_dosth1",regexp="\\s*臂力：\\s*(\\d+)/\\s*(\\d+)\\s*悟性：\\s*(\\d+)/\\s*(\\d+)",script=function(n,l,w)    always_skills.dosomething1(n,l,w)  end,},
		   {name="always_skills_dosth1",regexp="\\s*臂力：\\s*(.+)/\\s*(\\d+)\\s*悟性：\\s*(\\d+)/\\s*(\\d+)",script=function(n,l,w)    always_skills.dosomething1(n,l,w)  end,},
	       {name="always_skills_dosth2",regexp="\\s*根骨：\\s*(\\d+)/\\s*(\\d+)\\s*身法：\\s*(\\d+)/\\s*(\\d+)",script=function(n,l,w)    always_skills.dosomething2(n,l,w)  end,},
	       {name="always_skills_dosth3",regexp="\\s*\\D+ \\(\\w+\\)\\s*：\\s*(\\S+)\\s*有效等级：\\s*(\\d+)",script=function(n,l,w)    always_skills.dosomething3(n,l,w)  end,}, --收集jifa的有效等级
		   {name="always_skills_dosth3_1",regexp=linktri("以下是你目前使用中的特殊技能。"),script=function(n,l,w)    always_skills.dosomething3(n,l,w)  end,}, --重置已经激发的技能
	       {name="always_skills_dosth4",regexp=linktri("你的「(.+)」进步了！"),script=function(n,l,w)    always_skills.dosomething4(n,l,w)  end,},
	       {name="always_skills_dosth5",regexp="^│(　|□)(\\S+)\\s*\\((\\S+)\\)\\s+-\\s*\\S+\\s*(\\d+)\\/\\s*(\\d+)",script=function(n,l,w)    always_skills.dosomething5(n,l,w)  end,},
	       {name="always_skills_dosth6",regexp=linktri("(\\S+)目前所学过的技能：（共(\\S+)项技能）"),script=function(n,l,w)    always_skills.dosomething6(n,l,w)  end,},
		   {name="always_skills_dosth7",regexp="\\((\\S+)\\)\\s+\\-\\s+\\S+\\s+(\\d+)\\/",script=function(n,l,w)    always_skills.dosomething7(n,l,w)  end,},
	}
	for k,v in pairs(always_skills_triggerlist) do
		addtri(v.name,v.regexp,"always_skills",v.script)
	end
	_tb={
		"你现在没有组合任何特殊拳术技能。",
		"取消全部技能准备。",
		"完成技能准备。",
		"以下是你目前组合中的特殊拳术技能。",
		"(爪法|掌法|拳法|指法|手法|腿法) \\(\\w+\\)   \\S+",
	}
	local  always_items_triggerlist={
	       {name="always_skills_dosth8",regexp=linktri(_tb),script=function(n,l,w)    always_skills.dosomething8(n,l,w)  end,},
	}
	for k,v in pairs(always_items_triggerlist) do
		addtri(v.name,v.regexp,"always_skills",v.script)
	end
	openclass("always_skills")
	
	local  always_chkmj_triggerlist={
	       {name="always_chkmj_dosth1",regexp="^│\\s*.{2,4}教(\\S+)\\s+",script=function(n,l,w)    always_chkmj.dosomething1(n,l,w)  end,},
	       --{name="always_chkmj_dosth2",regexp="^│\\s+明教任务\\s+.+\\s+│",script=function(n,l,w)    always_chkmj.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(always_chkmj_triggerlist) do
		addtri(v.name,v.regexp,"always_checkmingjiao",v.script)
	end
	closeclass("always_checkmingjiao")
	_tb={
		"你开始感到身体变得冰凉。",
		"随着一阵钻心的疼痛，你开始感到四肢发麻，蛇毒发作了！",
		"风云突变，时代变迁，你已经不是武林盟主了。",
		"鬼门关 - ",
		"坐着走？",
		"此书乃吾留予后代峨嵋聪慧弟子，",
		"你正坐在镖车上呢！",
		"你只觉得“神门穴”上一阵酸麻",
		"鬼卒对着你一瞪眼吼道：“你怎么还赖在这里？进去进去！”",
		"你吃下一颗大血藤，只觉得肝肠寸断，五脏欲裂，原来服食太多药物，药效适得其反！",
		"你吃下一棵大血藤，顿时血气翻涌血脉膨胀，气力大长。",
		"你小心翼翼地把一包金创药敷在伤口上",
		"你吃下一丸紫金通脉丹，只觉得头重脚轻，摇摇欲倒，原来服食太急太多，药效适得其反！",
		"紫金通脉丹的药效渐渐散去。",
		"你将一丸紫金通脉丹放入口中，闭目凝神，待丹药完全融化，全身骨骼竟然发出啪啪的声响。",
		"你的伤口发麻，全身僵直，不听使唤，这不是普通的蛇毒！",
		"你的眼前一黑，接著什么也不知道了....",
		"你放弃手中的.+，缓然收起混天气功将内力纳回丹田。",
		"你感到.+一阵酸麻，血气不畅，顿时动弹不得！",
		"你见身边怪蛇的鳞片也逐渐恢复为银白色，不得不放慢『蟾蜍步法』。",
		"你凝神默然运功，不一会手上的.+似乎发出淡淡光辉！",
		"你微一凝神，运起混天气功，全身骨节发出一阵爆豆般的声响",
		"一道闪电从天降下，直朝你劈去……结果没打中！",
		"只见你的蛤蟆功运行完毕，将内力收回丹田。",
		"你风云行功已久，略觉步履沉重了一些。",
		"你脚下施展『蟾蜍步法』口中唏嘘之声不断，只见你身边怪蛇身上鳞片发红，游走异常。",
		"你所聚天地之精气已散回天地之间，你又恢复了原有精气。",
		"你体内已积过多浊气，似乎领悟力又归于寻常。",
		"你行大小二庄已久，又恢复了原有精气。",
		".+向你躬身为礼，说道：盟主您老人家好！",
		".+向你齐声大喊：盟主万岁，万岁，万万岁！",
		"地藏王菩萨念道：阿弥陀佛！",
		"慢慢地一阵眩晕感传来，你终于又有了知觉....",
		"牢门缓缓地开启了",
		"你双手攀着树枝，实在没闲暇再做其他事。",
		"只觉一阵腾云驾雾般，你昏昏沉沉地被扔出了监狱！",
		"你暗运风云两庄，心思浮云飘空之悠闲缓慢，默想狂风荡地之迅速紧急，",
		"你的混天气功运行完毕，将内力收回丹田。",
		"你缓缓吸了一口气，收回金刚神通，身形又恢复了原状。",
		"你已经发动了金刚神通","你双手合十念佛，刹那间四周地动山摇",
		"你只觉真气运转不畅，不得不散去护体真气",
		"你正在运用金刚不坏体神功","你双手合十，梵唱之声不绝于耳",
		"你屏息静气，交错运行大小二庄，只觉一股暖流出天门，穿地户，沿着全身经脉运行一周，汇入丹田气海。",
		"你微一凝神，运动之心两庄，去浊气出体外，收清气入心中，只觉灵台清明，领悟力似乎有所增加。",
		"你席地而坐，五心向天，运行天地二庄，益气升阳，益阴潜阳，升降反正，天地二气交泰于身，顿觉自己精气上限增加了。",
		"突然一股强大的力量将你推出秘洞。",
		"忽然一阵刺骨的奇寒袭来，你中的星宿掌毒发作了！",
		"你蛇杖里的暗器准备好了。",
		"一股阴冷的浓雾突然出现，很快地包围了你。",
		"只听你嘿嘿嘿几声奸笑，身法变得更加奇诡难测，接着双掌一划，丝丝白气自掌心冒出，",
		"你得到一只烤鸭。",
		"鬼卒将你的「阴司路引」收了起来，伸手指了指关门，好象是叫你进去。",
		"你觉得自己的意识越来越弱，渐渐不省人事了。。。",
		"一个守关鬼卒手执剑戟来到你面前，伸手抓住你项上的「阴司路引」仔细检查着。",
		"只见你口中叫道「差尔刺呼，哈虎」，忽做头下脚上之形，双手撑地，蹦来蹦去。",
		"突然你感觉到好像有东西在背后对着你的脖子吹气！",
		"你只觉得一阵头晕, 眼前只看见五彩斑斓的一片模糊, 原来你中的千蛛万毒手发作了!",
		"你觉得一股冷气从直透心口，全身立时寒战，牙齿互击，格格作响。",
		"忽然你一阵头晕目眩，你所中的混元无极劲内伤发作了！",
		"你并未受混元无极劲内伤！",
		"你气凝丹田，运起紫霞神功，脸上紫气大盛。",
		"你吐息呐气，将遍布全身的紫霞真气缓缓散去。",
		"只听得你一声大喝，拳风突然变得猛劲之极，身法却更加飘忽难测！","你已在使用雷动九天了",
		"你运起玄门先天功，内力遍布全身，头顶冒出丝丝热气，竟然呈现三朵莲花，紧跟劈出一掌，一股气劲似浪潮一般向.+袭来！","你已在使用三花聚顶了！",
		"你身法突然加快，身形更加飘忽","你已在使用逍遥游了！",
		"你脸上青气大盛.+碧涛玄功已发挥到极致","你正在运用「移形换位」心法",
		"你只觉真气运转不畅，不得不放慢步法，调息吐纳。",
		"只见你微微一笑，神情安宁，眼中竟似没有他人一样。","你已经在运用素心诀了。",
		"你玉女心经心法渐渐散去，神情逐渐恢复常态。",
		".+江湖各大门派妄想进攻光明顶",".+一批正派弟子已经攻向了",
		".+我明教上下一心，终于成功打退那帮所谓名门正派的进攻",
		"你觉得精气极为不足","你觉得气血严重淤塞","你觉得精神非常不振",
		"但见阴天子把手一招，飘来了牛头马面，架起你就往内殿而去。",
		"你一阵摇晃, 猛提丹田之气却提不上来，结果险些摔倒.",
		"一阵微风吹过，四面景致似乎起了些变化。",
		"你脸色转白，身上那股逼人的阴寒之气渐渐消失！",
		"只见你蹲在地下，双手弯与肩齐，宛似一只大青蛙般作势相扑，口中发出老牛嘶鸣般的咕咕之声，时歇时作。",
		"(.+)说道:“辛苦你了，(.+)，你为本门立下了一功。”",
		"丁春秋说道:“干得好，(.+)，老仙我越来越欣赏你了。”",
		".+酒袋已经被喝得一滴也不剩了。",
		"(\\S+) \-(.+)",
		"看来该找机会逃跑了...",
		"你目前还没有任何为 rbt=start 的变量设定。",
		"一个蒙面人向你走了过来，满身的杀气，看来似乎不是易与之辈。",
		"一股罡气自丹田涌出，直冲天灵，你痛得几乎晕死过去！",
		"只听你闷哼了一声, 后心已被.+指力戳中.",
		"你猛然觉得一阵寒气袭来，身子一晃，头脑微微有些发昏。",
		"你大喝一声，手中刀光霍霍，招招连环，快如电闪！",
		"你无法这样做。",
		"你的混天气功运行完毕，将内力收回丹田，手上招数也逐渐慢了下来。",
		"你的混天气功运行完毕，将内力缓缓收回丹田。",
		"一个.+弟子走了过来,对你报拳道：“在下奉(.+)之命，请你速回.+处晋见”。",
		"你大喝一声.+使出“十字砍”的凌厉刀势。","这正是你成名绝技“十字砍”",
		"突然间你双刀交错，“十字砍”已然招毕",
		"你.+(握在手中|取出白龙剑)",
		"你终于恢复了一点自信",
		"你吃下一颗大还丹，只觉得体内真力源源滋生，过紫宫，入泥丸",
		"你吃下一棵首乌精，药效立刻通彻肺腑，直达四肢。不仅精力大振，连伤痛也全都感觉不到了。",
		"你从何红药那里买下了一棵首乌精。",
		".+给你一棵首乌精。",
		"你捡起一个酥油罐。",
		"你丢下一本《玄门内功心法》。",
		"  重剑\\(Zhongjian\\)",
		"你身上带着.+件物品.+：",
		"目前你身上没有任何东西。",
		"你目前还没有任何为 checkitems=yes 的变量设定。",
		"你的经脉倒转运行完毕，经脉回复一如往常。",
		"你的龙象之力运行完毕，将内力收回丹田。",
		"你的内力增加了！！",
		"你的最大内力上升了(\\d+)点。",
		"你缓缓吸了一口气，将内劲收回丹田。",
		"你吸了一口气，将内力收回丹田！",
		"你口中默念大明六字真言，手结摩利支天愤怒印，运起.+之力！",
		"在寒玉床上要专心打坐！",
		"你已经将.+酒袋里的清水喝得底朝天了。",
		"阿二正盯著你看，不知道打些什么主意。",
		"阿三正盯著你看，不知道打些什么主意。",
		"方东白正盯著你看，不知道打些什么主意。",
		"你心诚意真地等了良久，突然大地一阵震动，两块试心石分", --xuantie-jian
		"【闲聊】.+\\(Mengzhu\\)：哈哈哈，到底是长江後浪推前浪，一代新人换旧人！",
		"没干完活儿就想溜，没门儿！",
		"你使不了那么多法轮。",
		"你体内聚毒过多，难以继续提高。",
		"先解.+上的兵将再离开吧。",
		"你阴柔之气不足，无法练习更高等级的辟邪剑法。",
		"你吃下一粒补阴丸，只觉得浑身一阵冰凉，一股阴寒之气之丹田串向全身，刹那间阳气锐减，阴气陡增。",
		"你一觉醒来，只觉精力充沛。该活动一下了。",
		"随着哨子声，玉笛里突然飞出蓝印印的一点火星，火星陡地熄灭，随即大亮，蓬的一声响，腾向半空，升起有丈许，这才缓缓降落。",
		"【丐帮】(\.+)\\((\\w+)\\)：各勘察大队：寒潮将至，请注意保暖。家中安好，勿挂念！",
		"(\.+)\\((\\w+)\\)告诉你：来电收悉，老家保重",
		"【队伍会话】.+：集合",
		"您目前 wlmz 的变量设定为： \\d+",
		"数码世界，数字地图，(\\d+)就是这里！",
	}
	local  always_watch_triggerlist={
	       {name="always_watch_dosth1",regexp=linktri(_tb),script=function(n,l,w)    always_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(always_watch_triggerlist) do
		addtri(v.name,v.regexp,"always_watch",v.script,v.line)
	end

	local noecho_trilist={
			"你目前还没有任何为",
			"设定环境变量：idle",
		--	"你身上没有",
			"你正忙着呢","你现在不忙","你现在很忙","你现在正忙着呢",
			"只听得江面上隐隐传来：“别急嘛，这儿正忙着呐……”",	
			"你正在运用","你正忙碌着呢",
			"你目前还没有任何为 date 的变量设定。",
			}
	local _noechotri=linktri(noecho_trilist)

	addtri("always_watch_gag_dosth1",_noechotri,"always_watch","")
	SetTriggerOption("always_watch_gag_dosth1","omit_from_output",1)
	
	AddTimer("cmdcount_timer", 0, 0, 0.1, "", timer_flag.Enabled + timer_flag.Replace, "cmd.numsdecrease")
	SetTimerOption("cmdcount_timer", "group", "cmdcount")
	closeclass("cmdcount")
	AddTimer("always_watch_timer10", 0, 0, 10, "", timer_flag.Enabled + timer_flag.Replace, "always_watch.timer10")
	SetTimerOption("always_watch_timer10", "group", "always_watch")
	AddTimer("always_watch_timer30", 0, 0, 30, "", timer_flag.Enabled + timer_flag.Replace, "always_watch.timer30")
	SetTimerOption("always_watch_timer30", "group", "always_watch")
	AddTimer("always_watch_timer60", 0, 1, 0, "", timer_flag.Enabled + timer_flag.Replace, "always_watch.timer60")
	SetTimerOption("always_watch_timer60", "group", "always_watch")
	AddTimer("always_watch_timer1d", 1, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "always_watch.timer1d")
	SetTimerOption("always_watch_timer1d", "group", "always_watch")
	for i=0,23,1 do
		AddTimer("always_watch_log_timer"..tostring(i), i, 0, 1, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.AtTime, "always_watch.timer_log")
		SetTimerOption("always_watch_log_timer"..tostring(i), "group", "always_watch")
	end
	AddTimer("always_watch_reset_war", 23, 50, 0, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.AtTime, "always_watch.resetwar")
	SetTimerOption("always_watch_reset_war", "group", "always_watch")
	openclass("always_watch")

	_tb={
		"你目前还没有任何为 check=lifesavehp 的变量设定。",
		"有一天，你踩着七色云彩来迎娶『俞岱岩』",
		"数码世界，数字地图，950就是这里！",
		"数码世界，数字地图，(\\d+)就是这里！",
		"你目前还没有任何为 checkexpover=death 的变量设定。",
		"你目前还没有任何为 check=lifesaveover 的变量设定。",
	}
	local  watch_death_triggerlist={
	       {name="watch_death_dosth1",regexp=linktri(_tb),script=function(n,l,w)    watch_death.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(watch_death_triggerlist) do
		addtri(v.name,v.regexp,"watch_death",v.script,v.line)
	end
	AddTimer("watch_death_timer", 0, 0, 10, "", timer_flag.Enabled + timer_flag.Replace, "alias.resetidle")
	SetTimerOption("watch_death_timer", "group", "watch_death")
	closeclass("watch_death")
	
	AddAlias("alias_goto","^goto (.*)","",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"alias.goto")
	AddAlias("alias_gotonpc","^gotonpc (.*)","alias.flytonpc('%1')",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	AddAlias("alias_wai","^wai$","alias.gps()",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	AddAlias("alias_fn","^fn$","",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"alias.flytonext")
	AddAlias("alias_for","^#(\\d+) (.+)","alias.loop('%1','%2')",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	AddAlias("alias_setproxy","^setproxy (.+) (.+) (.+)","alias.setproxy('%1','%2','%3')",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	SetAliasOption("alias_gotonpc","send_to",12)
	SetAliasOption("alias_wai","send_to",12)
	SetAliasOption("alias_for","send_to",12)
	SetAliasOption("alias_setproxy","send_to",12)
	
		---------------alias war一键teamwith
	AddAlias("alias_war","^war$","warteam()",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	SetAliasOption("alias_war","send_to",12)
		---------------alias 运气 运精 运精力
	AddAlias("alias_regenerate","^yj$","run('yun regenerate')",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	AddAlias("alias_refresh","^yjl$","run('yun refresh')",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	AddAlias("alias_recover","^yq$","run('yun recover')",alias_flag.Enabled + alias_flag.Replace+ alias_flag.RegularExpression ,"")
	SetAliasOption("alias_regenerate","send_to",12)
	SetAliasOption("alias_refresh","send_to",12)
	SetAliasOption("alias_recover","send_to",12)
	SetAliasOption("alias_regenerate","group","recover")
	SetAliasOption("alias_refresh","group","recover")
	SetAliasOption("alias_recover","group","recover")
	
		---------------tri 高亮显示特殊字符
	AddTriggerEx ("change_clour1","你","", 1+8+32+1024, custom_colour.Custom2, 0, "", "", 12, 100)
	SetTriggerOption("change_clour1","group","always_watch")
	AddTriggerEx ("change_clour2","重剑","", 1+8+32+1024, custom_colour.Custom3, 0, "", "", 12, 100)
	SetTriggerOption("change_clour2","group","always_watch")
end
always.update()