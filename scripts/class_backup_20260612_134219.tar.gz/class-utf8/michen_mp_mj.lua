local _tb
------------------------------------------------------------------------------------
-- mp_mj_pre
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	mj._ydtp=1900
	if me.shijian>=600 and mj.haveyd>0 and mj.yudi>0 and mj.ydnpckilled==0 and (not stat.use_jinhua or mj.lvl==6) and isInQuitTimeWindow() then
		alias.flytoid(1389)
	else
		alias.flytoid(596)
	end
end
_tb={"你目前还没有任何为 dealwithitems=over 的变量设定。",}
maketri("mp_mj_pre_dosth",_tb,"mp_mj_pre",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	mj.searchid=1
	mj.err=0
	mj.ydnpc=0
	mj.killid=""
	if stat.use_jinhua then 
		run("drop biao;ask wu about 金花;get biao")
	end
	wait.make(function()
		_f=function()		
			alias.dz(set_neili_job)			
		end
		wait.time(1);_f()
	end)
end
_tb={"数码世界，数字地图，596就是这里！",}
maketri("mp_mj_pre_dosth",_tb,"mp_mj_pre",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	run("h;quit")
end
_tb={"数码世界，数字地图，1389就是这里！",}
maketri("mp_mj_pre_dosth",_tb,"mp_mj_pre",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if not isopen("boat") then
		alias.resetidle()
		closeclass("mp_mj_pre")
		if mj_need_yudi() and mj.wxq==0 and mj.tyjob==0 then --2025.6.3临时修改，打开5xq就不去yudi
			stat.jingang=0
			stat.leidong=0
			pfmid=1
			mj.rekill=0
			stat.liuhe=0
			mj.killlist={}
			--mj.ydnpckilled=0
			run("order fighter do halt;order fighter 2 do halt;wavefighter fighter;wavefighter fighter;menpai")
			openclass("mp_mj_yudi")
			--alias.flytonpc("吴劲草")
			alias.dz(set_neili_global)
		elseif havefj>0 then 
			alias.startworkflow()
		elseif mj.wxq>0 then
			openclass("mp_mj_wxq")
			if mj.joblist=="挖地道" then
				alias.flytonpc("颜垣")
			elseif mj.joblist=="砍树" then
				alias.flytonpc("闻苍松")
			elseif mj.joblist=="挖矿" then
				alias.flytonpc("庄铮")
			elseif mj.joblist=="打铁" then
				alias.flytonpc("辛然")
			else
				alias.flytonpc("唐洋")	
			end
			--alias.flytonpc("唐洋")
			--print("还没做好")
			--alias.startworkflow()
		elseif mj.tyjob>0 then
			openclass("mp_mj_tyjob")
			alias.flytonpc("殷野王")
		else
			--if hp.pot<hp.maxpot then alias.flytonpc("杨逍") else alias.startlianwu() end
			openclass("mp_mj_pre")
			alias.startlianwu()
		end
	end
end
_tb={"你目前还没有任何为 dazuo=over 的变量设定。",}
maketri("mp_mj_pre_dosth",_tb,"mp_mj_pre",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if not isopen("boat") then
		alias.dz("addneili")
	end
end
_tb={"你目前还没有任何为 lian=over 的变量设定。",}
maketri("mp_mj_pre_dosth",_tb,"mp_mj_pre",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
		alias.startworkflow()
end
_tb={"你目前还没有任何为 checkexpover=mp 的变量设定。",}
maketri("mp_mj_pre_dosth",_tb,"mp_mj_pre",_ft)
closeclass("mp_mj_pre")
	--if findstring(l,"有一天，你踩着七色云彩来迎娶『杨逍』") then
	--	alias.resetidle()
		--if hp.pot<hp.maxpot then run("ask yang xiao about 奖励") end
	--end
------------------------------------------------------------------------------------
-- mp_mj_yudi
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
		--print("表单统计到"..#mj.killlist.."敌人")
		if ybjob.waitlimit>0 and ybLimited==0 then 
			alias.startyb()
		elseif tonumber(mj.ydnpc)==0 or tonumber(mj.ydnpc)>tonumber(mj._ydtp) then
			--alias.close_kill()
			_tb=Split(mj.search,"|")
			if mj.haveyd<1 or mj.err>5 then
				alias.flytonpc("吴劲草")
			elseif tonumber(mj.searchid)>tonumber(#_tb) then
				if mj._ydtp<mj.ydtp then
				mj._ydtp=mj._ydtp+5
				end
				alias.flytonpc("吴劲草")
			else
				if mj.yudi==3 or tonumber(mj.ydnpc)>tonumber(mj.ydtp) then run("halt") end
				run(_tb[mj.searchid])
				mj.searchid=mj.searchid+1
				mj.killid=""
				--if tonumber(mj.ydnpc)>tonumber(mj.ydtp) or always.where=="巴达克山" then run("halt") end
				run("set search=yes")
			end
			mj.ydnpc=0
			mj.killlist={}
		else
			_tb=Split(mpyun,"|")
			for k,v in ipairs(_tb) do run(v) end
			AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
			SetTimerOption("kill_timer", "group", "kill")
			check_battleidle=0
			openclass("kill")
			openclass("kill_pfm")
			closeclass("kill_run")
			reyun=1
			rekill=0
			runaway=false
			npcfaint=false
			killRunSuccess=false
			killid=""
			killname="npc"
			killskill=mpweapon
			killpfm=mppfm
			killyun=mpyun
			killjiali=mpjiali
			killjiajin=mpjiajin
			if mj.killid=="" and hp.exp>600000 and #mj.killlist>0 then
				mj.killid=mj.killlist[1]["id"]
			end
			if mj.killid~="" and hp.exp>600000 then 
				if stat.use_jinhua then alias.pfm() else run("kill "..mj.killid) end
			end
		end
end
_tb={"你目前还没有任何为 search=yes 的变量设定。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	if hp.exp<650000 then mj.yudi=3 end
	if mj.yudi==1 then mj.search=mj.yd1 else mj.search=mj.yd2 end
	mj.searchid=1
	mj.err=0
	mj.ydnpc=0
	mj.killid=""
	if mj.haveyd==1 then
		if mpjf~=nil and mpjf~="" then alias.jf(mpjf) end
		alias.checkitems()
	else
		if fjjf~=nil and fjjf~="" then alias.jf(fjjf) end
		alias.startworkflow()
	end
end
_tb={"有一天，你踩着七色云彩来迎娶『吴劲草』",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	alias.resetidle()
	if mj_need_yudi() then 
		alias.dz(set_neili_job) 
	else 
		alias.dz(set_neili_global) 
	end
end
_tb={"你目前还没有任何为 dealwithitems=over 的变量设定。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if not isopen("boat") then
		alias.resetidle()
		if roomno_now~=596 then 
			alias.flytonpc("吴劲草")
		elseif mpJobLimited>0 and havefj>0 then
			alias.startfj()
		else
			stat.jingang=0
			stat.leidong=0
			stat.liuhe=0
			pfmid=1
			if string.len(mpweapon)>0 then
				--wieldweapon=1
				if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
			else 
				alias.uw() 
			end
			mj.killlist={}
			--fighter;shoutfighter fighter;
			killskill=mpweapon
			killpfm=mppfm
			killyun=mpyun
			killjiali=mpjiali
			killjiajin=mpjiajin
			run("jiali "..killjiali..";jiajin "..killjiajin)
			run("unset no_parry;yield no;set search=yes")
		end
	end
end
_tb={"你目前还没有任何为 dazuo=over 的变量设定。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	mj.err=mj.err+1
end
_tb={"这个方向没有出路。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(w[0],"(.+)脚下一个不稳，跌在地上昏了过去。")
	if c~=nil then
		for k,v in ipairs(mj.killlist) do 
			if v["name"]==c then
				ResetTimer("kill_timer")
				if (mj.rekill==nil or mj.rekill==0) and mpJobLimited==0 and mj.lvl<6 and not stat.use_jinhua then
					run("halt")
					mj.rekill=1
				end
				if (tonumber(war.team)~=nil and war.team>0) or mj.lvl<5 then
					run("kill "..v["id"])
				end
				break
			end
		end
	end
end
_tb={".{4,8}脚下一个不稳，跌在地上昏了过去。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(w[0],"(.+)倒在地上，挣扎了几下就死了。")
	if c~=nil then
		for k,v in ipairs(mj.killlist) do 
			if v["name"]==c then
				table.remove(mj.killlist,k)
				if mj.killid==v["id"] and #mj.killlist>0 then mj.killid=mj.killlist[1]["id"] end
				break
			end
		end
	end
end
_tb={".{4,8}倒在地上，挣扎了几下就死了。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	if isopen("mp_mj_yudi") then
		mj.ydnpc=0
		mj.killid=""
		mj.rekill=0
		mj.killlist={}
	end	
end
_tb={"\\s+这里唯一的出口是 .+。","\\s+这里明显的出口是 .+。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)

local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	print("这里有"..mj.ydnpc.."个敌人, 总计击杀"..mj.ydnpckilled.."个敌人，获得["..mpLimited.mpexp.."]经验，花费时间："..tonumber(os.time()-mpLimited.MarkTime))
	alias.resetidle()
	if hp.healthqi<75 or tonumber(hp.neili)<tonumber(hp.maxneili*75/100) then
		runaway=true
	end
	if mj.ydnpc>=mj._ydtp then
		if string.len(mpweapon)>0 and (getweapon==1 or have[mpweapon]<1) then
			run("halt;get "..killskill) 
		end
		alias.close_kill()
		--alias.flytoid(585)
		run("halt;set search=yes")
	elseif runaway then
		if string.len(mpweapon)>0 and (getweapon==1 or have[mpweapon]<1) then
			run("halt;get "..killskill) 
		end
		alias.close_kill()
		alias.flytoid(585)
	elseif mj.ydnpc==0 and not isopen("checkbusy") then 
		print("敌人杀干净了，准备eat ydkillover")
		alias.checkbusy("ydkillover")
	elseif mj.killid~="" and hp.exp>600000 and mj.rekill==0 then 
		if not stat.use_jinhua then run("kill "..mj.killid) end
	end
end
_tb={"你目前还没有任何为 check=kill 的变量设定。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
		alias.close_kill()
		mj.killid=""
		mj.killlist={}
		if stat.use_jinhua then run("get jinhua") end
		run("look;set search=yes")
end
_tb={"你目前还没有任何为 busyover=ydkillover 的变量设定。","你目前还没有任何为 busyover=killover 的变量设定。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	runaway=true
end
_tb={"你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑","你摇头晃脑","你已经一副头重脚轻的模样",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if killskill=="" and mpjf~=nil and mpjf~="" then
		run(mpjf)
	else
		runaway=true
	end
end
_tb={".+你.+臂麻木，无力再使.+", "你请先用 enable 指令选择你要使用的外功"}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	--	_f=function() run("yun refresh") end
	--	wait.time(1);_f()
		alias.flytonpc("吴劲草")
end
_tb={"数码世界，数字地图，585就是这里！",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	--mpJobLimited=0
	mj.ydnpckilled=mj.ydnpckilled+1
	mj.checklimited=0
	if mj.checkexp==nil or mj.checkexp==0 then
		mj.checkexp=1
		if (os.time()-mpLimited.MarkTime>=3600) or mpJobLimited>0 then
			mpLimited.MarkTime=os.time()
			mpLimited.mpexp=0
		end
		mpJobLimited=0
		alias.checkexp("yudi")
	end
end
_tb={"你击毙围攻光明顶敌人一名！"}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
--[[local function _ft(n,l,w)		--废弃，与checkexp系统冲突
	local _tb,a,b,c,d,_f
	--mpJobLimited=0
	mj.ydnpckilled=mj.ydnpckilled+1
	if mj.checklimited==nil then mj.checklimited=0 end
	if mj.checklimited>2 or mpLimited.mpexp>13000 then
		mpJobLimited=1
		--alias.startworkflow()
		if not isopen("checkexp") then alias.checkexp("yudi") end
	else
		mj.checklimited=mj.checklimited+1
	end
end
_tb={"你杀敌许久，感觉有些累了。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)]]--
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	mj.checkexp=0
	if mpJobLimited>0 then 
		alias.startworkflow()
	end
end
_tb={"你目前还没有任何为 checkexpover=yudi 的变量设定。",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d,e=string.find(l,"[华山|峨嵋|少林|武当]+派弟子%s(%S+)%((%w+)%s(%w+)%)")
	if c~=nil and d~=nil and e~=nil and not findstring(l,"强盗","江湖侠士","魔教弟子","邪派弟子","蒙古哒子") then
		local _tb={name=c,id=string.lower(d).." "..string.lower(e),}
		table.insert(mj.killlist,_tb)
		mj.killid=string.lower(d).." "..string.lower(e)
		if findstring(l,"昏迷不醒") then 
			if mj.rekill==0 and mpJobLimited==0 and mj.lvl<6 and not stat.use_jinhua then
				run("halt")
				mj.rekill=1
			end
			if (tonumber(war.team)~=nil and war.team>0) or mj.lvl<5 then
				run("kill "..mj.killid)
			end
		--elseif mj.killid=="" then mj.killid=string.lower(d).." "..string.lower(e) 
		end
		if mj.yudi<3 or (mj.yudi==3 and findstring(l,"战斗中","昏迷不醒")) then mj.ydnpc=mj.ydnpc+1 end
	end
end
_tb={"  [华山|峨嵋|少林|武当]+派弟子 \\S+\\(\\w+ \\w+\\).*",}
maketri("mp_mj_yudi_dosth",_tb,"mp_mj_yudi",_ft)

closeclass("mp_mj_yudi")
------------------------------------------------------------------------------------
-- mp_mj_wxq
------------------------------------------------------------------------------------
function alias.wxqask()
	if roomno_now==466 then run("ask tang yang about 木桶;ask tang yang about job")
	elseif roomno_now==554 then run("ask yan yuan about 铁锹;ask yan yuan about job")
	elseif roomno_now==449 then run("ask wen cangsong about 斧头;ask wen cangsong about job")
	elseif roomno_now==597 then run("ask zhuang zheng about 铁锹;ask zhuang zheng about job")
	elseif roomno_now==444 then run("ask xin ran about job")
	elseif roomno_now==596 then run("ask wu jincao about 精铁;ask wu jincao about 打铁")
	else 
		if mj.joblist=="挖地道" then
			alias.flytonpc("颜垣")
		elseif mj.joblist=="砍树" then
			alias.flytonpc("闻苍松")
		elseif mj.joblist=="挖矿" then
			alias.flytonpc("庄铮")
		elseif mj.joblist=="打铁" then
			alias.flytonpc("辛然")
		else
			alias.flytonpc("唐洋")	
		end
	end
end
function mp_mj_wxq.dosomething1(n,l,w)
	local a,b,c
	if findstring(l,"有一天，你踩着七色云彩来迎娶『.+』") then
		alias.resetidle()
		if havefj>0 then alias.startworkflow() else alias.dz(set_neili_global) end
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。","唐洋给你一个木桶。","颜垣给你一把铁锹。","闻苍松给你一把斧头。","庄铮给你一把铁锹。","吴劲草给你一把铁锤。","辛然对着你点了点头。","吴劲草拿了一块精铁给你") then
		alias.resetidle()
		alias.wxqask()
	end
	if findstring(l,"数码世界，数字地图，.+就是这里！") then openclass("mp_mj_wxqjob") end
	if findstring(l,"你小心翼翼地","你挥动铁锹","你挥动大斧","你将铁锹拿在手上","你挥动大铁锤","你放进燃料","精铁已经开始溶化了","你往火枪模子里") then
		alias.resetidle()
	end
	if findstring(l,"你的明教功绩上升了%d+点。") then
		alias.startworkflow()
	end
	if findstring(l,"木桶这东西可装不了水","你把木桶里的水全部倒进大水缸里","你又挖通了一段地道","密道终于又向前挖进了一步！","你已经完成任务了，赶快回去复命吧！","你并没有挖地道的工作。","你使劲一抬，将刚砍下来的树干扛到肩上","你将一小块乌金矿石拿起来","你已经有一块矿石","我不是已給你铁锤了么","精铁终于炼出来了","你捡起一块硝磺石","火枪已经制成") then
		alias.resetidle()
		closeclass("mp_mj_wxqjob")
		alias.checkbusy("jobover")
	end
	if findstring(l,"你目前还没有任何为 busyover=jobover 的变量设定。") then
		alias.resetidle()
		if roomno_now==461 then alias.flytoid(469)
		elseif roomno_now==469 then alias.flytonpc("唐洋")
		elseif roomname=="地道" then alias.flytonpc("颜垣")
		elseif roomno_now==446 or roomno_now==450 then alias.flytonpc("闻苍松")
		elseif roomno_now==590 then alias.flytonpc("吴劲草") 
		elseif roomno_now==596 then _tb={594,595};alias.flytoid(_tb[math.random(1,2)])
		elseif roomno_now==594 or roomno_now==595 then run("h;nw;n;n;give jing tie to wu jincao")
		elseif roomno_now==539 then alias.flytoid(599) 
		elseif roomno_now==599 then run("h;w;w;give huo qiang to xin ran")
		end
	end
	if findstring(l,"这个火炉已经有人在用了") then
		alias.resetidle()
		if roomno_now==594 then alias.flytoid(595) else alias.flytoid(594) end
	end
end
function mp_mj_wxq.dosomething2(n,l,w)
	local a,b,c,d
	a,b,c,d=string.find(w[0],"你向(.+)打听有关「.+」的消息。\n(.+)")
	if c~=nil and d~=nil then
		if findstring(d,"现在最好去其他旗主那里看看有没有合适的任务") then
			if roomno_now==466 then alias.flytonpc("颜垣")
			elseif roomno_now==554 then alias.flytonpc("闻苍松")
			elseif roomno_now==449 then alias.flytonpc("庄铮")
			--elseif roomno_now==597 then alias.flytonpc("辛然")
			elseif roomno_now==597 then 
				if workflow.xf>0 and daytimes>1 and daytimes<6 and hp.pot<=hp.maxpot then 
					if skillslist["manicheism"]["lvl"]>500 then 
						workflow.xf=0			  --二宗三际超过500级，就关闭心法模块
						alias.startworkflow()
					else
						alias.startxinfa()
					end
				else 
					alias.startxue() 
				end
			elseif roomno_now==444 then alias.flytonpc("唐洋")
			end
		elseif findstring(d,".+说道：这位.+现在不是在挑水吗？等完成了再来领取其它任务吧。") then
			alias.flytoid(461)
		elseif findstring(d,".+说道：这位.+现在不是在挖地道吗？等完成了再来领取其它任务吧。") then
			alias.flytoid(550)
		elseif findstring(d,".+说道：这位.+现在不是在砍树吗？等完成了再来领取其它任务吧。") then
			alias.flytoid(446)
		elseif findstring(d,".+说道：这位.+现在不是在采集铁矿吗？等完成了再来领取其它任务吧。") then
			alias.flytoid(590)
		elseif findstring(d,".+然说道：这位.+现在不是在打造火枪吗？等完成了再来领取其它任务吧。") then
			alias.flytonpc("吴劲草") 
		elseif findstring(d,"吴劲草说道：你不是已经有一块了吗？还想要，真是贪得无厌。") then
			alias.flytoid()
		end
	end
end
------------------------------------------------------------------------------------
-- mp_mj_wxqjob
------------------------------------------------------------------------------------
function mp_mj_wxqjob.timer()
	if havefj>0 then alias.startfj()
	elseif roomno_now==461 or roomno_now==469 then run("fill tong;dao water into gang")
	elseif roomname=="地道" then run("dig north")
	elseif roomno_now==446 or roomno_now==450 then run("kang shu gan;wield axe;chop tree;unwield axe")
	elseif roomno_now==590 or roomno_now==594 or roomno_now==595 then run("dig;tou 矿石 in 火炉;da 铁")
	elseif roomno_now==539 then run("get xiaohuang shi")
	elseif roomno_now==599 then run("fang 精铁 in 熔炉;dao 铁水 in 火枪模子;add 硝磺 in 火枪模子")
	end
end
------------------------------------------------------------------------------------
-- mp_mj_tyjob
------------------------------------------------------------------------------------
function mp_mj_tyjob.dosomething1(n,l,w)
	local a,b,c,d,e
	a,b,c=string.find(w[0],"有一天，你踩着七色云彩来迎娶『(.+)』")
	if c~=nil and findstring(c,"殷野王") then
		if havefj>0 then alias.startworkflow() else run("ask yin yewang about job") end
	elseif c~=nil and findstring(c,"杨逍","韦一笑","周颠","冷谦","彭莹玉","张中","说不得","清平道人","哈斯","肖济民","吴宝琴","庄铮","吴劲草","唐洋","辛然","颜垣","闻苍松") then
		mj.tyjobnpc=c
		mj.tyjobnpcid=""
		run("id here;set checknpc")
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		AddTimer("mj_tyjob_wait_timer",0,0,30,"",timer_flag.Enabled + timer_flag.OneShot, "alias.tlw")
		alias.startlianwu()
	end
	if findstring(l,"你目前还没有任何为 lian=over 的变量设定。") then
		alias.resetidle()
		closeclass("skills_lian")
		alias.close_dz()
		DeleteTimer("mj_tyjob_wait_timer")
		alias.uw()
		if havefj>0 then alias.startworkflow() else run("h;ask yin yewang about job") end
	end
	a,b,c,d=string.find(l,"^"..tostring(mj.tyjobnpc).."%s+=%s+(%w+)%s+(%w+),%s*")
	if c~=nil and d~=nil then
		mj.tyjobnpcid=string.lower(c).." "..string.lower(d)
	end
	if findstring(l,"你目前还没有任何为 checknpc 的变量设定。") then
		alias.resetidle()
		if mj.tyjobnpcid~=nil and mj.tyjobnpcid~="" then run("halt;give mihan to "..mj.tyjobnpcid) end
		alias.flytonpc("殷野王")
	end
	if findstring(l,"双飞，三飞，大家一起飞，先×4 个『 周颠 』中的第.+ 个～～") then
		run("give mihan to zhou dian")
		alias.flytonext()
	end
	if findstring(l,"全部NPC搜索完毕！") then
		alias.flytonpc("殷野王")
	end
end
function mp_mj_tyjob.dosomething2(n,l,w)
	a,b,c=string.find(w[0],"你向殷野王打听有关「job」的消息。\n殷野王(.+)")
	if c~=nil and findstring(c,"最近.+总跟我教做对","教主叫你把.+找来","皱了皱眉，似乎想说什么") then
		run("ask yin yewang about abandon")
		alias.dz(set_neili_global)
	end
end
function mp_mj_tyjob.dosomething3(n,l,w)
	if findstring(w[0],"你向殷野王打听有关「job」的消息。\n殷野王拍了拍你的肩膀。\n殷野王说道：很好，我会禀告教主嘉奖你的！") then
		closeclass("mp_mj_tyjob")
		openclass("mp_mj_pre")
		alias.checkexp("mp")
	end
	a,b,c=string.find(w[0],"你向殷野王打听有关「job」的消息。\n殷野王给你一封密函。\n殷野王说道：教主叫你把这封信送给(.+)，事关重大，快去快回！")
	if c~=nil and findstring(c,"杨逍") then alias.flytonpc("杨逍")
	elseif c~=nil and findstring(c,"韦蝠王") then alias.flytonpc("韦一笑")
	elseif c~=nil and findstring(c,"周颠") then alias.flytonpc("周颠")
	elseif c~=nil and findstring(c,"冷谦") then alias.flytonpc("冷谦")
	elseif c~=nil and findstring(c,"彭莹玉") then alias.flytonpc("彭莹玉")
	elseif c~=nil and findstring(c,"张中") then alias.flytonpc("张中")
	elseif c~=nil and findstring(c,"说不得") then alias.flytonpc("说不得")
	elseif c~=nil and findstring(c,"清平道人") then alias.flytonpc("清平道人")
	elseif c~=nil and findstring(c,"哈斯") then alias.flytonpc("哈斯")
	elseif c~=nil and findstring(c,"肖济民") then alias.flytonpc("肖济民")
	elseif c~=nil and findstring(c,"吴宝琴") then alias.flytonpc("吴宝琴")
	elseif c~=nil and findstring(c,"庄铮") then alias.flytonpc("庄铮")
	elseif c~=nil and findstring(c,"吴劲草") then alias.flytonpc("吴劲草")
	elseif c~=nil and findstring(c,"唐洋") then alias.flytonpc("唐洋")
	elseif c~=nil and findstring(c,"辛然") then alias.flytonpc("辛然")
	elseif c~=nil and findstring(c,"颜垣") then alias.flytonpc("颜垣")
	elseif c~=nil and findstring(c,"闻苍松") then alias.flytonpc("闻苍松")
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function mp_mj.update()
	local _tb
	local  mp_mj_wxq_triggerlist={
	       {name="mp_mj_wxq_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_mj_wxq.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_mj_wxq_triggerlist) do
		addtri(v.name,v.regexp,"mp_mj_wxq",v.script,v.line)
	end
	local _tb2={
		"你向.+打听有关「.+」的消息。\\n(.+)\\Z",
	}
	local  mp_mj_wxq_m_triggerlist={
			{name="mp_mj_wxq_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_mj_wxq.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(mp_mj_wxq_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_mj_wxq",v.script,v.line)
	end
	closeclass("mp_mj_wxq")
	AddTimer("mp_mj_wxqjob_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_mj_wxqjob.timer")
	SetTimerOption("mp_mj_wxqjob_timer", "group", "mp_mj_wxqjob")
	closeclass("mp_mj_wxqjob")
	
	local  mp_mj_tyjob_triggerlist={
	       {name="mp_mj_tyjob_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_mj_tyjob.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_mj_tyjob_triggerlist) do
		addtri(v.name,v.regexp,"mp_mj_tyjob",v.script,v.line)
	end
	local _tb2={
		"你向殷野王打听有关「job」的消息。\\n(.+)\\Z",
	}
	local _tb3={
		"你向殷野王打听有关「job」的消息。\\n(.+)\\n(.+)\\Z",
	}
	local  mp_mj_tyjob_m_triggerlist={
			{name="mp_mj_tyjob_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_mj_tyjob.dosomething2(n,l,w)  end,},
			{name="mp_mj_tyjob_m_dosth3",line=3,regexp=linktri2(_tb3),script=function(n,l,w)    mp_mj_tyjob.dosomething3(n,l,w)  end,},
	}
	for k,v in pairs(mp_mj_tyjob_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_mj_tyjob",v.script,v.line)
	end
	closeclass("mp_mj_tyjob")
	
	--local noecho_trilist={
	--		"你正忙着呢",
	--		"你现在不忙。",
	--		"这里没有这个人。",
	--		"什么？",
	--		"你并没有装备这样东西作为武器",
	--		"只能对战斗中的对手使用",
	--		}
	--local _noechotri=linktri(noecho_trilist)

	--addtri("mp_mj_watch_gag_dosth1",_noechotri,"mp_mj_watch","")
	--SetTriggerOption("mp_mj_watch_gag_dosth1","omit_from_output",1)
end
mp_mj.update()