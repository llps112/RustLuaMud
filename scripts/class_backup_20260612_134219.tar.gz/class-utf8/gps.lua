-----------------------------------------------------------------------------------
-- gps_start
------------------------------------------------------------------------------------
function gps_start.dosomething1(n,l,w)
	local desc=Trim(w[3]) --去除两端空格
	if string.len(desc)==0 then xkxGPS.setDesc("none") else xkxGPS.setDesc(desc) end
end
function gps_start.dosomething2(n,l,w)
	entrance=w[1]
	xkxGPS.setEntrance(entrance)
end
function gps_start.dosomething3(n,l,w)
	roomname=w[2]
	--xkxGPS.setRoomname(roomname)
	xkxGPS["roomname"]=Trim(roomname) --去除两端空格
	if findstring(roomname,"崖顶","地牢") then xkxGPS.setEntrance("none") end
end
function gps_start.dosomething4(n,l,w)
	if w[1]~=gps.EndRoomName then return end
	GPS.End=true
end
function gps_start.dosomething5(n,l,w)
	local _f,_t,_tb
	--if w[2]~="checkGbSecretWay=err" and not findstring(w[2],"gps=") then return end --非GPS的触发不要纳入这个
	if w[2]=="checkGbSecretWay=err" then
		if gpserrnum>0 then set_GbSecretWay_err=set_GbSecretWay_err+1 else set_GbSecretWay_err=0 end
		if set_GbSecretWay_err>=3 then infobtn.set_GbSecretWay();run("score") end
		return
	end
	if w[2]=="gps=end" then
		alias.resetidle()
		if tonumber(roomno_now)~=nil and tonumber(roomno_now)>0 and tonumber(flytoid)~=nil and tonumber(flytoid)>0 then
			--print("gps.lua debug2:"..flytoid)
			path=xkxGPS.search(roomno_now,flytoid)
			gps.End=false
			gps.EndRoomName=xkxGPS.EndRoomName
			gps.EndRoomEntrance=xkxGPS.EndRoomEntrance
			if path==nil or string.len(path)==0 then
				Simulate("目标地点路径未通！flytoid="..tostring(flytoid).."\n")
			--	run("set gps=nopath")
				run("score")
				return
			end
			if path=="isHere" then
				print("飞什么飞，不就在这里么！")
				gps.End=true
				run("set walk over")
				return
			end
			xkxGPS.pathlist(path)
			pathindex=0
			_tb=Split(xkxGPS.pathArray2(pathindex),";")
			_t=string.gsub(_tb[#_tb]," ","")
			MathstepNum.nextLastStepName=string.gsub(_t,"-","")
			if aliasStepNum[MathstepNum.nextLastStepName]==nil then _t=0 else _t=aliasStepNum[MathstepNum.nextLastStepName] end
					run("halt")
					if roomno_now==2112 or roomno_now==2113 or roomno_now==2114 or roomno_now==2115 then run("stand") 
					elseif roomno_now==288 then run("drop qiguo ji;drop puer cha;drop guoqiao mixian;drop guoqiao heiyu;drop ye er ba;drop kaoya")  --大理厨房丢食物，防止卡房间
					elseif roomno_now==682 then run("drop kaoya;drop tao;drop qiguo ji") --武当厨房丢食物，防止卡房间
					elseif findstring(roomname,"南城墙下") then run("up")
					end
					if roomno_now~=91 and roomname~="擂台下" then alias.yjl() end
					run(xkxGPS.pathArray2(pathindex))
		else
			gpserrnum=1
		end
		return
	end
	if w[2]=="gps=check" then
		alias.resetidle()
		if xkxGPS.room_where then
			--print("重新定位")
			roomno_check=xkxGPS.location()
			--print(roomno_check)
			xkxGPS.roomwhere()
		end
		return
	end
	if w[2]=="gps=err" then
		alias.resetidle()
		if xkxGPS.roomcheck==1 then
		print(xkxGPS["roomname"])
		print(xkxGPS["desc"])
		print(xkxGPS["entrance"])
		print("")
		print("房间定位出错，存在重名或未知房间")
		end
		if flytoid>0 then
			--wait.make(function()
				--_f=function()
					run("halt")
					if findstring(roomname,"悬崖") then run("climb down") --end
					elseif findstring(roomname,"戈壁","夏拉") then if hp.jingli>hp.maxjingli/2 then run("s;hp") else run("yun refresh;s;hp") end
					elseif xkxGPS.roomcheck==1 then   --如果没有在定位周围房间
						run("go "..xkxGPS["entrance1"][math.random(1,#xkxGPS["entrance1"])])
					else	--如果在定位周围房间
						run("go "..xkxGPS["room_fx"][math.random(1,#xkxGPS["room_fx"])])
					end
					alias.close_gps()
					if string.len(flytoname)>0 then alias.flytoid_name(flytoid);return end
					if string.len(flytonpc)>0 then alias.flytoid_npc(flytoid);return end
					if flytoid>0 then alias.flytoid(flytoid);return end
				--end
				--wait.time(1);_f()
			--end)
		else
			print('press "yes number" or "no" to add this room')
			AddAlias("alias_addroomyes","^yes (.*)","xkxGPS.Addroom(xkxGPS['roomname'],xkxGPS['desc'],xkxGPS['entrance'],'%1')",alias_flag.Enabled + alias_flag.Replace + alias_flag.RegularExpression + alias_flag.OneShot ,"")
			AddAlias("alias_addroomno","^no$","xkxGPS.DelAddroomAlias()",alias_flag.Enabled + alias_flag.Replace + alias_flag.RegularExpression + alias_flag.OneShot ,"")
			AddAlias("alias_linkroom","^linkroom (.+) (.+)$","xkxGPS.Linkroom('1%','2%')",alias_flag.Enabled + alias_flag.Replace + alias_flag.RegularExpression ,"")
			SetAliasOption("alias_addroomyes","send_to",12)
			SetAliasOption("alias_addroomno","send_to",12)
			SetAliasOption("alias_linkroom","send_to",12)
			SetAliasOption("alias_addroomyes","group","addroom")
			SetAliasOption("alias_addroomno","group","addroom")
		end
		return
	end
	if w[2]=="gps=nopath" then
		alias.resetidle()
		checkmove.NotGPSMove=1
		--wait.make(function()
			--_f=function()
				run("halt;go "..xkxGPS["entrance1"][math.random(1,#xkxGPS["entrance1"])])
				alias.close_gps()
				if string.len(flytoname)>0 then alias.flytoid_name(flytoid);return end
				if string.len(flytonpc)>0 then alias.flytoid_npc(flytoid);return end
				if flytoid>0 then alias.flytoid(flytoid);return end
			--end
			--wait.time(1);_f()
		--end)
		return
	end
	if w[2]=="gps=start" then
		alias.resetidle()
		gpszeikou=""
		roomno_now=0
		roomno_now=xkxGPS.location()
		xkxGPS.roomcheck=1
		if type(roomno_now)=="table" then 
		    tprint(roomno_now)
			--[[if #roomno_now==0 then
				addlog("gps 出错告警")
				addlog(xkxGPS["roomname"])
				addlog(xkxGPS["desc"])
				addlog(xkxGPS["entrance"])
				alias.gps()
				return
			else]]--
			if #roomno_now==1 then 
				roomno_now=roomno_now[1] 
				if roomno_now==1991 then alias.emkilljumang() else run("set gps=end") end
				return
			elseif #roomno_now>0 then
				print("当前房间存在重复,可能的房间如下")
				tprint(roomno_now)
				xkxGPS.room_where=true
				xkxGPS.room_fx=xkxGPS["entrance1"]
				for k,v in pairs(xkxGPS["entrance1"]) do
					alias.gps(v)
				end
				return
			elseif xkxGPS["roomname"]=="中军帐" and isopen("war_pre") then --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;se;s;sw;s;s;s")
				run("look;set gps=start")
				--alias.gps()
				return
			elseif xkxGPS["roomname"]=="飞骑右营" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;s;sw;s;s;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="飞骑左营" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;s;se;s;s;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="前卫右营" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;sw;s;s;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="前卫左营" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;se;s;s;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="蒙古军营前" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;s;s;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="密林" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;s;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="北吊桥" and isopen("war_pre") then  --南阳war地图特殊处理，不加入数据库避免出错
				run("halt;s")
				run("look;set gps=start")
				return
			elseif xkxGPS["roomname"]=="天山山路" and xkxGPS["entrance"]=="westup" and skillslist["zhaixinggong"]~=nil and skillslist["zhaixinggong"]["lvl"]>99 then 
				run("halt;jump valley")
				run("look;set gps=start")
			elseif xkxGPS["roomname"]=="天山山路" and xkxGPS["entrance"]=="eastdown|enter|westup" and skillslist["zhaixinggong"]~=nil and skillslist["zhaixinggong"]["lvl"]>99 then 
				run("halt;ed;jump valley")
				run("look;set gps=start")
			elseif xkxGPS["roomname"]=="山洞" and xkxGPS["entrance"]=="out" and xkxGPS["desc"]=="这个山洞里伸手不见五指，只有出口处透进一丝光线。" and skillslist["zhaixinggong"]~=nil and skillslist["zhaixinggong"]["lvl"]>99 then 
				run("halt;out;ed;jump valley")
				run("look;set gps=start")
			elseif xkxGPS["roomname"]=="小峰" and xkxGPS["entrance"]=="eastdown|southdown" and xkxGPS["desc"]=="这里是天山上一座小小的山峰。从这里向周围望去，帕米尔高原" and skillslist["zhaixinggong"]~=nil and skillslist["zhaixinggong"]["lvl"]>99 then 
				run("halt;ed;ed;jump valley")
				run("look;set gps=start")
			elseif xkxGPS["roomname"]=="山谷" and xkxGPS["entrance"]=="northup|northwest" and xkxGPS["desc"]=="山谷四周都是陡峭的绝壁，谷内稀疏地长着些矮小的灌木。西" and skillslist["zhaixinggong"]~=nil and skillslist["zhaixinggong"]["lvl"]>99 then 
				run("halt;nu;ed;ed;jump valley")
				run("look;set gps=start")
			elseif xkxGPS["roomname"]=="迷宫洞口" and xkxGPS["entrance"]=="southeast" and xkxGPS["desc"]=="转过了一排树木，只见对面一座石山上嵌着两扇铁铸的大门(door)。" and skillslist["zhaixinggong"]~=nil and skillslist["zhaixinggong"]["lvl"]>99 then 
				run("halt;se;nu;ed;ed;jump valley")
				run("look;set gps=start")
			elseif findstring(xkxGPS["roomname"],"阴司第","轮回殿") then 
				alias.resetidle()
				alias.close_gps()			
			else
				print("当前房间不存在")
			end
			if buzhen then run("set gps=buzhen") else run("set gps=err") end
			return 
		elseif type(roomno_now)=="number" then
			if roomno_now>0 then
				if roomno_now==1991 then 
					alias.emkilljumang() 
				elseif roomno_now<2078 and roomno_now>2062 and me.menpai~="gm" then --非古墓派出古墓
					run("w;enter guan;use fire;turn left;d;ed;look;set gps=start")
				else
					if dl.findzei~=nil and dl.findzei>1 then dl.arrest_room=roomno_now end --记录大理抓贼背起来的地方
					print("当前房间号："..roomno_now)
					run("set gps=end") 
				end
			else
				if buzhen then run("set gps=buzhen") else run("set gps=err") end
			end
		end
		return
	end
	if w[2]=="gps=buzhen" then
		alias.resetidle()
		if buzhen then
			buzhen=false
			wait.make(function()
				_f=function() run("look;set gps=buzhen") end
				wait.time(10);_f()
			end)
		else
			run("halt")
			alias.close_gps()
			if string.len(flytoname)>0 then alias.flytoid_name(flytoid);return end
			if string.len(flytonpc)>0 then alias.flytoid_npc(flytoid);return end
			if flytoid>0 then alias.flytoid(flytoid);return end
		end
		return
	end
end
function gps_start.dosomething6(n,l,w)
	local _f,_t,_tb
	--wait.make(function()
		if findstring(l,'设定环境变量：walk = "off"') then
			alias.close_boat()
			alias.resetidle()
			if dropweapon>0 then
				if have["jian"]>0 then for i=1,have["jian"],1 do run("drop jian") end end
				if have["dao"]>0 then for i=1,have["dao"],1 do run("drop dao") end end
				run("get ".._G[workflow.nowjob.."weapon"])
				dropweapon=0
				--alias.gg()
			end
			if string.len(gpszeikou)==0 then
				if gpserrnum==0 then
					pathindex=pathindex+1
					if xkxGPS.pathListNum2>0 and pathindex<=xkxGPS.pathListNum2 then
						if xkxGPS.pathArray2(pathindex)~=nil then
							_tb=Split(xkxGPS.pathArray2(pathindex),";")
							_t=string.gsub(_tb[#_tb]," ","")
						else
							_tb={}
							_t=0
						end
						MathstepNum.nextLastStepName=string.gsub(_t,"-","")
						if aliasStepNum[MathstepNum.nextLastStepName]==nil then _t=0 else _t=aliasStepNum[MathstepNum.nextLastStepName] end
						MathstepNum.next=tonumber(#_tb+_t)
						if pathindex==(xkxGPS.pathListNum2-1) and xkxGPS.pathArray2(xkxGPS.pathListNum2)=="set walk over" and string.sub(xkxGPS.pathArray2(pathindex),-12)=="set walk off" then
							pathindex=pathindex+1
								run("halt")
								_t=string.gsub(xkxGPS.pathArray2(pathindex-1),"set walk off","set walk over");
								run(_t)
						else
								run("halt")
								run(xkxGPS.pathArray2(pathindex))
						end
					else
						--_f=function()
							run("halt")
							run(xkxGPS.pathArray2(0))
						--end
						--wait.time(1);_f()
					end
				else
					--_f=function()
						gpserrnum=0
						checkmove.NotGPSMove=1
						alias.close_gps()
						pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)
						-- Execute(gps_cmd)
					--end
					--wait.time(2);_f()
				end
			else
				if me["menpai"]=="em" then
					_tb=Split(gpszeikou," ")
					run("kill ".._tb[3]..";halt;persuade ".._tb[3])
				else alias.fjskillskill(gpszeikou) end
			end
		end
		if findstring(l,'设定环境变量：walk = "over"') then
			alias.close_boat()
			alias.resetidle()
			flytosum=0
			flytoidx=0
			if dropweapon>0 then
				if have["jian"]>0 then for i=1,have["jian"],1 do run("drop jian") end end
				if have["dao"]>0 then for i=1,have["dao"],1 do run("drop dao") end end
				run("get ".._G[workflow.nowjob.."weapon"])
				dropweapon=0
				--alias.gg()
			end
			if not GPS.End then
				gpserrnum=1
				checkmove.NotGPSMove=1
			end
			if string.len(flytoname)>0 then
				alias.walkover_flytoname()
			elseif string.len(flytonpc)>0 then
				alias.walkover_flytonpc()
			else alias.walkover_flytoid() end
		end
	--end)
end
------------------------------------------------------------------------------------
-- gps_watch
------------------------------------------------------------------------------------
function gps_watch.kill_zeikou(id,name)
	run("unset no_parry")
		reyun=1
		npcfaint=false
		killRunSuccess=false
		openclass("kill")
		openclass("kill_pfm")
		--openclass("kill_"..me.menpai)
		closeclass("kill_run")
		AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
		SetTimerOption("kill_timer", "group", "kill")
		runaway=false
		alias.uw()
		--if me.menpai=="hs" and fjweapon~="" then
		if jifa["forcename"]=="zixia-gong" then --门派判断改成内功判断
			if stat.leidong>0 then pfmid=2;alias.wi(fjweapon)
			else pfmid=1;alias.uw()
			end
		elseif jifa["forcename"]=="hunyuan-yiqi" then --门派判断改成内功判断
			if stat.jingang>0 then pfmid=2;alias.wi(fjweapon)
			else pfmid=1;alias.uw()
			end
		else
			pfmid=1
			if string.len(fjweapon)>0 then alias.wi(fjweapon)
			else alias.uw() 
			end
		end
		_tb=Split(fjyun,"|")
		for k,v in ipairs(_tb) do run(v) end
		killid=id
		killname=name
		killskill=fjweapon
		killpfm=fjpfm
		killyun=fjyun
		killjiali=fjjiali
		killjiajin=fjjiajin
		run("jiali "..killjiali..";jiajin "..killjiajin..";kill "..killid)
		if me.menpai=="bt" then run("convert staff;attack "..killid) end
		if me.menpai=="mj" then run("shoutfighter fighter;order fighter do attack "..killid..";order fighter 2 do attack "..killid) end
		alias.pfm()
end
function gps_watch.dosomething1(n,l,w)
	if string.find(l,"此书乃吾留予后代峨嵋聪慧弟子，") then
		run("give wenying wuxue jingyao;drop wuxue jingyao")
		gpserrnum=tonumber(gpserrnum)+1
	end
	if string.find(l,"好象有一只蝙蝠停在你身后的岩石上。") then gpserrnum=tonumber(gpserrnum)+1 end
	if string.find(l,"你像没头苍蝇一样在洞里瞎钻，结果一头撞在洞壁上。") then gpserrnum=tonumber(gpserrnum)+1 end
	if string.find(l,"只听里面有人说了声：阁下光临敝帮有何贵干？") then gpserrnum=tonumber(gpserrnum)+1 end
	if string.find(l,"临阵脱逃可是得受军法处置，你还是先帮忙力据蒙古大军吧。") then 
		print("来自gps的拦截")
		alias.close_fj()
		alias.close_mp()
		alias.startwar() 
		war.waring=1
	end
	if findstring(w[0],"草寇喝道：想溜？没门！","草寇向你一阵阴笑：爽快的将宝贝交出来，不然叫你后悔莫及！") then
		gpszeikou="zeikou 草寇 kou"
		gpserrnum=tonumber(gpserrnum)+1
		openclass("gps")
		openclass("gps_dealwith")
		openclass("gps_zeikou")
		gps_watch.kill_zeikou("cao kou","草寇")
	end
	if findstring(w[0],"毛贼喝道：想溜？没门！") then
		gpszeikou="zeikou 毛贼 zei"
		gpserrnum=tonumber(gpserrnum)+1
		openclass("gps")
		openclass("gps_dealwith")
		openclass("gps_zeikou")
		gps_watch.kill_zeikou("mao zei","毛贼")
	end
	if string.find(l,"别那么自私！你不能带走超过一把兵器。") then
		gpserrnum=tonumber(gpserrnum)+1
		dropweapon=1
	end
	if string.find(l,"此地不适合施展一苇渡江绝技！") then
		gpserrnum=tonumber(gpserrnum)+1
		run("set walk off")
	end
	if string.find(l,"老师傅拦着你说：你想把食物拿去哪里？东西放下再走。") or string.find(l,"明教弟子指了指你拿着的食物，说道：根据教规，明教弟子不得将食物带出大食殿。") then
		gpserrnum=tonumber(gpserrnum)+1
		alias.gg()
	end
	if string.find(l,"马贼凶巴巴地叫道：放聪明点，快将宝贝交出来！") then
		gpszeikou="zeikou 马贼 zei"
		gpserrnum=tonumber(gpserrnum)+1
		openclass("gps")
		openclass("gps_dealwith")
		openclass("gps_zeikou")
		gps_watch.kill_zeikou("ma zei","马贼")
	end
	if string.find(l,"南面乃峨嵋女侠休息之所，这位") then GPS.End=true end
	if string.find(l,"你的动作还没有完成，不能移动。") then
		if roomname~="桃花林" and not isopen("boat") then gpserrnum=tonumber(gpserrnum)+1 end
	end
	if string.find(l,"你刚要进入秘洞，一股巨大的力量将你挡在了洞口！") then
		cm.havebuff=0
		cm.mengzhu=0
		GPS.End=true
	end
	if string.find(l,"你还没将《武学大全》归还") then
		gpserrnum=tonumber(gpserrnum)+1
		run("return book")
	end
	if string.find(l,"你还是先站起来再走吧！") then
		gpserrnum=tonumber(gpserrnum)+1
		run("stand")
	end
	if string.find(l,"你脚下一滑，踩了个空！") or string.find(l,"你一不小心脚下踏了个空，") then
		gpserrnum=tonumber(gpserrnum)+1
		run("yun recover")
	end
	if string.find(l,"山贼大吼道：赶快将宝贝交出来，不然你就别指望活着离开！") then
		gpszeikou="zeikou 山贼 zei"
		gpserrnum=tonumber(gpserrnum)+1
		openclass("gps")
		openclass("gps_dealwith")
		openclass("gps_zeikou")
		gps_watch.kill_zeikou("shan zei","山贼")
	end
	if string.find(l,"少林弟子岂可贪生怕死，以坠本派声名！") then
		if gpserrnum<=3 then
			run("giveup")
			gpserrnum=tonumber(gpserrnum)+1
		end
	end
	if string.find(l,"石级旁边的草丛中忽然跃起一个身影，挡住了你！") then
		gpserrnum=tonumber(gpserrnum)+1
		run("giveup")
	end
	if string.find(l,"星宿派弟子恶狠狠地威胁道：快将宝贝交出来，否则取你狗命！") then
		gpszeikou="zeikou 星宿派弟子 dizi"
		gpserrnum=tonumber(gpserrnum)+1
		openclass("gps")
		openclass("gps_dealwith")
		openclass("gps_zeikou")
		gps_watch.kill_zeikou("xingxiu dizi","星宿派弟子")
	end
	if string.find(l,"袁紫衣说道：本姑娘在这里休息，别来打搅！") then
		-- 没有处理
	end
	if string.find(l,"这个方向没有出路。") then gpserrnum=tonumber(gpserrnum)+1 end
	if string.find(l,"艄公回到仓里，发现你还在，咦了一声") then
		openclass("boat")
	end
	if string.find(l,"你目前还没有任何为 gps=false 的变量设定。") then alias.close_gps() end
	if string.find(l,"四下景况似乎和寻常所见略有不同，透出森森鬼气。") then buzhen=true end
	if string.find(l,"一阵微风吹过，四面景致似乎起了些变化。") then buzhen=false end
end
function gps_watch.dosomething2(n,l,w)
	if not string.find(w[2],')') then roomname=w[2] end
end
------------------------------------------------------------------------------------
-- gps_dealwith
------------------------------------------------------------------------------------
function pfmkill()
	local _t
	_t=string.gsub(killnpcover,"-","")
	---------------------杀过路NPC无论是否用PFM，都装备FJ武器
	if string.len(fjweapon)>0 then
		alias.wi(fjweapon)
	else 
		alias.uw() 
	end
	--------------------------------------------
	--if ((hp.exp<1000000 and string.find("wdxym-wdsj|wdyzg-wdbl|hslwc-hskt|hslwc-hsbqf|hsdl-hssy|hshy-hszl|hsxl-hscf|hsxsl-hsxz|hztyjdm-qsl|qztj-qzyxd|ynfsl-ynfxj|slqfd-slzl|xsjgy-xshy",_t)) or (hp.exp<3000000 and string.find("emhcazd-emhcagc|dladf-xy|lmbj-xy|lzdjjf-jjfdy|xxyptdm-yptdy|xxyptdt-yptms|yzsclk-nshp|clbdm-clbdt|clbxt-clbws|qldt-ht|qlxt-dl",_t)) or (hp.exp<6000000 and string.find("gb-killjian|klmlm-sj|hspt-hsdlgf|hspt-hsxlgf|hspt-hsqs|qzcjg-cjg3l|xxysd-xxh|xxysd-xxxw",_t)) or (hp.exp<10000000 and string.find("wdhdzl-wdhy|wdhdzl-wddxzl|wdhdzl-wdxxzl|xscl-xsdd",_t))) then return true else return false end
	if (me.menpai=="bt" --bt杀所有拦路，都用pfm
	or (hp.exp~=nil and hp.exp<1000000 and string.find("wdxymwdsj|wdyzgwdbl|hslwchskt|hslwchsbqf|hsdlhssy|hshyhszl|hsxlhscf|hsxslhsxz|hztyjdmqsl|qztjqzyxd|ynfslynfxj|slqfdslzl|xsjgyxshy",_t)) 
	or (hp.exp~=nil and hp.exp<3000000 and string.find("emhcazdemhcagc|dladfxy|lmbjxy|lzdjjfjjfdy|xxyptdmyptdy|xxyptdtyptms|xxyptdydyq|yzsclknshp|clbdmclbdt|clbxtclbws|qldtht|qlxtdl",_t)) 
	or (hp.exp~=nil and hp.exp<6000000 and string.find("gbkilljian|klmlmsj|hspthsdlgf|hspthsxlgf|hspthsqs|qzcjgcjg3l|xxysdxxh|xxysdxxxw",_t)) 
	or (hp.exp~=nil and hp.exp<10000000 and string.find("wdhdzlwdhy|wdhdzlwddxzl|wdhdzlwdxxzl|xsclxsdd",_t))) then 
		return true 
	else 
		return false 
	end
end
function gps_dealwith.dosomething1(n,l,w)
	if findstring(l,"灵虚道长倒在地上，挣扎了几下就死了。","凌虚道长倒在地上，挣扎了几下就死了。","张松溪倒在地上，挣扎了几下就死了。","胡老爷倒在地上，挣扎了几下就死了。","邱山风倒在地上，挣扎了几下就死了。","司徒横倒在地上，挣扎了几下就死了。","帮众倒在地上，挣扎了几下就死了。","静心倒在地上，挣扎了几下就死了。","劳德诺倒在地上，挣扎了几下就死了。","梁发倒在地上，挣扎了几下就死了。","陆大有倒在地上，挣扎了几下就死了。","宁中则倒在地上，挣扎了几下就死了。","岳灵姗倒在地上，挣扎了几下就死了。","施戴子倒在地上，挣扎了几下就死了。","高根明倒在地上，挣扎了几下就死了。","天鹰教守卫倒在地上，挣扎了几下就死了。","都大锦倒在地上，挣扎了几下就死了。","说不得倒在地上，挣扎了几下就死了。","皇宫卫士倒在地上，挣扎了几下就死了。","校尉倒在地上，挣扎了几下就死了。","一品堂武士倒在地上，挣扎了几下就死了。","守城官兵日月神教卫士倒在地上，挣扎了几下就死了。","张志光倒在地上，挣扎了几下就死了。","谭处端倒在地上，挣扎了几下就死了。","虚通倒在地上，挣扎了几下就死了。","虚明倒在地上，挣扎了几下就死了。","清乐比丘倒在地上，挣扎了几下就死了。","清观比丘倒在地上，挣扎了几下就死了。","葛伦布倒在地上，挣扎了几下就死了。","萨木活佛倒在地上，挣扎了几下就死了。","戒律僧倒在地上，挣扎了几下就死了。","狮吼子倒在地上，挣扎了几下就死了。","采花子倒在地上，挣扎了几下就死了。","婢女倒在地上，挣扎了几下就死了。","蒙古军官倒在地上，挣扎了几下就死了。","简长老倒在地上，挣扎了几下就死了。","宁中则往.+落荒而逃了。","岳灵姗往.+落荒而逃了。","将灵虚道长扶了起来背在背上。","江百胜倒在地上，挣扎了几下就死了。") then
		if me.menpai=="bt" then run("convert she;unwield guai shezhang") end --bt收蛇
		if not pfmkill() then 
			--print(pfmkill(),not pfmkill(),"杀过路NPC")
			alias.KillNextNPC() 
		end
	end
	if string.find(l,"这里没有这个人。") then
		alias.close_kill()
		if me.menpai=="bt" then run("convert she") end  --bt收蛇
		if string.len(killnpcover)>0 then
			killnpcnum=99
			run(killnpcover)
			--killnpcover=""
			--killnpcnum=0
		end
	end
	if findstring(l,"家丁倒在地上，挣扎了几下就死了。") then
		if killnpcover=="btssm-qy" or killnpcover=="gyzdm-qy2" then 
			if not pfmkill() then alias.KillNextNPC() end 
		end
	end
	if findstring(l,"你目前还没有任何为 checkmove=yes 的变量设定。") then
		if trymovesuccess then
			alias.close_gps_dealwith()
			alias.movefinish()
		else
			if killnpcover~=nil and string.len(killnpcover)>0 then
				killnpcnum=tonumber(killnpcnum-1)
				run(killnpcover)
			end
		end
	end
	if findstring(l,"家丁挡住了你的去路：老爷正在练功，请改日再来。") then
		trymovesuccess=false
		killnpcover="btssm-qy"
	end
	if findstring(l,"家丁做了个揖，说道：尊驾与敝庄素无往来，庄主不见外客，还是请回吧") then
		trymovesuccess=false
		killnpcover="gyzdm-qy2"
	end
	-- 没过阵就放弃
	if findstring(l,"这位女施主还是请回罢","这位施主请回罢","立时从身畔挚出一把雪亮的戒刀来") then
		alias.close_gps()
		alias.startworkflow()
	end
	--if findstring(l,"你.+一招","你目前还没有任何为 .+ 的变量设定。") then
	--	alias.resetidle()
	--end
	if findstring(l,"你目前还没有任何为 killover=GPS 的变量设定。") then
		alias.KillNextNPC()
	end
	if findstring(l,"你目前还没有任何为 check=dealwith 的变量设定。") then
		if not pfmkill() then
			if hp.qi<(hp.maxqi*100/hp.healthqi/2) then run("yun recover") end
			if hp.jingli<(hp.maxjingli/2) then alias.yjl() end
		end
		if string.len(gpszeikou)==0 then
			-- 没有贼寇拦路
			if gpserrnum>0 then
				-- 处理特殊路径前走路错误，需要重走
				gpserrnum=0
				checkmove.NotGPSMove=1
				alias.close_gps()
				pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)  --保护模式执行flyto指令
			end
		end
	end
	if findstring(l,"狮吼子一言不发，闪身拦在你面前。","千年以来，少林向不许女流擅入。","你不是少林弟子，不得进入后殿。","请留步，恕小寺不接待女客。","帮众拦在你面前，说道：里面是关押本帮叛徒的地方，你请回吧。","采花子挡住了你：我的小妞可不是给你们","道一说道: 你未经许可，不能上二楼。","都大锦拦在你面前，喝道：","高根明拦住你说：由此往上乃本派禁地，请止步。","葛伦布挡住你说：你准备用什麽供奉我们佛爷呀？","胡老爷说: 我把阿凡提关在我的客厅里了，谁也不许进去。","简长老一把揪住你的衣领说：“慢着！”","江百胜伸手拦住你说道：盟主很忙，现在不见外客，你下山去吧！","戒律僧挡住你说：后面乃本寺重地，请回吧！","静心师太走上前说：后边是峨嵋弟子练功休息的地方，请留步。","劳德诺欠身说道：这位","梁发挡住你说道：后面是本派书院，这位","凌虚道长喝道：如不是上山敬香，即刻请回！","陆大有喝道：后面是华山派的内院，这位","蒙古军官一语不发，站在你面前挡著你的去路！","宁中则拦在你身前斥道：外人不能随易出入本派重地！还不快给我离开？","清观喝道：你不是少林弟子，不得进入后山竹林！","怎么连一点江湖规矩都不懂？起码也得孝敬一下老子。","如不是上山敬香，即刻请回！","萨木活佛挡住你说道：後面是本寺高僧修行之地，施主请回。","施戴子拦住你说：两位师叔祖不欲见客，请回吧。","说不得伸手拦住你，说道：上面是明教光明顶，这位","司徒横拦在你面前，喝道：","天鹰教守卫喝道：这位","卫士对你大吼一声：放肆！那不是你能进去的地方。","卫士对你喝道：看招！别妄想闯入本教重地！","卫士对着你喝道：看招！别妄想在本大爷手下救人！","校尉挡住了你的去路！","请放下兵刃。少林千年的规矩，外客","一品堂武士挡住了你的去路！","岳灵姗拦身说道：后面是本派厨房","张松溪喝道：里面是武当重地，闲人请止步。","张志光拦住说道：对不起，养心殿不对外开放！","婢女伸手挡住了你的去路：少庄主正在调训毒蛇，请改日再来。","一品堂武士一言不发地挡在你前面。") then
		trymovesuccess=false
	end
end
function gps_dealwith.timer()
	if not pfmkill() then run("hp;set check=dealwith") end
end
------------------------------------------------------------------------------------
-- gps_99guai
------------------------------------------------------------------------------------
function gps_99guai.dosomething1(n,l,w)
	if findstring(l,"忽然一阵腥风袭来，一条巨蟒从身旁大树上悬下，把你卷走了。") then mangsheexist=1 end
	if findstring(l,"巨蟒全身扭曲，翻腾挥舞，终於僵直而死了。") then
		--wait.make(function()
		--	local _f=function()
						alias.close_gps_dealwith()
						run(cmdonsheexist)
						alias.movefinish()
		--		end
		--	wait.time(3)
		--	_f()
		--end)
	end
end
function gps_99guai.dosomething2(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=jm 的变量设定。") then run("kill ju mang") end
	if findstring(l,"你目前还没有任何为 yinshe=end 的变量设定。") then
		if mangsheexist==1 then run("kill ju mang") else
			alias.close_gps_dealwith()
			run(cmdonsuccess)
			alias.movefinish()
		end
	end
	if findstring(l,"你目前还没有任何为 yinshe=start 的变量设定。") then mangsheexist=0 end
	if findstring(l,"你目前还没有任何为 检查蟒蛇在不在 的变量设定。") then
		wait.make(function()
			local _f=function()
						run("set yinshe=start")
						run(yinshecmd)
						DoAfter(8,"set yinshe=end")
						--wait.make(function()
						--	local _ff=function() run("set yinshe=end") end
						--	wait.time(8)
						--	_ff()
						--end)
						--run("set yinshe=end")
				end
			wait.time(3)
			_f()
		end)
	end
end
------------------------------------------------------------------------------------
-- gps_climbxy
------------------------------------------------------------------------------------
function gps_climbxy.dosomething1(n,l,w)
	if findstring(l,"那个方向没法爬。") then
		alias.close_gps_dealwith()
		alias.movefinish()
	end
	if findstring(l,"你爬了上来。") then alias.checkbusy("climbup") end
	if findstring(l,"你爬了下来。") then alias.checkbusy("climbdown") end
end
function gps_climbxy.dosomething2(n,l,w)
	if w[2]=="busyover=climbdown" then alias.yjl();run("climb down") end
	if w[2]=="busyover=climbup" then alias.yjl();run("climb up") end
end
------------------------------------------------------------------------------------
-- gps_dl_fsg
------------------------------------------------------------------------------------
function gps_dl_fsg.dosomething1(n,l,w)
	if findstring(l,"这不是活物！") then
		if not thrownpcfaint then
			run("get fu;w;drop fu;e")
			alias.trymove("s")
		end
	end
	if findstring(l,"守卫喝道：闲杂人等，不得乱闯。") then
		throw_npc="fu"
		trymovesuccess=false
		alias.tc(throw_npc)
	end
	if findstring(l,"傅思归脚下一个不稳，跌在地上昏了过去。") then
		thrownpcfaint=true
		wait.make(function()
			local _f=function()
						run("drop gold;drop armor;get fu;w;drop fu;e;get gold")
						alias.trymove("s")
				end
			wait.time(2)
			_f()
		end)
	end
	if findstring(l,"傅思归倒在地上，挣扎了几下就死了。") then alias.trymove("s") end
end
function gps_dl_fsg.dosomething2(n,l,w)
	if w[2]=="checkmove=yes" then
		if trymovesuccess then
			closeclass("gps_dl_fsg")
			closeclass("gps_thrownpc")
		end
	end
end
------------------------------------------------------------------------------------
-- gps_em_killjm
------------------------------------------------------------------------------------
function gps_em_killjm.dosomething1(n,l,w)
	if findstring(l,"巨蟒全身扭曲，翻腾挥舞，终於僵直而死了。") then alias.checkbusy("jmkilled") end
end
function gps_em_killjm.dosomething2(n,l,w)
	if w[2]=="busyover=jm" then run("kill ju mang") end
	if w[2]=="busyover=jmkilled" then
		alias.close_gps_dealwith()
		run("set gps=end")
	end
end
------------------------------------------------------------------------------------
-- gps_lsd_back
------------------------------------------------------------------------------------
function gps_lsd_back.dosomething1(n,l,w)
	if findstring(l,"船夫说：“塘沽口到啦，上岸吧”。") then
		alias.close_gps_dealwith()
		alias.close_dz()
		run("halt;out")
		alias.movefinish()
	end
	if findstring(l,"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。") then alias.resetidle();run("n") end
	if findstring(l,"船正往.+方向前进。") then alias.resetidle() end
end
------------------------------------------------------------------------------------
-- gps_lsd_go
------------------------------------------------------------------------------------
function gps_lsd_go.dosomething1(n,l,w)
	local _f,a,b,c
	--wait.make(function()
		if findstring(l,"船夫说：“灵蛇岛到啦，上岸吧”。") then
			alias.close_gps_dealwith()
			alias.close_dz()
			run("halt;out")
			alias.movefinish()
		end
		if findstring(l,"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。") then alias.resetidle();run("locate") end
		if findstring(l,"船正往.+方向前进。") then alias.resetidle() end
		if findstring(l,"你现在在塘沽口。") then run("s") end
		--if findstring(l,"你现在在塘沽口东约(.+)海哩南约(.+)海哩") then run("lookout") end
		a,b,c=string.find(l,"你现在在塘沽口正南约(.+)海哩。")
		if c~=nil then
			--if string.len(c)<6 then run("s") else if c=="五" then run("e") else run("s") end end
			if ctonum(c)<54 then run("s") else run("e") end
		end
end
------------------------------------------------------------------------------------
-- gps_nanyang
------------------------------------------------------------------------------------
function gps_nanyang.dosomething1(n,l,w)
	if findstring(l,"这不是活物！") then
		if not thrownpcfaint then alias.trymove("enter") end
	end
	if findstring(l,"守城军官瞅著你，举起手中兵器，挡住你的去路。") then
		throw_npc="bing"
		trymovesuccess=false
		alias.tc(throw_npc)
	end
	if findstring(l,"守城官兵脚下一个不稳，跌在地上昏了过去。") then
		thrownpcfaint=true
		--wait.make(function()
			--local _f=function()
						alias.trymove("enter")
			--	end
			--wait.time(1);_f()
		--end)
	end
	if findstring(l,"守城官兵倒在地上，挣扎了几下就死了。") then alias.trymove("enter") end
end
function gps_nanyang.dosomething2(n,l,w)
	if w[2]=="checkmove=yes" then
		if trymovesuccess then
			closeclass("gps_nanyang")
			closeclass("gps_thrownpc")
		end
	end
end
------------------------------------------------------------------------------------
-- gps_qzh_mcx
------------------------------------------------------------------------------------
function gps_qzh_mcx.dosomething1(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"这不是活物！") then
			if not thrownpcfaint then
				if throw_npc=="jiang" then run("get armor from jiang;drop armor;get jiang;south;drop jiang;north")
				else run("get bing;south;drop bing;north") end
				alias.trymove("ne")
			end
		end
		if findstring(l,"官兵大喝道：都督有令，闲杂人等不能由此经过！") then
			throw_npc="bing"
			trymovesuccess=false
			alias.tc(throw_npc)
		end
		if findstring(l,"武将大喝道：都督有令，闲杂人等不能由此经过！") then
			throw_npc="jiang"
			trymovesuccess=false
			alias.tc(throw_npc)
		end
		if findstring(l,"官兵脚下一个不稳，跌在地上昏了过去。") then
			thrownpcfaint=true
			_f=function()
						run("drop gold;drop armor;get bing;s;drop bing;n;get gold")
						alias.trymove("ne")
					end
			wait.time(2);_f()
		end
		if findstring(l,"武将脚下一个不稳，跌在地上昏了过去。") then
			thrownpcfaint=true
			_f=function()
						run("get armor from jiang;drop armor;drop gold;drop armor;get jiang;s;drop jiang;n;get gold")
						alias.trymove("ne")
					end
			wait.time(2);_f()
		end
		if findstring(l,"官兵倒在地上，挣扎了几下就死了。") then alias.trymove("ne") end
		if findstring(l,"武将倒在地上，挣扎了几下就死了。") then alias.trymove("ne") end
	end)
end
function gps_qzh_mcx.dosomething2(n,l,w)
	if w[2]=="checkmove=yes" then
		if trymovesuccess then
			closeclass("gps_qzh_mcx")
			closeclass("gps_thrownpc")
		end
	end
end
------------------------------------------------------------------------------------
-- gps_qzh_sl
------------------------------------------------------------------------------------
function gps_qzh_sl.dosomething1(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"这不是活物！") then
			if not thrownpcfaint then
				if throw_npc=="jiang" then run("get armor from jiang;drop armor;get jiang;w;drop jiang;e")
				else run("get bing;w;drop bing;e") end
				alias.trymove("n")
			end
		end
		if findstring(l,"官兵拦住了你的去路。") then
			throw_npc="bing"
			trymovesuccess=false
			alias.tc(throw_npc)
		end
		if findstring(l,"武将拦住了你的去路。") then
			throw_npc="jiang"
			trymovesuccess=false
			alias.tc(throw_npc)
		end
		if findstring(l,"官兵脚下一个不稳，跌在地上昏了过去。") then
			thrownpcfaint=true
			_f=function()
						run("drop gold;drop armor;get bing;w;drop bing;e;get gold")
						alias.trymove("n")
					end
			wait.time(2);_f()
		end
		if findstring(l,"武将脚下一个不稳，跌在地上昏了过去。") then
			thrownpcfaint=true
			_f=function()
						run("get armor from jiang;drop armor;drop gold;drop armor;get jiang;w;drop jiang;e;get gold")
						alias.trymove("n")
					end
			wait.time(2);_f()
		end
		if findstring(l,"官兵倒在地上，挣扎了几下就死了。") then alias.trymove("n") end
		if findstring(l,"武将倒在地上，挣扎了几下就死了。") then alias.trymove("n") end
	end)
end
function gps_qzh_sl.dosomething2(n,l,w)
	if w[2]=="checkmove=yes" then
		if trymovesuccess then
			closeclass("gps_qzh_sl")
			closeclass("gps_thrownpc")
		end
	end
end
------------------------------------------------------------------------------------
-- gps_qzh_xmdq
------------------------------------------------------------------------------------
function gps_qzh_xmdq.dosomething1(n,l,w)
	entrance=w[1]
	xkxGPS.setEntrance(entrance)
end
function gps_qzh_xmdq.dosomething2(n,l,w)
	local _tb,_f
	wait.make(function()
		alias.close_gps_dealwith()
		entrance=xkxGPS["entrance"]
		_tb=Split(entrance,"|")
		if #_tb==4 then
			run("halt;west")
			alias.movefinish()
			return
		end
		if #_tb==2 then
			run("halt;east")
			alias.movefinish()
			return
		end
		if isopen("ftb_start") then
			-- 如果是ftb搜索，则不继续等待
			alias.searchareanextpath()
			alias.close_gps_dealwith()
			return
		end
		if isopen("xf_mj") then
			chaobaitime=0
			alias.close_gps()
			alias.startworkflow()
			return
		end
		if findstring(l,"你目前还没有任何为 checklook=yes 的变量设定。") then
		_f=function()
			openclass("gps_dealwith")
			--print(always.where)
			if always.where=="新门吊桥" or always.where=="乱石岗" then openclass("gps_qzh_xmdq")	else closeclass("gps_qzh_xmdq") end
			run("look;set checklook=yes")
		end
		wait.time(10);_f()
		end
	end)
end
------------------------------------------------------------------------------------
-- gps_sgy_sd
------------------------------------------------------------------------------------
function gps_sgy_sd.dosomething1(n,l,w)
	if findstring(l,"良久，你突然有一股破壁") then gps_checkmianbi=true end
	if findstring(l,"只听得身后石头稀里哗拉坍塌下来，封住了入口。") then alias.close_gps_dealwith();alias.movefinish() end
end
function gps_sgy_sd.dosomething2(n,l,w)
	local _f
	--wait.make(function()
		if not gps_checkmianbi then
			--_f=function()
						for i=1,10,1 do run("mianbi") end
						run("set checkmianbi=yes")
			--	end
			--wait.time(2);_f()
		else
			alias.wi("jian")
			run("strike wall;enter")
		end
	--end)
end
------------------------------------------------------------------------------------
-- gps_sl_gate
------------------------------------------------------------------------------------
function gps_sl_gate.dosomething1(n,l,w)
	if findstring(l,"大门天亮前不开，怎么敲也没用。") then
		wait.make(function()
			local _f=function() run("knock gate") end
			wait.time(5);_f()
		end)
	end
	if findstring(l,"大门已经是开着了。","吱地一声，里面有人把大门打开了","你轻轻地敲了敲门，只听吱地一声，一位壮年僧人应声打开大门") then
		--run("n")
		--alias.close_gps_dealwith()
		--alias.movefinish()
		alias.trymove("n")
	end
end
------------------------------------------------------------------------------------
-- gps_sl_sl
------------------------------------------------------------------------------------
function gps_sl_sl.dosomething1(n,l,w)
	alias.close_gps_dealwith()
	run("halt")
	if w[1]=="southdown" then run(w[2]) else run(w[1]) end
	alias.movefinish()
end
------------------------------------------------------------------------------------
-- gps_slh
------------------------------------------------------------------------------------
function gps_slh.dosomething1(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"木筏又被冲到河中央去了。") then if not gps_slh_shangan then run("rowing") end end
		if findstring(l,"你操上手中的家伙，从树上砍下一些树枝。") then
			gps_slh_shuzhi=false
			_f=function() if not gps_slh_shuzhi then run("chop shuzhi") end end
			wait.time(3);_f()
		end
		if findstring(l,"你划了半天，木筏终於靠岸了。") then alias.checkbusy("up") end
		if findstring(l,"你砍下的树枝似乎足够做") then
			gps_slh_shuzhi=true
			_f=function() run("make raft") end
			wait.time(3);_f()
		end
		if findstring(l,"你用砍下的树枝做了一个木筏。") then
			gps_slh_shuzhi=true
			_f=function()
						gps_slh_shangan=false
						run("ride raft;rowing")
				end
			wait.time(1);_f()
		end
		if findstring(l,"疏勒河西岸") then
			gps_slh_shangan=true
			alias.close_gps_dealwith()
			alias.movefinish()
		end
	end)
end
function gps_slh.dosomething2(n,l,w)
	alias.uw()
	run("up")
end
------------------------------------------------------------------------------------
-- gps_thd_back
------------------------------------------------------------------------------------
function gps_thd_back.dosomething1(n,l,w)
	local _f,a,b,c,d
	--wait.make(function()
		a,b,c,d=string.find(l,"%s+这里明显的出口是%s+(%w+)%s+和%s+(%w+)。")
		if c~=nil and d~=nil then
			if c=="north" then run(d) else run(c) end
			run("start")
			alias.dz(200)
		end
		if findstring(l,"一条渔船应声慢慢驶了过来，渔夫将一块踏脚板搭在沙滩上。","别叫了，这么大眼睛没看见船？") then run("look") end
		if findstring(l,"船夫说：“舟山到啦，上岸吧”。") then
			alias.close_gps_dealwith()
			alias.close_dz()
			--_f=function() 
				run("halt;out");alias.movefinish() 
			--end
			--wait.time(1);_f()
		end
		if findstring(l,"你大喝一声“开船”，于是船便离了岸。") then
			run("w")
			--_f=function() run("locate") end
			--wait.time(2);_f()
		end
		if findstring(l,"船正往.+方向前进。") then alias.resetidle() end
		if findstring(l,"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。") then alias.resetidle();run("n") end
end
------------------------------------------------------------------------------------
-- gps_thd_go
------------------------------------------------------------------------------------
function gps_thd_go.dosomething1(n,l,w)		
	local _f,a,b,c,d
	--wait.make(function()
		if findstring(l,"穷光蛋，一边呆着去！") then
			print("你怎么不带钱啊。")
			alias.close_gps_dealwith()
			alias.checkitems()
		end
		a,b,c,d=string.find(l,"%s+这里明显的出口是%s+(%w+)%s+和%s+(%w+)。")
		if c~=nil and d~=nil then
			if c=="west" then run(d) else run(c) end
			run("start")
			alias.dz(200)
		end
		if findstring(l,"一条渔船应声慢慢驶了过来，渔夫将一块踏脚板搭在沙滩上。","别叫了，这么大眼睛没看见船？") then run("look") end
		if findstring(l,"船夫说：“桃花岛到啦，上岸吧”。") then
			alias.close_gps_dealwith()
			alias.close_dz()
			--_f=function() 
			run("halt;out");alias.movefinish() 
			--end
			--wait.time(1);_f()
		end
		if findstring(l,"你大喝一声“开船”，于是船便离了岸。") then
			run("s")
			--_f=function() run("locate") end
			--wait.time(2);_f()
		end
		if findstring(l,"船正往.+方向前进。") then alias.resetidle() end
		if findstring(l,"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。") then alias.resetidle();run("locate") end
		if findstring(l,"你现在在舟山。") then run("s") end
		a,b,c=string.find(l,"你现在在舟山正南约(.+)海哩。")
		if c~=nil then
			if ctonum(c)<9 then run("s") else run("e") end
		end
end
------------------------------------------------------------------------------------
-- gps_thd_ms
------------------------------------------------------------------------------------
function gps_thd_ms.dosomething1(n,l,w)
	local _t
	local gps_thad_guaname={"谦","乾","坤","屯","蒙","需","讼","师","比","小畜","履","泰","否","同人","大有",}
	local a,b,c,d,e=string.find(l,"今有物不知其数，三三数之剩(.+)，五五数之剩(.+)，七七数之剩(.+)，问物几何？")
	if c~=nil and d~=nil then
		c=tonumber(ctonum(c))
		d=tonumber(ctonum(d))
		e=tonumber(ctonum(e))
		_t=c*70+d*21+e*15
		--gps_thmsnum=tonumber(math.mod(d+3-c,3)*5+d)
		gps_thmsnum=_t-105*math.floor(_t/105)
		if gps_thmsnum>14 then gps_thmsnum=gps_thmsnum-15*math.floor(gps_thmsnum/15) end
		run("press "..gps_thad_guaname[gps_thmsnum+1])
	end
	if findstring(l,"只听得“隆隆”几声大响，石门缓缓向一侧划开") then alias.checkbusy("ms") end
	if findstring(l,"甬道顶部忽然飘落一束薄卷轴，") then run("look scroll") end
end
function gps_thd_ms.dosomething2(n,l,w)
	alias.close_gps_dealwith()
	run("enter")
	alias.movefinish()
end
------------------------------------------------------------------------------------
-- gps_thd_sg
------------------------------------------------------------------------------------
function gps_thd_sg.dosomething1(n,l,w)
	trymovesuccess=false
	run("fight sha gu;agree")
	wait.make(function()
		local _f=function() alias.trymove("enter") end
		wait.time(2);_f()
	end)
end
function gps_thd_sg.dosomething2(n,l,w)
	if trymovesuccess==true then alias.close_gps_dealwith() end
end
------------------------------------------------------------------------------------
-- gps_thd_thl
------------------------------------------------------------------------------------
function gps_thd_thl.dosomething1(n,l,w)
	local _f,a,b,c,entrance
	alias.resetidle()
	if thlfinish=="xiaojing" then
		if findstring(l,"小径 -") then trymovesuccess=true;alias.checkbusy("thl") end
		if findstring(l,"树丛 -","石洞 -") then run("s;s;look") end
	elseif thlfinish=="shidong" then
		if findstring(l,"树丛 -","石洞 -") then trymovesuccess=true;alias.checkbusy("thl") end
		if findstring(l,"你目前还没有任何为 busyover=zhoubotong 的变量设定。") then 
			if hp.jingli<tonumber(hp.maxjingli/2) then run("yun refresh") end
			run("s;n")
		end
		if findstring(l,"小径 -") then 
			run("hp")
			alias.checkbusy("zhoubotong")
		end
	end
	if findstring(l,"桃花林 -") then
		alias.checkbusy("passthl")
	end
	if findstring(l,"你目前还没有任何为 busyover=passthl 的变量设定。") then
		run("time")
	end
	wait.make(function()
		a,b,c=string.find(l,"现在泥潭时间是.+年.+月.+日(.+)时.+。")
		if c~=nil then
		--	alias.resetidle()
			if c=="子" then entrance="east" end
			if c=="丑" then entrance="southeast" end
			if c=="寅" then entrance="southeast" end
			if c=="卯" then entrance="southwest" end
			if c=="辰" then entrance="northeast" end
			if c=="巳" then entrance="northeast" end
			if c=="午" then entrance="west" end
			if c=="未" then entrance="south" end
			if c=="申" then entrance="south" end
			if c=="酉" then entrance="northwest" end
			if c=="戌" then entrance="north" end
			if c=="亥" then entrance="north" end
			run(entrance)
		--	_f=function() 
		--		if trymovesuccess then 
		--			alias.checkbusy("thl") 
		--		elseif always.where=="桃花林" then 
		--			print("过桃林")
		--			run("time") 
		--		end 
		--	end
		--	wait.time(1);_f()
		end
	end)
end
function gps_thd_thl.dosomething2(n,l,w)
	alias.close_gps_dealwith()
	alias.movefinish()
end
------------------------------------------------------------------------------------
-- gps_thrownpc
------------------------------------------------------------------------------------
function gps_thrownpc.dosomething1(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"往后一纵，说道：好！纪晓芙在此相劝，看在人家的面子上，这次就算了。","你胜了这招，向后跃开三尺，笑道：承让！","你双手一拱，笑著说道：承让！","你哈哈大笑，说道：承让了！","向后一纵，躬身做揖说道：阁下武艺不凡，果然高明！","向后退了几步，说道：这场比试算我输了，佩服，佩服！","脸色微变，说道：佩服，佩服！") then
			_f=function() alias.tc(throw_npc) end
			wait.time(1);_f()
		end
	end)
end
------------------------------------------------------------------------------------
-- gps_waitrelease
------------------------------------------------------------------------------------
function gps_waitrelease.dosomething1(n,l,w)
	if findstring(l,"你对你说道：“您的大恩大德小弟没齿难忘！”") then
		alias.close_gps_dealwith()
		alias.movefinish()
	end
	if findstring(l,"牢门缓缓地开启了．．．") then
		run("up;id here;emote 对你说道：“您的大恩大德小弟没齿难忘！”")
	end
end
function gps_waitrelease.timer()
	if math.random(3)==1 then run("chat 失败啊，被关地牢了，请求好心人搭救～～mush～～") end
	if math.random(3)==2 then run("chat SOS~~~~亲爱的兄弟姐妹们，请伸出热情的双手，搭救我从地牢出来吧～～mush～～") end
	if math.random(3)==3 then run("chat 祈求这个充满爱的泥塘，请赐予我一个好心人把我从地牢里搭救出来吧～～mush～～") end
end
------------------------------------------------------------------------------------
-- gps_xxmap
------------------------------------------------------------------------------------
function gps_xxmap.dosomething1(n,l,w)
	local a,b,c,d
	a,b,c=string.find(l,"这里唯一的出口是 (.+)。")
	if c~=nil then
		checkmove.notgpsmove=1
		gps_xxgangou=c
		run(gps_xxgangou)
		alias.movefinish()
	end
	a,b,c,d=string.find(l,"这里明显的出口是 (%w+) 和 (%w+)。")
	if c~=nil and d~=nil then
		checkmove.notgpsmove=1
		if gps_xxgg_dict==1433 and c=="eastdown" then
			gps_xxgangou=d
			run(gps_xxgangou)
			alias.movefinish()
			gps_xxgg_dict=0
			alias.close_gps_dealwith()
		end
		if gps_xxgg_dict==1433 and d=="eastdown" then
			gps_xxgangou=c
			run(gps_xxgangou)
			alias.movefinish()
			gps_xxgg_dict=0
			alias.close_gps_dealwith()
		end
		if gps_xxgg_dict==1432 then
			if c=="eastdown" then
				gps_xxgangou=d
				run(gps_xxgangou..";look")
			else
				if gps_xxgangou==d then run("go "..gps_xxgangou)
				else
					gps_xxgangou=c
					run("go "..gps_xxgangou)
				end
				run("look")
			end
		end
		if gps_xxgg_dict==1434 then
			if c=="eastdown" then
				alias.movefinish()
				gps_xxgg_dict=0
				alias.close_gps_dealwith()
			else
				if d=="eastdown" then
					alias.movefinish()
					gps_xxgg_dict=0
					alias.close_gps_dealwith()
				else
					if d==gps_xxgangou then run("go "..gps_xxgangou)
					else
						gps_xxgangou=c
						run("go "..gps_xxgangou)
					end
					run("look")
				end
			end
		end
	end
	
	a,b,c,d=string.find(l,"这里明显的出口是 northup、(%w+) 和 (.+)。")
	if c==nil or d==nil then
		a,b,c,d=string.find(l,"这里明显的出口是 (%w+)、northup 和 (.+)。")
		if c==nil or d==nil then
			a,b,c,d=string.find(l,"这里明显的出口是 (%w+)、(%w+) 和%s+northup。")
			if c==nil or d==nil then return end
		end
	end
	checkmove.notgpsmove=1
	if gps_xxgg_dict==1432 then
		alias.movefinish()
		gps_xxgg_dict=0
		alias.close_gps_dealwith()
	end
	if gps_xxgg_dict==1433 or gps_xxgg_dict==1434 then
		if c=="westup" then
			gps_xxgangou=d
			run(gps_xxgangou)
		else
			gps_xxgangou=c
			run(gps_xxgangou)
		end
		if gps_xxgg_dict==1433 then
			alias.movefinish()
			gps_xxgg_dict=0
			alias.close_gps_dealwith()
		else run("look") end
	end
end
------------------------------------------------------------------------------------
-- gps_xydcy
------------------------------------------------------------------------------------
function gps_xydcy.dosomething1(n,l,w)
	xkxGPS.setEntrance(w[2])
	entrance=xkxGPS.entrance
	if #xkxGPS["entrance1"]==5 then gps_xydcy_reachdest=1 end
end
function gps_xydcy.dosomething2(n,l,w)
	if gps_xydcy_reachdest==0 then run("east;set checkxydcy=yes")
	else
		alias.close_gps_dealwith()
		alias.movefinish()
	end
end
------------------------------------------------------------------------------------
-- gps_xydcy_sl
------------------------------------------------------------------------------------
function gps_xydcy_sl.dosomething1(n,l,w)
	gps_xydcy_reachdest=1
end
function gps_xydcy_sl.dosomething2(n,l,w)
	if gps_xydcy_reachdest==0 then run("north;set checkxydcy=yes")
	else
		alias.close_gps_dealwith()
		alias.movefinish()
	end
end
------------------------------------------------------------------------------------
-- gps_yz_lts
------------------------------------------------------------------------------------
function gps_yz_lts.dosomething1(n,l,w)
	if findstring(l,"这不是活物！") then
		if not thrownpcfaint then
			run("get ling;s;drop ling;n")
			alias.trymove("w")
		end
	end
	if findstring(l,"凌翰林挡住了你：请勿入内宅。") then
		throw_npc="ling"
		trymovesuccess=false
		alias.tc(throw_npc)
	end
	if findstring(l,"凌退思脚下一个不稳，跌在地上昏了过去。") then
		thrownpcfaint=true
		wait.make(function()
			local _f=function()
						run("drop gold;drop armor;get ling;s;drop ling;n;get gold")
						alias.trymove("w")
				end
			wait.time(2)
			_f()
		end)
	end
	if findstring(l,"凌退思倒在地上，挣扎了几下就死了。") then alias.trymove("w") end
end
function gps_yz_lts.dosomething2(n,l,w)
	if trymovesuccess then
		closeclass("gps_yz_lts")
		closeclass("gps_thrownpc")
	end
end
------------------------------------------------------------------------------------
-- gps_yz_ym
------------------------------------------------------------------------------------
function gps_yz_ym.dosomething1(n,l,w)
	if findstring(l,"这不是活物！") then
		if not thrownpcfaint then
			run("get ya;n;drop ya;s")
			alias.trymove("s")
		end
	end
	if findstring(l,"衙役喝道：“威……武……。”") then
		throw_npc="ya"
		trymovesuccess=false
		alias.tc(throw_npc)
	end
	if findstring(l,"衙役脚下一个不稳，跌在地上昏了过去。") then
		thrownpcfaint=true
		wait.make(function()
			local _f=function()
						run("drop gold;drop armor;get ya;n;drop ya;s;get gold")
						alias.trymove("s")
				end
			wait.time(2)
			_f()
		end)
	end
	if findstring(l,"衙役倒在地上，挣扎了几下就死了。") then alias.trymove("s") end
end
function gps_yz_ym.dosomething2(n,l,w)
	if trymovesuccess then
		closeclass("gps_yz_ym")
		closeclass("gps_thrownpc")
	end
end
------------------------------------------------------------------------------------
-- gps_yztd_1_2
------------------------------------------------------------------------------------
function gps_yztd_1_2.dosomething1(n,l,w)
	alias.close_gps_dealwith()
	if w[1]=="northwest" then gps_yztd122=w[2] else gps_yztd122=w[1] end
	gps_yztd322=""
	run("go "..gps_yztd122)
	alias.movefinish()
end
------------------------------------------------------------------------------------
-- gps_yztd_2_1
------------------------------------------------------------------------------------
function gps_yztd_2_1.dosomething1(n,l,w)
	alias.close_gps_dealwith()
	if w[1]==invDirection(gps_yztd122) or w[1]==invDirection(gps_yztd322) then gps_yztd221=w[2] else gps_yztd221=w[1] end
	run("halt;go "..gps_yztd221)
	alias.movefinish()
end
function gps_yztd_2_1.dosomething2(n,l,w)
	gps_yztd221=w[1]
	run("halt;go "..gps_yztd221..";look")
end
------------------------------------------------------------------------------------
-- gps_yztd_2_3
------------------------------------------------------------------------------------
function gps_yztd_2_3.dosomething1(n,l,w)
	alias.close_gps_dealwith()
	if w[1]==invDirection(gps_yztd122) or w[1]==invDirection(gps_yztd322) then gps_yztd223=w[2] else gps_yztd223=w[1] end
	run("halt;go "..gps_yztd223)
	alias.movefinish()
end
function gps_yztd_2_3.dosomething2(n,l,w)
	gps_yztd223=w[1]
	run("halt;go "..gps_yztd223..";look")
end
------------------------------------------------------------------------------------
-- gps_yztd_3_2
------------------------------------------------------------------------------------
function gps_yztd_3_2.dosomething1(n,l,w)
	alias.close_gps_dealwith()
	if w[1]=="northeast" then gps_yztd322=w[2] else gps_yztd322=w[1] end
	gps_yztd122=""
	run("halt;go "..gps_yztd322..";look")
	alias.movefinish()
end
------------------------------------------------------------------------------------
-- gps_zhou
------------------------------------------------------------------------------------
function gps_zhou.dosomething1(n,l,w) alias.movefinish() end
------------------------------------------------------------------------------------
-- gps_zeikou
------------------------------------------------------------------------------------
function gps_zeikou.dosomething1(n,l,w)
	local _f,_tb
	if findstring(l,"往后一纵，说道：好！","毛贼往大岩石上一跳，转眼就不见了","毛贼倒在地上，挣扎了几下就死了。","星宿派弟子死了！","草寇死了！","草寇倒在地上，挣扎了几下就死了！","马贼死了！","山贼死了！","毛贼带着毛贼往大岩石上一跳，转眼就不见了。","突然卖一破绽，跳出战圈，逃了！") then
		npcfaint=true
		run("set killover=zeikou")
		killaction=""
	end
	if findstring(l,"这不是你的蛇，它不会听从你的指挥的。") then
		if not isopen("kill_bt") then run(tostring(safego)..";convert she") end
	end
	if findstring(l,"怪蛇看了看你，突然似箭一般跃起，准确地落在蛇杖上，盘了起来。") then
		if not isopen("kill_bt") then alias.close_gps_dealwith();alias.movefinish() end
	end
	if findstring(l,"你想劝服谁？","受到你佛法感招，决定罢手不斗。") then
		run("set killover=zeikou")
		killaction=""
	end
	wait.make(function()
		if findstring(l,"你正在劝服别人！","你刚劝服过他，想必这次不会再听你劝了。","对你理也不理") then
			_f=function()
						_tb=Split(gpszeikou," ")
						run("halt;persuade "..tostring(_tb[3]))
				end
			wait.time(2);_f()
		end
	end)
end
function gps_zeikou.dosomething2(n,l,w)
	if findstring(l,"zeikou") then
		gpszeikou=""
		--closeclass("kill_"..me.menpai)
		closeclass("kill")
		closeclass("kill_pfm")
		if me.menpai=="bt" then run("convert she");return end
		if stat.zixia>0 then run("yun sangong") end
		if me.master=="风清扬" and fjweapon=="jian" then run("jifa dodge dugu-jiujian") end
		alias.close_gps_dealwith()
		alias.movefinish()
	end
end
function gps_zeikou.dosomething3(n,l,w)
	if not isopen("kill_bt") then
		sheid=tonumber(sheid+1)
		run("stop she "..sheid)
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function gps.update()
	local _tb,_tb2
	local  gps_start_m_triggerlist={
	       {name="gps_start_dosth1",line=2,regexp="^(> > > |> > |> |)(.+) - \\n(.*)\\Z",script=function(n,l,w)    gps_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"gps_start",v.script,v.line)
	end
	local  gps_start_triggerlist={
	       {name="gps_start_dosth2",regexp="^\\s*这里.{4}的出口是 (.*)。$",script=function(n,l,w)    gps_start.dosomething2(n,l,w)  end,},
	       {name="gps_start_dosth3",regexp="^(> > > |> > |> |)(\\S+) - ",script=function(n,l,w)    gps_start.dosomething3(n,l,w)  end,},
	       {name="gps_start_dosth4",regexp="^(\\S+)( - (\\S+)){0,1}",script=function(n,l,w)    gps_start.dosomething4(n,l,w)  end,},
	       {name="gps_start_dosth5",regexp="^(> > > |> > |> |)你目前还没有任何为 (\\S+) 的变量设定。",script=function(n,l,w)    gps_start.dosomething5(n,l,w)  end,},
	       {name="gps_start_dosth6",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    gps_start.dosomething6(n,l,w)  end,},
	}
	for k,v in pairs(gps_start_triggerlist) do
		addtri(v.name,v.regexp,"gps_start",v.script,v.line)
	end
	closeclass("gps_start")
	
	local _tb={
		"此书乃吾留予后代峨嵋聪慧弟子，\\n还忘师太能把书留在此处以便他人阅读参悟。\\Z",
		"好象有一只蝙蝠停在你身后的岩石上。\\n你像没头苍蝇一样在洞里瞎钻，结果一头撞在洞壁上。\\Z",
		"你像没头苍蝇一样在洞里瞎钻，结果一头撞在洞壁上。\\n你觉得你晕乎乎的，似乎撞傻了。\\Z",
		"只听里面有人说了声：阁下光临敝帮有何贵干？\\n什么？\\Z",
		"你被草寇挡住了去路。\\n草寇喝道：想溜？没门！\\Z",
		"你被挡住了去路。\\n毛贼喝道：想溜？没门！\\Z",
		"守城军官瞅著你，举起手中兵器，挡住你的去路。\\n临阵脱逃可是得受军法处置，你还是先帮忙力据蒙古大军吧。\\Z",
	}
	local  gps_watch_m_triggerlist={
	       {name="gps_watch_dosth1",line=2,regexp=linktri(_tb),script=function(n,l,w)    gps_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_watch_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"gps_watch",v.script,v.line)
	end
	
	_tb={
		"别那么自私！你不能带走超过一把兵器。",
		"草寇向你一阵阴笑：爽快的将宝贝交出来，不然叫你后悔莫及！",
		".+此地不适合施展一苇渡江绝技！",
		"老师傅拦着你说：你想把食物拿去哪里？东西放下再走。",
		"马贼凶巴巴地叫道：放聪明点，快将宝贝交出来！ ",
		"明教弟子指了指你拿着的食物，说道：根据教规，明教弟子不得将食物带出大食殿。",
		"南面乃峨嵋女侠休息之所，这位\\S+还请留步。",
		"你的动作还没有完成，不能移动。",
		"你刚要进入秘洞，一股巨大的力量将你挡在了洞口！",
		"你还没将《武学大全》归还\\(return\\)，就想溜？",
		"你还是先站起来再走吧！",
		"你脚下一滑，踩了个空！",
		"你一不小心脚下踏了个空，\\.\\.\\. 啊\\.\\.\\.！",
		"山贼大吼道：赶快将宝贝交出来，不然你就别指望活着离开！",
		"少林弟子岂可贪生怕死，以坠本派声名！",
		"石级旁边的草丛中忽然跃起一个身影，挡住了你！",
		"星宿派弟子恶狠狠地威胁道：快将宝贝交出来，否则取你狗命！",
		"袁紫衣说道：本姑娘在这里休息，别来打搅！",
		"这个方向没有出路。",
		"艄公回到仓里，发现你还在，咦了一声, 说：“你还没有上岸啊, 我送你到岸边。",
		"你目前还没有任何为 gps=false 的变量设定。",
		"\\.*四下景况似乎和寻常所见略有不同，透出森森鬼气。",
		"\\.*一阵微风吹过，四面景致似乎起了些变化。",
	}
	local  gps_watch_triggerlist={
	       {name="gps_watch_dosth11",regexp=linktri(_tb),script=function(n,l,w)    gps_watch.dosomething1(n,l,w)  end,},
	       {name="gps_watch_dosth2",regexp="^(> > > |> > |> |)(\\S+)\\s+-\\s+",script=function(n,l,w)    gps_watch.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_watch_triggerlist) do
		addtri(v.name,v.regexp,"gps_watch",v.script,v.line)
	end
	closeclass("gps_watch")
	
	_tb={
		"(武当NPC|灵虚道长|凌虚道长|张松溪)倒在地上，挣扎了几下就死了。",
		"这里没有这个人。",
		"(白驼NPC|家丁)倒在地上，挣扎了几下就死了。",
		"(西域NPC|胡老爷)倒在地上，挣扎了几下就死了。",
		"(长乐帮NPC|邱山风|司徒横|帮众)倒在地上，挣扎了几下就死了。",
		"(峨嵋NPC|静心)倒在地上，挣扎了几下就死了。",
		"(华山NPC|劳德诺|梁发|陆大有|宁中则|岳灵姗|施戴子|高根明)倒在地上，挣扎了几下就死了。",
		"(华山NPC|宁中则|岳灵姗)往\\S+落荒而逃了。",
		"(杭州NPC|天鹰教守卫|都大锦)倒在地上，挣扎了几下就死了。",
		"(明教NPC|说不得)倒在地上，挣扎了几下就死了。",
		"(西夏NPC|皇宫卫士|校尉|一品堂武士)倒在地上，挣扎了几下就死了。",
		"(南阳NPC|守城官兵)倒在地上，挣扎了几下就死了。",
		"(祁连山NPC|日月神教卫士)倒在地上，挣扎了几下就死了。",
		"(全真NPC|张志光|谭处端)倒在地上，挣扎了几下就死了。",
		"(少林NPC|虚通|虚明|清观比丘|清乐比丘)倒在地上，挣扎了几下就死了。",
		"(雪山NPC|葛伦布|萨木活佛|戒律僧)倒在地上，挣扎了几下就死了。",
		"(星宿NPC|狮吼子|采花子)倒在地上，挣扎了几下就死了。",
		"(扬州NPC|婢女|蒙古军官)倒在地上，挣扎了几下就死了。",
		"(武当NPC|\\S*将灵虚道长扶了起来背在背上。)",
		"(星宿NPC|狮吼子一言不发，闪身拦在你面前。)",
		"\\S*(少林NPC|千年以来，少林向不许女流擅入。|你不是少林弟子，不得进入后殿。|请留步，恕小寺不接待女客。)",
		"\\S*(没过阵|这位女施主还是请回罢|这位施主请回罢|立时从身畔挚出一把雪亮的戒刀来)",
		"(长乐帮NPC|帮众拦在你面前，说道：里面是关押本帮叛徒的地方，你请回吧。)",
		"(星宿NPC|采花子挡住了你：我的小妞可不是给你们)",
		"(少林NPC|道一说道: 你未经许可，不能上二楼。)",
		"(杭州NPC|都大锦拦在你面前，喝道：)",
		"(华山NPC|高根明拦住你说：由此往上乃本派禁地，请止步。)",
		"(雪山NPC|葛伦布挡住你说：你准备用什麽供奉我们佛爷呀？)",
		"(西域NPC|胡老爷说: 我把阿凡提关在我的客厅里了，谁也不许进去。)",
		"(白驼NPC|家丁挡住了你的去路：老爷正在练功，请改日再来。)",
		"(归云庄NPC|家丁做了个揖，说道：尊驾与敝庄素无往来，庄主不见外客，还是请回吧)",
		"(丐帮NPC|简长老一把揪住你的衣领说：“慢着！”)",
		"(丐帮NPC|简长老)倒在地上，挣扎了几下就死了。",
		"(泰山NPC|江百胜伸手拦住你说道：盟主很忙，现在不见外客，你下山去吧！)",
		"(泰山NPC|江百胜倒在地上，挣扎了几下就死了。)",
		"(雪山NPC|戒律僧挡住你说：后面乃本寺重地，请回吧！)",
		"(峨嵋NPC|静心师太走上前说：后边是峨嵋弟子练功休息的地方，请留步。)",
		"(华山NPC|劳德诺欠身说道：这位)",
		"(华山NPC|梁发挡住你说道：后面是本派书院，这位)",
		"(武当NPC|凌虚道长喝道：如不是上山敬香，即刻请回！)",
		"(华山NPC|陆大有喝道：后面是华山派的内院，这位)",
		"(扬州NPC|蒙古军官一语不发，站在你面前挡著你的去路！)",
		"(华山NPC|宁中则拦在你身前斥道：外人不能随易出入本派重地！还不快给我离开？)",
		"(少林NPC|清观喝道：你不是少林弟子，不得进入后山竹林！)",
		"\\S*(长乐帮NPC|怎么连一点江湖规矩都不懂？起码也得孝敬一下老子。)",
		"\\S*(武当NPC|如不是上山敬香，即刻请回！)",
		"(雪山NPC|萨木活佛挡住你说道：後面是本寺高僧修行之地，施主请回。)",
		"(华山NPC|施戴子拦住你说：两位师叔祖不欲见客，请回吧。)",
		"(明教NPC|说不得伸手拦住你，说道：上面是明教光明顶，这位\\S+并非我教弟子，请止步!)",
		"(长乐帮NPC|司徒横拦在你面前，喝道：)",
		"(杭州NPC|天鹰教守卫喝道：这位)",
		"(西夏NPC|卫士对你大吼一声：放肆！那不是你能进去的地方。)",
		"(祁连山NPC|卫士对你喝道：看招！别妄想闯入本教重地！)",
		"(祁连山NPC|卫士对着你喝道：看招！别妄想在本大爷手下救人！)",
		"(西夏NPC|校尉挡住了你的去路！)",
		"(少林NPC|请放下兵刃。少林千年的规矩，外客)",
		"(西夏NPC|一品堂武士挡住了你的去路！)",
		"(华山NPC|岳灵姗拦身说道：后面是本派厨房)",
		"(武当NPC|张松溪喝道：里面是武当重地，闲人请止步。)",
		"(全真NPC|张志光拦住说道：对不起，养心殿不对外开放！)",
		"(扬州NPC|婢女伸手挡住了你的去路：少庄主正在调训毒蛇，请改日再来。)",
		"(归云庄NPC|家丁)倒在地上，挣扎了几下就死了。",
		"你目前还没有任何为 checkmove=yes 的变量设定。",
		"你目前还没有任何为 check=dealwith 的变量设定。",
		"你目前还没有任何为 killover=GPS 的变量设定。",
		"你目前还没有任何为 (.+) 的变量设定。",
		"你.+一招",
	}
	local  gps_dealwith_triggerlist={
	       {name="gps_dealwith_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_dealwith.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_dealwith_triggerlist) do
		addtri(v.name,v.regexp,"gps_dealwith",v.script,v.line)
	end
	AddTimer("gps_dealwith_kill_timer", 0, 0, 5, "", timer_flag.Enabled + timer_flag.Replace, "gps_dealwith.timer")
	SetTimerOption("gps_dealwith_kill_timer", "group", "gps_dealwith")
	closeclass("gps_dealwith")
	
	_tb={
		"忽然一阵腥风袭来，一条巨蟒从身旁大树上悬下，把你卷走了。",
		"巨蟒全身扭曲，翻腾挥舞，终於僵直而死了。",
	}
	_tb2={
	"你目前还没有任何为 .+ 的变量设定。"
	}
	local  gps_99guai_triggerlist={
	       {name="gps_99guai_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_99guai.dosomething1(n,l,w)  end,},
	       {name="gps_99guai_dosth2",regexp=linktri(_tb2),script=function(n,l,w)    gps_99guai.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_99guai_triggerlist) do
		addtri(v.name,v.regexp,"gps_99guai",v.script,v.line)
	end
	closeclass("gps_99guai")
	
	_tb={
		"那个方向没法爬。",
		"你爬了上来。",
		"你爬了下来。",
	}
	local  gps_climbxy_triggerlist={
	       {name="gps_climbxy_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_climbxy.dosomething1(n,l,w)  end,},
	       {name="gps_climbxy_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 (.+) 的变量设定。",script=function(n,l,w)    gps_climbxy.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_climbxy_triggerlist) do
		addtri(v.name,v.regexp,"gps_climbxy",v.script,v.line)
	end
	closeclass("gps_climbxy")
	
	_tb={
		"这不是活物！",
		"守卫喝道：闲杂人等，不得乱闯。",
		"傅思归脚下一个不稳，跌在地上昏了过去。",
		"傅思归倒在地上，挣扎了几下就死了。",
	}
	local  gps_dl_fsg_triggerlist={
	       {name="gps_dl_fsg_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_dl_fsg.dosomething1(n,l,w)  end,},
	       {name="gps_dl_fsg_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 (.+) 的变量设定。",script=function(n,l,w)    gps_dl_fsg.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_dl_fsg_triggerlist) do
		addtri(v.name,v.regexp,"gps_dl_fsg",v.script,v.line)
	end
	closeclass("gps_dl_fsg")
	
	_tb={
		"巨蟒全身扭曲，翻腾挥舞，终於僵直而死了。",
	}
	local  gps_em_killjm_triggerlist={
	       {name="gps_em_killjm_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_em_killjm.dosomething1(n,l,w)  end,},
	       {name="gps_em_killjm_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 (.+) 的变量设定。",script=function(n,l,w)    gps_em_killjm.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_em_killjm_triggerlist) do
		addtri(v.name,v.regexp,"gps_em_killjm",v.script,v.line)
	end
	closeclass("gps_em_killjm")
	
	_tb={
		"船夫说：“塘沽口到啦，上岸吧”。",
		"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。",
		"船正往.+方向前进。",
	}
	local  gps_lsd_back_triggerlist={
	       {name="gps_lsd_back_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_lsd_back.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_lsd_back_triggerlist) do
		addtri(v.name,v.regexp,"gps_lsd_back",v.script,v.line)
	end
	closeclass("gps_lsd_back")
	
	_tb={
		"船夫说：“灵蛇岛到啦，上岸吧”。",
		"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。",
		"船正往.+方向前进。",
		"你现在在塘沽口。",
		"你现在在塘沽口正南约(.+)海哩。",
		--"你现在在塘沽口东约(.+)海哩南约(.+)海哩",
		--"你极目远眺，发现(.+)方向数里外是个树木葱翠的海岛，岛上奇峰挺拔，耸立着好几座高山。",
	}
	local  gps_lsd_go_triggerlist={
	       {name="gps_lsd_go_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_lsd_go.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_lsd_go_triggerlist) do
		addtri(v.name,v.regexp,"gps_lsd_go",v.script,v.line)
	end
	closeclass("gps_lsd_go")
	
	_tb={
		"守城官兵倒在地上，挣扎了几下就死了。",
		"守城官兵脚下一个不稳，跌在地上昏了过去。",
		"守城军官瞅著你，举起手中兵器，挡住你的去路。",
		"这不是活物！",
	}
	local  gps_nanyang_triggerlist={
	       {name="gps_nanyang_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_nanyang.dosomething1(n,l,w)  end,},
	       {name="gps_nanyang_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 (.+) 的变量设定。",script=function(n,l,w)    gps_nanyang.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_nanyang_triggerlist) do
		addtri(v.name,v.regexp,"gps_nanyang",v.script,v.line)
	end
	closeclass("gps_nanyang")
	
	_tb={
		"(武将|官兵)倒在地上，挣扎了几下就死了。",
		"(武将|官兵)脚下一个不稳，跌在地上昏了过去。",
		"(武将|官兵)大喝道：都督有令，闲杂人等不能由此经过！",
		"这不是活物！",
	}
	local  gps_qzh_mcx_triggerlist={
	       {name="gps_qzh_mcx_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_qzh_mcx.dosomething1(n,l,w)  end,},
	       {name="gps_qzh_mcx_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 (.+) 的变量设定。",script=function(n,l,w)    gps_qzh_mcx.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_qzh_mcx_triggerlist) do
		addtri(v.name,v.regexp,"gps_qzh_mcx",v.script,v.line)
	end
	closeclass("gps_qzh_mcx")
	
	_tb={
		"(武将|官兵)倒在地上，挣扎了几下就死了。",
		"(武将|官兵)脚下一个不稳，跌在地上昏了过去。",
		"(武将|官兵)拦住了你的去路。",
		"这不是活物！",
	}
	local  gps_qzh_sl_triggerlist={
	       {name="gps_qzh_sl_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_qzh_sl.dosomething1(n,l,w)  end,},
	       {name="gps_qzh_sl_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 (.+) 的变量设定。",script=function(n,l,w)    gps_qzh_sl.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_qzh_sl_triggerlist) do
		addtri(v.name,v.regexp,"gps_qzh_sl",v.script,v.line)
	end
	closeclass("gps_qzh_sl")
	
	local  gps_qzh_xmdq_triggerlist={
	       {name="gps_qzh_xmdq_dosth1",regexp="^\\s*这里.{4}的出口是 (.*)。$",script=function(n,l,w)    gps_qzh_xmdq.dosomething1(n,l,w)  end,},
	       {name="gps_qzh_xmdq_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checklook=yes 的变量设定。",script=function(n,l,w)    gps_qzh_xmdq.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_qzh_xmdq_triggerlist) do
		addtri(v.name,v.regexp,"gps_qzh_xmdq",v.script,v.line)
	end
	closeclass("gps_qzh_xmdq")
	
	_tb={
		"良久，你突然有一股破壁\\(strike\\)的冲动。",
		"只听得身后石头稀里哗拉坍塌下来，封住了入口。",
	}
	local  gps_sgy_sd_triggerlist={
	       {name="gps_sgy_sd_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_sgy_sd.dosomething1(n,l,w)  end,},
	       {name="gps_sgy_sd_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checkmianbi=yes 的变量设定。",script=function(n,l,w)    gps_sgy_sd.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_sgy_sd_triggerlist) do
		addtri(v.name,v.regexp,"gps_sgy_sd",v.script,v.line)
	end
	closeclass("gps_sgy_sd")
	
	_tb={
		"大门天亮前不开，怎么敲也没用。",
		"大门已经是开着了。",
		"你轻轻地敲了敲门，只听吱地一声，一位壮年僧人应声打开大门",
		"吱地一声，里面有人把大门打开了",
	}
	local  gps_sl_gate_triggerlist={
	       {name="gps_sl_gate_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_sl_gate.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_sl_gate_triggerlist) do
		addtri(v.name,v.regexp,"gps_sl_gate",v.script,v.line)
	end
	closeclass("gps_sl_gate")
	
	local  gps_sl_sl_triggerlist={
	       {name="gps_sl_sl_dosth1",regexp="这里明显的出口是\\s+(\\w+)\\s+和\\s+(\\w+)。",script=function(n,l,w)    gps_sl_sl.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_sl_sl_triggerlist) do
		addtri(v.name,v.regexp,"gps_sl_sl",v.script,v.line)
	end
	closeclass("gps_sl_sl")
	
	_tb={
		"木筏又被冲到河中央去了。",
		"你操上手中的家伙，从树上砍下一些树枝。",
		"你划了半天，木筏终於靠岸了。",
		"你砍下的树枝似乎足够做\\(make\\)一个木筏\\(raft\\)了。",
		"你用砍下的树枝做了一个木筏。",
		"疏勒河西岸\\s+-",
	}
	local  gps_slh_triggerlist={
	       {name="gps_slh_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_slh.dosomething1(n,l,w)  end,},
	       {name="gps_slh_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 busyover=up 的变量设定。",script=function(n,l,w)    gps_slh.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_slh_triggerlist) do
		addtri(v.name,v.regexp,"gps_slh",v.script,v.line)
	end
	closeclass("gps_slh")
	
	_tb={
		"\\s+这里明显的出口是\\s+(\\w+)\\s+和\\s+(\\w+)。",
		"(一条渔船应声慢慢驶了过来，渔夫将一块踏脚板搭在沙滩上。|别叫了，这么大眼睛没看见船？)",
		"你大喝一声“开船”，于是船便离了岸。",
		"船夫说：“舟山到啦，上岸吧”。",
		"船正往.+方向前进。",
		"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。",
	}
	local  gps_thd_back_triggerlist={
	       {name="gps_thd_back_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_thd_back.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_thd_back_triggerlist) do
		addtri(v.name,v.regexp,"gps_thd_back",v.script,v.line)
	end
	closeclass("gps_thd_back")
	
	_tb={
		"穷光蛋，一边呆着去！",
		"\\s+这里明显的出口是\\s+(\\w+)\\s+和\\s+(\\w+)。",
		"(一条渔船应声慢慢驶了过来，渔夫将一块踏脚板搭在沙滩上。|别叫了，这么大眼睛没看见船？)",
		"船夫说：“桃花岛到啦，上岸吧”。",
		"你大喝一声“开船”，于是船便离了岸。",
		"船正往.+方向前进。",
		"船夫说：叹！漂到了一荒岛，还是赶紧离开吧。",
		"你现在在舟山正南约(.+)海哩。",
		"你现在在舟山。",
	}
	local  gps_thd_go_triggerlist={
	       {name="gps_thd_go_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_thd_go.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_thd_go_triggerlist) do
		addtri(v.name,v.regexp,"gps_thd_go",v.script,v.line)
	end
	closeclass("gps_thd_go")
	
	_tb={
		"今有物不知其数，三三数之剩(.+)，五五数之剩(.+)，七七数之剩(.+)，问物几何？",
		"只听得“隆隆”几声大响，石门缓缓向一侧划开",
		"甬道顶部忽然飘落一束薄卷轴，",
	}
	local  gps_thd_ms_triggerlist={
	       {name="gps_thd_ms_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_thd_ms.dosomething1(n,l,w)  end,},
	       {name="gps_thd_ms_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 busyover=ms 的变量设定。",script=function(n,l,w)    gps_thd_ms.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_thd_ms_triggerlist) do
		addtri(v.name,v.regexp,"gps_thd_ms",v.script,v.line)
	end
	closeclass("gps_thd_ms")

	local  gps_thd_sg_triggerlist={
	       {name="gps_thd_sg_dosth1",regexp="傻姑傻笑了几声，伸开双手一拦，说到：要进去先陪我玩一会儿吧，",script=function(n,l,w)    gps_thd_sg.dosomething1(n,l,w)  end,},
	       {name="gps_thd_sg_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checkmove=yes 的变量设定。",script=function(n,l,w)    gps_thd_sg.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_thd_sg_triggerlist) do
		addtri(v.name,v.regexp,"gps_thd_sg",v.script,v.line)
	end
	closeclass("gps_thd_sg")
	
	_tb={
		"小径 -","树丛 -","石洞 -","桃花林 -",
		"现在泥潭时间是.+年.+月.+日(.+)时.+。",
		"你目前还没有任何为 busyover=zhoubotong 的变量设定。",
		"你目前还没有任何为 busyover=passthl 的变量设定。",
	}
	local  gps_thd_thl_triggerlist={
	       {name="gps_thd_thl_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_thd_thl.dosomething1(n,l,w)  end,},
	       {name="gps_thd_thl_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 busyover=thl 的变量设定。",script=function(n,l,w)    gps_thd_thl.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_thd_thl_triggerlist) do
		addtri(v.name,v.regexp,"gps_thd_thl",v.script,v.line)
	end
	closeclass("gps_thd_thl")
	
	_tb={
		"只见.+往后一纵，说道：好！纪晓芙在此相劝，看在人家的面子上，这次就算了。",
		"你胜了这招，向后跃开三尺，笑道：承让！",
		"你双手一拱，笑著说道：承让！",
		"你哈哈大笑，说道：承让了！",
		".+向后一纵，躬身做揖说道：阁下武艺不凡，果然高明！",
		".+向后退了几步，说道：这场比试算我输了，佩服，佩服！",
		".+脸色微变，说道：佩服，佩服！",
	}
	local  gps_thrownpc_triggerlist={
	       {name="gps_thrownpc_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_thrownpc.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_thrownpc_triggerlist) do
		addtri(v.name,v.regexp,"gps_thrownpc",v.script,v.line)
	end
	closeclass("gps_thrownpc")
	
	_tb={
		"你对你说道：“您的大恩大德小弟没齿难忘！”",
		"牢门缓缓地开启了．．．",
	}
	local  gps_waitrelease_triggerlist={
	       {name="gps_waitrelease_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_waitrelease.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_waitrelease_triggerlist) do
		addtri(v.name,v.regexp,"gps_waitrelease",v.script,v.line)
	end
	AddTimer("gps_waitrelease_timer", 0, 0, 30, "", timer_flag.Enabled + timer_flag.Replace, "gps_waitrelease.timer")
	SetTimerOption("gps_waitrelease_timer", "group", "gps_waitrelease")
	closeclass("gps_waitrelease")
	
	_tb={
		"\\s+这里唯一的出口是 (.+)。",
		"\\s+这里明显的出口是 northup、(\\w+) 和 (.+)。",
		"\\s+这里明显的出口是 (\\w+)、northup 和 (.+)。",
		"\\s+这里明显的出口是 (\\w+)、(\\w+) 和\\s+northup。",
		"\\s+这里明显的出口是 (\\w+) 和 (\\w+)。",
	}
	local  gps_xxmap_triggerlist={
	       {name="gps_xxmap_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_xxmap.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_xxmap_triggerlist) do
		addtri(v.name,v.regexp,"gps_xxmap",v.script,v.line)
	end
	closeclass("gps_xxmap")

	local  gps_xydcy_triggerlist={
	       {name="gps_xydcy_dosth1",regexp="^(> > > |> > |> |)大草原\\s+-\\s+(.+)",script=function(n,l,w)    gps_xydcy.dosomething1(n,l,w)  end,},
	       {name="gps_xydcy_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checkxydcy=yes 的变量设定。",script=function(n,l,w)    gps_xydcy.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_xydcy_triggerlist) do
		addtri(v.name,v.regexp,"gps_xydcy",v.script,v.line)
	end
	closeclass("gps_xydcy")

	local  gps_xydcy_sl_triggerlist={
	       {name="gps_xydcy_sl_dosth1",regexp="^(> > > |> > |> |)疏勒\\s+-",script=function(n,l,w)    gps_xydcy_sl.dosomething1(n,l,w)  end,},
	       {name="gps_xydcy_sl_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checkxydcy=yes 的变量设定。",script=function(n,l,w)    gps_xydcy_sl.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_xydcy_sl_triggerlist) do
		addtri(v.name,v.regexp,"gps_xydcy_sl",v.script,v.line)
	end
	closeclass("gps_xydcy_sl")
	
	_tb={
		"凌退思倒在地上，挣扎了几下就死了。",
		"凌退思脚下一个不稳，跌在地上昏了过去。",
		"凌翰林挡住了你：请勿入内宅。",
		"这不是活物！",
	}
	local  gps_yz_lts_triggerlist={
	       {name="gps_yz_lts_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_yz_lts.dosomething1(n,l,w)  end,},
	       {name="gps_yz_lts_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checkmove=yes 的变量设定。",script=function(n,l,w)    gps_yz_lts.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_yz_lts_triggerlist) do
		addtri(v.name,v.regexp,"gps_yz_lts",v.script,v.line)
	end
	closeclass("gps_yz_lts")
	
	_tb={
		"衙役倒在地上，挣扎了几下就死了。",
		"衙役脚下一个不稳，跌在地上昏了过去。",
		"衙役喝道：“威……武……。”",
		"这不是活物！",
	}
	local  gps_yz_ym_triggerlist={
	       {name="gps_yz_ym_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_yz_ym.dosomething1(n,l,w)  end,},
	       {name="gps_yz_ym_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 checkmove=yes 的变量设定。",script=function(n,l,w)    gps_yz_ym.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_yz_ym_triggerlist) do
		addtri(v.name,v.regexp,"gps_yz_ym",v.script,v.line)
	end
	closeclass("gps_yz_ym")
	
	local  gps_yztd_1_2_triggerlist={
	       {name="gps_yztd_1_2_dosth1",regexp="\\s*这里明显的出口是\\s+(\\w+)\\s*和\\s*(\\w+)。",script=function(n,l,w)    gps_yztd_1_2.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_yztd_1_2_triggerlist) do
		addtri(v.name,v.regexp,"gps_yztd_1_2",v.script,v.line)
	end
	closeclass("gps_yztd_1_2")
	
	local  gps_yztd_2_1_triggerlist={
	       {name="gps_yztd_2_1_dosth1",regexp="^\\s*这里明显的出口是\\s+(\\w+)\\s*和\\s*(\\w+)。",script=function(n,l,w)    gps_yztd_2_1.dosomething1(n,l,w)  end,},
	       {name="gps_yztd_2_1_dosth2",regexp="^\\s*这里唯一的出口是\\s*(\\w+)。",script=function(n,l,w)    gps_yztd_2_1.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_yztd_2_1_triggerlist) do
		addtri(v.name,v.regexp,"gps_yztd_2_1",v.script,v.line)
	end
	closeclass("gps_yztd_2_1")
	
	local  gps_yztd_2_3_triggerlist={
	       {name="gps_yztd_2_3_dosth1",regexp="^\\s*这里明显的出口是\\s+(\\w+)\\s*和\\s*(\\w+)。",script=function(n,l,w)    gps_yztd_2_3.dosomething1(n,l,w)  end,},
	       {name="gps_yztd_2_3_dosth2",regexp="^\\s*这里唯一的出口是\\s*(\\w+)。",script=function(n,l,w)    gps_yztd_2_3.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_yztd_2_3_triggerlist) do
		addtri(v.name,v.regexp,"gps_yztd_2_3",v.script,v.line)
	end
	closeclass("gps_yztd_2_3")
	
	local  gps_yztd_3_2_triggerlist={
	       {name="gps_yztd_3_2_dosth1",regexp="\\s*这里明显的出口是\\s+(\\w+)\\s*和\\s*(\\w+)。",script=function(n,l,w)    gps_yztd_3_2.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_yztd_3_2_triggerlist) do
		addtri(v.name,v.regexp,"gps_yztd_3_2",v.script,v.line)
	end
	closeclass("gps_yztd_3_2")
	
	local  gps_zhou_triggerlist={
	       {name="gps_zhou_dosth1",regexp="忽然有个人拉住你，进了洞。你跟着那人在黑暗中左转右转，不久就出了洞。",script=function(n,l,w)    gps_zhou.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(gps_zhou_triggerlist) do
		addtri(v.name,v.regexp,"gps_zhou",v.script,v.line)
	end
	closeclass("gps_zhou")
	
	_tb={
		"只见.+往后一纵，说道：好！.+在此相劝，看在人家的面子上，这次就算了。",
		"只见.+往后一纵，说道：好！.+良言相劝，暂且罢手。",
		"这不是你的蛇，它不会听从你的指挥的。",
		"毛贼往大岩石上一跳，转眼就不见了",
		"怪蛇看了看你，突然似箭一般跃起，准确地落在蛇杖上，盘了起来。",
		"你想劝服谁？",
		"你正在劝服别人！",
		"你刚劝服过他，想必这次不会再听你劝了。",
		"毛贼倒在地上，挣扎了几下就死了。",
		"马贼死了！",
		"山贼死了！",
		"毛贼带着毛贼往大岩石上一跳，转眼就不见了。",
		"草寇死了！",
		"草寇倒在地上，挣扎了几下就死了！",
		"星宿派弟子死了！",
		".+突然卖一破绽，跳出战圈，逃了！",
		".+对你理也不理",
		".+受到你佛法感招，决定罢手不斗。",
	}
	local  gps_zeikou_triggerlist={
	       {name="gps_zeikou_dosth1",regexp=linktri(_tb),script=function(n,l,w)    gps_zeikou.dosomething1(n,l,w)  end,},
	       {name="gps_zeikou_dosth2",regexp="^(> > > |> > |> |)你目前还没有任何为 killover=zeikou 的变量设定。",script=function(n,l,w)    gps_zeikou.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(gps_zeikou_triggerlist) do
		addtri(v.name,v.regexp,"gps_zeikou",v.script,v.line)
	end
	script=function(n,l,w)    gps_zeikou.dosomething3(n,l,w)  end
	addtri_multiline("gps_zeikou_dosth3","^(> > > |> > |> |)你用蛇杖示意怪蛇停下来。\\n可是怪蛇理都不理。\\Z","gps_zeikou",script,2)
	closeclass("gps_zeikou")
	
	--local noecho_trilist={
		--	"^(> > > |> > |> |)你目前还没有任何为 (\\S+) 的变量设定。",
	--		}
	--local _noechotri=linktri(noecho_trilist)

	--addtri("gps_noecho",_noechotri,"gps","")
	--SetTriggerOption("gps_noecho","omit_from_output",1)
end
gps.update()

--[[
古墓地图更新
UPDATE Room SET Entrance='out|westdown', EntranceSafe='out' WHERE RoomNO=641;
INSERT INTO Entrance VALUES('gumuenter',4408,2060,641,'');
INSERT INTO Room VALUES('在地下潜流中,你只觉得水声轰轰,身子不由自主的被强大的水流向前','eastup|west','','','地下水道',2060,'古墓派',0);
INSERT INTO Entrance VALUES('eu',4409,641,2060,'');
INSERT INTO Entrance VALUES('w',4410,2061,2060,'');
INSERT INTO Room VALUES('在地下潜流中,你只觉得水声轰轰,身子不由自主的被强大的水流向前','east|westup','','','地下水道',2061,'古墓派',0);
INSERT INTO Entrance VALUES('e',4411,2060,2061,'');
INSERT INTO Entrance VALUES('wu',4412,2062,2061,'');
INSERT INTO Room VALUES('密道中乌漆妈黑，伸手不见五指，水面已升到了膝盖，并且不断上升','eastdown|westup','','','密道',2062,'古墓派',0);
INSERT INTO Entrance VALUES('ed',4413,2061,2062,'');
INSERT INTO Entrance VALUES('wu',4414,2063,2062,'');
INSERT INTO Room VALUES('密道中乌漆妈黑，伸手不见五指，但只觉越走越低，湿气也越来越重','eastdown|westup','','','密道',2063,'古墓派',0);
INSERT INTO Entrance VALUES('ed',4415,2062,2063,'');
INSERT INTO Entrance VALUES('wu',4416,2064,2063,'');
INSERT INTO Room VALUES('密道中乌漆妈黑，伸手不见五指，但只觉越走越低，湿气也越来越重','eastdown|up','','','密道',2064,'古墓派',0);
INSERT INTO Entrance VALUES('ed',4417,2063,2064,'');
INSERT INTO Entrance VALUES('u',4418,2065,2064,'');
INSERT INTO Room VALUES('室中也无特异之处，抬头仰望，但见室顶密密麻麻的写满了字迹符号，','down|up','','','石室',2065,'古墓派',0);
INSERT INTO Entrance VALUES('d',4419,2064,2065,'');
INSERT INTO Entrance VALUES('u',4420,2066,2065,'');
INSERT INTO Room VALUES('石室中放着五具石棺(guan)，其中两具石棺棺盖以密密盖着。据说放','east','','','石室',2066,'古墓派',0);
INSERT INTO Entrance VALUES('enterguan',4421,2067,2066,'');
INSERT INTO Entrance VALUES('e',4422,2068,2066,'');
INSERT INTO Room VALUES('你可以看到石棺底部有个可容一手的凹处，','out','','','棺',2067,'古墓派',0);
INSERT INTO Entrance VALUES('out',4423,2066,2067,'');
INSERT INTO Entrance VALUES('turnleft',4424,2065,2067,'');
INSERT INTO Room VALUES('这阴森森的走道，也不知道是通到哪ㄦ的。墙上的一枝小蜡烛，正哔','east|south|west','','','走道',2068,'古墓派',0);
INSERT INTO Entrance VALUES('w',4425,2066,2068,'');
INSERT INTO Entrance VALUES('s',4426,2069,2068,'');
INSERT INTO Entrance VALUES('e',4427,2070,2068,'');
INSERT INTO Room VALUES('由於古墓派只收女弟子，墓中也只有此一间休息室。室中几张石床上','north','','','弟子休息室',2069,'古墓派',0);
INSERT INTO Entrance VALUES('n',4428,2068,2069,'');
INSERT INTO Room VALUES('这大厅布置的极为简单，几张木椅和椅张桌子放在正当中，靠墙的椅','east|north|south|west','','','大厅',2070,'古墓派',0);
INSERT INTO Entrance VALUES('w',4429,2068,2070,'');
INSERT INTO Entrance VALUES('s',4430,2071,2070,'');
INSERT INTO Entrance VALUES('n',4431,2072,2070,'');
INSERT INTO Entrance VALUES('e',4432,2074,2070,'');
INSERT INTO Room VALUES('这里就是後堂了。只见堂上空空荡荡的没什麽陈设。几张椅子靠着墙','north','','','後堂',2071,'古墓派',0);
INSERT INTO Entrance VALUES('n',4433,2070,2071,'');
INSERT INTO Room VALUES('这阴森森的走道，也不知道是通到哪ㄦ的。墙上的一枝小蜡烛，正哔','east|north|south|west','north|south','','走道',2072,'古墓派',0);
INSERT INTO Entrance VALUES('s',4434,2070,2072,'');
INSERT INTO Entrance VALUES('n',4435,2073,2072,'');
INSERT INTO Room VALUES('这阴森森的走道，也不知道是通到哪ㄦ的。墙上的一枝小蜡烛，正哔','east|south|west','south','','走道',2073,'古墓派',0);
INSERT INTO Entrance VALUES('s',4436,2072,2073,'');
INSERT INTO Room VALUES('这阴森森的走道，也不知道是通到哪ㄦ的。墙上的一枝小蜡烛，正哔','north|south|west','','','走道',2074,'古墓派',0);
INSERT INTO Entrance VALUES('w',4437,2070,2074,'');
INSERT INTO Entrance VALUES('n',4438,2075,2074,'');
INSERT INTO Entrance VALUES('s',4439,2077,2074,'');
INSERT INTO Room VALUES('这里好像是个厨房。只见石室中的桌上放了些碗和碟子。墙角边堆满了','north|south','','','厨房',2075,'古墓派',0);
INSERT INTO Entrance VALUES('s',4440,2074,2075,'');
INSERT INTO Entrance VALUES('n',4441,2076,2075,'');
INSERT INTO Room VALUES('这里是个蜂房。许多蜜蜂来来往往的飞来飞去，还有不少玉峰，看起来品','south','','','蜂房',2076,'古墓派',0);
INSERT INTO Entrance VALUES('s',4442,2075,2076,'');
INSERT INTO Room VALUES('这石室形状甚是奇特，北窄南宽，成为梯形，东边半圆，西边却作','east|north','','','练功室',2077,'古墓派',0);
INSERT INTO Entrance VALUES('n',4443,2074,2077,'');
INSERT INTO Entrance VALUES('e',4444,2078,2077,'');
INSERT INTO Room VALUES('这石室和西边那石室是处处对称，ㄦ又处处相反，乃是北宽南窄，西圆东角,','west','','','练功室',2078,'古墓派',0);
INSERT INTO Entrance VALUES('w',4445,2077,2078,'');
UPDATE Entrance set Condition=null WHERE ID>=4408 and ID<=4445;

--------------------------------------------------------------------------------------------------------------------------------

UPDATE Room SET EntranceSafe='east|west' WHERE RoomNO=841;
UPDATE Room SET EntranceSafe='east|west' WHERE RoomNO=840;
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|northeast|northwest|southeast|southwest|west','','','树林',2079,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4446,2080,2079,null);
INSERT INTO Entrance VALUES('n',4447,2082,2079,null);
INSERT INTO Entrance VALUES('ne',4448,2083,2079,null);
INSERT INTO Entrance VALUES('nw',4449,2084,2079,null);
INSERT INTO Entrance VALUES('se',4450,841,2079,null);
INSERT INTO Entrance VALUES('sw',4451,840,2079,null);
INSERT INTO Entrance VALUES('w',4452,2081,2079,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','north|west','','','树林',2080,'华山村树林',0);
INSERT INTO Entrance VALUES('n',4453,2083,2080,null);
INSERT INTO Entrance VALUES('w',4454,2079,2080,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|northwest','','','树林',2081,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4455,2079,2081,null);
INSERT INTO Entrance VALUES('n',4456,2084,2081,null);
INSERT INTO Entrance VALUES('nw',4457,2097,2081,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|south|west','','','树林',2082,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4458,2083,2082,null);
INSERT INTO Entrance VALUES('n',4459,2096,2082,null);
INSERT INTO Entrance VALUES('s',4460,2079,2082,null);
INSERT INTO Entrance VALUES('w',4461,2084,2082,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','northeast|south|southwest|west','','','树林',2083,'华山村树林',0);
INSERT INTO Entrance VALUES('ne',4462,2094,2083,null);
INSERT INTO Entrance VALUES('s',4463,2080,2083,null);
INSERT INTO Entrance VALUES('sw',4464,2079,2083,null);
INSERT INTO Entrance VALUES('w',4465,2082,2083,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|south|southeast|southwest','','','树林',2084,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4466,2082,2084,null);
INSERT INTO Entrance VALUES('s',4467,2081,2084,null);
INSERT INTO Entrance VALUES('se',4468,2079,2084,null);
INSERT INTO Entrance VALUES('sw',4469,2097,2084,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|northwest|southeast|southwest|west','','','树林',2085,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4470,2087,2085,null);
INSERT INTO Entrance VALUES('n',4471,841,2085,null);
INSERT INTO Entrance VALUES('nw',4472,840,2085,null);
INSERT INTO Entrance VALUES('se',4473,2089,2085,null);
INSERT INTO Entrance VALUES('sw',4474,2088,2085,null);
INSERT INTO Entrance VALUES('w',4475,2086,2085,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|south','','','树林',2086,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4476,2085,2086,null);
INSERT INTO Entrance VALUES('s',4477,2088,2086,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','south|southeast|southwest|west','','','树林',2087,'华山村树林',0);
INSERT INTO Entrance VALUES('s',4478,2091,2087,null);
INSERT INTO Entrance VALUES('se',4479,2090,2087,null);
INSERT INTO Entrance VALUES('sw',4480,2089,2087,null);
INSERT INTO Entrance VALUES('w',4481,2085,2087,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|northeast|south','','','树林',2088,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4482,2089,2088,null);
INSERT INTO Entrance VALUES('n',4483,2086,2088,null);
INSERT INTO Entrance VALUES('ne',4484,2085,2088,null);
INSERT INTO Entrance VALUES('s',4485,2093,2088,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','northeast|northwest|south|southwest|west','','','树林',2089,'华山村树林',0);
INSERT INTO Entrance VALUES('ne',4486,2087,2089,null);
INSERT INTO Entrance VALUES('nw',4487,2085,2089,null);
INSERT INTO Entrance VALUES('s',4488,2092,2089,null);
INSERT INTO Entrance VALUES('sw',4489,2093,2089,null);
INSERT INTO Entrance VALUES('w',4490,2088,2089,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','northwest|southwest','','','树林',2090,'华山村树林',0);
INSERT INTO Entrance VALUES('nw',4491,2087,2090,null);
INSERT INTO Entrance VALUES('sw',4492,2091,2090,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','north|northeast|west','','','树林',2091,'华山村树林',0);
INSERT INTO Entrance VALUES('n',4493,2087,2091,null);
INSERT INTO Entrance VALUES('ne',4494,2090,2091,null);
INSERT INTO Entrance VALUES('w',4495,2092,2091,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|west','','','树林',2092,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4496,2091,2092,null);
INSERT INTO Entrance VALUES('n',4497,2089,2092,null);
INSERT INTO Entrance VALUES('w',4498,2093,2092,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|north|northeast','','','树林',2093,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4499,2092,2093,null);
INSERT INTO Entrance VALUES('n',4500,2088,2093,null);
INSERT INTO Entrance VALUES('ne',4501,2089,2093,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','east|southwest','','','树林',2094,'华山村树林',0);
INSERT INTO Entrance VALUES('e',4502,2095,2094,null);
INSERT INTO Entrance VALUES('sw',4503,2083,2094,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','west','','','树林',2095,'华山村树林',0);
INSERT INTO Entrance VALUES('w',4504,2094,2095,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','south','','','树林',2096,'华山村树林',0);
INSERT INTO Entrance VALUES('s',4505,2082,2096,null);
INSERT INTO Room VALUES('树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。','northeast|southeast','','','树林',2097,'华山村树林',0);
INSERT INTO Entrance VALUES('ne',4506,2084,2097,null);
INSERT INTO Entrance VALUES('se',4507,2081,2097,null);

INSERT INTO Entrance VALUES('ne',4508,2079,840,null);
INSERT INTO Entrance VALUES('se',4509,2085,840,null);
INSERT INTO Entrance VALUES('nw',4510,2079,841,null);
INSERT INTO Entrance VALUES('s',4511,2085,841,null);
--------------------------------------------------------------------------------------------------------------------------------

delete from Room where roomno>=2098 and roomno<=2109;
delete from Entrance where id>=4508 and id<=4529;
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','north|northeast|northwest|south','','','星宿密林',2098,'星宿密林',0);
INSERT INTO Entrance VALUES('n',4508,2099,2098,null);
INSERT INTO Entrance VALUES('ne',4509,2101,2098,null);
INSERT INTO Entrance VALUES('nw',4510,2100,2098,null);
INSERT INTO Entrance VALUES('s',4511,1440,2098,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','south|west','','','星宿密林',2099,'星宿密林',0);
INSERT INTO Entrance VALUES('s',4512,2098,2099,null);
INSERT INTO Entrance VALUES('w',4513,2100,2099,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','east|southeast','','','星宿密林',2100,'星宿密林',0);
INSERT INTO Entrance VALUES('e',4514,2098,2100,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','east|west','','','星宿密林',2101,'星宿密林',0);
INSERT INTO Entrance VALUES('w',4515,1458,2101,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','west','','','星宿密林',2102,'星宿密林',0);
INSERT INTO Entrance VALUES('w',4516,2101,2102,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','east|northeast','','','星宿密林',2103,'星宿密林',0);
INSERT INTO Entrance VALUES('e',4517,1428,2103,null);
INSERT INTO Entrance VALUES('ne',4518,2104,2103,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','northeast|southwest','','','星宿密林',2104,'星宿密林',0);
INSERT INTO Entrance VALUES('ne',4519,2105,2104,null);
INSERT INTO Entrance VALUES('sw',4520,2103,2104,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','northeast|southwest','','','星宿密林',2105,'星宿密林',0);
INSERT INTO Entrance VALUES('sw',4521,2104,2105,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','east|southwest','','','星宿密林',2106,'星宿密林',0);
INSERT INTO Entrance VALUES('e',4522,1436,2106,null);
INSERT INTO Entrance VALUES('sw',4523,2098,2106,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','south|west','','','星宿密林',2107,'星宿密林',0);
INSERT INTO Entrance VALUES('s',4524,2100,2107,null);
INSERT INTO Entrance VALUES('w',4525,1434,2107,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','south|west','','','星宿密林',2108,'星宿密林',0);
INSERT INTO Entrance VALUES('s',4526,2098,2108,null);
INSERT INTO Entrance VALUES('w',4527,1335,2108,null);
INSERT INTO Room VALUES('这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。','south|west','','','星宿密林',2109,'星宿密林',0);
INSERT INTO Entrance VALUES('s',4528,2106,2109,null);
INSERT INTO Entrance VALUES('w',4529,1324,2109,null);
INSERT INTO Entrance VALUES('n',4530,2098,1440,null);

星宿密林
这里是星宿海旁边的森林，高大的松树几乎把所有的光线都遮掩住了。
2098			1				n(2)			ne(4)		nw(3)		s(xxh5)
2099			2				s(1)			w(3)
2100			3				e(1)			se()
2101			4				e()			w(shankou)
2102			5				w(4)
2103			6				e(xxroad10)		ne(7)
2104			7				ne(8)		sw(6)
2105			8				ne()			sw(7)
2106			9				e(xxh2)		sw(1)
2107			10			s(3)			w(yinshan)
2108			11			s(1)			w(saimachang)
2109			12			s(9)			w(silk1)
saimachang	1335
silk1				1324
yinshan			1434
xxh2				1436
xxh5				1440
shankou		1458
xxroad10		1428


树林里生着北方常见的榆树和杨树，树木高大，遮掩得天色都黯淡了下来。
2097			19			ne(6)		se(3)
2096			18			s(4)
2095			17			w(16)
2094			16			e(17)		sw(5)
2093			15			ne(11)		n(10)		e(14)
2092			14			n(11)		w(15)		e(13)
2091			13			w(14)		n(9)			ne(12)
2090			12			nw(9)		sw(13)
2089			11			nw(7)		ne(9)		sw(15)		s(14)		w(10)
2088			10			ne(7)		n(8)			s(15)		e(11)
2087			9				sw(11)		se(12)		s(13)		w(7)
2086			8				s(10)		e(7)
2085			7				n(tulu3)		nw(tulu2)	sw(10)		se(11)		w(8)				e(9)
2084			6				sw(19)		se(1)		s(3)			e(4)
2083			5				sw(1)		ne(16)		s(2)			w(4)
2082			4				s(1)			n(18)		w(6)			e(5)
2081			3				n(6)			e(1)			nw(19)
2080			2				n(5)			w(1)
2079			1				nw(6)		ne(5)		se(tulu3)	sw(tulu2)	n(4)				w(3)			e(2)
tulu3=841 east|northwest|south|west   840  east|northeast|southeast|west

--------------------------------------------------------------------------------------------------------------------------------
--DELETE FROM Room WHERE Roomno>=2110;
--DELETE FROM Entrance WHERE ID>=4531;
INSERT INTO Room VALUES('你睁眼打量四周，发现石棺内甚是宽敞。不过因为棺盖半关的关','out','','','石棺里',2110,'星宿密室',0);
INSERT INTO Entrance VALUES('out',4531,1445,2110,null);
INSERT INTO Entrance VALUES('pressstone',4532,2111,2110,null);
INSERT INTO Room VALUES('这是一个终年不见天日的甬道，因此阴暗潮湿地令人难以忍受。','east|north|south|up|west','','','甬道',2111,'星宿密室',0);
INSERT INTO Entrance VALUES('u',4533,2110,2111,null);
INSERT INTO Entrance VALUES('e',4534,2112,2111,null);
INSERT INTO Entrance VALUES('s',4535,2113,2111,null);
INSERT INTO Entrance VALUES('w',4536,2114,2111,null);
INSERT INTO Entrance VALUES('n',4537,2115,2111,null);
INSERT INTO Room VALUES('这是一个极小的石房，看起来只容得下几个人。正前方的石壁','west','','','小石房',2112,'星宿密室',0);
INSERT INTO Entrance VALUES('w',4538,2111,2112,null);
INSERT INTO Room VALUES('这是一个极小的石房，看起来只容得下几个人。正前方的石壁','north','','','小石房',2113,'星宿密室',0);
INSERT INTO Entrance VALUES('n',4539,2111,2113,null);
INSERT INTO Room VALUES('这是一个极小的石房，看起来只容得下几个人。正前方的石壁','east','','','小石房',2114,'星宿密室',0);
INSERT INTO Entrance VALUES('e',4540,2111,2114,null);
INSERT INTO Room VALUES('这是一个极小的石房，看起来只容得下几个人。正前方的石壁','south','','','小石房',2115,'星宿密室',0);
INSERT INTO Entrance VALUES('s',4541,2111,2115,null);
INSERT INTO Entrance VALUES('tangcoffin',4542,2110,1445,null);

--------------------------------------------------------------------------------------------------------------------------------

INSERT INTO Room VALUES('这里乃是大轮寺外一处僻静所在，四下绝无人迹。前前後後，大大小小几','southup|west','west','卓玛|央宗','忘忧谷',2116,'藏边大雪山',0);
INSERT INTO Entrance VALUES('w',4543,2117,2116,null);
INSERT INTO Entrance VALUES('su',4544,414,2116,null);
INSERT INTO Room VALUES('一团团雾气，从神秘莫测的路的深处涌出来。小路豁然开朗，你的眼前出','east','','','鹿野苑',2117,'藏边大雪山',0);
INSERT INTO Entrance VALUES('e',4545,2116,2117,null);
INSERT INTO Entrance VALUES('enterpicture',4546,2116,434,"xs");
delete from Room where roomno=2116 or roomno=2117;
delete from entrance where id>=4543 and id<=4546;
INSERT INTO Entrance VALUES('enterpicture',4543,1854,434,"xs");
-----------------------------------------------------------------------------------------------------------------------------------
白驼蛇谷地图更新
INSERT INTO Room VALUES('蛇谷是白驼山中最险恶的密境，栖息了无数毒蛇，因而得名。此','northdown|south','','','蛇谷',2118,'白驼蛇谷',0);

--]]

