--[[
修改的时候一定要注意别丢标点符号，也别错用成中文符号
--@shana 2023年07月28日
]]

--@ln的war列表，请按照自己所在的站填写
function set_war_trust_ln() 
	war_trust_a={	--本组为自己的6msj大号，有足够战斗力的，可以一人带正常war，无条件组（战斗力不够也放E组或者D组）
					--每行第一个字符代表IP编号，不能有冲突的
					{"ip1","icrien"},	--81.71....
					{"ip2","ecrikq"},	--120.79....阿里云
					{"ip3","lsjmj"},	--BAY TRAIL(NETGEAR)
					{"ip4","zorro"},	--117.172....
					{"ip5","ini"},		--牛13....
				}
	war_trust_b={	--本组为别人的强力6msj，必须有足够战斗力的，可以一人带正常war
					{"ip11","monkpkzj"},
					{"ip12","ashe"},
					{"ip13","cinedl"},
					{"ip14","liu"},				
					{"ip15","lmsjboss"},					
					{"ip16","pride"},
					{"ip17","lnnev"},
					{"ip18","txdy","acrize","manxtjcn","gzgr"},
					{"ip19","jfxt"},
					{"ip20","ixwyu"},
					{"ip21","alias"},									
					{"ip22","hhyhscc"},				
					{"ip23","suv"},
					{"ip24","saiya"},
					{"ip25","mllc"},				
					{"ip26","mlle"},
					{"ip27","zhiruo"},
					{"ip28","qiuchuji"},
					{"ip29","caipa"},
					{"ip30","maccfz"},
					{"ip31","daosheng"},
					{"ip32","thhdm"}, 
					{"ip33","miaoz"},
					{"ip34","lndla"},
					{"ip35","turning","riverdmv"},
					{"ip36","baojian","dlhuashi"},
					{"ip37","caveman"},	
					--{"ip38","jianhua"},
					{"ip39","ocyx","octt","ocyqm","oxysn","jakuf"},
					{"ip40","lsjdl"},
					{"ip41","ccbgu"},
					{"ip42","cinexxce","zhengfzr"},
					{"ip43","jaqcl"},
					{"ip44","lnjzid","jaqcl","jianhua"},					
					{"ip45","hndl","ygx","che"},
					{"ip46","lnbtbt"},		
					{"ip47","lpswara"},	
					{"ip48","prophecy"},
					{"ip49","fastswd","stryl"},
				}
	war_trust_c={	--本组为优先级略低的6msj大号		

					{"ip61","hbsyqz"},

					
				}
	war_trust_d={	--本组为拉垮6msj或其他战斗力不足的大号，当队伍中强力6msj未组满时，才考虑组这些人					
					{"ip71","pkidln"},
					{"ip72","btding"},
					{"ip73","lwbgr"},
					{"ip74","lnbta"},
					{"ip75","xtjaca"},
					{"ip76","zhaosia"},
				}		
	war_trust_e={	--本组为凑人头war大米，无条件组，推荐exp30m-160m		
					{"ip90","lpswarh","cinexlzb","cinexlzn","burntu"}, --101.43....btid 代理
					{"ip91","lpswarj","cinexlze","cinexlzo","nagedg"}, --47.97....btid阿里云
					{"ip92","lpswark","cinexlzf","cinexlzp","lpswarl"}, --124的linux系统
					{"ip93","lpswarm","lpswarn","lpswaro","lpswarp"}, --单位PRODESK
					{"ip94","cinexlzc","cinexlzh","cinexlzl","cinexlzq","dljgjhz"}, --EQ12MINI(移动宽带)
					{"ip95","lpswarq","lpswarr","lpswars","lpswart"},	--37733 N5105
					{"ip96","rmdwara","rmdwarb","rmdwarc","bingsan","lpsgmc"},	--N_BOX N100(X60PRO)	
					{"ip97","rmdward","rmdware","rmdwarf","rmdwarg","lpsgmd"},	--GMK(X32PRO)						
					{"ip98","litchi"},					
					{"ip6","dingip"},	
					{"ip99","gtea"},
					{"ip100","lnwaraa"},
					{"ip101","lnwarbb"},	
					--{"ip102","mylorda","mylordb","mylordc","mylordd","mylorde","mylordf","mylordg"},
					--{"ip103","zzzsla","zzzslb","zzzslc","zzzsld","zzzsle","zzzslf","zzzslg","zzzslh"},
					--{"ip104","oma","omb","omc","omd","ome","omf","omg","omh"},
					--{"ip105","metawara","metawarb","metawarc","metaward","metaware","metawarf","metawarg","metawarh"},
					--{"ip106","booka","bookb","bookc","bookd","booke","bookf","bookg","bookh"},
					--{"ip107","ccaai","ccabw","ccabx","ccaea","ccaho","ccahs","ccaim","mylordk"},
					--{"ip108","xxxm","xiandoud","birdf","magich","xianem","keye","magicg","xiandoua"},
				}
end	

--@qt的war列表，请按照自己所在的站填写
function set_war_trust_qt() 
	war_trust_a={
					{"ip1","qtdlia"},	--小方糖
					{"ip2","fkaibu"}, --39.108...九刀代理
					
				}
	war_trust_b={
					{"ip11","xianfolm"}, --120.79...
					{"ip12","qzwdem"}, --EQ12MINI
					{"ip18","rqtalz"},	--主路由
					{"ip19","qtqqdp"}, 
					{"ip20","mmehvk"}, 
					{"ip21","hongmi","zgjz"}, 
					{"ip22","mmmmht"}, 
					{"ip23","icine"},
					{"ip24","faker"},
					{"ip25","cinelmsj"},
					{"ip26","dcg"},
					{"ip27","jyjaf","teenmix","zqfy"},
					{"ip28","newseng"},
					{"ip29","cinextj"},
					{"ip30","yehn"},
					{"ip31","baiff"},
					{"ip32","ldjhz"},
					{"ip33","sohikz"},
					{"ip34","mllqt"},
					
					
					--以下为btid war id，自己保证不出现ip冲突
					{"ip81","rqtker"},
					{"ip82","lmjs"},
					{"ip83","fkavlf"},
					{"ip84","cbossx"},
					{"ip85","rqtsbw"},
					{"ip86","cbossxx"},
					{"ip87","fkawif"},
					{"ip88","lmseng"},
					{"ip89","lmlama"},
					{"ip90","fkazkg"},
					{"ip91","xlzza"},
					{"ip92","rei"},
					{"ip93","pxjj"},
					{"ip94","fkaprj"},
					{"ip95","fkawdu"},
					{"ip96","fkaquk"},					
					{"ip97","thduang"},
					
				}
	war_trust_c={
					
				}
	war_trust_d={
					
				}
	war_trust_e={
					--{"ip40","waryi","kla","pkboss","wartwoxw","warsanxw"}, --牛13VPS
					{"ip103","qzwdgm","warwuxw","warqixw","warbaxw","warjiuxw"}, --106.12....牛13 代理
					{"ip104","gmguo","btidrmdf","btidrmdg","hnined","htend"}, --81.71...
					{"ip105","honed","htwod","hsixd","hsevend","heightd"}, --N_BOX N100(X60PRO)
					{"ip106","btidrmda","btidrmdb","btidrmdc","btidrmdd","btidrmde"}, --单位PRODESK
					{"ip107","hfourd","hfived","btidrmdh","testdba","warsixxw"}, --GMK(X32PRO)
					{"ip108","xhk"},
					{"ip109","xhbb"},
					{"ip110","guoj","beijt","frlh"}, --海天孤雁war大米
				}
end

--根据站点地址，设置war的各项参数
--if GetInfo(1)=="119.23.142.101" then 
if GetInfo(1)=="ln.xkxmud.com" then 
	set_war_trust_ln()	--载入ln名单
	npcAssassinOnRewardFail = false --war杀元帅结束后未拿到奖励，是否要杀掉太守
	npcAssassinOnReward = false --war结束领取奖励后10秒，杀掉太守(防止flood)
	war.private_mode=true	--若private模式激活，仅当自己大号在场时，大米才主动发起teamwith
	war.max_partner=5   --组几个队友？最多9个，太多或太少都有可能频繁出现实力悬殊；(填0是随机4-9)
	if war.mod=="vip" then war.max_vip=2 else war.max_vip=3 end      --组几个大号6msj？不包括自己
	war.casualties=5	--城内百姓伤亡数限制，超出后大米不会出击城外（war.dummy_attack设置为1时）	
	war.request_interval=0.10	--太flood，不激烈的时候尽量不开启
	--war.request_interval=1.05		--flood teamwith的时间间隔，短了容易组到，但是会很卡，建议竞争不激烈的设置2-3秒
elseif GetInfo(1)=="112.124.31.157" then 
	set_war_trust_qt()	--载入qt名单
	npcAssassinOnRewardFail = false --war杀元帅结束后未拿到奖励，是否要杀掉太守
	npcAssassinOnReward = false --war结束领取奖励后10秒，杀掉太守(防止flood)
	war.private_mode=false	--若private模式激活，仅当自己大号在场时，大米才主动发起teamwith
	war.max_partner=0   --组几个队友？最多9个，太多或太少都有可能频繁出现实力悬殊；(填0是随机4-9)
	if war.mod=="vip" then war.max_vip=2 else war.max_vip=3 end      --组几个大号6msj？不包括自己
	war.casualties=14  --城内百姓伤亡数限制，超出后大米不会出击城外（war.dummy_attack设置为1时）
	war.request_interval=2.00	--flood teamwith的时间间隔，短了容易组到，但是会很卡，建议竞争不激烈的设置2-3秒
end

function shouldActivateTeamwith() --判断是否发起teamwith
    local team = war.team
    local open = war.open
    local private_mode = war.private_mode
    local mod = war.mod

    -- 提前返回 false，提高可读性
    if team <= 0 or open <= 0 or war.waring >= 3 then
        return false
    end

    -- 判断模式条件
    local is_valid_mod = false
    if mod == "vip" or "once" then
        is_valid_mod = true
    elseif mod == "dummy" then
        if war.have_vvip > 0 and private_mode then
            is_valid_mod = true
        elseif war.have_vip > 0 and not private_mode then
            is_valid_mod = true
        end
    end

    if not is_valid_mod then
        return false
    end

    -- 时间检查
    if os.time() <= war.ready then
        return false
    end

    return true
end

-- 创建一个表来存储所有的信任表(看不懂千万别动)
local trust_tables = {
		war_trust_e,
		war_trust_d,
		war_trust_c,
		war_trust_b,
		war_trust_a
	}

-- 优化数据结构(看不懂千万别动)
local memberIDs_a = {}  -- 存储表war_trust_a中的成员ID集合
local memberIDs_b = {}  -- 存储表war_trust_b中的成员ID集合
local memberIDs_c = {}  -- 存储表war_trust_c中的成员ID集合
local memberIDs_d = {}  -- 存储表war_trust_d中的成员ID集合
local memberIDs_e = {}  -- 存储表war_trust_e中的成员ID集合
local memberToIPMap = {}  -- 哈希表用于存储成员ID到IP编号的映射

-- 合并所有信任表为一个大表，并同时存储每个子表(看不懂千万别动)
local trust_tables_combined = {}
for _, trust_table in ipairs(trust_tables) do
    for _, subtab in pairs(trust_table) do
        table.insert(trust_tables_combined, subtab)
    end
end

--检索成员str是否存在于表tab中(看不懂千万别动)
function is_include(tab, str)
    for _, subtab in pairs(tab) do
        for _, value in ipairs(subtab) do
            if value == str then return true end
        end
    end
    return false
end


-- 初始化成员ID集合和成员ID到IP编号的映射(看不懂千万别动)
function initializeDataStructures()
    for _, subtab in ipairs(trust_tables_combined) do
        local ip = subtab[1]
        for i = 2, #subtab do
            local memberID = subtab[i]
            memberToIPMap[memberID] = ip
            
            if is_include(war_trust_a,memberID) then
                memberIDs_a[memberID] = true
            elseif is_include(war_trust_b,memberID) then
                memberIDs_b[memberID] = true
            elseif is_include(war_trust_c,memberID) then
                memberIDs_c[memberID] = true
            elseif is_include(war_trust_d,memberID) then
                memberIDs_d[memberID] = true
            elseif is_include(war_trust_e,memberID) then
                memberIDs_e[memberID] = true
            end
        end
    end
end

-- 初始化数据结构(看不懂千万别动)
initializeDataStructures()

-- 根据成员id查找对应的IP编号(看不懂千万别动)
function ip_get(str)
    local memberID = str
    local ip = memberToIPMap[memberID]
    if ip then
        return ip
    else
        return "none"
    end
end

-- 判断成员str的IP是否可用（无冲突返回true，冲突返回false）
function is_ip_available(tb, str)
    local my_ip = ip_get(GetInfo(3))
    local target_ip = memberToIPMap[str]

    -- 如果目标IP与当前用户IP相同，直接不可用（冲突）
    if my_ip == target_ip then
        return false
    end

    -- 检查目标IP是否已被其他成员占用
    for _, member_id in pairs(tb) do
        if memberToIPMap[member_id] == target_ip then
            return false
        end
    end

    -- 通过所有检查，IP可用
    return true
end

--停止teamwith
local _tb
function alias.stop_ask_war()
	closeclass("war_start_timer")
	run("look")
	alias.resetidle()
end

--杀元帅pfm
function alias.yspfm()
	run("kill yuanshuai")
	if jifa.forcename=="longxiang-banruo" then run("perform riyue yuanshuai")
	--elseif jifa.forcename=="xiantian-gong" then run("wield jian;perform sanqing;yun shentong yuanshuai")
	--elseif jifa.forcename=="huntian-qigong" then run("perform cross yuanshuai")
	--elseif jifa.forcename=="zixia-gong" then run("perform jianzhang yuanshuai")
	elseif jifa.forcename=="linji-zhuang" then run("yun taiyin")
	end
end
function warteam()
	local _f,f
	if type(war.realteam)=="table" and #war.realteam>3 then
		_f="teamwith"
		f=0
		while #war.realteam>f do 
		f=f+1
		_f=_f.." "..war["realteam"][f]
		end
		run(_f)
	else
		tprint(war.realteam)
		print("条件不足，请检查！")
		end
end
--完整复制table(看不懂千万别动)
function deepCopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepCopy(orig_key)] = deepCopy(orig_value)
        end
        setmetatable(copy, deepCopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

------------------------------------------------------------------------------------
-- war_pre
------------------------------------------------------------------------------------
--核心部分，组队逻辑(看不懂千万别动)
maketri_num=1
local function _ft(n, l, w)
    local a,b,c=string.find(l,".-%((%w+)%)$")
	c=string.lower(c)
	--print(c)
	if not is_ip_available(war.teamwith, c) then return end  -- IP冲突直接退出
    if always.where == "太守府" and war.team > 0 then
        if memberIDs_a[c] then
            if #war.teamwith < war.max_player then--不满最大人数，直接插入成员
                if war.have_vip < war.max_vip then 
					table.insert(war.teamwith, c)
					war.have_vip = war.have_vip + 1
				else
					for k, v in ipairs(war.teamwith) do
						if memberIDs_b[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);break end
					end
				end                
            else
                for i = #war.teamwith, 1, -1 do	--人满，遍历表单，依次剔除高优先级bcde，增加a级
					local v = war.teamwith[i]
                    if memberIDs_b[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);break --先踢普通vip，防止vip数量过多
                    elseif memberIDs_c[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);war.have_vip = war.have_vip + 1;break
                    elseif memberIDs_d[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);war.have_vip = war.have_vip + 1;break
                    elseif memberIDs_e[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);war.have_vip = war.have_vip + 1;break
                    end
                end
            end
        elseif memberIDs_b[c] and war.have_vip < war.max_vip then
            if #war.teamwith < war.max_player then--不满最大人数，直接插入成员
                table.insert(war.teamwith, c)
                war.have_vip = war.have_vip + 1
            else
                for k, v in ipairs(war.teamwith) do--人满，遍历表单，依次剔除低优先级edc，增加高优先级
                    if memberIDs_e[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);war.have_vip = war.have_vip + 1;break
                    elseif memberIDs_d[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);war.have_vip = war.have_vip + 1;break
                    elseif memberIDs_c[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, c);war.have_vip = war.have_vip + 1;break
                    end
                end
            end
        elseif memberIDs_c[c] and war.have_vip < 1 then
            if #war.teamwith < war.max_player then--不满最大人数，直接插入成员
                table.insert(war.teamwith, 1, c)
                war.have_vip = war.have_vip + 1
            else
                for k, v in ipairs(war.teamwith) do--人满，遍历表单，依次剔除低优先级ed，增加高优先级
                    if memberIDs_e[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, 1, c);war.have_vip = war.have_vip + 1;break
                    elseif memberIDs_d[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, 1, c);war.have_vip = war.have_vip + 1;break
                    end
                end
            end
        elseif memberIDs_d[c] and (GetInfo(1) == "ln.xkxmud.com" and war.have_vip == 1 or GetInfo(1) == "112.124.31.157" and war.have_vip < 5) then
            if #war.teamwith < war.max_player then--不满最大人数，直接插入成员
                table.insert(war.teamwith, 1, c)
            else
                for k, v in ipairs(war.teamwith) do--人满，遍历表单，依次剔除低优先级e，增加高优先级
                    if memberIDs_e[v] then table.remove(war.teamwith, k);table.insert(war.teamwith, 1, c);break
					end
                end
            end
        elseif memberIDs_e[c] then--不满最大人数，直接插入成员
            if #war.teamwith < war.max_player then table.insert(war.teamwith, 1, c)
			end
        end
    end
end
_tb={".+\\(\\w+\\)$",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
--[[local function _ft(n,l,w)  --太守有时候会死，这条就不触发了，改为看公告牌触发
	local _f,a,b,c,d,e,f,_tb
	if war.teamwith~=nil then
		war.realteam= {}
		war.realteam= deepCopy(war.teamwith)
		tprint(war.realteam)
	end
end
_tb={".+太守\\(Tai shou\\)$",}
maketri("war_pre_doth",_tb,"war_pre",_ft)]]--

local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if tonumber(war.team)~=nil and war.team==1 then
		if war.max_partner == 0 then war.max_player = math.random(4, 9) else war.max_player = war.max_partner end
		war.teamwith = {}
		war.have_vip = 0
		war.have_vvip = 0
	end
end
_tb={"太守府 - $","太守府 - north、out$",}
maketri("war_pre_doth",_tb,"war_pre",_ft)

local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if war.teamwith~=nil then
		war.realteam= {}
		war.realteam= deepCopy(war.teamwith)
		war.have_vvip = 0
		for k, v in ipairs(war.realteam) do
			if memberIDs_a[v] then war.have_vvip = war.have_vvip + 1 end
		end
		tprint(war.realteam)
		print("本队伍内有VIP※_"..war.have_vip.."_※人,VVIP※_"..war.have_vvip.."_※人")
	end
end
_tb={".+南阳公告\\(Board\\).+$",}
maketri("war_pre_doth",_tb,"war_pre",_ft)

local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.close_war()
	war.taishouDead=0
	run("say 没办法，"..me.charid.."懦夫了，也不知道这样够不够长了，凑合着挂吧。;h;n")
	if war.ready<os.time() then war.ready=os.time()+3600 end
    wait.make(function()	
		_f=function()
        alias.startworkflow() end
        wait.time(8);_f()
        end)
end
_tb={"太守冷笑道：「我大宋不需要懦夫，你快滚开，别碍了本官的视线。」",}
maketri("war_pre_doth",_tb,"war_pre",_ft)

local function _ft(n,l,w)
	closeclass("war_restart_timer")
	war.taishouDead=0
end
_tb={".+向太守作揖道：「.+愿为太守效力，以拯救苍生百",}
maketri("war_pre_doth",_tb,"war_pre",_ft)

local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,".+没办法，(%w+)懦夫了，也不知道这样够不够长了，凑合着挂吧。")
	if war.teamwith~=nil then
		f=0
		--print(a,b,c)
		while #war.teamwith>f do
		 f=f+1
		 if war["teamwith"][f]==c then
			table.remove(war.teamwith,f)
			return
		 end
		end
	end
end
_tb={".+没办法，.+懦夫了，也不知道这样够不够长了，凑合着挂吧。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
		alias.resetidle()
		--if roomno_now~=1902 then
		if always.where~="太守府" then
			alias.flytoid(1902)
		elseif war.waring<3 then
			run("look")
			--alias.dz(set_neili_global)
			alias.dz(195)
		end
end
_tb={"你目前还没有任何为 dealwithitems=over 的变量设定。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if findstring(l,"数码世界，数字地图，1902就是这里！") then
		alias.resetidle()
		if war.waring<3 then
			run("unset brief")
			--alias.dz(set_neili_global)
			alias.dz(195)
		end
	end
end
_tb={"数码世界，数字地图，1902就是这里！",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if not isopen("boat") and not isopen("war_start") then
		alias.resetidle()
		if war.waring>0 then
			openclass("war_start")
			if war.waring==2 then alias.flytoid(1933) else alias.flytoid(1945) end
		else
		    if not isopen_timer("war_start_timer") then run("look") end
			if war.ready-os.time()<0 then
				--if type(war.teamwith)=="table" and #war.teamwith>3 and wartime-os.time(<0 then
				if type(war.teamwith)=="table" and #war.teamwith>3 then
					_f="teamwith"
					f=0
					while #war.teamwith>f do 
					f=f+1
					_f=_f.." "..war["teamwith"][f]
					end
					--run(_f) --每次打坐完都问的话，有可能抢开，导致上一支队伍没有收益
				elseif tonumber(war.team)~=nil and war.team>0 then
					run("say "..me.charid.."同志准备完毕！")
				elseif war.place=="上墙" then
					run("say "..me.charid.."同志准备完成了!")
				else
					run("say "..me.charid.."同志准备完成了！")
				end
			end
			war.late=0
			openclass("war_pre_time")
		end
	end
end
_tb={"你目前还没有任何为 dazuo=over 的变量设定。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if war.waring==0 then 
		war.people_dead=0
		alias.flytoid(1902) 
	end
end
_tb={"你目前还没有任何为 recheckready 的变量设定。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	    alias.resetidle()
		war.taishouDead=0
	    war.people_dead=0
	    print("战斗开始了！")
	    closeclass("war_pre_time")
		closeclass("war_start_timer")
		closeclass("war_restart_timer")
	    if war.jf~=nil and war.jf~="" then alias.jf(war.jf) end
		war.late=0
	    war.waring=1
	    war.npc=0
		war.see_marshal=0
	    openclass("war_start")
	    _tb=Split(war.yun,"|")
	    for k,v in ipairs(_tb) do run(v) end
	    alias.tdz()
	    alias.flytoid(1945)
	    run("tune chat")
end
_tb={"北边城外传来阵阵马蹄声，蒙古大军随时可能攻城",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	    if war.waring==0 then
	        alias.resetidle()
	        war.people_dead=0
			war.taishouDead=0
	        print("战斗开始了！")
	        closeclass("war_pre_time")
			closeclass("war_start_timer")
			closeclass("war_restart_timer")
	        if war.jf~=nil and war.jf~="" then alias.jf(war.jf) end
		    war.late=0
	        war.waring=1
			war.npc=0
			war.see_marshal=0
			openclass("war_start")
			_tb=Split(war.yun,"|")
			for k,v in ipairs(_tb) do run(v) end
			alias.tdz()
			alias.flytoid(1945)
			--run("tune chat")
		end
end
_tb={"忽然间鼓声大作，城外传来轰轰声响，蒙古大军已登陆.+！",".+位蒙古兵已登陆.+！",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	--local _f,a,b,c,d,e,f,_tb
	war.taishouDead=0
	if war.people_dead~=nil then
		war.people_dead=war.people_dead+1
		alias.setstatus()
		print("城内百姓已伤亡※"..war.people_dead.."/14※人")
	end
end
_tb={"城里远远传来一阵「啊～～」的惨嚎"}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	 alias.resetidle()
	 war.taishouDead=0
	print("城门已开！")
	if war.mod~=nil and (war.mod=="vip" or war.mod=="dummy" and war.people_dead<=war.casualties and war.dummy_attack==1) then
		war.waring=2
		war.checkAward=1
		war.err=6
		if isopen("kill") and war.weapon~="lun" then 
			alias.close_kill()
			alias.flytoid(1933) 
		end
	end
end
_tb={"这时四周城墙传来一阵阵巨响，南阳城各边吊桥放了下来，该是进攻的时候了",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()
		war.waring=3
		closeclass("war_start")
		closeclass("war_start_timer")
		closeclass("war_restart_timer")
		alias.close_kill()
		if always.where=="太守府" then alias.tdz();run("n")
		end
		alias.close_gps()
		alias.flytoid(1902)
end
_tb={".{4,8}手刃了蒙古军元帅",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	run("team")
end
_tb={".{4,8}决定加入你的队伍。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()
	--print("失败了！") 
	war.waring=0
	war.checkAward=0
	alias.close_kill()
	if always.where=="中军帐" then 
		run("halt;se;s;sw;s;s;s") 
	else
		run("n")
	end
	alias.startwar()
end
_tb={"忽然探子来报，城内百姓死伤惨重，太守也弃城而逃","太守鄙视地看着你，一言不发。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()
	war.taishouDead=1
	if war.waring>0 then 	
		war.waring=0
		war.checkAward=0
		alias.close_kill()
		if always.where=="中军帐" then 
			run("halt;se;s;sw;s;s;s")
		elseif always.where=="太守府" then 
			run("n")
		end 
			alias.startworkflow()
	end
end
_tb={"【谣言】某人：南阳城太守被.+杀害！\\n【谣言】某人：蒙古大军攻陷了南阳！\\Z",}
maketri("war_pre_doth",_tb,"war_pre",_ft,2)

local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()
	if war.ready <= os.time() then
		war.waring=0
		war.checkAward=0
		war.taishouDead=1
		alias.close_kill()	
		alias.stop_ask_war()
		local current_seconds = os.time() % 60
		local refresh_time = 60 - current_seconds
		local look_time = refresh_time - 2.5
		local startFloodTime = refresh_time - 0.9
		local stopFloodTime = refresh_time + 1.9
		if current_seconds >3 and current_seconds < 59 then
			AddTimer("taishou_killed_look_timer", 0, 0, look_time, "look", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "")
			--AddTimer("start_loopFlood_timer", 0, 0, startFloodTime, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "alias.loopFloodWar")
			AddTimer("start_teamwith_timer", 0, 0, startFloodTime, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "alias.start_teamwith")
			AddTimer("stop_ask_war_timer", 0, 0, stopFloodTime, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "alias.stop_ask_war")
		else
			run("#20 war")
		end
	end
end
_tb={"太守倒在地上，挣扎了几下就死了。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
--[[
function alias.loopFloodWar()
	if shouldActivateTeamwith() then run("#40 war") end
end
]]--
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	closeclass("war_pre")
	closeclass("war_pre_time")
	closeclass("war_start_timer")
	closeclass("war_restart_timer")
	alias.resetidle()
	war.taishouDead=0
	alias.close_gps()  --war已经结束，关闭gps
	war.npc=0
	war.see_marshal=0	
	war.checkAward=0
	if war.ready-os.time()<20 then war.ready=os.time()+20 end
	wait.make(function()
		_f=function()
			run("halt;n")
			openclass("war_pre")
			alias.checkexp("war")
		end
	wait.time(3);_f()
	end)
end
_tb={"太守冲上前去，激动地紧紧握住你的双手，哽咽着说不出话来。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()
	war.taishouDead=0
	run("h;n")
	alias.close_gps()  --war已经结束，关闭gps
	alias.close_war()
	alias.startworkflow()
	war.npc=0
	war.see_marshal=0
	--war.ready=os.time()+10800 --并非每次出这个提示都算懦夫
end
_tb={"太守轻蔑地看了你一眼，说道：「没用的窝囊废，连个小小蒙古鞑子都杀不了。快给我滚开，别丢我大宋的脸。」",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	war.taishouDead=0
	wait.make(function()
		_f=function()
			if npcAssassinOnReward then 
				run("kill taishou") 
				if war.pfm~=nil and war.pfm~="" then run(war.pfm.." taishou") end
			end
		end
		wait.time(10);_f()
	end)
	if war.waring==0 then 
		AddTimer("start_teamwith_timer", 0, 0, 28, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "alias.start_teamwith")
		AddTimer("stop_ask_war_timer", 0, 0, 32, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "alias.stop_ask_war")
	end
end
_tb={"太守说道：昔日郭大侠带领群雄守卫襄阳，为怕中原技艺失传，曾与群侠留下许多技艺精要。","太守太守跨上大青马，头也不回地朝南门奔驰而去。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	war.taishouDead=0
	if shouldActivateTeamwith() then 
		run("war") 
	end
end
_tb={"忽然南边传来一阵号角，一群宋国兵马簇拥著南阳城太守，派来坐阵指挥！",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	war.taishouDead=0
	alias.start_teamwith()
end
_tb={"太守说道：「蒙古军前些日子吃了败仗，短期之内应该不会再动兵才对！」",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
local _f,a,b,c,d,e,f,_tb
	war.taishouDead=0
	openclass("war_restart_timer")
end
_tb={"太守打量了四周对你问道：「你说的是哪位大侠？怎么我没看到他的影子。」","太守摇头说道：「你们队伍之间的实力相差太过悬殊！」",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()	
	if add.exp<500 or WarExp>=13000 then
		WarLimited=1
		print("统计到的War上限为："..WarExp)
		if WarLimitedMarkTime<(os.time()-3600) then
			if de_bug>0 then print("到War时间却仍然busy，推迟2分钟") end
			WarLimitedMarkTime=tonumber(os.time()-3600+120)
		end
	end	
	war.waring=0
	war.checkAward=0
	war.late=0
	alias.close_war()
	alias.startworkflow()
end
_tb={"你目前还没有任何为 checkexpover=war 的变量设定。",}
maketri("war_pre_doth",_tb,"war_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
    closeclass("war_start_timer")
	closeclass("war_restart_timer")
	war.taishouDead=0
	war.late=war.late+1
	print("war.late计数"..war.late)
	if mj_need_yudi() and war.waring==0 and war.late>15 then 
	    print("别人开war了，我去做yudi")
	    alias.close_war()
	    war.late=0
	    alias.startworkflow()
	elseif havefj>0 and war.waring==0 and war.late>15 then 
	    print("别人开war了，我去做fj")
	    alias.close_war()
	    war.late=0
	    alias.startworkflow()
	else
		return
	end
end
_tb={"太守对.+说道：「你怎么现在才来？蒙古大军已经攻进城了！」",}
maketri("war_pre_doth",_tb,"war_pre",_ft)

closeclass("war_pre")
------------------------------------------------------------------------------------
-- war_start_t
------------------------------------------------------------------------------------
function war_start.timer()
	run("war") 
end

function war_restart.timer() --组队不成功，人不在或者差距过大，look后重新组队
	run("look")
	if shouldActivateTeamwith() then 		
		wait.make(function()	
			_f=function()
				run("war")
			end
			wait.time(1.0);_f()
		end)
    end
end
------------------------------------------------------------------------------------
-- war_start
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,"忽然间鼓声大作，城外传来轰轰声响，蒙古大军已登陆(.+)！")
	if c~=nil and war.waring<2 and war.path_no>5 then
		alias.close_kill()
		war.err=6
		if c=="东门" then alias.flytoid(1916) end
		if c=="南门" then alias.flytoid(1942) end
		if c=="西门" then alias.flytoid(1858) end
		if c=="北门" then alias.flytoid(1933) end
	end
end
_tb={"忽然间鼓声大作，城外传来轰轰声响，蒙古大军已登陆.+！",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil then
		alias.resetidle()
		check_battleidle=0
		war.pathid=1
		if string.len(war.weapon)>0 then
			--wieldweapon=1
			if war.weapon=="staff" then alias.wi(staffid) else alias.wi(war.weapon) end
		else alias.uw() end
		killskill=war.weapon
		killpfm=war.pfm
		killyun=war.yun
		killjiali=war.jiali
		killjiajin=war.jiajin
		run("unset no_parry;yield no;jiali "..killjiali..";jiajin "..killjiajin)
		if roomno_now==1945 or war.waring==2 then 
			war.err=0 
		elseif roomno_now==1933 and war.waring==2 then 
			--war.npc=0
			--run("h;n") 
		end
		run("set search=yes")
	end
end
_tb={"数码世界，数字地图，\\d+就是这里！",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	war.err=war.err+1
end
_tb={"这个方向没有出路。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	war.pathid=war.pathid+1
end
_tb={".+晚上不开，请天亮了再来！",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	war.pathid=war.pathid-1
end
_tb={"你被蒙古军拦住，潜入不了军营深处。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if tonumber(war.waring>0) then 
		alias.close_war()
        alias.startworkflow()	
        war.waring=0
		war.checkAward=0		
	end
end
_tb={"城外太危险了，你还是不要出去比较好。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	war.npc=0 
end
_tb={"\\s+这里唯一的出口是 .+。","\\s+这里明显的出口是 .+。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if tonumber(hp.healthqi)<60 or (tonumber(hp.neili)<tonumber(hp.maxneili*60/100) and (jifa.fingername==nil or jifa.fingername~="liumai-shenjian")) then runaway=true end
	if runaway then
		closeclass("war_start")
		alias.close_kill()
		alias.flytoid(1902)
	else
		if war.npc==0 then 	
			alias.close_kill()
			alias.checkbusy("warkillover")
		elseif war.see_marshal>0 then 
			if not stat.use_jinhua then 
				alias.yspfm()
			else
				for i=1,war.npc-1,1 do run("kill soldier "..i) end
			end
		else 
			for i=1,war.npc,1 do run("kill soldier "..i) end			
		end
	end
end
_tb={"你目前还没有任何为 check=kill 的变量设定。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.close_kill()
	war.npc=0
	if stat.use_jinhua then run("get jinhua") end
	if war.killover==0 then run("look;set search=yes") end
	war.killover=war.killover+1
end
_tb={"你目前还没有任何为 busyover=warkillover 的变量设定。","你目前还没有任何为 killover=yes 的变量设定。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	runaway=true
end
_tb={"你.+臂麻木，无力再使.+", "你请先用 enable 指令选择你要使用的外功","你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑","你摇头晃脑","你已经一副头重脚轻的模样",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,"(.+)%(%w+%s%w+%)")
	if c~=nil then
		if findstring(c,"蒙古兵","十夫长","百夫长","千夫长") then 
			if findstring(c,"七位") then war.npc=war.npc+7 
			elseif findstring(c,"六位") then war.npc=war.npc+6
			elseif findstring(c,"五位") then war.npc=war.npc+5
			elseif findstring(c,"四位") then war.npc=war.npc+4
			elseif findstring(c,"三位") then war.npc=war.npc+3
			elseif findstring(c,"二位") then war.npc=war.npc+2
			else war.npc=war.npc+1
			end
		end
		if findstring(c,"蒙古元帅") then war.see_marshal=1;war.npc=war.npc+1 end
	end
end
_tb={"  (.+)\\(\\w+\\s\\w+\\)",}
--三位蒙古军 千夫长(Qianfu zhang) <战斗中>
--蒙古军 百夫长(Baifu zhang) <战斗中>
--蒙古元帅(Menggu yuanshuai) <战斗中>
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	alias.resetidle()
	war.killover=0
	if war.npc>0 then
		_tb=Split(war.yun,"|")
		for k,v in ipairs(_tb) do run(v) end
		openclass("kill")
		openclass("kill_pfm")
		closeclass("kill_run")
		AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
		SetTimerOption("kill_timer", "group", "kill")
		reyun=1
		rekill=0
		runaway=false
		npcfaint=false
		killRunSuccess=false
		if war.see_marshal>0 then 
			if not stat.use_jinhua then 
				killid="yuanshuai"
				alias.yspfm()
			else
				--run("kill yuanshuai")
				for i=1,war.npc,1 do run("kill soldier "..i) end
			end
		else 
			killid=""
			for i=1,war.npc,1 do run("kill soldier "..i) end			
		end
		killname="npc"
		killskill=war.weapon
		killpfm=war.pfm
		killyun=war.yun
		killjiali=war.jiali
		killjiajin=war.jiajin
		alias.pfm()
	else
		alias.close_kill()
		pfmid=1
		if war.waring==2 then 
			if war.mod=="vip" then _tb=Split(war.pathys_vip,"|") else _tb=Split(war.pathys,"|") end
		else 
			_tb=Split(war.path[war.path_no],"|") 
		end
		if war.err>5 or tonumber(war.pathid)>tonumber(#_tb) then
			if war.waring==2 then 
				alias.flytoid(1933) 
			else 
				if war.place=="东" or war.place=="南" or war.place=="西" or war.place=="北" then
					war.path_no=war.path_no+1
					if war.path_no>4 then 
						war.path_no=1						
					end
				end
				alias.flytoid(1945) 
			end
		else
			run(_tb[war.pathid])
			war.pathid=war.pathid+1
			run("set search=yes")
		end
	end
end
_tb={"你目前还没有任何为 search=yes 的变量设定。",}
maketri("war_start_doth",_tb,"war_start",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if war.waring<3 then 
	    alias.resetidle()
		war.waring=0
	    closeclass("war_start")
		alias.close_kill()
		if always.where=="太守府" then alias.tdz();run("n") end
		alias.flytoid(1902)
	end
end
_tb={".+诧道：「没想到大宋兵力如此厉害，今天算是你们走运！」","几个宋兵把城外的吊桥缓缓升起，大门随之紧闭，断绝了对外的通道。",}
maketri("war_start_doth",_tb,"war_start",_ft)

closeclass("war_start")
function war.getready()
	if war.waring==0 and isopen("war_pre") then run("set recheckready") end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function war.update()
	local _tb
	AddTimer("war_pre_time", 0, 0, 20, "", timer_flag.Enabled + timer_flag.Replace, "war.getready")
	SetTimerOption("war_pre_time", "group", "war_pre_time")
	closeclass("war_pre_time")
-------war ask----------------------------------------------------------------------------------------------------------
	AddTimer("war_start_timer", 0, 0, war.request_interval, "", timer_flag.Enabled + timer_flag.Replace, "war_start.timer")
	SetTimerOption("war_start_timer", "group", "war_start_timer")
	closeclass("war_start_timer")	
	
	AddTimer("war_restart_timer", 0, 0, 5, "", timer_flag.Enabled + timer_flag.Replace, "war_restart.timer")
	SetTimerOption("war_restart_timer", "group", "war_restart_timer")
	closeclass("war_restart_timer")	
end
war.update()
