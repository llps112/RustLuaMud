function _isopen(a)
	if a~=nil and a>0 then return "开启" else return "关闭" end
end

-- cfg 命令行接口：替代原 MushClient InfoBox GUI 按钮功能
cfg = cfg or {}

function cfg.idle()
	if setting_resetidle>0 then setting_resetidle=0 else setting_resetidle=1 end
	if setting_resetidle>0 then resetidle=1 else resetidle=0 end
	Note("防发呆 ".._isopen(setting_resetidle))
end

function cfg.fj()
	if workflow.fj>0 then workflow.fj=0 else workflow.fj=1 end
	Note("FJ模块 ".._isopen(workflow.fj))
end

function cfg.mp()
	if workflow.mp>0 then workflow.mp=0 else workflow.mp=1 end
	Note("MP模块 ".._isopen(workflow.mp))
end

function cfg.xf()
	if workflow.xf>0 then workflow.xf=0 else workflow.xf=1 end
	Note("XF模块 ".._isopen(workflow.xf))
end

function cfg.cm()
	if workflow.cm>0 then workflow.cm=0 else workflow.cm=1 end
	Note("CM模块 ".._isopen(workflow.cm))
end

function cfg.yb()
	if workflow.yb>0 then workflow.yb=0 else workflow.yb=1 end
	Note("YB模块 ".._isopen(workflow.yb))
end

function cfg.ftb()
	if workflow.ftb>0 then workflow.ftb=0 else workflow.ftb=1 end
	Note("FTB模块 ".._isopen(workflow.ftb))
end

function cfg.qzwd()
	if workflow.qzwd>0 then workflow.qzwd=0 else workflow.qzwd=1 end
	Note("QZWD ".._isopen(workflow.qzwd))
end

function cfg.set_neili_job(neili)
	if neili~=nil then
		set_neili_job=tonumber(neili) or set_neili_job
	end
	Note("内力任务 "..tostring(set_neili_job).."%")
end

function cfg.set_neili_global(neili)
	if neili~=nil then
		set_neili_global=tonumber(neili) or set_neili_global
	end
	Note("全局内力 "..tostring(set_neili_global).."%")
end

function cfg.set_GbSecretWay()
	if set_GbSecretWay>0 then set_GbSecretWay=0 else set_GbSecretWay=1 end
	Note("密道 ".._isopen(set_GbSecretWay))
end

function cfg.resetstatus()
	mark.time=os.time()
	mark.sTime=os.time()
	addneili.fj=0
	addneili.dazuo=0
	addneili.dahuandan=0
	addneili.putizi=0
	list.shizhe=""
	list.putizi=""
	list.pk=""
	cmd.waitcount=0
	sum.fj=0
	sum.mp=0
	sum.beg1=0
	sum.beg2=0
	sum.arrest=0
	sum.ftb=0
	sum.yb=0
	sum.war=0
	sum.death=0
	sum.lifesave=0
	count.fj=0
	count.mp=0
	count.ftb=0
	count.yb=0
	count.death=0
	count.lifesave=0
	resetExplist=""
	ErrList=""
	DeathList=""
	Note("统计已重置")
end

function cfg.skill_xue(...)
	local args = {...}
	if args[1]~=nil and args[1]~="" then
		skills_xue = args[1]
	end
	Note("学习技能: "..tostring(skills_xue or "未设置"))
end

function cfg.skill_lingwu(...)
	local args = {...}
	if args[1]~=nil and args[1]~="" then
		skills_lingwu = args[1]
	end
	Note("领悟技能: "..tostring(skills_lingwu or "未设置"))
end

function cfg.potuseC()
	if usepot=="xue" then return "学习"
	elseif usepot=="lingwu" then return "领悟"
	elseif usepot=="jingyao" then return "精要"
	else return "不使用" end
end

function cfg.potuse()
	if usepot=="none" then usepot="xue"
	elseif usepot=="xue" then usepot="lingwu"
	elseif usepot=="lingwu" then usepot="jingyao"
	else usepot="none" end
	Note("潜能: "..cfg.potuseC())
end

function cfg.xuelitC()
	if wantxuelit<2 then return "优先"
	elseif wantxuelit==2 then return "学习"
	elseif wantxuelit==3 then return "不学"
	end
end

function cfg.xuelit()
	if wantxuelit<2 then wantxuelit=2
	elseif wantxuelit==2 then wantxuelit=3
	elseif wantxuelit==3 then wantxuelit=1
	end
	Note("学文化 "..cfg.xuelitC())
end

function cfg.xuefirstC()
	if xuefirst>0 then return "优先" else return "最后" end
end

function cfg.xuefirst()
	if xuefirst==0 then xuefirst=1 else xuefirst=0 end
	Note("学习"..cfg.xuefirstC().."内功")
end

function cfg.lingwuatC()
	if lingwuat=="menpai" then return "门派" else return "少林" end
end

function cfg.lingwuat()
	if lingwuat=="menpai" then lingwuat="shaolin" else lingwuat="menpai" end
	Note("领悟地点 "..cfg.lingwuatC())
end

-- 兼容旧脚本中 infobtn.xxx 调用，转发到 cfg.xxx
infobtn = infobtn or {}
setmetatable(infobtn, {__index = function(_, key)
	if cfg[key] then
		return cfg[key]
	end
	return function() end
end})

-- cfg.status() -- 显示所有配置项的当前状态
function cfg.status()
	Note("===== 配置状态总览 =====")
	Note("")
	Note("-- 模块开关 --")
	Note("  防发呆     : ".._isopen(setting_resetidle))
	Note("  FJ模块     : ".._isopen(workflow.fj))
	Note("  MP模块     : ".._isopen(workflow.mp))
	Note("  XF模块     : ".._isopen(workflow.xf))
	Note("  CM模块     : ".._isopen(workflow.cm))
	Note("  YB模块     : ".._isopen(workflow.yb))
	Note("  FTB模块    : ".._isopen(workflow.ftb))
	Note("  QZWD       : ".._isopen(workflow.qzwd))
	Note("  密道       : ".._isopen(set_GbSecretWay))
	Note("")
	Note("-- 数值设置 --")
	Note("  内力任务   : "..tostring(set_neili_job).."%")
	Note("  全局内力   : "..tostring(set_neili_global).."%")
	Note("")
	Note("-- 功能设置 --")
	Note("  潜能用途   : "..cfg.potuseC())
	Note("  学文化     : "..cfg.xuelitC())
	Note("  学习优先   : "..cfg.xuefirstC())
	Note("  领悟地点   : "..cfg.lingwuatC())
	Note("  学习技能   : "..tostring(skills_xue or "未设置"))
	Note("  领悟技能   : "..tostring(skills_lingwu or "未设置"))
	Note("")
	Note("========================")
end

-- ============================================================
-- Web UI 集成 API：cfg.schema / cfg.data / cfg.update
-- ============================================================

-- cfg.schema: 配置项元数据定义（供 Web UI 渲染表单）
cfg.schema = {
	-- 模块开关
	{ key="setting_resetidle", label="防发呆", type="boolean", category="开关",
	  getter=function() return setting_resetidle and setting_resetidle>0 end,
	  setter=function(v) local n=v and 1 or 0; setting_resetidle=n; resetidle=n end },
	{ key="workflow.fj",       label="FJ模块",  type="boolean", category="开关",
	  getter=function() return workflow.fj and workflow.fj>0 end,
	  setter=function(v) workflow.fj=v and 1 or 0 end },
	{ key="workflow.mp",       label="MP模块",  type="boolean", category="开关",
	  getter=function() return workflow.mp and workflow.mp>0 end,
	  setter=function(v) workflow.mp=v and 1 or 0 end },
	{ key="workflow.xf",       label="XF模块",  type="boolean", category="开关",
	  getter=function() return workflow.xf and workflow.xf>0 end,
	  setter=function(v) workflow.xf=v and 1 or 0 end },
	{ key="workflow.cm",       label="CM模块",  type="boolean", category="开关",
	  getter=function() return workflow.cm and workflow.cm>0 end,
	  setter=function(v) workflow.cm=v and 1 or 0 end },
	{ key="workflow.yb",       label="YB模块",  type="boolean", category="开关",
	  getter=function() return workflow.yb and workflow.yb>0 end,
	  setter=function(v) workflow.yb=v and 1 or 0 end },
	{ key="workflow.ftb",      label="FTB模块", type="boolean", category="开关",
	  getter=function() return workflow.ftb and workflow.ftb>0 end,
	  setter=function(v) workflow.ftb=v and 1 or 0 end },
	{ key="workflow.qzwd",     label="QZWD",    type="boolean", category="开关",
	  getter=function() return workflow.qzwd and workflow.qzwd>0 end,
	  setter=function(v) workflow.qzwd=v and 1 or 0 end },
	{ key="set_GbSecretWay",   label="密道",    type="boolean", category="开关",
	  getter=function() return set_GbSecretWay and set_GbSecretWay>0 end,
	  setter=function(v) set_GbSecretWay=v and 1 or 0 end },
	-- 数值设置
	{ key="set_neili_job",     label="内力任务%",   type="number", category="数值", min=0, max=500,
	  getter=function() return set_neili_job end,
	  setter=function(v) set_neili_job=tonumber(v) or set_neili_job end },
	{ key="set_neili_global",  label="全局内力%",   type="number", category="数值", min=0, max=500,
	  getter=function() return set_neili_global end,
	  setter=function(v) set_neili_global=tonumber(v) or set_neili_global end },
	-- 功能选项
	{ key="usepot",            label="潜能用途",  type="option", category="选项",
	  options={"none","xue","lingwu","jingyao"},
	  option_labels={"不使用","学习","领悟","精要"},
	  getter=function() return usepot end,
	  setter=function(v) usepot=v end },
	{ key="wantxuelit",        label="学文化",    type="option", category="选项",
	  options={1,2,3}, option_labels={"不学","学习","必学"},
	  getter=function() return wantxuelit end,
	  setter=function(v) wantxuelit=tonumber(v) or wantxuelit end },
	{ key="xuefirst",          label="学习内功",  type="boolean", category="选项",
	  getter=function() return xuefirst and xuefirst>0 end,
	  setter=function(v) xuefirst=v and 1 or 0 end },
	{ key="lingwuat",          label="领悟地点",  type="option", category="选项",
	  options={"menpai","shaolin"}, option_labels={"门派","少林"},
	  getter=function() return lingwuat end,
	  setter=function(v) lingwuat=v end },
	{ key="skills_xue",        label="学习技能",  type="string", category="选项",
	  getter=function() return skills_xue end,
	  setter=function(v) skills_xue=v end },
	{ key="skills_lingwu",     label="领悟技能",  type="string", category="选项",
	  getter=function() return skills_lingwu end,
	  setter=function(v) skills_lingwu=v end },
}

-- cfg.data(): 导出当前所有配置值 + 元数据（供 Web UI / JSON 序列化）
function cfg.data()
	local result = {}
	for _, field in ipairs(cfg.schema) do
		local entry = {
			key = field.key,
			label = field.label,
			type = field.type,
			category = field.category,
			value = field.getter(),
		}
		if field.type == "number" then
			entry.min = field.min
			entry.max = field.max
		elseif field.type == "option" then
			entry.options = field.options
			entry.option_labels = field.option_labels
		end
		table.insert(result, entry)
	end
	return result
end

-- cfg.update(changes): 接受 key→value 映射表，验证后应用
-- changes = { setting_resetidle = true, set_neili_job = 200, ... }
-- 返回 { ok = true/false, errors = { key = "错误信息", ... } }
function cfg.update(changes)
	if type(changes) ~= "table" then
		return { ok=false, errors={ _global="参数必须是 table" } }
	end
	local errors = {}
	local schema_map = {}
	for _, field in ipairs(cfg.schema) do
		schema_map[field.key] = field
	end
	for key, value in pairs(changes) do
		local field = schema_map[key]
		if not field then
			errors[key] = "未知配置项"
		else
			-- 类型检查与转换
			local ok, err = cfg._validate(field, value)
			if not ok then
				errors[key] = err
			else
				-- 应用值
				local success, apply_err = pcall(field.setter, value)
				if not success then
					errors[key] = "应用失败: "..tostring(apply_err)
				end
			end
		end
	end
	if next(errors) then
		return { ok=false, errors=errors }
	end
	return { ok=true }
end

-- cfg._validate(field, value): 单个字段验证（内部函数）
function cfg._validate(field, value)
	local t = field.type
	if t == "boolean" then
		if type(value) ~= "boolean" then
			return false, "需要布尔值 (true/false)"
		end
	elseif t == "number" then
		local n = tonumber(value)
		if n == nil then
			return false, "需要数字"
		end
		if field.min ~= nil and n < field.min then
			return false, "最小值 "..tostring(field.min)
		end
		if field.max ~= nil and n > field.max then
			return false, "最大值 "..tostring(field.max)
		end
	elseif t == "string" then
		if type(value) ~= "string" then
			return false, "需要字符串"
		end
	elseif t == "option" then
		local valid = false
		for _, opt in ipairs(field.options) do
			if tostring(opt) == tostring(value) then
				valid = true
				break
			end
		end
		if not valid then
			return false, "无效选项"
		end
	end
	return true, nil
end

-- 挂机启动/停止快捷命令
function cfg.go()
	mark.gold=0
	mark.setpot=1
	ftbnpckilled=0
	weapon_id=1
	buzhen=false
	checkmove.NotGPSMove=1
	gpszeikou=""
	haveshizhe=0
	stat.reverse=0
	stat.powerup=0
	stat.daxiao=0
	stat.fengyun=0
	stat.tiandi=0
	stat.quiting=0
	stat.zhixin=0
	stat.huntianup=0
	stat.shengang=0
	stat.heji=0
	have.nousejy=0
	set_neili=set_neili_global
	set_GbSecretWay_err=0
	gold.roomNo=0
	burnnpc.have=0
	killaction=""
	gold.id=""
	alias.resetidle()
	run("hp;set rbt=start")
end

function cfg.stop()
	alias.initialize_trigger()
	print("已停止所有工作")
end

-- 注册命令行别名，通过 #cfg xxx 触发配置
AddAlias("cfg_idle",       "^#cfg idle$",                   "cfg.idle()",             33)
AddAlias("cfg_fj",         "^#cfg fj$",                     "cfg.fj()",               33)
AddAlias("cfg_mp",         "^#cfg mp$",                     "cfg.mp()",               33)
AddAlias("cfg_xf",         "^#cfg xf$",                     "cfg.xf()",               33)
AddAlias("cfg_cm",         "^#cfg cm$",                     "cfg.cm()",               33)
AddAlias("cfg_yb",         "^#cfg yb$",                     "cfg.yb()",               33)
AddAlias("cfg_ftb",        "^#cfg ftb$",                    "cfg.ftb()",              33)
AddAlias("cfg_qzwd",       "^#cfg qzwd$",                   "cfg.qzwd()",             33)
AddAlias("cfg_neili_job",  "^#cfg neili_job\\s*(.*)$",      "cfg.set_neili_job(%1)",  33)
AddAlias("cfg_neili_global","^#cfg neili_global\\s*(.*)$",   "cfg.set_neili_global(%1)",33)
AddAlias("cfg_secretway",  "^#cfg secretway$",              "cfg.set_GbSecretWay()",  33)
AddAlias("cfg_reset",      "^#cfg reset$",                  "cfg.resetstatus()",      33)
AddAlias("cfg_potuse",     "^#cfg potuse$",                 "cfg.potuse()",           33)
AddAlias("cfg_xuelit",     "^#cfg xuelit$",                 "cfg.xuelit()",           33)
AddAlias("cfg_xuefirst",   "^#cfg xuefirst$",               "cfg.xuefirst()",         33)
AddAlias("cfg_lingwuat",   "^#cfg lingwuat$",               "cfg.lingwuat()",         33)
AddAlias("cfg_skill_xue",      "^#cfg skill_xue$",                     "cfg.skill_xue()",             33)
AddAlias("cfg_skill_xue_set",  "^#cfg skill_xue\\s+(.+)$",             "cfg.skill_xue('%1')",         33)
AddAlias("cfg_skill_lingwu",      "^#cfg skill_lingwu$",                     "cfg.skill_lingwu()",             33)
AddAlias("cfg_skill_lingwu_set",  "^#cfg skill_lingwu\\s+(.+)$",             "cfg.skill_lingwu('%1')",         33)
AddAlias("cfg_go",         "^#go$",                          "cfg.go()",               33)
AddAlias("cfg_stop",       "^#stop$",                        "cfg.stop()",             33)
AddAlias("cfg_status",     "^#cfg status$",                   "cfg.status()",           33)
AddAlias("cfg_help",       "^#cfg$",                          "cfg.help()",             33)
AddAlias("cfg_help2",      "^#cfg help$",                     "cfg.help()",             33)

function cfg.help()
	Note("=== 配置命令列表 ===")
	Note("#go             - 启动挂机")
	Note("#stop           - 停止挂机")
	Note("#cfg idle        - 防发呆 开/关")
	Note("#cfg fj          - FJ模块 开/关")
	Note("#cfg mp          - MP模块 开/关")
	Note("#cfg xf          - XF模块 开/关")
	Note("#cfg cm          - CM模块 开/关")
	Note("#cfg yb          - YB模块 开/关")
	Note("#cfg ftb         - FTB模块 开/关")
	Note("#cfg qzwd        - QZWD 开/关")
	Note("#cfg neili_job N - 内力任务百分比")
	Note("#cfg neili_global N - 全局内力百分比")
	Note("#cfg secretway   - 密道 开/关")
	Note("#cfg reset       - 重置统计")
	Note("#cfg potuse      - 潜能用途切换")
	Note("#cfg xuelit      - 学文化开关")
	Note("#cfg xuefirst    - 学习优先级切换")
	Note("#cfg lingwuat    - 领悟地点切换")
	Note("#cfg skill_xue [技能列表]   - 设置学习技能（如 sword|blade|force）")
	Note("#cfg skill_lingwu [技能列表] - 设置领悟技能（如 sword|blade|parry）")
	Note("  无参数时显示当前列表")
	Note("#cfg status      - 查看所有配置当前状态")
	Note("===================")
end
