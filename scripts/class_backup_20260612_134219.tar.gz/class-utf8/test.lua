maketri_num=1
local function _f1(n,l,w)
	print("test1")
end
_tb={
		"你自言自语不知道在说些什么。",
	}
	maketri("test",_tb,"test",_f1)
	--[[local  mp_gb_watch_triggerlist={
	       {name="test1",regexp=linktri(_tb),script=function(n,l,w)    _f1()  end,},
	}
	for k,v in pairs(mp_gb_watch_triggerlist) do
		addtri(v.name,v.regexp,"test",v.script,v.line)
	end]]
	
local _f1=function(n,l,w)
	print("test2")
end
_tb={
		"你双手抱拳，作了个揖道：各位英雄请了！",
	}
	maketri("test",_tb,"test",_f1)
	--[[local  mp_gb_watch_triggerlist={
	       {name="test2",regexp=linktri(_tb),script=function(n,l,w)    _f1()  end,},
	}
	for k,v in pairs(mp_gb_watch_triggerlist) do
		addtri(v.name,v.regexp,"test",v.script,v.line)
	end]]
openclass("test")