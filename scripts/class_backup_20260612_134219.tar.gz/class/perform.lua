function alias.kmq()
	if me.master=="������" then run("unwield jian") else run("bei none;bei kongming-quan") end
	local _tb=Split(killpfm,"|")
	run(_tb[pfmid].." "..killid)
	if me.master=="������" then run("wield jian") else run("bei none;bei sanhua-juding;perform sanhua") end
end
function alias.jzpfm()
	if pfmid<9 then 
		pfmid=9
		if jifa.parryname~="qiankun-danuoyi" then run("jifa parry qiankun-danuoyi");jifa.parryname="qiankun-danuoyi" end
		run("nuoyi move") 
	end
	if workflow.nowjob~="yb" then
		if skillslist["pishi-poyu"]["lvl"]>100 and stat.leidong==0 then run("jifa cuff pishi-poyu;bei none;bei pishi-poyu;unwield dao;nuoyi zixia-gong pishi-poyu leidong");jzpfm="leidong"
		elseif skillslist["jingang-quan"]["lvl"]>100 and stat.jingang==0 then run("jifa cuff jingang-quan;bei none;bei jingang-quan;unwield dao;nuoyi hunyuan-yiqi jingang-quan jingang");jzpfm="jingang"
		elseif skillslist["liuhe-dao"]["lvl"]>100 and stat.liuhe==0 then run("wield dao;nuoyi huntian-qigong liuhe-dao lianhuan");jzpfm="liuhe"
		elseif skillslist["liuhe-dao"]["lvl"]>150 and stat.cross<3 then run("wield dao;nuoyi huntian-qigong liuhe-dao cross")
		end
	else
		run("wield dao")
	end
end
function alias.jjz()
	run("wield jian;jifa sword huashan-jianfa;perform jianzhang "..killid..";jifa sword dugu-jiujian")
end
function alias.pfmxy()
	if stat.leidong==0 then run("bei none;bei xianglong-zhang xiaoyaoyou;jifa parry xiaoyaoyou;perform xiaoyao "..killid..";jifa parry xianglong-zhang;bei none;bei xianglong-zhang") end
	run("perform sanhui "..killid)
end
function alias.xxpfm(a)
	alias.resetidle()
	-- #if @debug {#say xx������pfm}
	if a==nil then a=tostring(killid) end
	--if xx.suck==0 or hp.jing<(hp.maxjing*4/5) or hp.healthjing<90 or hp.qi<(hp.maxqi*4/5) or hp.healthqi<90 then
	if hp.qi<(hp.maxqi/4) then run("yun recover") end
	if xx.suck==0 or hp.healthjing<90 or hp.healthqi<90 then
		run("yun jiexin "..killid)
	elseif xx.suck==1 or hp.neili<hp.maxneili then
		run("yun jiemai "..killid)
	else
		run("yun huagong "..killid)
	end
end
function alias.qklm() --����pfm qiankun�Ժ󣬻�������
	alias.resetidle()
	--if skillslist["dafeng-yunfei"]~=nil and jifa.strikename=="dafeng-yunfei" and skillslist["dafeng-yunfei"]["lvl"]>280 then
		if jifa.fingername~="liumai-shenjian" then
			run("jifa finger liumai-shenjian;jifa")
		end
		if #always.bei==0 or #always.bei>1 or always["bei"][1]~="������" then
			run("bei none;bei liumai-shenjian")
		end
		if workflow.nowjob~="war" and not isopen("mp_mj_yudi") then kill_pfm.getflood() end
end
function alias.shlm() --����pfm sanhua�Ժ󣬻�������
	alias.resetidle()
	if jifa.fingername~="liumai-shenjian" then
		run("jifa finger liumai-shenjian;jifa")
	end
	if stat.sanhua==0 then run("perform sanhua")
	elseif #always.bei==0 or #always.bei>1 or always["bei"][1]~="������" then
		run("bei none;bei liumai-shenjian")
	end
end
function alias.shdy() --ȫ��pfm sanhua�Ժ󣬻����Ʊ� pfm duanyun
	alias.resetidle()
	if stat.sanhua==0 then 
		run("unwield whip;perform sanhua")
	else
		run("wield bian;perform duanyun")
	end
end
function alias.pfmyxjf()
	--if yp.name=="�ɹ��佫" or yp.name=="����" or fjselectnpc.menpai=="bt" then 
		--ftbselectnpc.menpai="bt"
	if weapon_now=="jian" then
		run("perform jianmang "..killid)
	elseif weapon_now=="" then
		if jifa.strikename~=nil and jifa.strikename~="luoying-shenjian" then run("jifa strike luoying-shenjian;jifa") end
		if jifa.kickname~=nil and jifa.kickname~="xuanfeng-saoye" then run("jifa kick xuanfeng-saoye;jifa") end
		if always.bei~=nil and #always.bei<2 or (always.bei[1]~="��Ӣ����" and always.bei[1]~="����ɨҶ��") or (always.bei[2]~="��Ӣ����" and always.bei[2]~="����ɨҶ��") then run("bei none;bei xuanfeng-saoye luoying-shenjian") end
		run("perform kuangfeng "..killid)
	else
		run("perform jianzhi "..killid)
	end
end
--thpfm��ʹ��Ҫ��ͬʱ����һ���ȼ������｣����һ�������Ľ��⣩����ָ��ͨ����Ӣ���ƣ�����ɨҶ�ȡ�
--�����ɹ��佫��ɱ�ֻ��Զ�ʹ�ÿ�磬����yapu��fjnpc��jianzhi��������xiao
function alias.thpfm(a)
    alias.resetidle()
	if a==nil then a=tostring(killid) end
	if killid=="menggu wujiang" or killid=="shashou" then
	    killskill=""
	    if hp["jiali"]<10 then run("jiali max") end  
		if hp["jiajin"]>1 then run("jiajin basic") end
	    if weapon_now~="" then alias.uw() end
		if jifa.strikename~=nil and jifa.strikename~="luoying-shenjian" then run("jifa strike luoying-shenjian;jifa") end
		if jifa.parryname~=nil and jifa.parryname~="luoying-shenjian" then run("jifa parry luoying-shenjian;jifa") end
		if jifa.kickname~=nil and jifa.kickname~="xuanfeng-saoye" then run("jifa kick xuanfeng-saoye;jifa") end
		if always.bei~=nil and #always.bei<2 or (always.bei[1]~="��Ӣ����" and always.bei[1]~="����ɨҶ��") or (always.bei[2]~="��Ӣ����" and always.bei[2]~="����ɨҶ��") then run("bei none;bei xuanfeng-saoye luoying-shenjian") end
		run("perform kuangfeng "..killid)
	else
	    if hp["jiali"]<10 then run("jiali max") end  
		if hp["jiajin"]<10 then run("jiajin max") end
	    if weapon_now=="" then alias.wi(killskill) end
		if jifa.swordname~=nil and jifa.swordname~="yuxiao-jian" then run("jifa sword yuxiao-jian;jifa") end
		if jifa.parryname~=nil and jifa.parryname~="yuxiao-jian" then run("jifa parry yuxiao-jian;jifa") end
		if jifa.fingername~=nil and jifa.fingername~="tanzhi-shentong" then run("jifa finger tanzhi-shentong;jifa") end
		if always.bei[1]~="��ָ��ͨ" and always.bei[2]~="��ָ��ͨ" then run("bei none;bei tanzhi-shentong") end
		run("perform jianzhi "..killid)
	end
end
function alias.pfmxtjf()
	if jifa.parryname~="xuantie-jianfa" then run("jifa parry xuantie-jianfa;jifa") end
	if jifa.forcename=="xiantian-gong" and jifa.swordname=="quanzhen-jian" then
		kill_pfm.getflood()
		run("jiali 1;perform sanqing")
		run("jiali "..killjiali)
	end
	if (have.zhongjian>0 or have.xuantiejian>0) and jifa.swordname~="xuantie-jianfa" then
		run("jifa sword xuantie-jianfa;jifa")
	elseif (have.zhongjian<1 and have.xuantiejian<1) and skillslist["dugu-jiujian"]~=nil and me.master=="������" and jifa.swordname~="dugu-jiujian" then
		run("jifa sword dugu-jiujian;jifa parry dugu-jiujian;jifa dodge dugu-jiujian;jifa")
	end
	if jifa.forcename=="xiantian-gong" and killid==me.fjnpcid and jifa.swordname~="dugu-jiujian" then
		run("yun shentong "..killid)
	end
end
function alias.pfm()
	local _tb
	_tb=Split(killpfm,"|")
	if pfmid==nil or pfmid>#_tb then pfmid=1 end
	if pfmid<=#_tb and not (me["menpai"]=="bt" and xy.pfm()<1) then
		if killid==nil then killid="" end
		if kmq() or killpfm=="kmq" then alias.kmq()
		elseif killpfm=="qncg" then run("unwield jian;perform qinna "..killid..";perform cuogu "..killid..";wield jian")
		elseif killpfm=="shst" then run("perform sanhua "..killid..";bei none;bei pili-quan;yun shentong "..killid..";bei sanhua-juding")
		elseif killpfm=="9jst" then run("wield jian;jifa sword quanzhen-jian;perform sanqing "..killid..";jifa sword dugu-jiujian;yun shentong "..killid)
		elseif killpfm=="pfmxy" then alias.pfmxy()
		elseif killpfm=="pfmyxjf" then alias.pfmyxjf()
		elseif killpfm=="thpfm" then alias.thpfm()
		elseif killpfm=="pfmxtjf" then alias.pfmxtjf()
		elseif killpfm=="jzpfm" then alias.jzpfm()
		elseif killpfm=="jjz" then alias.jjz()
		elseif _tb[pfmid]=="qklm" then alias.qklm()
		elseif _tb[pfmid]=="shlm" then alias.shlm()
		elseif _tb[pfmid]=="perform mian" or findstring(_tb[pfmid],"bei ") then run(_tb[pfmid])
		elseif _tb[pfmid]=="shdy" then alias.shdy() 
		elseif killpfm~="" then run(_tb[pfmid].." "..killid) end
	end
end
