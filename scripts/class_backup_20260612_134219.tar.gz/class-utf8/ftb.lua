function ftbselectnpc.select()
	local _t,_tb
	if workflow.nowjob=="lzjob" then return 1 end
	_t=_G["ftbselectnpc"][ftbselectnpc.menpai]
	_tb=Split(_t,"|")
	return tonumber(_tb[ftbselectnpc.weapon+1])
end
ftb_debar={
{nick="说书先生",name="张十五",id="Zhang shiwu",},
{nick="关东大魔",name="滕一雷",id="Teng yilei",},
{nick="巨人",name="忽伦三虎",id="San hu",},
{nick="巨人",name="忽伦四虎",id="Si hu",},
{nick="巨人",name="忽伦大虎",id="Da hu",},
{nick="巨人",name="忽伦二虎",id="Er hu",},
{nick="黑衣僧",name="萧远山",id="Xiao yuanshan",},
{nick="一剑无血",name="冯锡范",id="Feng xifan",},
{nick="天龙门北宗掌门人",name="田归农",id="Tian guinong",},
{nick="铁面判官",name="单正",id="Shan zheng",},
{nick="柔云剑",name="刘承风",id="Liu chengfeng",},
{nick="仁义陆大刀",name="陆天抒",id="Lu tianshu",},
{nick="冷月剑",name="水岱",id="Shui dai",},
{nick="赤练仙子",name="李莫愁","Li mochou",},
}

------------------------------------------------------------------------------------
-- ftb_pre
------------------------------------------------------------------------------------
function ftb_pre.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 checkexpover=ftb 的变量设定。") then
		alias.resetidle()
		ftbnpckilled=0
		ftbnpcabandon=0
		ftbnum=0
		workflow.nowjob="ftb"
		alias.startworkflow()
	end
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		alias.resetidle()
		alias.flyto("大堂","扬州")
	end
	if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『大堂』立马到达！") then
		alias.resetidle()
		closeclass("ftb_pre")
		openclass("ftb_ask")
		if ftbnpckilled>0 then run("ask cheng jinfu about job") end
		alias.dz(set_neili_job)
	end
end
--function ftb_pre.dosomething2(n,l,w)
	--if findstring(w[0],"你向程金斧打听有关「job」的消息。\n程金斧交给你几锭黄金","你向程金斧打听有关「job」的消息。\n程金斧说道：好样的, 斧头帮就靠你这样的大才啊!") then
	--	alias.resetidle()
	--	alias.checkexp("ftb")
	--end
	--if findstring(w[0],"你向程金斧打听有关「job」的消息。\n程金斧说道：我早就告诉过你了:") then
	--	alias.resetidle()
	--	closeclass("ftb_pre")
	--	openclass("ftb_ask")
	--	run("ask cheng about job")
	--end
--end
--function ftb_pre.dosomething3(n,l,w)
	--if findstring(w[0],"你向程金斧打听有关「job」的消息。\n程金斧一脚正好踢中你的屁股！\n程金斧说道：去了这么久才回来, 人家早得手啦%.") then
	--	alias.resetidle()
	--	alias.startftb()
	--end
---end
------------------------------------------------------------------------------------
-- ftb_ask
------------------------------------------------------------------------------------
function ftb_ask.dosomething1(n,l,w)
	if findstring(l,"这里没有 cheng jinfu 这个人。") then
		alias.resetidle()
		ftbfail=1
		alias.startworkflow()
		--if havefj>0 then alias.startworkflow()
		--else alias.dz("addneili") end
	end
	if findstring(l,"区域搜索中心点房间查找失败！") then
		alias.resetidle()  --以下内容移动到alias.lua
		--[[ftbfail=1
		table.insert(ftbfail_table,{ftbzone,ftbroom,})
		alias.startworkflow()]]
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。","你目前还没有任何为 lian=over 的变量设定。") then
		alias.resetidle()
		if havefj>0 then alias.startworkflow();print("ftb dazuo结束")
		else run("ask cheng jinfu about job;set checkjob") end
	end
	--if findstring(l,"你目前还没有任何为 checkhp=addneili 的变量设定。") then
	--	if hp.neili>(hp.maxneili*set_neili_job/100) then alias.tdz() end
	--end
	if findstring(l,"你目前还没有任何为 checkjob 的变量设定。") then
		ftb_start_search()
	end
end
function ftb_start_search()
	if ftbnum==0 or ftbarea=="" or ftbareanum==0 then 
			alias.close_ftb()
			--if hp.pot<50 then alias.dz("addneili") else ftbfail=1;alias.startworkflow() end
			alias.startworkflow()
		else
			--if ftbareanum>4 then ftbareanum=4 end
			ftbsearcherr=0
			alias.ftbarea(ftbarea)
			if ftbroom=="丹凤洞" then ftbroom="羊肠小路" end
			alias.uw()
			print("ftb 地点="..ftbzone.." "..ftbroom.." 范围="..tostring(ftbareanum+1).." 数量="..tostring(ftbnum))
			if ftbjf~=nil and ftbjf~="" then
				run(ftbjf)
			end
			alias.flytoarea(ftbroom,ftbzone,tonumber(ftbareanum)+1)
		end
end
function ftb_ask.dosomething2(n,l,w)
	local a,b,c=string.find(w[0],"你向程金斧打听有关「job」的消息。\n程金斧(.+)")
	if c~=nil and findstring(c,"交给你几锭黄金","就靠你这样的大才") then
		alias.resetidle()
		ftbnum=0
		ftbarea=""
		ftbareanum=0
		--ftbfail=1
		if me.menpai=="th" then run("cun all;taohua") end
		closeclass("ftb_ask")
		openclass("ftb_pre")
		alias.checkexp("ftb")
	elseif c~=nil and findstring(c,"踢中你的屁股") then
		alias.resetidle()
		ftbnum=0
		ftbarea=""
		ftbareanum=0
		--ftbfail=1
		if me.menpai=="th" then run("cun all;taohua") end
		alias.startworkflow()
		--closeclass("ftb_ask")
		--openclass("ftb_pre")
		--alias.checkexp("ftb")
	elseif c~=nil and findstring(c,"我早就告诉过你") then
		alias.resetidle()
		ftbnum=0
		ftbarea=""
		ftbareanum=0
		ftbfail=1
		if me.menpai=="th" then run("cun all;taohua") end
		alias.startworkflow()
		--closeclass("ftb_ask")
		--openclass("ftb_pre")
		--alias.checkexp("ftb")
	end
end
function ftb_ask.dosomething3(n,l,w)
	local a,b,c,d,e=string.find(w[0],"你向程金斧打听有关「job」的消息。\n程金斧说道：听说有(.+)个家伙想对本帮不利.\n程金斧说道：据说他们已经到了([^(]+).*方圆(.+)里之内%.")
	if c~=nil and d~=nil and e~=nil then
		alias.resetidle()
		ftbarea_table={}
		ftbnum=ctonum(c)
		--ftbnum=1
		a,b,e=string.find(l,"方圆(.+)里之内")
		ftbareanum=ctonum(e)
		a,b,c,d=string.find(l,"程金斧说道：据说他们已经到了(.+)方圆.+里之内%.")
		c=string.gsub(c,"%(该处靠近","|")
		c=string.gsub(c,"%)","")
		c=string.gsub(c,", ","|")
		_tb=Split(c,"|")
		tprint(_tb)
		ftbarea_table=_tb		--把附近的地点也记录下来，用以搜索
		ftbarea=ftbarea_table[1]	
		ftbfail=0
		addlog("ftb 地点="..ftbarea.." 范围="..tostring(ftbareanum+1).." 数量="..tostring(ftbnum))
	end
end
--function ftb_ask.dosomething4(n,l,w)
--	local a,b,c,d,e=string.find(w[0],"你向程金斧打听有关「job」的消息。\n程金斧说道：我早就告诉过你了:\n程金斧说道：听说有(.+)个家伙想对本帮不利.\n程金斧说道：据说他们已经到了([^(]+).*方圆(.+)里之内")
--	if c~=nil and d~=nil and e~=nil then
--		alias.resetidle()
--		ftbnum=0
--		ftbarea=""
--		ftbareanum=0
--	end
--end
------------------------------------------------------------------------------------
-- ftb_start
------------------------------------------------------------------------------------
function ftb_start.dosomething1(n,l,w)
	local _f,_tb,a,b,c,d,e
--	wait.make(function()
		if findstring(l,"你目前还没有任何为 checknpc=yes 的变量设定。") then
		--elseif findstring(l,"路漫漫其修远兮，在『.+』中的第『.+』条 第『.+』步") then
			alias.resetidle()
			if hp.qi<(hp.maxqi*90/100) then run("yun recover;hp") end
			if npcfind==0 then
				if cmd.nums>=cmd.setnums then
					alias.yjl()
				end
				if roomno_now==630 or roomno_now==633 or roomno_now==634 or roomno_now==635 or roomno_now==409 or roomno_now==419 then run("halt") end --npc自动kill的房间，加个halt防止被拦
				if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
			else
				_tb=Split(ftbnpcname,"|")
				npcname=_tb[ftbnpcindex]
				_tb=Split(ftbnpcid,"|")
				npcid=_tb[ftbnpcindex]
				if me.menpai=="xs" and lzjob.open>0 then 
					run("kick4 "..npcid) 
				else 
					run("ask "..npcid.." about 刺客") 
				end
			end
		elseif findstring(l,"这里不准战斗。") then
			rekill=rekill+1
			if workflow.nowjob=="lzjob" then run("ask "..tostring(npcid).." about 酥油罐")
			else run("ask "..tostring(npcid).." about 程金斧") end
			if rekill>30 then
				--closeclass("kill_"..me.menpai)
				closeclass("kill")
				closeclass("kill_pfm")
				wieldweapon=0
				getweapon=0
				run("set killover=yes")
			end
		elseif findstring(l,"你忙着呢，你等会儿在问话吧。") then
			wait.make(function()
			if npcid==nil then npcid="" end
			_f=function() run("ask "..npcid.." about 刺客") end
			wait.time(1);_f()
			end)
		elseif findstring(l,"里面是大男人住的地方，你还是不要进去的好，以免玷污自己的名节！") then
			print("房间不允许进入，追加一步绕过此房间")
			flytoarealist_searchindex=flytoarealist_searchindex+1
		elseif findstring(l,"这个方向没有出路。") then
			print(startid.."startid")
			gpserrnum=gpserrnum+1
		elseif findstring(l,'设定环境变量：walk = "off"') then
			alias.resetidle()
			run("set checknpc=yes")
		elseif findstring(l,"突然从(.+)布袋中掉下一个酥油罐。") then
			run("halt;get suyou guan")
		elseif findstring(l,"对方正忙着呢，你等会儿在问话吧。") then
			alias.resetidle()
			ftbnpcindex=ftbnpcindex+1
			_tb=Split(ftbnpcid,"|")
			if ftbnpcindex<=#_tb then
				_tb=Split(ftbnpcname,"|")
				npcname=_tb[ftbnpcindex]
				_tb=Split(ftbnpcid,"|")
				npcid=_tb[ftbnpcindex]
				run("ask "..npcid.." about 刺客")
			else
				npcfind=0
				ftbnpcindex=1
				--_f=function() 
				if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end 
				--end
			end
		elseif findstring(l,"你要对谁做 kick4 这个动作？","你气得伸足乱踢，只踢得地上的白雪飞溅。") then
			alias.resetidle()
			ftbnpcindex=ftbnpcindex+1
			_tb=Split(ftbnpcid,"|")
			if ftbnpcindex<=#_tb then
				_tb=Split(ftbnpcname,"|")
				npcname=_tb[ftbnpcindex]
				_tb=Split(ftbnpcid,"|")
				npcid=_tb[ftbnpcindex]
				run("kick4 "..npcid)
			else
				npcfind=0
				ftbnpcindex=1
				if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
			end
		--elseif findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
		elseif findstring(l,"你目前还没有任何为 busyover=killstart 的变量设定。") then
			alias.resetidle()
			_tb=Split(ftbpfm,"|")
			if findstring(_tb[pfmid],"leidong") and me.menpai=="hs" then
				run("jifa dodge huashan-shenfa;jifa parry pishi-poyu")
			end
			if me.menpai=="hs" then
				if me.master=="风清扬" then run("jifa sword dugu-jiujian")
				elseif ftbweapon=="jian" then run("jifa parry huashan-jianfa")
				elseif ftbweapon=="staff" then run("jifa parry jinhua-zhang") end
			end
			if ftbjf~=nil and ftbjf~="" then run(ftbjf) end
			_tb=Split(killyun,"|")
			for k,v in ipairs(_tb) do run(v) end
			run("kill "..npcid)
			killaction=""
			if me.menpai=="bt" then run("conver staff;attack "..npcid) end
			--if me.menpai=="mj" then run("shoutfighter fighter;order fighter do attack "..npcid..";order fighter 2 do attack "..npcid) end
			if me.menpai=="xs" and lzjob.open then print("lzjob 开始杀人") end
			--_tb=Split(killpfm,"|")
			--run(_tb[pfmid].." "..npcid)
			run(killpfm)
		elseif findstring(l,"你目前还没有任何为 checknpc=menpai 的变量设定。") then
			alias.resetidle()
			if ftbselectnpc.select()>0 then
				-- #say 发现@ftbselectnpc.menpai npc @npcname~(@npcid~，%if( @ftbselectnpc.weapon, 武器, 没武器)
				-- #if @explist.keephour {#add explist.tempinfo %concat( " NPC=", @ftbselectnpc.menpai, " ", %if( @ftbselectnpc.weapon, 武器, 没武器)}
				check_battleidle=0
				openclass("kill")
				openclass("kill_pfm")
				--openclass("kill_"..me.menpai)
				closeclass("kill_run")
				AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
				SetTimerOption("kill_timer", "group", "kill")
				runaway=false
				npcfaint=false
				killRunSuccess=false
				rekill=0
				killid=npcid
				killname=npcname
				killskill=ftbweapon
				killpfm=ftbpfm
				killyun=ftbyun
				killjiali=ftbjiali
				killjiajin=ftbjiajin
				--if me.menpai=="dl" then alias.jfdl() end
				run("jiali "..killjiali..";jiajin "..killjiajin)
				--if me.menpai=="hs" then
				if jifa["forcename"]=="zixia-gong" then --门派判断改成内功判断
					if stat.leidong>0 then
						pfmid=2
						if ftbweapon=="staff" then alias.wi(staffid) else alias.wi(ftbweapon) end
					else
						pfmid=1
						alias.uw()
					end
				else
					pfmid=1
					if string.len(ftbweapon)>0 then
						if ftbweapon=="staff" then alias.wi(staffid) else alias.wi(ftbweapon) end
					else alias.uw() end
				end
				if jifa.forcename=="hunyuan-yiqi" and ftbselectnpc.menpai=="xx" then
					run("yun sangong")
				else
					_tb=Split(ftbyun,"|")
					for k,v in ipairs(_tb) do run(v) end
				end
				alias.checkbusy("killstart")
			else
				-- #if @debug=1 {#say @ftbselectnpc.menpai npc，%if( @ftbselectnpc.weapon, 武器, 没武器 不杀}
				run("follow none")
				ftbnpcabandon=ftbnpcabandon+1
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if tonumber(ftbnpcabandon+ftbnpckilled)==ftbnum then
						-- 放弃和杀掉的NPC数量等于需要找的NPC总数，直接回去了
						if me.menpai=="xs" and lzjob.open>0 then
							alias.checkbusy("suyou")
						else
							if ftbnpckilled>0 then alias.startftb() else alias.startworkflow() end
						end
					else
						if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
					end
				end
			end
		elseif findstring(l,"你目前还没有任何为 busyover=suyou 的变量设定。") then
			run("get suyou guan")
			flytoareastartid=0
			workflow.nowjob="ftb"
			nextJobGodazuobase=1
			openclass("ftb")
			openclass("ftb_pre")
			closeclass("ftb_ask")
			closeclass("ftb_start")
			alias.checkexp("ftb")
		
		elseif findstring(l,"你目前还没有任何为 searcharea=over 的变量设定。") then
			alias.resetidle()
			print("搜索完毕，杀了"..ftbnum.."个中的"..ftbnpckilled.."个NPC")
			if me.menpai=="xs" and lzjob.open>0 and ftbarea_times>0 then
				openclass("ftb")
				openclass("ftb_pre")
				closeclass("ftb_ask")
				closeclass("ftb_start")
				alias.checkexp("ftb")
			elseif ftbnpckilled>0 then 
				alias.startftb()
			elseif ftbarea_times<1 then
				ftbarea_times=ftbarea_times+1
				print("没有找到，扩大范围再找一次")
				alias.flytoarea(ftbroom,ftbzone,9)
			else
				ftbarea_times=0
				alias.startworkflow() 
			end
		elseif findstring(l,"你在(.+)屁股上踢了一脚，将他踢得几个斤斗翻将出去，砰的一声，撞在墙上。") then
			alias.resetidle()
			if ftbjf~=nil and ftbjf~="" then alias.jf(ftbjf) end
			killaction=""
			ftbselectnpc.menpai="dl"
			ftbselectnpc.weapon=0
			run("follow "..npcid..";look "..npcid..";set checknpc=menpai")
		elseif findstring(l,"你要对谁做 18mo 这个动作？") then
			alias.startworkflow()
		end
		--a,b,c=string.find(l,"(.+)倒在地上，挣扎了几下就死了。") 
		--if c~=nil and npcname~=nil and findstring(c,npcname) then 
		if findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
			alias.resetidle()
			ftbnpckilled=ftbnpckilled+1
			ftbnpcindex=ftbnpcindex+1
			alias.yjl()
			if stat.use_jinhua then run("get jinhua") end
			if me.menpai=="xs" and lzjob.open>0 then
				run("get suyou guan")
				print("所有npc杀完！lzjob")
				alias.checkbusy("suyou")
			else
				if me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter;wavefighter fighter") end
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					wait.make(function()
					_f=function() if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end end
					if tonumber(ftbnpckilled)<1 then
						wait.time(1);_f()
					else
						print("所有npc杀完！")
						alias.startftb()
					end
					end)
				end
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)说道：老子怎么看都觉得你比我像杀手!")
		if c~=nil then
			alias.resetidle()
			if ftbjf~=nil and ftbjf~="" then alias.jf(ftbjf) end
			killaction=""
			if c==npcname then run("follow "..npcid..";look "..npcid..";set checknpc=menpai") end
		end
		a,b,c=string.find(l,"这里没有 (.+) 这个人。")
		if c~=nil and c==npcid then
			alias.resetidle()
			ftbnpcindex=ftbnpcindex+1
			_tb=Split(ftbnpcid,"|")
			if ftbnpcindex<=#_tb then
				_tb=Split(ftbnpcname,"|")
				npcname=_tb[ftbnpcindex]
				_tb=Split(ftbnpcid,"|")
				npcid=_tb[ftbnpcindex]
				run("ask "..npcid.." about 刺客")
			else
				npcfind=0
				ftbnpcindex=1
				--_f=function() 
				if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end 
				--end
			end
		end
		a,b,c=string.find(l,"但是很显然的，(.+)现在的状况没有办法给你任何答覆。")
		if c~=nil then
			alias.resetidle()
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
				end
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)说道：青天白日的, 哪里有刺客%? 笑话%.")
		if c~=nil then
			alias.resetidle()
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
				end
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)说道：嗯%.%.%.%.这我可不清楚，你最好问问别人吧。")
		if c~=nil then
			alias.resetidle()
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
				end
			end
		end
		a,b,c=string.find(l,"他看起来是(.+)高手。")
		if c~=nil then
			if findstring(c,"大理段家") then ftbselectnpc.menpai="dl" end
			if findstring(c,"全真教") then ftbselectnpc.menpai="qz" end
			if findstring(c,"武当派") then ftbselectnpc.menpai="wd" end
			if findstring(c,"少林派") then ftbselectnpc.menpai="sl" end
			if findstring(c,"桃花岛") then ftbselectnpc.menpai="th" end
			if findstring(c,"峨嵋派") then ftbselectnpc.menpai="em" end
			if findstring(c,"华山派") then ftbselectnpc.menpai="hs" end
			if findstring(c,"星宿派") then ftbselectnpc.menpai="xx" end
			if findstring(c,"白驼山") then ftbselectnpc.menpai="bt" end
			if findstring(c,"雪山派") then ftbselectnpc.menpai="xs" end
			if findstring(c,"密宗") then ftbselectnpc.menpai="xs" end
			if findstring(c,"丐帮") then ftbselectnpc.menpai="gb" end
			ftbselectnpc.weapon=0
		end
		a,b,c=string.find(l,"□(.+)%(.+%)")
		if c~=nil then
			if not findstring(c,"皮背心") then ftbselectnpc.weapon=1 end
			if findstring(c,"蛇杖") then
				ftbselectnpc.menpai="bt"
				ftbselectnpc.weapon=1
				if me.menpai=="xs" and lzjob.open>0 then print("蛇杖有毒，放弃不杀") end
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)耸了耸肩，很抱歉地说：无可奉告。")
		if c~=nil then
			alias.resetidle()
			-----------------------问过的NPC存入table不再问第二次
			if #ftbnpc_table<1 then 
					table.insert(ftbnpc_table,{name=ftbnpcname,id=ftbnpcid}) 
				else
					for k,v in ipairs(ftbnpc_table) do 
						if v["name"]==ftbnpcname and v["id"]==ftbnpcid then
							--return
						end
					end
					table.insert(ftbnpc_table,{name=ftbnpcname,id=ftbnpcid}) 
			end
			---------------------
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
				end
			end
		end
		a,b,c,d,e=string.find(l,"%s+「(.+)」(%S+)%((.+)%)")
		if c~=nil and d~=nil and e~=nil and findstring(e," ") then
			--print(c,d,e,workflow.nowjob)
			for k,v in ipairs(ftb_debar) do --系统NPC排除
				if v["nick"]==c and v["name"]==d and v["id"]==e then 
					return
				end
			end
			if workflow.nowjob=="ftb" then
				alias.resetidle()
				npcfind=1
				ftbnpcname=additem(ftbnpcname,d)
				ftbnpcid=additem(ftbnpcid,string.lower(e))
				ftbnpcindex=1
			end
		end
		a,b,c,d,e=string.find(l,"%s+(%S+)%((%w+) (%w+)%)")
		--if c~=nil and d~=nil and e~=nil and findstring(c,lzjob.name) then
		if c~=nil and d~=nil and e~=nil and c==lzjob.name then
			if workflow.nowjob=="lzjob" then
				alias.resetidle()
				npcfind=1
				ftbnpcname=lzjob.name
				ftbnpcid=string.lower(d).." "..string.lower(e)
				ftbnpcindex=1
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)想了一会儿，说道：对不起，你问的事我实在没有印象。")
		if c~=nil then
			alias.resetidle()
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end 
				end
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)摇摇头，说道：没听说过。")
		if c~=nil then
			alias.resetidle()
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end 
				end
			end
		end
		a,b,c=string.find(l,"[> ]*(.+)睁大眼睛望着你，显然不知道你在说什么。")
		if c~=nil then
			alias.resetidle()
			if c==npcname then
				ftbnpcindex=ftbnpcindex+1
				_tb=Split(ftbnpcid,"|")
				if ftbnpcindex<=#_tb then
					_tb=Split(ftbnpcname,"|")
					npcname=_tb[ftbnpcindex]
					_tb=Split(ftbnpcid,"|")
					npcid=_tb[ftbnpcindex]
					run("ask "..npcid.." about 刺客")
				else
					npcfind=0
					ftbnpcindex=1
					if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end 
				end
			end
		end
		a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
		if c~=nil and tonumber(c)==tonumber(flytoareastartid) then
			alias.resetidle()
			run("set checknpc=yes")
		end
	--end)
end
------------------------------------------------------------------------------------
-- ftb_watch
------------------------------------------------------------------------------------
function ftb_watch.dosomething1(n,l,w)
	local _f
	--wait.make(function()
		if findstring(l,"此地不适合施展一苇渡江绝技！") then
			gpserrnum=gpserrnum+1
		end
		if findstring(l,"别那么自私！你不能带走超过一把兵器。") then
			gpserrnum=gpserrnum+1
			dropweapon=dropweapon+1
		end
		if findstring(l,"这个方向没有出路。") then
			print(roomno_now.."出错！")
			if tonumber(roomno_now)==934 then 
				alias.searchareastep3() 
			elseif ftbsearcherr<3 then
				--gpserrnum=gpserrnum+1
				ftbsearcherr=ftbsearcherr+1
				alias.close_ftb()
				alias.flytoarea(ftbroom,ftbzone,tonumber(ftbareanum)+1)
			else
				alias.startworkflow()
			end
		end
		if findstring(l,"老师傅拦着你说：你想把食物拿去哪里？东西放下再走。","明教弟子指了指你拿着的食物，说道：根据教规，明教弟子不得将食物带出大食殿。",".+拦着你说：别着急，还是把东西吃完再走吧。") then
			alias.gg()
			gpserrnum=gpserrnum+1
		end
		if findstring(l,"店小二一下挡在楼梯前，白眼一翻：怎麽着，想白住啊！","看清楚点，那是男弟子休息室！","看清楚点，那是男厢房！","看清楚点，那是女厢房！","看清楚点，那是女弟子休息室！","你一个大男人到女人店里去想干什么？","晚上不开，请天亮了再来！","未经许可，不得进入藏经阁三楼！","袁紫衣说道：本姑娘在这里休息，别来打搅！") 
		--or roomno_now==439
		then
			if flytoarealist_backpath==nil or string.len(flytoarealist_backpath)==0 then alias.searchareastep2() else alias.searchareaback2() end
		end
		--未经许可，不得进入藏经阁三楼！","看清楚点，那是男厢房！","看清楚点，那是男弟子休息室！","看清楚点，那是女弟子休息室！","你一个大男人到女人店里去想干什么？","晚上不开，请天亮了再来！","袁紫衣说道：本姑娘在这里休息，别来打搅！
		a,b,c=string.find(l,"[> ]*(.+)%s+%-%s+")
		if c~=nil then
			if not findstring(c,"%)") then roomname=c end
		end
		if findstring(l,"你的动作还没有完成，不能移动。") then
			if not findstring(roomname,"桃花林") then gpserrnum=gpserrnum+1 end
		end
		if findstring(l,"艄公回到仓里，发现你还在，咦了一声, 说：“你还没有上岸啊, 我送你到岸边。") then
			openclass("boat")
		end
		if findstring(l,"你正要有所动作，突然身旁有人将你一拍：好好看比武，别乱动！") then
			alias.close_gps()
			wait.make(function()
			_f=function() run("s;s;set checknpc=yes") end
			wait.time(5);_f()
			end)
		end
		if findstring(l,"^%s+(.+)两黄金%(Gold%)") then
			getgold=1
		end
		if findstring(l,"石级旁边的草丛中忽然跃起一个身影，挡住了你！") then
			run("giveup")
		end
		if findstring(l,"这是丐帮 极其秘密的地下通道，乃用丐帮几辈人之心血掘成。") then
			alias.resetidle()
			run("ne;ne;u;set checknpc=yes")
		end
		if findstring(l,"你目前还没有任何为 checkGbSecretWay=err 的变量设定。") then
			alias.resetidle()
			run("look")
		end
	--end)
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function ftb.update()
	local _tb
	local  ftb_ask_triggerlist={
	       {name="ftb_ask_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    ftb_ask.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(ftb_ask_triggerlist) do
		addtri(v.name,v.regexp,"ftb_ask",v.script,v.line)
	end
	local _tb2={
		"你向程金斧打听有关「job」的消息。\\n(.+)\\Z",
	}
	local _tb3={
		"你向程金斧打听有关「job」的消息。\\n(.+)\\n(.+)\\Z",
	}
	--local _tb4={
	--	"你向程金斧打听有关「job」的消息。\\n(.+)\\n(.+)\\n(.+)\\Z",
	--}
	local  ftb_ask_m_triggerlist={
	       {name="ftb_ask_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    ftb_ask.dosomething2(n,l,w)  end,},
	       {name="ftb_ask_m_dosth3",line=3,regexp=linktri2(_tb3),script=function(n,l,w)    ftb_ask.dosomething3(n,l,w)  end,},
	      -- {name="ftb_ask_m_dosth4",line=4,regexp=linktri2(_tb4),script=function(n,l,w)    ftb_ask.dosomething4(n,l,w)  end,},
	}
	for k,v in pairs(ftb_ask_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"ftb_ask",v.script,v.line)
	end
	closeclass("ftb_ask")
	
	local  ftb_pre_triggerlist={
	       {name="ftb_pre_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    ftb_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(ftb_pre_triggerlist) do
		addtri(v.name,v.regexp,"ftb_pre",v.script,v.line)
	end
	closeclass("ftb_pre")
	
	local  ftb_start_triggerlist={
	       {name="ftb_start_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    ftb_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(ftb_start_triggerlist) do
		addtri(v.name,v.regexp,"ftb_start",v.script,v.line)
	end
	closeclass("ftb_start")
	
	local  ftb_watch_triggerlist={
	       {name="ftb_watch_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    ftb_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(ftb_watch_triggerlist) do
		addtri(v.name,v.regexp,"ftb_watch",v.script,v.line)
	end
	closeclass("ftb_watch")
end
ftb.update()