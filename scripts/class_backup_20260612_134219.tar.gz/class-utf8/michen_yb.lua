--[[
整体思路：
ASK JOB部份：
1.要到JOB了，n或者sw，shang che,check che
2.还不能要JOB，startworkflow
3.已经有任务，就放弃吧
送镖部份：
1.CHECK CHE来判断要送去的地点，路径
2.建一个TIMER，每秒check busy，如果不busy就可以继续行走，如果在FIGHT,就YQ和PFM
	不BUSY的时候，如果有FJ，并且在安全房间，就回去FJ
	如果安全房间就在前方路径上，就送到安全房间，再回去FJ
	如果安全房间就在附近，就送到安全房间，再回去FJ
3.车子行走成功的描述，来确认行走成功了，继续下一个路径
4.车子行走错误，重新定位，寻找路径
5.出贼的描述，标记FIGHT状态，交给TIMER处理
到达目的地部份：
1.回到镖局了，startworkflow
2.到取货的地点了，check che
3.到卸货的地点了，返回镖局
4.NPC没在，找当前房间的SAFEEXIT，来回走，一直到NPC回来
特殊部份：
1.超过时间了，回去放弃任务
2.车没了，回去放弃任务
]]

--[[  --失败log
褚万里上前对着你抱拳道：「这位督公请了。」
褚万里说道：「这份东西麻烦这位督公能交给在大雪山的柔云剑手上，一切小心。」
]]
--setybjob=1


-- 分岔口房间清单  
ybrouteroom_list={  --hhy添加于2016年9月21日
1396,1372,1394,618,1102,927,1053,930,1369,1381,1376,1298,1388,949,610,1378,1123,1,52,1042,143,814,1314,1032,1115,1055,1144,608,928,940,208,104,176,
}

-- 安全房间清单
--ybsaferoom_list="1402|608|928|1042|1033|1055|1115|1097|1123|91|940|960"
--ybsaferoom_list={
	--1402,608,928,1042,1033,1055,1115,1097,1123,91,940,960,
--}
ybsaferoom_list={
	1402,608,928,949,1115,993,940,960,963,1033,91,
}
-- 检查是否是安全房间的函数
function isSafeRoom(roomno)
    for _, safeRoom in ipairs(ybsaferoom_list) do
        if safeRoom == roomno then
            return true
        end
    end
    return false
end
--ybsaferoom_list={}
ybplace_list={}
table.insert(ybplace_list,{NpcId="fu sigui",NpcName1="傅思归",NpcName2="傅将军",NpcArea="大理",Place="定安府",Roomno=285,})
table.insert(ybplace_list,{NpcId="duan xing",NpcName1="段陉",NpcName2="段判官",NpcArea="大理",Place="法堂",Roomno=292,})
table.insert(ybplace_list,{NpcId="xue laoban",NpcName1="薛老板",NpcName2="薛大老板",NpcArea="大理",Place="薛记成衣铺",Roomno=283,})
table.insert(ybplace_list,{NpcId="he hongyao",NpcName1="何红药",NpcName2="五毒教何堂主",NpcArea="大理",Place="药铺",Roomno=282,})
table.insert(ybplace_list,{NpcId="song laoban",NpcName1="宋老板",NpcName2="太和居老板",NpcArea="大理",Place="太和居二楼",Roomno=280,})
table.insert(ybplace_list,{NpcId="chu wanli",NpcName1="褚万里",NpcName2="褚将军",NpcArea="大理",Place="王府大门：",Roomno=177,})
table.insert(ybplace_list,{NpcId="cui baiquan",NpcName1="崔管家",NpcName2="金算盘崔百泉",NpcArea="大理",Place="前院",Roomno=178,})
table.insert(ybplace_list,{NpcId="hua hegen",NpcName1="华赫艮",NpcName2="华司徒",NpcArea="大理",Place="司徒堂",Roomno=181,})
table.insert(ybplace_list,{NpcId="ba tianshi",NpcName1="巴天石",NpcName2="巴司空",NpcArea="大理",Place="司徒堂",Roomno=180,})
table.insert(ybplace_list,{NpcId="fan ye",NpcName1="范骅",NpcName2="范司马",NpcArea="大理",Place="司马堂",Roomno=182,})
table.insert(ybplace_list,{NpcId="zhu danchen",NpcName1="朱丹臣",NpcName2="朱将军",NpcArea="大理",Place="厢房",Roomno=194,})
table.insert(ybplace_list,{NpcId="gao shengtai",NpcName1="侯爷高升泰",NpcName2="善阐侯",NpcArea="大理",Place="楼梯",Roomno=315,})
table.insert(ybplace_list,{NpcId="daizu shouling",NpcName1="傣族首领",NpcName2="洪源洞洞主",NpcArea="大理",Place="贵宾房",Roomno=322,})
table.insert(ybplace_list,{NpcId="nuerhai",NpcName1="努儿海",NpcName2="一品堂总管",NpcArea="西夏",Place="账房",Roomno=1975,})
table.insert(ybplace_list,{NpcId="helian tieshu",NpcName1="赫连铁树",NpcName2="征东大将军",NpcArea="西夏",Place="一品堂大厅",Roomno=1977,})
table.insert(ybplace_list,{NpcId="lao daoshi",NpcName1="老道士",NpcName2="老道士",NpcArea="西夏",Place="八仙道观",Roomno=1612,})
table.insert(ybplace_list,{NpcId="duan yanqing",NpcName1="段延庆",NpcName2="恶贯满盈",NpcArea="西夏",Place="密室",Roomno=1986,})
table.insert(ybplace_list,{NpcId="ye erniang",NpcName1="叶二娘",NpcName2="无恶不作",NpcArea="西夏",Place="林中大屋",Roomno=1590,})
table.insert(ybplace_list,{NpcId="nanhai eshen",NpcName1="南海鳄神",NpcName2="凶神恶煞",NpcArea="西夏",Place="林中大屋",Roomno=1590,})
table.insert(ybplace_list,{NpcId="yun zhonghe",NpcName1="云中鹤",NpcName2="穷凶极恶",NpcArea="西夏",Place="接引堂",Roomno=1976,})
table.insert(ybplace_list,{NpcId="qiu shanfeng",NpcName1="邱山风",NpcName2="长乐帮虎猛堂香主",NpcArea="宜兴",Place="大门",Roomno=1101,})
table.insert(ybplace_list,{NpcId="bei haishi",NpcName1="贝海石",NpcName2="着手成春",NpcArea="宜兴",Place="大厅",Roomno=1102,})
table.insert(ybplace_list,{NpcId="ding dang",NpcName1="丁当",NpcName2="叮叮当当",NpcArea="宜兴",Place="八角亭",Roomno=1112,})
table.insert(ybplace_list,{NpcId="situ heng",NpcName1="司徒横",NpcName2="长乐帮主八爪金龙",NpcArea="宜兴",Place="小厅",Roomno=1107,})
table.insert(ybplace_list,{NpcId="zhuang yuncheng",NpcName1="庄允城",NpcName2="庄允城",NpcArea="宜兴",Place="南浔镇",Roomno=1297,})
table.insert(ybplace_list,{NpcId="feng liang",NpcName1="风良",NpcName2="青龙门掌门人",NpcArea="宜兴",Place="树林",Roomno=1095,})
table.insert(ybplace_list,{NpcId="gao san",NpcName1="高三娘子",NpcName2="万马庄女庄主",NpcArea="宜兴",Place="树林",Roomno=1095,})
table.insert(ybplace_list,{NpcId="fan yifei",NpcName1="范一飞",NpcName2="鹤笔门掌门人",NpcArea="宜兴",Place="树林",Roomno=1094,})
table.insert(ybplace_list,{NpcId="lu zhengping",NpcName1="吕正平",NpcName2="快刀门掌门人",NpcArea="宜兴",Place="树林",Roomno=1094,})
table.insert(ybplace_list,{NpcId="hu laoye",NpcName1="巴依",NpcName2="胡老爷",NpcArea="伊犁",Place="巴依家院",Roomno=1336,})
table.insert(ybplace_list,{NpcId="li wenxiu",NpcName1="李文秀",NpcName2="李文秀",NpcArea="伊犁",Place="赛马场",Roomno=1335,})
table.insert(ybplace_list,{NpcId="jia renda",NpcName1="贾人达",NpcName2="青城派弟子",NpcArea="泉州",Place="望州亭",Roomno=1289,})
table.insert(ybplace_list,{NpcId="wang tongzhi",NpcName1="王通治",NpcName2="药铺掌柜",NpcArea="泉州",Place="济世堂老店",Roomno=4,})
table.insert(ybplace_list,{NpcId="shi lang",NpcName1="施琅",NpcName2="靖海侯",NpcArea="泉州",Place="将军府",Roomno=86,})
table.insert(ybplace_list,{NpcId="ouyang zhan",NpcName1="欧阳詹",NpcName2="欧阳老师",NpcArea="泉州",Place="学堂",Roomno=83,})
table.insert(ybplace_list,{NpcId="tao lao",NpcName1="陶老人",NpcName2="陶老先生",NpcArea="泉州",Place="淘然茶居",Roomno=59,})
table.insert(ybplace_list,{NpcId="wu laoban",NpcName1="吴老板",NpcName2="烟雨楼大老板",NpcArea="泉州",Place="万国烟雨楼",Roomno=73,})
table.insert(ybplace_list,{NpcId="xu laoban",NpcName1="许老板",NpcName2="绸缎庄老板",NpcArea="泉州",Place="鸿翔绸缎庄",Roomno=71,})
table.insert(ybplace_list,{NpcId="ma wude",NpcName1="马五德",NpcName2="马师傅",NpcArea="泉州",Place="前厅",Roomno=34,})
table.insert(ybplace_list,{NpcId="long quan",NpcName1="龙铨",NpcName2="龙铨师傅",NpcArea="泉州",Place="刀刃部",Roomno=42,})
table.insert(ybplace_list,{NpcId="chen hu",NpcName1="陈浒",NpcName2="陈浒师傅",NpcArea="泉州",Place="棒杖部",Roomno=41,})
table.insert(ybplace_list,{NpcId="xiao fei",NpcName1="萧飞",NpcName2="萧飞师傅",NpcArea="泉州",Place="暗器部",Roomno=40,})
table.insert(ybplace_list,{NpcId="liu hongying",NpcName1="刘虹瑛",NpcName2="刘虹瑛师傅",NpcArea="泉州",Place="剑部",Roomno=38,})
table.insert(ybplace_list,{NpcId="miao zhu",NpcName1="庙祝",NpcName2="城隍庙祝",NpcArea="泉州",Place="城隍庙",Roomno=15,})
table.insert(ybplace_list,{NpcId="lu guanying",NpcName1="陆冠英",NpcName2="归云庄少庄主",NpcArea="杭州",Place="太湖",Roomno=1091,})
table.insert(ybplace_list,{NpcId="gu yanwu",NpcName1="顾炎武",NpcName2="顾老师",NpcArea="杭州",Place="玉泉书院",Roomno=1171,})
table.insert(ybplace_list,{NpcId="ou yezi",NpcName1="欧冶子",NpcName2="欧铁匠",NpcArea="杭州",Place="铁匠铺",Roomno=1256,})
table.insert(ybplace_list,{NpcId="guo xiaotian",NpcName1="郭啸天",NpcName2="郭啸天",NpcArea="嘉兴",Place="牛家村",Roomno=1277,})
table.insert(ybplace_list,{NpcId="yang tiexin",NpcName1="杨铁心",NpcName2="杨铁心",NpcArea="嘉兴",Place="牛家村",Roomno=1277,})
table.insert(ybplace_list,{NpcId="qu san",NpcName1="曲三",NpcName2="曲老板",NpcArea="嘉兴",Place="酒店",Roomno=1278,})
table.insert(ybplace_list,{NpcId="feng qi",NpcName1="凤七",NpcName2="凤楼主",NpcArea="佛山",Place="英雄楼",Roomno=105,})
table.insert(ybplace_list,{NpcId="feng yiming",NpcName1="凤一鸣",NpcName2="凤馆主",NpcArea="佛山",Place="英雄会馆",Roomno=103,})
table.insert(ybplace_list,{NpcId="wang laohan",NpcName1="王老汉",NpcName2="王老汉",NpcArea="佛山",Place="烧饼油条铺",Roomno=109,})
table.insert(ybplace_list,{NpcId="zhang chaotang",NpcName1="张朝唐",NpcName2="张公子",NpcArea="佛山",Place="林间道",Roomno=113,})
table.insert(ybplace_list,{NpcId="xiaoxiang zi",NpcName1="潇湘子",NpcName2="湘西名宿",NpcArea="三不管",Place="麻溪铺",Roomno=626,})
table.insert(ybplace_list,{NpcId="qi changfa",NpcName1="戚长发",NpcName2="铁锁横江",NpcArea="三不管",Place="戚家大院",Roomno=627,})
table.insert(ybplace_list,{NpcId="li mochou",NpcName1="李莫愁",NpcName2="赤练仙子",NpcArea="嘉兴",Place="嘉兴南湖",Roomno=1271,})
table.insert(ybplace_list,{NpcId="xiang wentian",NpcName1="向问天",NpcName2="向右使",NpcArea="嘉兴",Place="茶亭",Roomno=1269,})
table.insert(ybplace_list,{NpcId="jin xin",NpcName1="金鑫",NpcName2="柜房掌柜",NpcArea="南阳城",Place="柜房",Roomno=1886,})
table.insert(ybplace_list,{NpcId="yu jiang",NpcName1="玉匠",NpcName2="瑰玮阁大老板",NpcArea="南阳城",Place="瑰玮阁",Roomno=1894,})
table.insert(ybplace_list,{NpcId="yu jiang",NpcName1="玉匠",NpcName2="瑰玮阁老板",NpcArea="南阳城",Place="瑰玮阁",Roomno=1894,})
table.insert(ybplace_list,{NpcId="lang zhong",NpcName1="郎中",NpcName2="大夫",NpcArea="南阳城",Place="张仲景墓",Roomno=1925,})
table.insert(ybplace_list,{NpcId="xiao yuanshan",NpcName1="萧远山",NpcName2="黑衣僧",NpcArea="赫图阿拉",Place="官道",Roomno=1537,})
table.insert(ybplace_list,{NpcId="yuzhen zi",NpcName1="玉真子",NpcName2="护国真人",NpcArea="赫图阿拉",Place="木桥",Roomno=1707,})
table.insert(ybplace_list,{NpcId="teng yilei",NpcName1="滕一雷",NpcName2="关东大魔",NpcArea="赫图阿拉",Place="南城",Roomno=1474,})
table.insert(ybplace_list,{NpcId="feng xifan",NpcName1="冯锡范",NpcName2="一剑无血",NpcArea="赫图阿拉",Place="老龙头",Roomno=1535,})
table.insert(ybplace_list,{NpcId="jiao wenqi",NpcName1="焦文期",NpcName2="关东三魔",NpcArea="赫图阿拉",Place="土窑馆",Roomno=1479,})
table.insert(ybplace_list,{NpcId="ma guangzuo",NpcName1="马光佐",NpcName2="白驼山庄武师",NpcArea="扬州郊外",Place="小路",Roomno=925,})
table.insert(ybplace_list,{NpcId="ouyang ke",NpcName1="欧阳克",NpcName2="白驼山少庄主",NpcArea="扬州郊外",Place="小山丘",Roomno=926,})
table.insert(ybplace_list,{NpcId="cui hua",NpcName1="翠花",NpcName2="翠姑娘",NpcArea="华山村",Place="民房",Roomno=826,})
table.insert(ybplace_list,{NpcId="feng",NpcName1="冯铁匠",NpcName2="冯铁匠",NpcArea="华山村",Place="铁匠铺",Roomno=833,})
table.insert(ybplace_list,{NpcId="li si",NpcName1="李四",NpcName2="小店老板",NpcArea="华山村",Place="杂货店",Roomno=831,})
table.insert(ybplace_list,{NpcId="li tiezui",NpcName1="李铁嘴",NpcName2="李师傅",NpcArea="华山",Place="玉泉院",Roomno=922,})
table.insert(ybplace_list,{NpcId="shan zheng",NpcName1="单正",NpcName2="铁面判官",NpcArea="泰山",Place="岱宗坊",Roomno=1060,})
table.insert(ybplace_list,{NpcId="zu qianqiu",NpcName1="祖千秋",NpcName2="祖先生",NpcArea="黄河",Place="黄河岸边",Roomno=1304,})
table.insert(ybplace_list,{NpcId="hou tonghai",NpcName1="侯通海",NpcName2="三头蛟",NpcArea="黄河",Place="黄河岸边",Roomno=1314,})
table.insert(ybplace_list,{NpcId="shen qinggang",NpcName1="沈青刚",NpcName2="黄河四鬼老大",NpcArea="黄河",Place="黄河帮寨门",Roomno=1315,})
table.insert(ybplace_list,{NpcId="ma qingxiong",NpcName1="马青雄",NpcName2="黄河四鬼老三",NpcArea="黄河",Place="黄河帮寨门",Roomno=1315,})
table.insert(ybplace_list,{NpcId="wu qinglie",NpcName1="吴青烈",NpcName2="黄河四鬼老二",NpcArea="黄河",Place="广场",Roomno=1316,})
table.insert(ybplace_list,{NpcId="qian qingjian",NpcName1="钱青健",NpcName2="黄河四鬼老四",NpcArea="黄河",Place="广场",Roomno=1316,})
table.insert(ybplace_list,{NpcId="sha tongtian",NpcName1="沙通天",NpcName2="黄河帮帮主",NpcArea="黄河",Place="侠义厅",Roomno=1317,})
table.insert(ybplace_list,{NpcId="liang ziweng",NpcName1="梁子翁",NpcName2="参仙老怪",NpcArea="黄河",Place="侠义厅",Roomno=1317,})
table.insert(ybplace_list,{NpcId="peng lianhu",NpcName1="彭连虎",NpcName2="千手人屠",NpcArea="黄河",Place="侠义厅",Roomno=1317,})
table.insert(ybplace_list,{NpcId="lu tianshu",NpcName1="陆天抒",NpcName2="仁义陆大刀",NpcArea="大雪山",Place="大雪山山路",Roomno=419,})
table.insert(ybplace_list,{NpcId="shui dai",NpcName1="水岱",NpcName2="冷月剑",NpcArea="大雪山",Place="大雪山山路",Roomno=419,})
table.insert(ybplace_list,{NpcId="hua tiegan",NpcName1="花铁干",NpcName2="中平无敌",NpcArea="大雪山",Place="大雪山北麓",Roomno=418,})
table.insert(ybplace_list,{NpcId="liu chengfeng",NpcName1="刘承风",NpcName2="柔云剑",NpcArea="大雪山",Place="山路",Roomno=647,})
table.insert(ybplace_list,{NpcId="lin zhennan",NpcName1="林震南",NpcName2="林震南",NpcArea="扬州",Place="福威镖局",Roomno=964,})
table.insert(ybplace_list,{NpcId="zhen xibei",NpcName1="镇西北",NpcName2="镇西北",NpcArea="祁连山",Place="兰州",Roomno=1376,})

robber_list={}
table.insert(robber_list,{name="流氓",id="liu mang",})
table.insert(robber_list,{name="无赖",id="wu lai",})
table.insert(robber_list,{name="路霸",id="lu ba",})
table.insert(robber_list,{name="草寇",id="cao kou",})
table.insert(robber_list,{name="流寇",id="liu kou",})
table.insert(robber_list,{name="恶霸",id="e ba",})
table.insert(robber_list,{name="抢匪",id="qiang fei",})
table.insert(robber_list,{name="帮匪",id="bang fei",})
table.insert(robber_list,{name="毛贼",id="mao zei",})
table.insert(robber_list,{name="小贼",id="xiao zei",})
table.insert(robber_list,{name="贼头",id="zei tou",})
table.insert(robber_list,{name="小贼头",id="xiaozei tou",})
table.insert(robber_list,{name="毛贼头",id="maozei tou",})
table.insert(robber_list,{name="流氓头",id="liumang tou",})
table.insert(robber_list,{name="山大王",id="shan dawang",})
table.insert(robber_list,{name="独行盗",id="duxing dao",})
table.insert(robber_list,{name="盗贼",id="dao zei",})
table.insert(robber_list,{name="盗贼王",id="daozei wang",})
table.insert(robber_list,{name="盗贼首领",id="daozei shouling",})
table.insert(robber_list,{name="盗贼领袖",id="daozei lingxiu",})
table.insert(robber_list,{name="盗贼大王",id="daozei dawang",})
table.insert(robber_list,{name="寨主",id="zhai zhu",})
table.insert(robber_list,{name="山寨主",id="shan zhaizhu",})
table.insert(robber_list,{name="山寨首领",id="shanzhai shouling",})
table.insert(robber_list,{name="山寨领袖",id="shanzhai lingxiu",})
table.insert(robber_list,{name="山寨大王",id="shanzhai dawang",})
table.insert(robber_list,{name="强盗",id="qiang dao",})
table.insert(robber_list,{name="强盗头",id="qiangdao tou",})
table.insert(robber_list,{name="强盗王",id="qiangdao wang",})
table.insert(robber_list,{name="强盗首领",id="qiangdao shouling",})
table.insert(robber_list,{name="强盗领袖",id="qiangdao lingxiu",})
table.insert(robber_list,{name="强盗大王",id="qiangdao dawang",})
table.insert(robber_list,{name="土匪",id="tufei",})
table.insert(robber_list,{name="土匪头",id="tufei tou",})
table.insert(robber_list,{name="土匪首领",id="tufei shouling",})
table.insert(robber_list,{name="土匪领袖",id="tufei lingxiu",})
table.insert(robber_list,{name="土匪大王",id="tufei dawang",})
table.insert(robber_list,{name="山贼",id="shan zei",})
table.insert(robber_list,{name="小山贼",id="xiao shanzei",})
table.insert(robber_list,{name="山贼头",id="shanzei tou",})
table.insert(robber_list,{name="山贼首领",id="shanzei shouling",})
table.insert(robber_list,{name="山贼领袖",id="shanzei lingxiu",})
table.insert(robber_list,{name="山贼大王",id="shanzei dawang",})
robber_act={
	a={"无预警地","","突然","不知从哪里","不知从何处","毫无征兆地","无征兆地","忽然","毫无预警地","从某处",},
	b={"跳了","跑了","窜了","走了","跃了","冲了","跳","跑","窜","走","跃","冲"},
	c={"喝道","喊道","叫道","怒道","说道","说","道"},
}
function alias.getybinfo() --计算押镖路径
	local _tb,msg,_t
	if type(roomno_now)=="table" then print("当前房间不是唯一的，避免报错，跳出程序");return end
	for k,v in pairs(ybplace_list) do
		if v["NpcName1"]==ybjob.ybnpcname or v["NpcName2"]==ybjob.ybnpcname then
			ybjob.ybnpcid=v["NpcId"]
			ybjob.ybroomno=tonumber(v["Roomno"])
			ybjob.place=v["Place"]
			ybjob.ybpathnow=1
			ybjob.gosaferoom=false
			-- 这里特别处理一下，不能钻狗洞的
			_t=xkxGPS.EntranceCondition
			xkxGPS.setEntranceCondition("condition is null")
			ybjob.ybpath=pathfix(xkxGPS.search(roomno_now,ybjob.ybroomno))
			xkxGPS.setEntranceCondition(_t)
			if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
			_tb=Split(ybjob.ybpath,"|")
			ybjob.ybpathnum=#_tb
			ybjob.ybfx=_tb[1]
			msg="运镖路径查找完成，到达 "..ybjob.ybnpcname.." 需要走"..ybjob.ybpathnum.."步"
			if findstring(ybjob.ybpath,"guohe") then msg=msg.."，需要过河。" else msg=msg.."，不需要过河。" end
			if de_bug>0 then print(ybjob.ybpath) end
			print(msg)
			return
		end
	end
	print("获取押镖信息失败！NPCNAME="..ybjob.ybnpcname)
	addlog("获取押镖信息失败！NPCNAME="..ybjob.ybnpcname)
	alias.close_yb()
	wait.make(function()
		_f=function() alias.startworkflow() end
		wait.time(1);_f()
	end)
end

function alias.getybsaferoom()
	local _tb,_t,a
	for k,v in pairs(ybsaferoom_list) do		
		_t=xkxGPS.EntranceCondition
		xkxGPS.setEntranceCondition("condition is null")
		a=pathfix(xkxGPS.search(roomno_now,v))
		xkxGPS.setEntranceCondition(_t)
		--if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
		_tb=Split(a,"|")
		if #_tb<6 then
			ybjob.ybpath=a
			ybjob.ybpathnow=1
			ybjob.ybpathnum=#_tb
			ybjob.ybfx=_tb[1]	
			ybjob.gosaferoom=true			
			print("fj更改路径:前往安全房间"..v..",需要走"..ybjob.ybpathnum.."步")
			return
		end
	end
	run("score")
end
function pathfix(a)
	if a==nil then return ""
	else
		if findstring(a,"opendoor") then run("open door") end
		a=string.gsub(string.gsub(string.gsub(a," ",""),"-",""),";","|")
		a=string.gsub(a,"opendoor","")
		a=string.gsub(a,"qzqcjy","e|s|w|n")	--青城沙漠
		a=string.gsub(a,"qzjyqc","s|e|n|w")
		a=string.gsub(a,"se|yztd1yztd2","n|n|e")	--扬州田地
		a=string.gsub(a,"yztd2yztd3|ne|e","e|e|se")
		a=string.gsub(a,"w|sw|yztd3yztd2","nw|w|w")
		a=string.gsub(a,"yztd2yztd1|nw","w|s|s")
		a=string.gsub(a,"slgatesl","n")
		-------------------------------
		a=string.gsub(a,"yzxlyzxsq","wu")
		a=string.gsub(a,"xxyptdtyptms","w")
		a=string.gsub(a,"xxyptdydyq","w")
		a=string.gsub(a,"xxyptdmyptdy","n")
		a=string.gsub(a,"clbdmclbdt","enter")
		a=string.gsub(a,"nycjnynm","enter")
		return a
	end
end
function fxfix(a)
	if a==nil then return ""
	elseif a=="eu" then return "eastup"
	elseif a=="e" then return "east" --一品堂大院到段延庆
	elseif a=="ed" then return "eastdown"
	elseif a=="se" then return "southeast"
	elseif a=="su" then return "southup"
	elseif a=="s" then return "south"
	elseif a=="sd" then return "southdown"
	elseif a=="sw" then return "southwest"
	elseif a=="wu" or a=="yzxlyzxsq" then return "westup"
	elseif a=="w" or a=="xxyptdtyptms" or a=="xxyptdydyq"  then return "west"
	elseif a=="wd" then return "westdown"
	elseif a=="nw" then return "northwest"
	elseif a=="nu" then return "northup"
	elseif a=="n" or a=="xxyptdmyptdy" or a=="slgatesl" then return "north"
	elseif a=="nd" then return "northdown"
	elseif a=="ne" then return "northeast"
	elseif a=="d" then return "down"
	elseif a=="u" then return "up"
	elseif a=="clbdmclbdt" or a=="nycjnynm" then return "enter"
	--elseif a=="isHere" then run("set ganche=isHere");roomno_now=0;return always.exit --防止原地踏步
	elseif a=="isHere" then run("set ganche=isHere");return always.exit --防止原地踏步
	else return a end
end
function alias.checkybroom()
	alias.initialize_gps()
	alias.open_gps()
	closeclass("michen_yb_start_t")
	run("look;set gps=start")
end
function alias.ybdokill()
	openclass("kill")
	openclass("kill_pfm")
	closeclass("kill_run")
	AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
	SetTimerOption("kill_timer", "group", "kill")
	reyun=1
	rekill=0
	runaway=false
	npcfaint=false
	killRunSuccess=false
	killaction=""
	--killid=""
	killname=""
	killskill=yb.weapon
	killpfm=yb.pfm
	killyun=yb.yun
	killjiali=yb.jiali
	killjiajin=yb.jiajin
	--run("unset no_parry;yield no;jiali "..yb.jiali..";jiajin "..yb.jiajin)
	--[[if string.len(yb.weapon)>0 then
		wieldweapon=1
		if yb.weapon=="staff" then alias.wi(staffid) else alias.wi(yb.weapon) end
	else alias.uw() end]]--
	if string.len(yb.yun)>0 then
		_tb=Split(yb.yun,"|")
		for k,v in ipairs(_tb) do run(v) end
	end
	alias.pfm()
end
function alias.checkche()
	closeclass("michen_yb_pre")
	closeclass("michen_yb_start_t")
	openclass("michen_yb_watch")
	openclass("michen_yb_start")
	run("open door;convert she;shang che;shang che 2;shang che 3;shang che 4;shang che 5;shang che 6;check;jiali "..yb["jiali"])
	--if ybjob.ybnpcname=="" then run("check che") end
	if ybjob.ybnpcname=="" then
		set_yb()
	else
		if roomno_now==0 then 
			alias.checkybroom()
		else
			alias.getybinfo()
			openclass("michen_yb_start_t")
		end
	end
end
function alias.leaveche()
	alias.initialize_trigger()
	alias.open_yb()
	--if me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter;wavefighter fighter") end
	set_yb()
	run("h;leave che")
	if setybjob=="zhen xibei" then alias.flytoid(1376) else alias.flytoid(964) end
end
function ybtest()
	alias.initialize_gps()
	workflow.nowjob="yb"
	roomno_now=0
	openclass("michen_yb_start")
	openclass("michen_yb_watch")
	alias.checkybroom()
end
------------------------------------------------------------------------------------
-- michen_yb_pre
------------------------------------------------------------------------------------
function michen_yb_pre.dosomething1(n,l,w)
	local _f,a,b,c,d,e,f
	wait.make(function()
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		alias.resetidle()
		run("unset no_parry;yield no;jiali "..yb.jiali..";jiajin "..yb.jiajin)
		if string.len(yb.weapon)>0 then
			wieldweapon=1
			if yb.weapon=="staff" then alias.wi(staffid) else alias.wi(yb.weapon) end
		else alias.uw() 
		end
		if setybjob=="zhen xibei" then alias.flytoid(1376) else alias.flytoid(964) end
	end
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil then
		alias.resetidle()
		if tonumber(c)==1376 or tonumber(c)==964 then
			if ybjob.waitlimit>0 then
				alias.dz(set_neili_job)
			elseif hp.maxneili<30000 then
				alias.dz(set_neili)
			else
				alias.dz(set_neili_global)
			end
		elseif tonumber(c)==ybjob.ybroom then
			alias.checkche()
		end
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		ybjob.haveyixing=0 --重置移行buff
		ybjob.ybfight=0 --重置战斗
		if yb.jf~=nil and yb.jf~="" then alias.jf(yb.jf) end
		if jifa.forcename=="bitao-xuangong" then stat.yixing=0;run("yun yixing") end
		if ybjob.ybroom>0 then 
			alias.flytoid(ybjob.ybroom)
		elseif ybjob.waitlimit>0 and ybLimited==0 then 
			print("押镖上限时间已结束，领取上次押镖的奖励")
			ybjob.waitlimit=0
			alias.checkbusy("ybend")
			return
		elseif havefj>0 or mj_need_yudi() then 
			print("yb_pre")
			alias.startworkflow()
		else
			set_yb()
			if roomno_now==1376 then run("ne") elseif roomno_now==964 then run("s") end
			run("ask "..setybjob.." about abandon;ask "..setybjob.." about job")
		end
	end
	if findstring(l,"你目前还没有任何为 busyover=ybend 的变量设定。") then
		alias.resetidle()
		if ybjob.waitlimit>0 and ybLimited>0 then
			if me.menpai=="th" and workflow.fj>0 then
				alias.startfj()
			else
				alias.startworkflow()
			end
		else
			run("ne;s")
		end
	end
	if findstring(l,".+对着你笑道：你干的好！.+你这样的人才") then
		alias.resetidle()
		ybjob.ybstatus=0
		if me.menpai=="th" then run("cun all;taohua") end
		ybjob.ybnpcname=""
		alias.checkexp("yb")
	end
	if findstring(l,"你目前还没有任何为 checkexpover=yb 的变量设定。") then
		alias.resetidle()
		if add.exp<200 or ybexp>=5000 then
			ybLimited=1
			print("统计到的yb上限为："..ybexp)
			if ybLimitedMarkTime<(os.time()-3600) then
				if de_bug>0 then print("到yb时间却仍然busy，推迟2分钟") end
				ybLimitedMarkTime=tonumber(os.time()-3600+120)
			end
		end
		set_yb()
		if me.menpai=="th" and ybLimited>0 and (ybjob.waitlimit>0 or os.time()-tonumber(ybLimitedMarkTime)<2000) and (workflow.mp==0 or mpJobLimited>0) and workflow.fj>0 then
			alias.startfj()
		else
			alias.startworkflow()
		end
	end
	if findstring(l,"你忙着呢，你等会儿在问话吧。","对方正忙着呢，你等会儿在问话吧。") then
		alias.resetidle()
		_f=function() run("ask "..setybjob.." about job") end
		wait.time(1);_f()
	end
	if findstring(l,"这里没有 "..setybjob.." 这个人。") then alias.startxue() end
	end)
end
function michen_yb_pre.dosomething2(n,l,w) --多行触发
	local _f,a,b,c,e,f,g,h,i
	wait.make(function()
	a,b,c=string.find(w[0],"你向[镇西北|林震南]+打听有关「job」的消息。\n[镇西北|林震南]+(.+)")
	if c~=nil and not findstring(c,"你来得正是时候，我这儿正缺人用") then
		--print(a,b,c)
		alias.resetidle()
		if findstring(c,"今天所有的镖都已送完了") then alias.startxue() end
		if findstring(c,"生气地撅了撅嘴","你这不中用的家伙","暂时信不过你去干") then
			ybjob.needfangqi=1
			alias.startworkflow()
		end
		if findstring(c,"是黑道上的英雄","难道是福威镖局派来") then
			if setybjob=="zhen xibei" then setybjob="lin zhennan" else setybjob="zhen xibei" end
			alias.startworkflow()
		end
	end
	--g,h,i=string.find(l,".+说道：这份东西是要送给在南阳城柜房柜房掌柜的，路上一切注意。")
	if findstring(w[0],"你向.+打听有关「job」的消息。\n.+说道：好吧，你来得正是时候，我这儿正缺人用。\n.+说道：.+的.+") then
		alias.resetidle()
		check_battleidle=0
		set_yb()
		a,b,c=string.find(l,".+说道：.+的(.+)有")
		d,e,f=string.find(l,".+说道：.+的(.+)所")
		local function start_yb()
			if c~=nil then ybjob.ybnpcname=c elseif f~=nil then ybjob.ybnpcname=f end
			--if c~=nil then ybjob.ybnpcname=c end
			workflow.nowjob="yb"
			ybjob.ybstatus=1
			if me.shen>=0 then
				roomno_now=964   --正神车的位置
				run("n")
				if jifa.forcename=="bitao-xuangong" then run("shang che") end
			else
				roomno_now=1376  --负神车位置
				run("sw")
				if jifa.forcename=="bitao-xuangong" then run("shang che") end
			end
			alias.checkche()
		end
		start_yb()
	end
	end)
end
------------------------------------------------------------------------------------
-- michen_yb_start
------------------------------------------------------------------------------------
function ybstatus()
	local s
	if ybjob.ybstatus==2 then s="送往" elseif ybjob.ybstatus==3 then s="返回" else s="前往" end
	return s
end
function isValidRoomForLeaving() --绝对不能下车的房间
    local roomno = tonumber(roomno_now)
    if roomno <= 0 then
        return false
    end
    
    -- 排除的特殊房间列表
    local forbiddenRooms = {
	--一品堂大厅，福威镖局，兰州，汉水北岸，南阳金鑫，南阳玉匠
        1977, 964, 1376, 1526, 1886, 1894
    }
    
    for _, forbiddenRoom in ipairs(forbiddenRooms) do
        if roomno == forbiddenRoom then
            return false
        end
    end
    
    -- 沙漠和船上不能随便跑
    if always.where == "沙漠" or findstring(always.where, "船") then
        return false
    end
    
    -- 西夏和扬州郊外区船不好等，不下车
    if roomno >= 1554 and roomno <= 1614 then
        return me.menpai == "sl"  -- 只有少林下车，可以yun du
    end
    
    return true
end
function michen_yb_start.dosomething1(n,l,w)
	local _f,_t,_tb,a,b,c,d,e,f,g,h,i,j,k,s
	wait.make(function()
		---------------------------------------------------------------------------- 获取目的地位置
		if findstring(l,"你目前还没有任何为 gps=end 的变量设定。")  then
			if tonumber(roomno_now)==nil then
				print("房间定位异常，等待下一次定位")
				return
			elseif tonumber(roomno_now)~=nil and tonumber(roomno_now)~=0 then
				if type(roomno_now)=="number" then
					alias.close_gps()
					_f=function() alias.checkche() end
					wait.time(1);_f()
				end
			else
				ybjob.ybfx=always.exit
				openclass("michen_yb_start_t")
			end
		end
		a,b,c,d=string.find(l,"这是(.+)押运的镖车，要去向(.+)取货。")
		if c~=nil and d~=nil then
			if c==me.charname then
				ybjob.ybstatus=1
				if tonumber(d)==nil then 
					ybjob.ybnpcname=d 
				end
				stat.yixing=0
				if roomno_now==0 then 
					alias.checkybroom()
				else
					alias.getybinfo()
					openclass("michen_yb_start_t")
				end
			else
				-- 不是我的车
				_f=function() alias.checkche() end
				wait.time(1);_f()
			end
		end
		a,b,c,d=string.find(l,"这是(.+)押运的重镖，要送给(.+)的。")
		if c~=nil and d~=nil then
			if c==me.charname and ybjob.ybstatus~=3 then
				ybjob.ybstatus=2
				if tonumber(d)==nil then ybjob.ybnpcname=d end
				stat.yixing=0
				if roomno_now==0 then 
					alias.checkybroom()
				else
					alias.getybinfo()
					openclass("michen_yb_start_t")
				end
			else
				-- 不是我的车
				_f=function() alias.checkche() end
				wait.time(1);_f()
			end
		end
		a,b,c=string.find(l,"这是(.+)押运的空车，正在归途中")
		if c~=nil then
			if c==me.charname then
				ybjob.ybstatus=3
				if setybjob=="zhen xibei" then ybjob.ybnpcname="镇西北" else ybjob.ybnpcname="林震南" end
				stat.yixing=0
				if roomno_now==0 then 
					alias.checkybroom()
				else
					alias.getybinfo()
					openclass("michen_yb_start_t")
				end
			else
				-- 不是我的车
				_f=function() alias.checkche() end
				wait.time(1);_f()
			end
		end
		if findstring(l,"只有乞丐才能打探别人的技能！") then 
			alias.leaveche()
		end
		---------------------------------------------------------------------------- YB过程中，赶车部份的处理
		if findstring(l,"你又不在镖车上！怎么赶车？") then alias.checkche() end
		if findstring(l,"你要驱赶什么？","无此方向可去！","此方向无路可行！","此方向去不了！","此方向无法去！","此方向无法前进！","此路不通！","无法前进！","前进不了！","无法走！") then
			alias.resetidle()
			run("open door")
			ybjob.err=ybjob.err+1
			if ybjob.err>5 and not findstring(always.where,"船") then 
			--	ybjob.ybfx=always.exit 
				ybjob.err=0
				closeclass("michen_yb_start_t")
				alias.checkybroom()
			end
			if findstring(always.where,"船") then run("h;gan che out") end
		end
		if findstring(l,"你一声长啸，脚下踩著奇门步法，趋前抢后，尤如天神行法，鬼魅遁影，瞬间只见数十个身影飞射而出，游走不定！") then ybjob.haveyixing=1;michen_yb_start.timer() end
		if findstring(l,"只见.+先天护体神功自然而然发动，将你的力道尽数反震向你自己。") then run("yun recover") end
		if findstring(l,"你缓缓吸了一口气，将内劲收回丹田。") and jifa["forcename"]=="zixia-gong" then stat.leidong=0;pfmid=1 end
		if findstring(l,"你缓缓吸了一口气，收回金刚神通，身形又恢复了原状。") then stat.jingang=0;pfmid=1 end
		if findstring(l,"^侧坐在.*你.*车.*来。$","^靠在.*你.*车.*来。$","^立在.*你.*车.*来。$","^斜靠在.*你.*车.*来。$","^倚在.*你.*车.*来。$","^站立在.*你.*车.*来。$","^站在.*你.*车.*来。$","^坐在.*你.*车.*来。$","^你.*车.*而来。$","^你.*车.*驶来。$","^你.*车.*驶过来。$") then
			alias.resetidle()
			check_battleidle=0
			ybjob.ybfight=0
			ybjob.killlist={}
			alias.close_dz()
			alias.close_kill()
			_tb=Split(ybjob.ybpath,"|")
			if not findstring(always.where,"船") then
				--if tonumber(roomno_now)~=nil and tonumber(roomno_now)>0 then 
				if roomno_now~=nil then
					roomno_now=xkxGPS.getnextroomno(roomno_now,ybjob.ybfx)
					print(ybstatus()..": "..ybjob.ybnpcname.." 前进方向: "..ybjob.ybfx.." 当前房间: "..roomno_now.." | 第"..ybjob.ybpathnow.."/"..#_tb.."步")
				    ybjob.ybpathnow=ybjob.ybpathnow+1
                else
                    alias.gps()					
				end
			end
			if always.where=="青城" then roomno_now=1403 	--修复一些地区的roomno_now
			elseif always.where=="靖远" then roomno_now=1362 
			elseif always.where=="一品堂大厅" then roomno_now=1977 
			elseif always.where=="古长城" then roomno_now=1365 
			elseif always.where=="汉水北岸" then roomno_now=1526
			elseif always.where=="汉水南岸" then roomno_now=1049 
			elseif always.where=="宣和堡" then roomno_now=1554 
			end
			ybjob.ybroom=roomno_now
			if ybjob.ybpathnow<=#_tb then 
				ybjob.ybfx=tostring(_tb[ybjob.ybpathnow]) 
			else 
				closeclass("michen_yb_start_t") 
				--if always.where~=ybjob.place or roomno_now==0 then
				if always.where~=ybjob.place and not ybjob.gosaferoom then
					alias.checkche()
				end
			end
			if (ybjob.haveyixing==0 or ybjob.ybpathnow<3) and jifa.forcename=="bitao-xuangong" and ybjob.yxnpc~="" and roomno_now~=1376 and roomno_now~=964 and (me.menpai~="gb" or (roomno_now~=0 and not findstring(xkxGPS.find_zone(roomno_now),"杭州","广东佛山","福建泉州","云南大理城"))) then
					run("attack "..ybjob.yxnpc);ybjob.yxnpc="" 
			elseif ybjob.haveyixing==0 and jifa.forcename=="bitao-xuangong" and roomno_now==1376 then
				run("fight "..ybjob.yxnpc)
			elseif jifa.forcename=="bitao-xuangong" and ybjob.yxanimal~="" and roomno_now~=1376 and roomno_now~=964 then 
					run("fight "..ybjob.yxanimal);ybjob.yxanimal="" 
			end
			ybjob.haveyixing=0 
			--[[
				if ybjob.steptime==nil then 
					ybjob.steptime=os.time() 
					print(ybstatus()..": "..ybjob.ybnpcname.." 前进方向: "..ybjob.ybfx.." 当前房间: "..roomno_now.." | 第"..ybjob.ybpathnow.."/"..#_tb.."步")
				else
					print(ybstatus()..": "..ybjob.ybnpcname.." 前进方向: "..ybjob.ybfx.." 当前房间: "..roomno_now.." | 第"..ybjob.ybpathnow.."/"..#_tb.."步，小步用时"..tonumber(os.time()-ybjob.steptime))
					ybjob.steptime=os.time() 
				end
			--]]
			if ybjob.err>5 then
				ybjob.err=0
				closeclass("michen_yb_start_t")
				alias.checkybroom()
			elseif (havefj>0 or mj_need_yudi()) and isValidRoomForLeaving() then	--来fj或者yudi，先判断是否在不宜下车的区域
				if ybjob.ybstatus==1 and (tonumber(#_tb-ybjob.ybpathnow)<1) then 
					ybjob.gosaferoom = false
					print("取货到了目的地房间，不下车")
				elseif ybjob.ybstatus==2 then         --送货路上
					if isSafeRoom(roomno_now) then		--在安全房间，可以下车做fj
						print("送货路上，镖车停在安全房间:"..ybjob.ybroom.." "..always.where.." 任务完成后回来开车")
						ybjob.gosaferoom = true
						closeclass("michen_yb_start_t")
						run("leave che")
						alias.checkbusy("fj")
					elseif tonumber(#_tb-ybjob.ybpathnow)>6 then		--不在安全房间，寻找6步内的安全房间开过去
						alias.getybsaferoom()
					end
				else								--取货或者回镖局路上，可以下车做fj
					print("镖车停在:"..ybjob.ybroom.." "..always.where.." 运镖状态:"..ybstatus().." "..ybjob.ybnpcname)
					ybjob.gosaferoom = true
					closeclass("michen_yb_start_t")
					run("leave che")
					alias.checkbusy("fj")
				end
			end
		end
		if findstring(l,"你目前还没有任何为 busyover=fj 的变量设定。") then
			alias.resetidle()
			--alias.startfj()
			alias.startworkflow()
		end
		if ybjob.ybfx=="guohe" and findstring(l,"岸边一只渡船上的老艄公说道：正等着你呢，上来吧。","岸边一只渡船上的船夫说道：正等着你呢，上来吧。","一条渔船应声慢慢驶了过来","一叶扁舟缓缓地驶了过来") then
			alias.resetidle()
			check_battleidle=0
			alias.close_dz()
			run("halt;eat guoheenter")
		end
		if ybjob.ybfx=="guohe" and findstring(l,"说“到啦，上岸吧”，随即把一块踏脚板搭上堤岸。","船夫扳桨划船，在湖中行了数里，缓缓停泊在岸边，将一块踏脚板搭上了堤岸。") then
			alias.resetidle()
			check_battleidle=0
			alias.close_dz()
			run("halt;eat guoheout")
		end
		if findstring(l,"你身上没有 guoheenter 这样食物。") then run("h;gan che enter") end
		if findstring(l,"你身上没有 guoheout 这样食物。") then run("h;gan che out") end
		---------------------------------------------------------------------------- YB到地方了
		if findstring(l,"你到了此处却见不到主人，于是大声说道：「请问有人吗？」","可是你却找不到主人，把你急得直冒汗") then
			alias.resetidle()
			closeclass("michen_yb_start_t")
			ybjob.waitnpc=1
			ybjob.arrive=1
			if de_bug>0 then print("到达: "..ybjob.ybnpcname.." "..roomno_now.." npc不在反走一步 "..ybjob.ybfx.." "..ybjob.ybpathnow) end
			wait.make(function()
			    local _f=function()
			    alias.resetidle()
			    end
			wait.time(56)
			_f()
			end)
		end
		if findstring(l,".+急急忙忙走了过来") then
			alias.resetidle()
			if ybjob.waitnpc==1 then
			    ybjob.waitnpc=0
				ybjob.ybpathnow=ybjob.ybpathnow-2
			    ybjob.ybfx=invDirection(fxfix(ybjob.ybfx))
			    openclass("michen_yb_start_t")
			end
		end
		a,b,c,d=string.find(w[0],"[> ]*(.+)上前对着你抱拳道：「.+」\n.+道：「.+能.+的.+")
		if c~=nil then
			alias.resetidle()
			addlog(w[0])
			--if roomno_now==0 then
				set_yb()
			--	alias.gps()
				for k,v in pairs(ybplace_list) do	--修正目的地roomno_now
					if v["NpcName1"]==c or v["NpcName2"]==c then
						roomno_now=tonumber(v["Roomno"])
						break
					end
				end
			--end
			pfmid=1
			ybjob.ybroom=roomno_now
			if de_bug>0 then print("到达: "..c.." 当前房间: "..ybjob.ybroom) end
			ybjob.haveyixing=0
			closeclass("michen_yb_start_t")
			------------------------------------------
			e,f,g=string.find(l,".+道：「.+能.+的(.+)处，")
			h,i,k=string.find(l,".+道：「.+能.+的(.+)手上，")
				ybjob.ybstatus=2  --此阶段不能随意离开镖车
				alias.resetidle()
				if g~=nil then
					ybjob.ybnpcname=g
					if roomno_now==0 then 
						alias.checkybroom()
					else
						alias.getybinfo()
						openclass("michen_yb_start_t")
					end
				elseif k~=nil then
					ybjob.ybnpcname=k
					if roomno_now==0 then 
						alias.checkybroom()
					else
						alias.getybinfo()
						openclass("michen_yb_start_t")
					end
				else
					ybjob.ybnpcname=""
					alias.checkche()
				end
			-----------------------------------------
			--alias.checkbusy("yb")
		end
		a,b,c=string.find(w[0],"你上前对着(.+)抱拳道：「这位.+现将镖货原物奉上")
		if c~=nil then
			alias.resetidle()
			set_yb()
			ybjob.ybstatus=3
			ybjob.haveyixing=0
			for k,v in pairs(ybplace_list) do	--修正目的地roomno_now
				if v["NpcName1"]==c or v["NpcName2"]==c then
					roomno_now=tonumber(v["Roomno"])
				end
			end
			ybjob.ybroom=roomno_now
			if setybjob=="zhen xibei" then ybjob.ybnpcname="镇西北" else ybjob.ybnpcname="林震南" end
			if me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter;wavefighter fighter") end
			run("shang che;jiali "..yb.jiali)
			if roomno_now==0 then 
				alias.checkybroom()
			else
				alias.getybinfo()
				openclass("michen_yb_start_t")
			end
			--
		end
		if findstring(l,"接着你把骡子和镖车重新拴好准备回去了。") then 
			alias.resetidle()
			ybjob.ybstatus=3
			ybjob.haveyixing=0
			if setybjob=="zhen xibei" then ybjob.ybnpcname="镇西北" else ybjob.ybnpcname="林震南" end
			if me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter;wavefighter fighter") end
			run("shang che;jiali "..yb.jiali)
			--if roomno_now==0 then 
			--	alias.checkybroom()
			--else
			--	alias.getybinfo()
			--	openclass("michen_yb_start_t")
			--end
		end
		if findstring(l,"你目前还没有任何为 busyover=yb 的变量设定。") then
			alias.resetidle()
			alias.checkche()
		end
		if findstring(l,"你松了一口气说道：「终于回到了镖局！」") then
			set_yb()
			alias.resetidle()
			alias.open_yb()
			--alias.checkexp("war")
			if me.menpai=="th" then run("cun all") end
			if ybLimited>0 then ybjob.waitlimit=1 end
			alias.checkbusy("ybend")
		end
		a,b,c,d,e=string.find(l,"(%S+)%((%w+) (%w+)%)")			--bitao-xuangong attack加速
		if c~=nil and findstring(c,"位","只") then c=string.sub(c,5,-1) end
		if c~=nil and d~=nil and e~=nil and findstring(btxg_attack,"|"..c.."|") then
			ybjob.yxnpc=string.lower(d).." "..string.lower(e)
		elseif c~=nil and d~=nil and e~=nil and findstring(btxg_kill,"|"..c.."|") then
			ybjob.yxanimal=string.lower(d).." "..string.lower(e)
		end
		a,b,c,d=string.find(l,"(%S+)%((%w+)%)")			--bitao-xuangong attack加速
		if c~=nil and findstring(c,"位","只") then c=string.sub(c,5,-1) end
		if c~=nil and d~=nil and findstring(btxg_attack,"|"..c.."|") then
			ybjob.yxnpc=string.lower(d)
		elseif c~=nil and d~=nil and findstring(btxg_kill,"|"..c.."|") then
			ybjob.yxanimal=string.lower(d)
		end
		----------------------------------------------------------------------------  YB过程中，强盗的处理部份
		a,b,c=string.find(w[0],"(.+)急急忙忙离开了")
		a,b,d=string.find(w[0],"(.+)脚下一个不稳，跌在地上昏了过去。")
		a,b,e=string.find(w[0],"(.+)倒在地上，挣扎了几下就死了。")
		--if findstring(l,"急急忙忙离开了","跌在地上昏了过去","挣扎了几下就死了。") then
		if c~=nil or d~=nil or e~=nil then
			alias.resetidle()
			if c~=nil then _f=c
			elseif d~=nil then _f=d
			elseif e~=nil then _f=e
			end
			--print(_f)
			for k,v in pairs(ybjob.killlist) do
				if _f==v["name"] then
					table.remove(ybjob.killlist,k)
					break
				end
			end
			ybjob.ybfight=0
			xx.suck=0
			if #ybjob.killlist==0 then
				alias.close_kill()
			else
				killid=ybjob.killlist[1]["id"]
				ybjob.haveyixing=0
			end
			--if me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter;wavefighter fighter") end
		end
		a,b,c=string.find(w[0],"(.+)喝道：「.+」\n看起来.+想杀死你！")
		if c~=nil and ybjob.ybstatus==2 and not findstring(w[0],"，看招！」") then
			--山贼领袖喝道：「贫僧我正好缺几个钱花。相好的，赶快交出宝贝受死，就饶你一条全尸！」
			--土匪首领喝道：「此树是我栽，此路是我开，要从此处过，留下买路钱。相好的，识趣点交出宝贝，就饶你一条狗命！」
			--
			if isopen("dazuo") or isopen("dazuo_resetidle") then
				alias.close_dz()
			end
			killid=""
			ybjob.haveyixing=0
			for k,v in pairs(robber_list) do
				_t={name=v["name"],id=v["id"],}
				if c==v["name"] then
					killid=tostring(v["id"])
					run("attack "..tostring(v["id"]))
					table.insert(ybjob.killlist,_t)
					if me.menpai=="bt" then run("convert staff;attack "..tostring(v["id"])) end
					if me.menpai=="mj" then run("shoutfighter fighter;order fighter do attack "..tostring(v["id"])..";order fighter 2 do attack "..tostring(v["id"])) end
					break
				end
			end
			if killid~="" then 
				ybjob.ybfight=1 
				alias.ybdokill()
			end
		end
		a,b,c=string.find(w[0],"你驾着镖车扬了扬鞭子，高声驱赶骡子朝.+驶去。\n(.+)：.+！")
		if c~=nil then
			for k,v in pairs(robber_act.c) do
			for a,b in pairs(robber_list) do
				_t=tostring(b["name"])..tostring(v)
				if c==_t then
					--print(_t)
					killid=tostring(b["id"])
					run("attack "..tostring(b["id"])..";kill "..tostring(b["id"]))
					ybjob.killlist={}
					table.insert(ybjob.killlist,b)
					if me.menpai=="bt" then run("convert staff;attack "..tostring(b["id"])) end
					if me.menpai=="mj" then run("shoutfighter fighter;order fighter do attack "..tostring(b["id"])..";order fighter 2 do attack "..tostring(b["id"])) end
				end
			end
			end
			if killid~="" then 
				ybjob.ybfight=1 
				alias.ybdokill()
			end
		end
		a,b,c,d=string.find(w[0],"(.+)受到(.+)佛法感招，决定罢手不斗。")
		if	d~=nil and c~=nil then
			for k,v in pairs(ybjob.killlist) do
				if c==v["name"] then
					table.remove(ybjob.killlist,k)
					break
				end
			end
			if d=="你" then
				alias.checkexp("mp")
			end
		end
	end)
end
------------------------------------------------------------------------------------
-- michen_yb_start_t
------------------------------------------------------------------------------------
--if ybjob.ybfx=="guohe" then run("yell boat") else run("eat ybrun") end
function michen_yb_start.timer()
	alias.resetidle()
	if #ybjob.killlist==0 then ybjob.ybfight=0 end
	if stat.yixing==0 and jifa.forcename=="bitao-xuangong" and roomno_now~=91 and always.where~="擂台下" then run("yun yixing") end
	if hp.healthqi<60 or (hp.neili<(hp.maxneili/5) and jifa.fingername~="liumai-shenjian") then alias.leaveche() end
	if ybjob.ybfight==0 then
		if findstring(always.where,"船") then
			if hp.neili<(hp.maxneili*190/100) then alias.dz1() end
		else
			if ybjob.ybfx=="guohe" then 
				run("yell boat") 
			elseif isopen_timer("michen_yb_start_t") then
				run("gan che "..fxfix(ybjob.ybfx)) 
			end
		end
	end
end
------------------------------------------------------------------------------------
-- michen_yb_watch
------------------------------------------------------------------------------------
function michen_yb_watch.dosomething1(n,l,w)
	if findstring(l,"周围没人能帮你去了解别人的消息","只有乞丐才能打探别人的技能","你只是个不入流的小乞丐") then
		alias.leaveche()
	end
	if findstring(l,"骡子突然发疯似的拉着镖车就跑，把你一屁股甩在地上","你抬头看了看天空，估算着日子，突然发觉时限已到") then
		alias.leaveche()
	end
	if findstring(l,"你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑") then
		alias.leaveche()
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function michen_yb.update()
	local _tb,_tb2
	_tb={
		"你目前还没有任何为 .+ 的变量设定。",
		"数码世界，数字地图，.+就是这里！",
		"[林震南|镇西北]+对着你笑道：你干的好！.+你这样的人才",
		"你忙着呢，你等会儿在问话吧。",
		"对方正忙着呢，你等会儿在问话吧。",
		"这里没有 .+ 这个人。",
		"今天所有的镖都已送完了",
		"[林震南|镇西北]+生气地撅了撅嘴",
	--	"你这不中用的家伙，亏你还有脸回来见我要求走镖！",
		"[林震南|镇西北]+说道：我这里倒有几桩差事，可是暂时信不过你去干！",
		"林震南说道：.+是黑道上的英雄",
		"镇西北说道：.+难道是福威镖局派来卧底的",
	}
	--林震南说道：你真是不中用，下回再要差事，我可要考虑考虑！
	local  michen_yb_pre_triggerlist={
	       {name="michen_yb_pre_dosth1",regexp=linktri(_tb),script=function(n,l,w)    michen_yb_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(michen_yb_pre_triggerlist) do
		addtri(v.name,v.regexp,"michen_yb_pre",v.script,v.line)
	end
	---------------------------------------------------------
	_tb2={
		"你向(镇西北|林震南)+打听有关「job」的消息。\\n(.+)\\Z",
	}
	local  michen_yb_pre_m_triggerlist={
	      -- {name="michen_yb_pre_m_dosth1",line=2,regexp="^(> > > |> > |> |)你向(镇西北|林震南)+打听有关「job」的消息。\\n(.+)\\Z",script=function(n,l,w)    michen_yb_pre.dosomething2(n,l,w)  end,},
		 {name="michen_yb_pre_m_dosth1",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    michen_yb_pre.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(michen_yb_pre_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"michen_yb_pre",v.script,v.line)
	end
	---------------------------------------------------------
	_tb2={
		"你向(镇西北|林震南)打听有关「job」的消息。\\n(.+)\\n(镇西北|林震南)说道：.+的.+。\\Z",
	}
	local  michen_yb_pre_m_triggerlist={
	       {name="michen_yb_pre_m_dosth2_2",line=3,regexp=linktri2(_tb2),script=function(n,l,w)    michen_yb_pre.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(michen_yb_pre_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"michen_yb_pre",v.script,v.line)
	end
	closeclass("michen_yb_pre")
	---------------------------------------------------------
	
	_tb={
		"你目前还没有任何为 .+ 的变量设定。",
		"这是.+押运的镖车，要去向.+取货。",
		"这是.+押运的重镖，要送给.+的。",
		"这是.+押运的空车，正在归途中",
		"只有乞丐才能打探别人的技能！",
		"你又不在镖车上！怎么赶车？",
		"你要驱赶什么？","无此方向可去！","此方向无路可行！","此方向去不了！","此方向无法去！","此方向无法前进！","此路不通！","无法前进！","前进不了！","无法走！",
		"你一声长啸，脚下踩著奇门步法，趋前抢后，尤如天神行法，鬼魅遁影，瞬间只见数十个身影飞射而出，游走不定！",
		"只见.+先天护体神功自然而然发动，将你的力道尽数反震向你自己。",
		"你缓缓吸了一口气，将内劲收回丹田。",
		"你缓缓吸了一口气，收回金刚神通，身形又恢复了原状。",
		--"侧.*你.*车.*来。","靠.*你.*车.*来。","立.*你.*车.*来。","你.*车.*来。","斜.*你.*车.*来。","倚.*你.*车.*来。","站.*你.*车.*来。","坐.*你.*车.*来。",
		"侧坐在.*你.*车.*来。","靠在.*你.*车.*来。","立在.*你.*车.*来。","斜靠在.*你.*车.*来。","倚在.*你.*车.*来。","站立在.*你.*车.*来。","站在.*你.*车.*来。","坐在.*你.*车.*来。","你.*车.*而来。","你.*车.*驶来。","你.*车.*驶过来。",
		"岸边一只渡船上的老艄公说道：正等着你呢，上来吧。","岸边一只渡船上的船夫说道：正等着你呢，上来吧。","一条渔船应声慢慢驶了过来","一叶扁舟缓缓地驶了过来",
		".{4,8}说“到啦，上岸吧”，随即把一块踏脚板搭上堤岸。","船夫扳桨划船，在湖中行了数里，缓缓停泊在岸边，将一块踏脚板搭上了堤岸。",
		"你身上没有 guoheenter 这样食物。",
		"你身上没有 guoheout 这样食物。",
		"可是你却找不到主人，把你急得直冒汗","你到了此处却见不到主人，于是大声说道：「请问有人吗？」",
		--".{4,8}上前对着你抱拳道：「.+」\n.+道：「.+能.+的.+",
		"你上前对着(.+)抱拳道：「这位.+现将镖货原物奉上",
		"接着你把骡子和镖车重新拴好准备回去了。",
		"你松了一口气说道：「终于回到了镖局！」",
		".+急急忙忙走了过来",
		".+急急忙忙离开了",
		".+脚下一个不稳，跌在地上昏了过去。",
		".+倒在地上，挣扎了几下就死了。",
		--".{4,8}喝道：「.+」\n看起来.+想杀死你！",
		--"你驾着镖车扬了扬鞭子，高声驱赶骡子朝.+驶去。\n(.+)：.+！",
		".+受到.+佛法感招，决定罢手不斗。",
		"\\s+\\S+\[ \]*\\S+\\(\\w+ \\w+\\)",
		"\\s+\\S+\[ \]*\\S+\\(\\w+\\)",
		}
	local  michen_yb_start_triggerlist={
	       {name="michen_yb_start_dosth1",regexp=linktri(_tb),script=function(n,l,w)    michen_yb_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(michen_yb_start_triggerlist) do
		addtri(v.name,v.regexp,"michen_yb_start",v.script,v.line)
	end
	_tb2={
		"你驾着镖车扬了扬鞭子，高声驱赶骡子朝.+驶去。\\n(.+)：.+！\\Z",
		"(.+)上前对着你抱拳道：「.+」\\n.+道：「.+能.+的.+[处|手上]",
		"(.+)喝道：「.+」\\n看起来.+想杀死你！",
	}
	local  michen_yb_start_m_triggerlist={
	       {name="michen_yb_start_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    michen_yb_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(michen_yb_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"michen_yb_start",v.script,v.line)
	end
	closeclass("michen_yb_start")
	
	AddTimer("michen_yb_start_timer", 0, 0, 1.0, "", timer_flag.Enabled + timer_flag.Replace, "michen_yb_start.timer")
	SetTimerOption("michen_yb_start_timer", "group", "michen_yb_start_t")
	closeclass("michen_yb_start_t")
	------------------------------------------------------------------
	_tb={
	"周围没人能帮你去了解别人的消息",
	"只有乞丐才能打探别人的技能",
	"你只是个不入流的小乞丐",
	"骡子突然发疯似的拉着镖车就跑，把你一屁股甩在地上",
	"你抬头看了看天空，估算着日子，突然发觉时限已到",
	"你受伤过重",
	"你已经受伤过重",
	"你已经陷入半昏迷状态",
	"你受了相当重的伤",
	"你伤重之下已经难以支撑",
	}
	local  michen_yb_watch_triggerlist={
	       {name="michen_yb_watch_dosth1",regexp=linktri(_tb),script=function(n,l,w)    michen_yb_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(michen_yb_watch_triggerlist) do
		addtri(v.name,v.regexp,"michen_yb_watch",v.script,v.line)
	end
	closeclass("michen_yb_watch")
end
michen_yb.update()