zzxlroom="333|644|628|932|824|826|819|829|1384"  --用来修炼的房间
function setzhizhu()
	if skillslist["qianzhu-wandu"]==nil then skillslist["qianzhu-wandu"]={} end
	if skillslist["qianzhu-wandu"]["lvl"]==nil then skillslist["qianzhu-wandu"]["lvl"]=0 end
	if skillslist["zhaixinggong"]==nil then skillslist["zhaixinggong"]={} end
	if skillslist["zhaixinggong"]["lvl"]==nil then skillslist["zhaixinggong"]["lvl"]=0 end
	if skillslist["qianzhu-wandu"]["lvl"]<80 then zhizhulist="1349|1427|1440|1324|1325|1367|2051|45|1519"
	elseif skillslist["qianzhu-wandu"]["lvl"]<150 then
		if skillslist["zhaixinggong"]["lvl"]>100 then
			zhizhulist="896|1431|1153|1349|1427|1324|1325|1440|1367|2051|45|1519"
		else
			zhizhulist="896|1153|1349|1427|1324|1325|1440|1367|2051|45|1519"
		end
	else
		if skillslist["zhaixinggong"]["lvl"]>100 then
			zhizhulist="1787|896|1431|1153|1349|1427|1324|1325|1440|1367|2051|45|1519"
		else
			zhizhulist="1787|896|1153|1349|1427|1324|1325|1440|1367|2051|45|1519"
		end
	end
	print("qzwd技能等级: "..skillslist["qianzhu-wandu"]["lvl"].." 蜘蛛id: "..zhizhulist)
end
------------------------------------------------------------------------------------
-- qzwd_pre
------------------------------------------------------------------------------------
function qzwd_pre.doit()
	alias.resetidle()
	_tb=Split(zzxlroom,"|")
	if always.where=="迷宫洞口" then 
		run("se;nu;ed;ed;jump valley")
	elseif always.where=="井中" then 
		run("u;break men;n;n") 
	end
	if roomno_now==1787 or findstrlist2(roomno_now,_tb) then
		if roomno_now==1787 then
			wait.make(function()
				_f=function()
					print("等待了3秒，防止进入羊肠小路")
				end
				wait.time(3);_f()
			end)			
		end
		setzhizhu()
		openclass("qzwd_start")
		if me.menpai=="wd" and jifa.forcename=="taiji-shengong" then run("yun yinyun")
		elseif jifa.forcename=="xiantian-gong" and skillslist["xiantian-gong"]["lvl"]>99 then run("yun bidu")
		elseif jifa.forcename=="hamagong" and skillslist["hamagong"]["lvl"]>99 then run("yun qudu") 
		else run("xiulian") 
		end			
	else 
		alias.flytoid(_tb[math.random(#_tb)]) --随机挑一个房间修炼千蛛万毒手
	end
end
function qzwd_pre.dosomething1(n,l,w)
	local _f,_tb,a,b,c
	wait.make(function()
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		qzwd_pre.doit()
	elseif findstring(l,"你用锦盒盖子轻轻地把.*蛛拨进盒子。") then
		qzwd.havezhu=1
		if roomno_now==896 or roomno_now==1431 then --华山秘洞和天山迷宫入口，杀了蜈蚣和蝎子再走
			run("kill wu gong;kill scorpion")
			alias.checkbusy("doit")
		else
			qzwd_pre.doit()
		end
	elseif findstring(l,"这里不能练习。") then
		alias.startqzwd()
	elseif findstring(l,"你并未中毒。","你所学的内功中没有这种功能。") then
		run("xiulian")
	elseif findstring(l,"你得找些毒蜘蛛来才能练千蛛万毒手。") then
		alias.resetidle()
		--alias.ch()
		qzwd.havezhu=0
		if qzwd.needquit==1 then
		qzwd.needquit=0
		run("h;quit")
		else
		run("set qzwd=start")
		end
	elseif findstring(l,"你要抓什么？") then
		alias.resetidle()
		run("unwield jian;kill wu gong;kill scorpion")
		zhizhunum=zhizhunum+1
		if roomno_now==1787 then
			wait.make(function()
				_f=function()
					print("等待了3秒，防止进入羊肠小路")
					alias.checkbusy("nextspider")
				end
				wait.time(3);_f()
			end)			
		else		
			alias.checkbusy("nextspider")
		end
	elseif findstring(l,"很明显, .*蛛现在没法干这") then
		alias.resetidle()
		qzwd.havezhu=0
		_f=function() run("xiulian") end
		wait.time(2);_f()
	elseif findstring(l,"请输入正确的房间") then
		alias.resetidle()
		print("没蜘蛛了")
		run("shout")
		alias.close_gps()
		alias.startxue()
	elseif findstring(l,"目标地点路径未通","那麽小的洞你专得进去吗") then run("u;u;break men;n;n") 
	elseif findstring(l,"房间定位出错，存在重名或未知房间") then run("h;wield jian;strike wall;out") 
	elseif findstring(l,"慢慢地一阵眩晕感传来，你终于又有了知觉....") then roomno_now=0 
	elseif findstring(l,"良久，你突然有一股破","你随即抽出剑来") then pobi=1 
	end
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil then
		alias.resetidle()
		if tonumber(c)==1431 then 
			run("jump valley")
			alias.checkbusy("valley")
		else
			if tonumber(c)==45 then 
				run("break men;s;d;zhua zhizhu") 
			elseif tonumber(c)==896 then
				pobi=0
				checkpobi=0
				run("set checkpobi")
			elseif findstring(c,"1427","1787","1519","1153","1324","1325","1349","1367","1440","2051") then
				run("move qi;move stone;zhua zhizhu")
			elseif findstring(c,"333","644","628","932","824","826","819","829","1384") then
				alias.dz(set_neili)
			end
		end
	end
	a,b,c=string.find(l,"你目前还没有任何为 (.+) 的变量设定。")
	if c~=nil then
		alias.resetidle()
		if findstring(c,"checkbusy=qzwd") then
			alias.dz1()
		elseif findstring(c,"busyover=qzwd") then
			alias.dz(set_neili)
		elseif findstring(c,"qzwd=start") then
			setzhizhu()
			zhizhunum=1
			_tb=Split(zhizhulist,"|")
			alias.flytoid(tonumber(_tb[zhizhunum]))
		elseif findstring(c,"checkpobi") then
			if pobi>0 then
				run("h;wield jian;strike wall;enter;zhua zhizhu")
				--;strike wall;out;unwield jian
				pobi=0
				checkpobi=0
			else
				for i=1,10,1 do run("mianbi") end
				checkpobi=checkpobi+1
				if checkpobi>4 then
				pobi=1
				end
				run("set checkpobi")
			end
		elseif findstring(c,"busyover=nextspider") then
			if always.where=="迷宫洞口" then 
				run("se;nu;ed;ed;jump valley")
			elseif always.where=="井中" then 
				run("u;break men;n;n") 
			end
			_tb=Split(zhizhulist,"|")
			--if zhizhunum>#_tb then zhizhunum=1 end
			if zhizhunum>#_tb then 
				alias.close_qzwd()  --抓一圈蜘蛛，没有就进入打坐增加内力模式
				if tonumber(hp.neili/hp.maxneili*100)<set_neili then
					alias.dz()
				else
					alias.startqzwd()
				end
			else
				alias.flytoid(_tb[zhizhunum])
			end
		elseif not isopen("boat") and findstring(c,"dazuo=over") then
			alias.resetidle()
			if havefj>0 then alias.startworkflow() else alias.startqzwd() end
		elseif findstring(c,"busyover=valley") then 
			run("wu;wu;sd;nw;zhua zhizhu")
		elseif findstring(c,"busyover=doit") then 
			qzwd_pre.doit()
		end
	end
	end)
end

------------------------------------------------------------------------------------
-- qzwd_start
------------------------------------------------------------------------------------
function qzwd_start.dosomething1(n,l,w)
	if findstring(l,"你运功完毕， 长长的吐了口气。","你的内力太低") then
		alias.resetidle()
		run("hp")
		alias.checkbusy("qzwd")
	end
end
------------------------------------------------------------------------------------
-- qzwd_watch
------------------------------------------------------------------------------------
function qzwd_watch.dosomething1(n,l,w)
	if findstring(l,"毒蛛丝无法用来练千蛛万毒手。") then
		alias.resetidle()
		qzwd.havezhu=0
		run("get all from jin he;drop zhusi;xiulian")
	end
	if findstring(l,"你觉得体内的千蛛毒气翻腾不止，你脸上浮肿又加重了。") then
		alias.resetidle()
		run("say 变丑了需要quit")
		qzwd.needquit=1
	end
	if findstring(l,"蛛吸取你手指上的血液为食，但你手指上血脉运转，也带了.*蛛体内毒液，回入自己血中。","盒中的.*蛛慢慢爬近，分别咬住了你两根指头。","你从怀里取出锦盒，打开盒盖，将双手两根食指伸进盒中。","你满脸庄严肃穆之容，眉心和太阳穴上淡淡的罩上了一层黑气，咬紧牙关，竭力忍受痛楚。","你深深吸一口气，双臂轻微颤抖，潜运内功和蛛毒相抗。","你又运功良久，脸上黑气渐退，重现血色。","你这功夫练了几有半个时辰，.*蛛直到吸饱了血，肚子胀得和圆球相似，这才跌在盒中，沉沉睡去。","再过一会，又见你鼻尖上渗出细细的一粒粒汗珠。") then
		alias.resetidle()
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function qzwd.update()
	local _tb
	_tb={
	"你用锦盒盖子轻轻地把.*蛛拨进盒子。",
	"这里不能练习。",
	"你并未中毒。",
	"你所学的内功中没有这种功能。",
	"你目前还没有任何为 .+ 的变量设定。",
	"数码世界，数字地图，.+就是这里！",
	"你得找些毒蜘蛛来才能练千蛛万毒手。",
	"你要抓什么？",
	"很明显, .+蛛现在没法干这",
	"请输入正确的房间",
	"目标地点路径未通","那麽小的洞你专得进去吗",
	"房间定位出错，存在重名或未知房间",
	"慢慢地一阵眩晕感传来，你终于又有了知觉.+",
	"良久，你突然有一股破",
	"你随即抽出剑来",
	}
	local  qzwd_pre_triggerlist={
	       {name="qzwd_pre_dosth1",regexp=linktri(_tb),script=function(n,l,w)    qzwd_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(qzwd_pre_triggerlist) do
		addtri(v.name,v.regexp,"qzwd_pre",v.script,v.line)
	end
	closeclass("qzwd_pre")
	
	_tb={
	"你运功完毕， 长长的吐了口气。",
	"你的内力太低",
	}
	local  qzwd_start_triggerlist={
	       {name="qzwd_start_dosth1",regexp=linktri(_tb),script=function(n,l,w)    qzwd_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(qzwd_start_triggerlist) do
		addtri(v.name,v.regexp,"qzwd_start",v.script,v.line)
	end
	closeclass("qzwd_start")
	
	_tb={
	"毒蛛丝无法用来练千蛛万毒手。",
	"蛛吸取你手指上的血液为食，但你手指上血脉运转，也带了.*蛛体内毒液，回入自己血中。",
	"盒中的.*蛛慢慢爬近，分别咬住了你两根指头。",
	"你从怀里取出锦盒，打开盒盖，将双手两根食指伸进盒中。",
	"你满脸庄严肃穆之容，眉心和太阳穴上淡淡的罩上了一层黑气，咬紧牙关，竭力忍受痛楚。",
	"你深深吸一口气，双臂轻微颤抖，潜运内功和蛛毒相抗。",
	"你又运功良久，脸上黑气渐退，重现血色。",
	"你这功夫练了几有半个时辰，.*蛛直到吸饱了血，肚子胀得和圆球相似，这才跌在盒中，沉沉睡去。",
	"再过一会，又见你鼻尖上渗出细细的一粒粒汗珠。",
	"你觉得体内的千蛛毒气翻腾不止，你脸上浮肿又加重了。",
	}
	local  qzwd_watch_triggerlist={
	       {name="qzwd_watch_dosth1",regexp=linktri(_tb),script=function(n,l,w)    qzwd_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(qzwd_watch_triggerlist) do
		addtri(v.name,v.regexp,"qzwd_watch",v.script,v.line)
	end
	closeclass("qzwd_watch")
end
qzwd.update()
