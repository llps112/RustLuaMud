function alias.ceilneili()
	--[[ 关闭过期检测
	if not yun_is_ok then
		ColourNote("red","blue","重要警告信息！！！！！！！！！")
		ColourNote("red","blue","============================")
		ColourNote("red","blue","你目前使用的版本已经过期！！！")
		ColourNote("red","blue","如果需要继续使用！！！！！！！")
		ColourNote("red","blue","请联系Michen！！！！！！！！！")
		ColourNote("red","blue","============================")
		run=""
	end
	if yun_check then return end
	wait.make(function()
		Execute("time")
		local l,w=wait.regexp('^\\s+北京时间 \\->(\\S+)\\s+(\\S+)\\s+\\d+:\\d+$')
		if l==nil then
			return
		end
		local a,b,c,d,e,f=string.find(l,"%s+北京时间 %->(%S+)%s+(.-)年(.-)月(.-)日%s+%d+:%d+")
		if d~=nil and e~=nil and f~=nil then
			yun_check=true
			d=string.gsub(d,"零","0")
			d=string.gsub(d,"一","1")
			d=string.gsub(d,"二","2")
			d=string.gsub(d,"三","3")
			d=string.gsub(d,"四","4")
			d=string.gsub(d,"五","5")
			d=string.gsub(d,"六","6")
			d=string.gsub(d,"七","7")
			d=string.gsub(d,"八","8")
			d=string.gsub(d,"九","9")
			d=tonumber(d)
			if d>=2016 then
				yun_is_ok=false
			end
		end
	end)
	]]
end
------------------------------------------------------------------------------------
-- xkxGPS
------------------------------------------------------------------------------------

conn=nil
dbfile="xkxMAP.db"
room={
	name=nil,
	desc=nil,
	exits=nil,
}
function xkxGPS.setRoomname(w)
	xkxGPS["roomname"]=Trim(w) --去除两端空格
end
function xkxGPS.setDesc(w)
	xkxGPS["desc"]=Trim(w) --去除两端空格
end
function xkxGPS.setEntrance(w)
	local exits=nil
	exits = (string.gsub(w, " 和 ", "、"))
	exits = strexplit(exits, "、")
	if #exits>0 and exits[1]~="none" then
		always.exit=exits[1]
		--print("always.exit:"..always.exit)
	end
	xkxGPS["entrance1"]=exits
	table.sort(xkxGPS["entrance1"]) 
	xkxGPS["entrance"]=table.concat(xkxGPS["entrance1"], "|")
end
function xkxGPS.setEntranceCondition(w)
	xkxGPS.EntranceCondition=w
end
function xkxGPS.connectDB()
	--DatabaseClose(dbfile)
	if conn==nil then
		conn=assert(sqlite3.open(dbfile))
	end
	 
end
function DB_Import()	--房间信息导入到table直接调用，避免频繁调用数据库，在michen_xkx.lua中自动调用。
	xkxGPS.connectDB()
	local sql="SELECT * FROM Room"
	for row in conn:nrows(sql) do
		--tprint(row)
		table.insert(Room_table,row)
	end
	table.sort(Room_table,function(a,b) return a["RoomNO"]<b["RoomNO"] end)	--用房间编号排序
	local sql="SELECT * FROM Entrance"
	local _tb={}
	for row in conn:nrows(sql) do
		if row["RoomNo"]==nil then row["RoomNo"]="" end
		if row["Direction"]==nil then row["Direction"]="" end
		if row["ID"]==nil then row["ID"]="" end
		if row["LinkRoomNo"]==nil then row["LinkRoomNo"]="" end
		if row["Condition"]==nil then row["Condition"]="" end
		table.insert(_tb,row)
	end
	table.sort(_tb,function(a,b) return a["RoomNo"]<b["RoomNo"] end )	--用房间编号排序
	--print(table_getn(_tb),_tb[table_getn(_tb)]["RoomNo"])
	for i=1,_tb[table_getn(_tb)]["RoomNo"],1 do 
		Entrance_table[i]={}
	end
	for k,v in ipairs(_tb) do 
		table.insert(Entrance_table[v["RoomNo"]],{v["Direction"],v["ID"],v["LinkRoomNo"],v["Condition"]})
	end
	if table_getn(Room_table)>0 and table_getn(Entrance_table)>0 then
		print("房间信息["..table_getn(Room_table).."]条数据导入成功")
		print("房间连接情况["..table_getn(Entrance_table).."]条数据导入成功")
	else
		print("请注意数据库导入失败，脚本无法正常运行")
		if table_getn(Room_table)==0 then DB_Import() end
	end
end
all_fx_list={"eu","e","ed","se","su","s","sd","sw","wu","w","wd","nw","nu","n","nd","ne","enter","out","u","d","1","2","3","4","5","6","7","8",}
function xkxGPS.pathlist(path)
	local _tb
	local row=0
	xkxGPS.pathArray1={}
	local indexQueue={}
	local col=0

	if path==nil then path="" end
	_tb=Split(path,";")
	xkxGPS.pathListNum2=#_tb

	for k,v in ipairs(_tb) do
		if xkxGPS.pathArray1[row]==nil then xkxGPS.pathArray1[row]="" end
		xkxGPS.pathArray1[row]=xkxGPS.pathArray1[row]..v..";"
		if not findstrlist2(v,all_fx_list) then
			table.insert(indexQueue,row)
			row=row+1
			xkxGPS.pathArray1[row]=""
			col=0
		end
		if col<20 or col+(21*row)==xkxGPS.pathListNum2 then col=col+1
		else
			row=row+1
			xkxGPS.pathArray1[row]=""
			col=0
		end
	end
	local Index=-1
	if #indexQueue>0 then Index=table.remove(indexQueue,1) end
	local i=0
	while i<=#xkxGPS.pathArray1 do
		if i==Index then
			if #indexQueue>0 then Index=table.remove(indexQueue,1) end
			xkxGPS.pathArray1[i]=string.sub(xkxGPS.pathArray1[i],1,-2)
		elseif i==#xkxGPS.pathArray1 then
			xkxGPS.pathArray1[i]=xkxGPS.pathArray1[i].."set walk over"
		else
			xkxGPS.pathArray1[i]=xkxGPS.pathArray1[i].."set walk off"
		end
		i=i+1
	end
	-- print("完整路径为："..path)
	-- print("切割后的路径为：")
	-- tprint(xkxGPS.pathArray1)
end
function xkxGPS.pathArray2(idx)
	return xkxGPS.pathArray1[idx]
end
function xkxGPS.findSafeExit(id)
	xkxGPS.connectDB()
	if tonumber(id)~=nil and tonumber(id)>0 then
		for k,v in ipairs(Room_table) do 
			if tonumber(v["RoomNO"])==tonumber(id) then 
				--tonumber(id)~=nil and tonumber(id)>0 and 
				--print(v["RoomNO"])
				if v["EntranceSafe"]~=nil then return v["EntranceSafe"] else return v["Entrance"] end
			end
		end
	end
	return ""
end
function xkxGPS.location()	--用房间描述查询当前房间，如果查到多个结果，返回一个表单
	xkxGPS.connectDB()
	table_roomno={}
	for k,v in ipairs(Room_table) do 
		if v["roomname"]==xkxGPS["roomname"] and v["desciption"]==xkxGPS["desc"] and v["Entrance"]==xkxGPS["entrance"] then
			table.insert(table_roomno,v["RoomNO"])
		end
	end
	if #table_roomno==1 then
		return table_roomno[1]
	elseif #table_roomno>1 then
		return table_roomno
	end
	for k,v in ipairs(Room_table) do 
		if v["roomname"]==xkxGPS["roomname"] and v["desciption"]==xkxGPS["desc"] then --定位失败，去掉出口信息重新定位。防止古墓开房无法定位
			table.insert(table_roomno,v["RoomNO"])
		end
	end
	if #table_roomno==1 then
		return table_roomno[1]
	else
		return table_roomno
	end
end
function xkxGPS.findroomarea(a,b,c)--flytoname,flytozone,flytoareanum
	str_link,startid=trversal(a,b,c)
	return str_link,startid
end
-- 传入整个的TABLE，传入一个起始ROOMID，传入起始层，返回一个TABLE，里面有完整的行走路线，和没处理完的要过河的ROOMID，以及在哪个层
function xkxGPS._tmp_findroomarea(room_list,roomid,level,PastRoom)
	xkxGPS.connectDB()
	local str=""
	local roomno=roomid
	local ret={
		str="",
		id=0,
		upid=0,
		endid=0,
		level=nil,
		pastroom=PastRoom,
	}
	for i=level,0,-1 do
		if room_list[i][roomno]["Direction"]=="over" then
			if str~="" then
				str=str.."#over"
			end
			if PastRoom[roomno]==nil then PastRoom[roomno]=roomno end
			ret.pastroom=PastRoom
			ret.str=str
			ret.endid=tonumber(roomno)
			return ret
		elseif room_list[i][roomno]["Direction"]=="guohe" then
			if str~="" then
				str=str.."#over"
			end
			if PastRoom[roomno]==nil then PastRoom[roomno]=roomno end
			ret.pastroom=PastRoom
			ret.str=str
			ret.upid=tonumber(room_list[i][roomno]["FatherRoom"])
			ret.id=tonumber(roomno)
			ret.endid=tonumber(roomno)
			ret.level=i-1
			return ret
		else
			if str=="" then
				str=tostring(room_list[i][roomno]["FatherRoom"]).."#"..tostring(room_list[i][roomno]["Direction"]..">"..tostring(roomno))
			else
				str=tostring(room_list[i][roomno]["FatherRoom"]).."#"..tostring(room_list[i][roomno]["Direction"]..">"..str)
			end
			--print(str)
			if PastRoom[roomno]==nil then PastRoom[roomno]=roomno end
			ret.pastroom=PastRoom
			roomno=room_list[i][roomno]["FatherRoom"]
		end
	end
	ret.str=str
	return ret
end
--1049#nw>1048#over|1049#nw>1048#over|1049#s>1050#s>1051#s>1052#se>1053#over|1049#guohe>1526#e>1531#guohe>1708#n>1709#over|1049#guohe>1526#n>1525#n>1524#n>1523#over|1049#guohe>1526#w>1527#nu>1529#slsl-slsl>1530#over|1049#guohe>1526#w>1527#sw>1528#over

function xkxGPS.findroomarea_old_bak(a,b,c)	--无调用的函数名，原名 xkxGPS.findroomarea_old(a,b,c) 更名试用一段时间，没问题就删除
	alias.ceilneili()
	xkxGPS.connectDB()
	local roomno1={}
	local roomno2={}
	local level_roomNo={}
	local sql="SELECT distinct RoomNO,ZoneNO FROM Room WHERE roomname='"..a.."'"
	for row in conn:nrows(sql) do
		local cell={Direction="over",FatherRoom=0,}
		if b=="none" or (b~="none" and findstring(row["ZoneNO"],b)) then
			if roomno1[row["RoomNO"]]==nil then roomno1[row["RoomNO"]]={} end
			roomno1[row["RoomNO"]]=cell
		end
		if findstring(row["ZoneNO"],b) then
			if roomno2[row["RoomNO"]]==nil then roomno2[row["RoomNO"]]={} end
			roomno2[row["RoomNO"]]=cell
		end
	end
	if #roomno2>0 then level_roomNo[0]=roomno2 else level_roomNo[0]=roomno1 end
	local i=1
	local _Vb_t_i4_0=tonumber(c)-1
	local levelEnumerator={}
	local PastRoomNo={}
	while i<=_Vb_t_i4_0 do
		level_roomNo[i]={}
		levelEnumerator=level_roomNo[i-1]
		for j,v in pairs(levelEnumerator) do
			sql="SELECT distinct a.LinkRoomNo,a.Direction FROM Entrance AS a,Room AS b,Room AS c WHERE a.RoomNo=b.RoomNO AND a.LinkRoomNo=c.RoomNO AND b.FTBSearch=1 AND c.FTBSearch=1 AND "..xkxGPS.EntranceCondition.." AND a.RoomNo="..j
			if PastRoomNo[j]==nil then PastRoomNo[j]=j end
			for row in conn:nrows(sql) do
				local LinkRoomno=row["LinkRoomNo"]
				local Direction=row["Direction"]
				if level_roomNo[i][LinkRoomno]==nil and PastRoomNo[LinkRoomno]==nil then
					cell={Direction=Direction,FatherRoom=j,}
					if level_roomNo[i]==nil then level_roomNo[i]={} end
					level_roomNo[i][LinkRoomno]=cell
				end
			end
		end
		i=i+1
	end
	levelEnumerator={}
	local Channel={}
	local Channels={}
	local ChannelsIndex={}
	local j=0
	local n=0
	i=tonumber(c)-1
	--print("level_roomNo===")
	--tprint(level_roomNo)
	while i>=1 do
		--print("  循环i="..i)
		levelEnumerator=level_roomNo[i]
		--print("  levelEnumerator=level_roomNo[i]===")
		--tprint(levelEnumerator)
		for k,v in pairs(levelEnumerator) do
			--print("    循环levelEnumerator,k="..k..",v===")
			--tprint(v)
			local needAdd=true
			local _Vb_t_i4_1=#ChannelsIndex
			j=1
			while j<=_Vb_t_i4_1 do
				--print("      循环j="..j..",_Vb_t_i4_1=".._Vb_t_i4_1)
				--print("      对比ChannelsIndex[j]="..ChannelsIndex[j].."&"..k)
				if ChannelsIndex[j]~=nil and tonumber(ChannelsIndex[j])==tonumber(k) then
					--print("对比成功！")
					needAdd=false
					Channel=Channels[j]
					table.insert(Channel,1,v)
					cell=v
					ChannelsIndex[j]=cell["FatherRoom"]
				end
				j=j+1
			end
			if needAdd then
				local cell1={}
				n=n+1
				cell=v
				ChannelsIndex[n]=cell["FatherRoom"]
				Channel={}
				cell1["Direction"]="over"
				cell1["FatherRoom"]=tonumber(k)
				table.insert(Channel,1,cell1)
				table.insert(Channel,1,v)
				Channels[n]=Channel
			end
		end
		i=i-1
	end
	--tprint(Channels)
	--tprint(ChannelsIndex)
	local channelEnumerator=Channels
	j=0
	local temp=""
	local channels1={}
	local Num_channels1=#Channels-1
	for k,v in pairs(channelEnumerator) do
		Channel=v
		while #Channel>0 do
			cell=table.remove(Channel,1)
			if channels1[j]==nil then channels1[j]="" end
			channels1[j]=channels1[j]..cell.FatherRoom.."#"..cell.Direction..">"
			temp=temp..cell.FatherRoom.."#"..cell.Direction..">"
		end
		temp=string.sub(temp,1,-2)
		channels1[j]=string.sub(channels1[j],1,-2)
		--print(channels1[j])
		--if channels1[j]~=nil then channels1[j]=string.sub(channels1[j],1,-2) else channels1[j]="" end
		j=j+1
		temp=temp.."|"
	end
	if string.len(temp)>1 then
		temp=xkxGPS.findroomAreaList(string.sub(temp,1,-2),c)
		temp=xkxGPS.SortArealist(temp)
		return temp
	else
		return ""
	end
end
function xkxGPS.findroomAreaList(AreaList,range)
	xkxGPS.connectDB()
	local Arr_AreaList=Split(string.gsub(AreaList,"guohe","zzzzguohe"),"|")
	local Arr_AreaList_temp={}
	local Arr_AreaListStep={}
	table.sort(Arr_AreaList)
	local x,y,i
	findroomAreaList=""
	--tprint(Arr_AreaList)
	for y=1,#Arr_AreaList,1 do
		--print(Arr_AreaList[y])
		Arr_AreaList_temp=Split(Arr_AreaList[y],">")
		for x=1,#Arr_AreaList_temp,1 do
			if Arr_AreaListStep[x]==nil then Arr_AreaListStep[x]={} end
			Arr_AreaListStep[x][y]=Arr_AreaList_temp[x]
		end
	end
	--tprint(Arr_AreaListStep)
	for x=1,#Arr_AreaListStep,1 do
		if x>1 and Arr_AreaListStep[x]~=nil and Arr_AreaListStep[x][1]~=nil then findroomAreaList=findroomAreaList..">" end
		if Arr_AreaListStep[x]~=nil and Arr_AreaListStep[x][1]~=nil then findroomAreaList=findroomAreaList..Arr_AreaListStep[x][1] end
	end
	for y=1,#Arr_AreaList,1 do
		findroomAreaList=findroomAreaList.."|"
		for x=1,#Arr_AreaListStep,1 do
			if Arr_AreaListStep[x]~=nil and Arr_AreaListStep[x][y]~=nil and (Arr_AreaListStep[x][y-1]~=nil or Arr_AreaListStep[x][y]~=Arr_AreaListStep[x][y-1]) then
				for i=x,#Arr_AreaListStep,1 do
					if Arr_AreaListStep[i]~=nil and Arr_AreaListStep[i][y]~=nil then findroomAreaList=findroomAreaList..">" end
					if Arr_AreaListStep[i]~=nil and Arr_AreaListStep[i][y]~=nil then findroomAreaList=findroomAreaList..Arr_AreaListStep[i][y] end
				end
				break
			end
		end
	end
	findroomAreaList=string.gsub(string.gsub(findroomAreaList,"zzzzguohe","guohe"),"|>","|")
	--print(findroomAreaList)
	return findroomAreaList
end
function xkxGPS.SortArealist(a)
	xkxGPS.connectDB()
	if a==nil then a="" end
	local Arr_AreaList=Split(string.gsub(a,"guohe","zzzzguohe"),"|")
	table.sort(Arr_AreaList)
	local SortArealist=""
	for i=1,#Arr_AreaList,1 do
		if i>1 then SortArealist=SortArealist.."|" end
		SortArealist=SortArealist..Arr_AreaList[i]
	end
	Arr_AreaList=string.gsub(SortArealist,"zzzzguohe","guohe")
	return Arr_AreaList
end
function xkxGPS.findroomno(a,b)
	alias.ceilneili()
	xkxGPS.connectDB()
	local _tb={}
	local str2=""
	for k,v in ipairs(Room_table) do 
		if v["roomname"]==a and _tb[v["RoomNO"]]==nil then
			if b=="none" or (b~="none" and findstring(v["ZoneNO"],b)) then 
				_tb[v["RoomNO"]]=1
				if str2=="" then str2=v["RoomNO"] else str2=str2.."|"..v["RoomNO"] end
			end
		end
	end
	return str2
end
function xkxGPS.jhfx(a)
	if a==nil then return ""
	elseif a=="eu" or a=="eastup" then alias.fzfx="wd" return "eu"
	elseif a=="e" or a=="east" then alias.fzfx="w" return "e"
	elseif a=="ed" or a=="eastdown" then alias.fzfx="wu" return "ed"
	elseif a=="se" or a=="southeast" then alias.fzfx="nw" return "se"
	elseif a=="su" or a=="southup" then alias.fzfx="nd" return "su"
	elseif a=="s" or a=="south" then alias.fzfx="n" return "s"
	elseif a=="sd" or a=="southdown" then alias.fzfx="nu" return "sd"
	elseif a=="sw" or a=="southwest" then alias.fzfx="ne" return "sw"
	elseif a=="wu" or a=="westup" then alias.fzfx="ed" return "wu"
	elseif a=="w" or a=="west" then alias.fzfx="e" return "w"
	elseif a=="wd" or a=="westdown" then alias.fzfx="eu" return "wd"
	elseif a=="nw" or a=="northwest" then alias.fzfx="se" return "nw"
	elseif a=="nu" or a=="northup" then alias.fzfx="sd" return "nu"
	elseif a=="n" or a=="north" then alias.fzfx="s" return "n"
	elseif a=="nd" or a=="northdown" then alias.fzfx="su" return "nd"
	elseif a=="ne" or a=="northeast" then alias.fzfx="sw" return "ne"
	elseif a=="d" or a=="down" then alias.fzfx="u" return "d"
	elseif a=="u" or a=="up" then alias.fzfx="d" return "u"
	else return a end
end
function xkxGPS.getnextroomno(a,b)
	alias.ceilneili()
	xkxGPS.connectDB()
	local str2=0
	b=tostring(b)
	b=xkxGPS.jhfx(b)
	if tonumber(a)~=nil and tonumber(a)>0 and b~=nil then
		for k,v in ipairs(Entrance_table[a]) do 
			if v[1]==b then 
				str2=tonumber(v[3])
			end
		end
	end
	return str2
end
function xkxGPS.findroomnpc(a,b)
	alias.ceilneili()
	xkxGPS.connectDB()
	local str2=""
	for k,v in ipairs(Room_table) do 
		if v["famousnpc"]~=nil and v["famousnpc"]~="" then
			if b=="none" or (b~="none" and findstring(v["ZoneNO"],b)) then
			if string.find(v["famousnpc"],a) then
				if str2=="" then str2=v["RoomNO"] else str2=str2.."|"..v["RoomNO"] end
			end
		end
		end
	end
	return str2
end
function xkxGPS.EndRoomInfo(EndRoomNo)
	alias.ceilneili()
	xkxGPS.connectDB()
	local links={}
	-----------------
	xkxGPS.EndRoomName=""
	for k,v in ipairs(Room_table) do 
		if v["RoomNO"]==EndRoomNo then
			xkxGPS.EndRoomName=v["roomname"]
			xkxGPS.EndRoomEntrance="#"..v["Entrance"].."#"
			return
		end
	end
end
-- 广度优先算法寻路
function xkxGPS.search(startid, endid)
	alias.ceilneili()
	xkxGPS.connectDB()
	if startid==endid then
		return "isHere"
	end
	local searchedRoom={}			-- 存放已经搜索过的房间ID
	local queue={}						-- 待处理的队列
	local queueT={}
	
	startid=tonumber(startid)
	endid=tonumber(endid)
	xkxGPS.EndRoomInfo(endid)
	
	table.insert(queue, startid)							-- 把初始房间加入到待处理队列中
	queueT[startid]={}
	queueT[startid]["Direction"]="none"
	queueT[startid]["RoomNo"]=0

	while #queue>=1 do												-- 循环待处理房间队列
		local nowid=queue[1]
		table.remove(queue, 1)														-- 从队列取出第一个房间ID,并从队列中删除，并放入已经处理过的队列
		searchedRoom[nowid]=1
		local links=xkxGPS.Forward_Search(nowid)								-- 取得当前房间的所有出口信息
		table.foreachi(links, function(i, link)									-- 循环当前房间的每一个出口
			if searchedRoom[link["LinkRoomNo"]]==nil and queueT[link["LinkRoomNo"]]==nil then	-- 如果目标房间没有被处理过，加到待处理房间队列里
				table.insert(queue, link["LinkRoomNo"])
				queueT[link["LinkRoomNo"]]={}
				queueT[link["LinkRoomNo"]]["Direction"]=link["Direction"]
				queueT[link["LinkRoomNo"]]["RoomNo"]=nowid
			end
		end)
		if queueT[endid]~=nil then
			break
		end
	end
	-- tprint(queueT)
	-- 反向从队列里面找出路径
	nowid=endid
	local path={}
	while nowid~=startid do
		if queueT[nowid]==nil then
			path=nil
			break
		end
		if queueT[nowid]["Direction"]=="none" then
			break
		end
		table.insert(path, 1, queueT[nowid]["Direction"])
		nowid=queueT[nowid]["RoomNo"]
	end
	if path~=nil then path = table.concat(path, ";") end
	return path
end
-- 向前搜索一步
function xkxGPS.Forward_Search(RoomNo)
	xkxGPS.connectDB()
	RoomNo=tonumber(RoomNo)
	local links={}
		--新代码,数据结构如下：
		--table.insert(Entrance_table[row["RoomNo"]],{row["Direction"],row["ID"],row["LinkRoomNo"],row["Condition"]})
	if xkxGPS.EntranceCondition=="condition is null" then	--不钻狗洞
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if v[4]=="" then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='dong') and id<>3247"	then --print("古墓派、大理、武当、少林、桃花、峨眉、华山、星宿、白驼、明教、走路方式")
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='dong') and v[2]~=3247 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='dong' or condition='qz') and id<>3247" then	--全真派钻洞方式
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='dong' or v[4]=='qz') and v[2]~=3247 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='qz')" then --全真派不钻洞方式
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='qz') and v[2]~=3247 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='dong' or condition='xs') and id<>3247" then --雪山派心法高于150
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='dong' or v[4]=='xs') and v[2]~=3247 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='dong') and id<>3247" then --雪山派心法低于150
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='dong') and v[2]~=3247 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='gb' or condition='dong') and id<>3247 and id<>3248" then --丐帮走路方式
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=="gb" or v[4]=='dong') and v[2]~=3247 and v[2]~=3248 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='dong' or condition='feng') and id<>3247" then --风弟子钻洞
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='dong' or v[4]=='feng') and v[2]~=3247 then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	elseif xkxGPS.EntranceCondition=="(condition is null or condition='feng')" then --风弟子不钻洞
		for k,v in ipairs(Entrance_table[RoomNo]) do 
			if (v[4]=="" or v[4]=='feng') then
				table.insert(links, {LinkRoomNo=v[3],Direction=v[1],ID=v[2]})
			end
		end
	else
		print("xkxGPS.Forward_Search 出现特殊情况需要处理情况是["..xkxGPS.EntranceCondition"]")
	end
	
	 --[[老代码备档
	local sql="SELECT LinkRoomNo,Direction,ID FROM Entrance WHERE RoomNo='"..RoomNo.."' and "..xkxGPS.EntranceCondition
	for row in conn:nrows(sql) do
		table.insert(links, row)
	end]]
	return links
end
function xkxGPS.roomwhere()
	local _tb
	xkxGPS.connectDB()
	--重复房间，通过附近房间来确认当前位置
	--tprint(roomno_now)
	if xkxGPS.room_where then
		if xkxGPS.roomcheck>1 then roomno_now=_tb3 end
		if roomno_check==0 then xkxGPS.roomcheck=xkxGPS.roomcheck+1;_tb3=roomno_now;return end
		if type(roomno_check)=="table" then --周围房间仍然重复
			_tb=roomno_check
			--tprint(_tb) 
		elseif type(roomno_check)=="number" then --周围有唯一房间
			--print("查找第"..xkxGPS['roomcheck'].."个房间，方向："..xkxGPS['room_fx'][xkxGPS['roomcheck']].."成功")
			_tb={roomno_check,}
		else --周围房间无法定位
			_tb={} 
		end
		if type(roomno_now)=="table" then 
			_tb2=roomno_now 
		else 
			_tb2={} 
		end
		_tb3={}
		local _t
		for k,v in pairs(_tb2) do
			--print(k)
			for m,n in pairs(_tb) do 
				--print("fzfx"..alias.fzfx)
				if n==(xkxGPS.getnextroomno(v,xkxGPS.jhfx(xkxGPS.room_fx[xkxGPS.roomcheck]))) then 
					_tb3_checkerr=0
					if tonumber(_tb3[1])~=nil then
						for a,b in pairs(_tb3) do
						if v==b then _tb3_checkerr=1;break end
						end
						if _tb3_checkerr==0 then table.insert(_tb3,v) end
					else
						table.insert(_tb3,v)
						
					end
				end
			end
		end
		--print("检查房间"..xkxGPS.roomcheck)
		xkxGPS.roomcheck=xkxGPS.roomcheck+1
		if #_tb3==1 then 
			roomno_now=_tb3[1]
			print("修正后的房间号："..roomno_now)
			xkxGPS.room_where=false
			if roomno_now<2078 and roomno_now>2062 and me.menpai~="gm" then --非古墓派出古墓
				run("w;enter guan;use fire;turn left;d;ed;look;set gps=start")
				return
			end
		-----------------------------------------------------------
			if flytoid~=nil and flytoid>0 then
				path=xkxGPS.search(roomno_now,flytoid)
				gps.End=false
				gps.EndRoomName=xkxGPS.EndRoomName
				gps.EndRoomEntrance=xkxGPS.EndRoomEntrance
				if path==nil or string.len(path)==0 then
					Simulate("目标地点路径未通！flytoid="..tostring(flytoid).."\n")
				--	run("set gps=nopath")
					run("score")
					return
				end
				if path=="isHere" then
					print("飞什么飞，不就在这里么！")
					gps.End=true
					run("set walk over")
					return
				end
				xkxGPS.pathlist(path)
				pathindex=0
				_tb=Split(xkxGPS.pathArray2(pathindex),";")
				_t=string.gsub(_tb[#_tb]," ","")
				MathstepNum.nextLastStepName=string.gsub(_t,"-","")
				if aliasStepNum[MathstepNum.nextLastStepName]==nil then _t=0 else _t=aliasStepNum[MathstepNum.nextLastStepName] end
					run("halt")
					if roomno_now~=91 and roomname~="擂台下" then alias.yjl() end
					run(xkxGPS.pathArray2(pathindex))
			else
				gpserrnum=1
				run("set gps=end")
			end
			return
			------------------------------------------------------------------  
		elseif #_tb3==0 then
			_tb3=roomno_now
		end
		if xkxGPS.roomcheck>#xkxGPS.room_fx then
			run("set gps=err")
			xkxGPS.room_where=false 
		end
	end
end

function xkxGPS.roomno_find(dx,zone) --用房间名和区域名搜索数据库，并返回一个表
	xkxGPS.connectDB()
	local room_No_temp={}
	for k,v in ipairs(Room_table) do 
		if v["roomname"]==dx and v["ZoneNO"]==zone then
			table.insert(room_No_temp, v["RoomNO"])
		end
	end
	--[[ --改用table，老代码备档
	local sql = "SELECT distinct RoomNO FROM Room WHERE roomname='"..dx.."' and ZoneNO='"..zone.."'"
	for row in conn:nrows(sql) do
		table.insert(room_No_temp, row["RoomNO"])
	end]]
	if zone=="华山" and #room_No_temp<1 then room_No_temp=xkxGPS.roomno_find_hsc(dx,"华山村") end	--搜索华山失败，用“华山村”作为区域名搜索
	if zone=="扬州" and #room_No_temp<1 then room_No_temp=xkxGPS.roomno_find_hsc(dx,"扬州郊外") end	--搜索华山失败，用“华山村”作为区域名搜索
	Multi_room_No=room_No_temp
	return room_No_temp
end

function xkxGPS.roomno_find_hsc(dx,zone) --搜索华山失败，用“华山村”作为区域名搜索
	xkxGPS.connectDB()
	local room_No_temp={}
	--local zone="华山村"
	for k,v in ipairs(Room_table) do 
		if v["roomname"]==dx and v["ZoneNO"]==zone then
			table.insert(room_No_temp, v["RoomNO"])
		end
	end
	--[[ --改用table,老代码备档
	local sql = "SELECT distinct RoomNO FROM Room WHERE roomname='"..dx.."' and ZoneNO='"..zone.."'"
	for row in conn:nrows(sql) do
		table.insert(room_No_temp, row["RoomNO"])
	end]]
	Multi_room_No=room_No_temp
	return room_No_temp
end
function xkxGPS.find_zone(a) --a=roomno_now 用房间编号查找对应的区域
	local _f=""
	if a>#Room_table then 
		print("房间编号输入错误，超出数据库范围")
		return _f 
	elseif a==0 then
		print("房间编号为“0”，无法定位所在城市")
		return _f 
	end
	for i=a,#Room_table,1 do 
		if tonumber(Room_table[i]["RoomNO"])==tonumber(a) then
			print("区域查找成功："..Room_table[i]["ZoneNO"])
			_f=Room_table[i]["ZoneNO"]
			return _f
		end
	end
	print("城市区域搜索失败")
	return _f
end
function trversal(dx,zone,DBi) --利用数据库建立深度为"DBi"的深度遍历路径
	--flytoname,flytozone,flytoareanum
	local startid
	xkxGPS.setEntranceCondition("condition is null")
	xkxGPS.connectDB()
	if tonumber(DBi)==nil or tonumber(DBi)<5 then DBi=5 end  --最小搜索步数设置为5步
	local DB=tonumber(0)
		local nowid=xkxGPS.roomno_find(dx,zone)
	--if #xkxGPS.guohe_search>0 then
	--	startid=xkxGPS.guohe_search[1]
	--else
		startid=nowid[1]
	--end
		xkxGPS.guohe_search={}	--用来存储需要过河的房间
	local nowid1={} 
	local breadth={}
	local room_No_temp=startid
	local path,str_link
	if room_No_temp==nil then 
		str_link=""
	else
		str_link=room_No_temp.."#look>"
	end
	local breadth_path=""
	local temp_breadth={}
	temp_breadth[tostring(nowid[1])]=nowid[1]
	while #nowid~=0 and DBi>DB do
		for loop,vv in ipairs(nowid) do
			local links=xkxGPS.Forward_Search(nowid[loop])
			for i,v in ipairs(links) do
				if v["Direction"]==nil then
					print("编号"..v["LinkRoomNo"].."的房间路径为空，请检查")
				elseif v["Direction"]~="guohe" --不找要过河的房间
					and v["Direction"]~="followhudie" --不找蝴蝶谷的房间
					and v["Direction"]~="enterdong" --不找扬州树洞
					and v["Direction"]~="tgk-lsddy" --不找灵蛇岛
					and temp_breadth[tostring(v["LinkRoomNo"])]==nil --数据库里的空房间不找
					and v["Direction"]~="sgysd-sgyyd" --不找华山密洞
					and v["Direction"]~="sgyyd-sgysd" --不找华山密洞
					and v["Direction"]~="zs-thdht" 	--舟山不上桃花岛
					and v["LinkRoomNo"]~=2000 --华山树林不找
					and v["LinkRoomNo"]~=2010 --华山树林不找
					and v["LinkRoomNo"]~=1614 --灵州客店二楼不找
					and v["LinkRoomNo"]~=957 --扬州客店二楼不找
					and v["LinkRoomNo"]~=20 --泉州客店二楼不找
					and v["LinkRoomNo"]~=1258 --西湖天外天二楼不找
					and v["LinkRoomNo"]~=1391 --永登客店二楼不找
					and v["LinkRoomNo"]~=1890 --南阳悦来客栈二楼不找
					and (v["LinkRoomNo"]~=439 or me.menpai~="xs") --雪山派不找度母殿
					and v["LinkRoomNo"]~=938 --袁紫衣不找
					and (v["LinkRoomNo"]~=2060 or me.menpai=="gm") --非古墓派古墓暗河不找
					and (v["LinkRoomNo"]~=401 or not me.sex) --男人不找峨嵋福寿庵斋堂
					and (v["LinkRoomNo"]~=934 or have.bagua>0) --没八卦不进程英房间
					and v["LinkRoomNo"]~=801 --终南山武器库不找
					and v["LinkRoomNo"]~=1220 --天鹰教武器库不找
					and (v["LinkRoomNo"]~=800 or not me.sex) --男人不找终南山女厢房
					and (v["LinkRoomNo"]~=803 or me.sex) --女人不找终南山男厢房
					and (v["LinkRoomNo"]~=1987 or not me.sex) --男人不找华山女弟子休息室
					and (v["LinkRoomNo"]~=1988 or me.sex) --女人不找华山男弟子休息室
					and (v["LinkRoomNo"]~=562 or not me.sex) --男人不找明教女寝室
					and (v["LinkRoomNo"]~=561 or me.sex) --女人不找明教男寝室
					and (v["LinkRoomNo"]~=290 or not me.sex) --男人不找大理女寝室
					and (v["LinkRoomNo"]~=287 or me.sex) --女人不找大理男寝室
					and v["LinkRoomNo"]~=1220 --天鹰教武器库不找
					and v["LinkRoomNo"]~=2055 --周芷若房间不找
					and v["LinkRoomNo"]~=1422 --全真不爬悬崖找不找
					and v["LinkRoomNo"]~=331 --大理迷宫树林不找
					and (v["LinkRoomNo"]~=1245 or not me.sex) --男人不找天鹰教女厢房
					and (v["LinkRoomNo"]~=1246 or me.sex) --女人不找天鹰教男厢房
					and v["LinkRoomNo"]~=1429 --星宿山洞有巨蟒，不找
					and v["LinkRoomNo"]~=1962 --日月神教里面不找，不找
					and v["LinkRoomNo"]~=1299 --扬州田地不找
					and v["LinkRoomNo"]~=1302 --扬州田地不找
					and v["LinkRoomNo"]~=2058 --泰山探海石不跳上去找
					and v["LinkRoomNo"]~=965  --林震南房间不找
					and v["LinkRoomNo"]~=1386 --镇西北房间不找
					then	
					
				--elseif v["Direction"]~="guohe" and temp_breadth[tostring(v["LinkRoomNo"])]==nil then
					--print("剔除房间"..v["Direction"])
					temp_breadth[tostring(v["LinkRoomNo"])]=v["LinkRoomNo"]
					table.insert(breadth,v["LinkRoomNo"])
					table.insert(nowid1,v["LinkRoomNo"])
				else
					local loop_insert=0
					--print(v["LinkRoomNo"])
					for a,b in ipairs(xkxGPS.guohe_search) do
						if v["LinkRoomNo"]==b then 
							loop_insert=1 
							break
						end
					end
					if loop_insert==0 then 
						table.insert(xkxGPS.guohe_search,v["LinkRoomNo"])
					end
				end
			end
		end
		nowid=nowid1
		nowid1={}
		DB= DB+1
	end
	--tprint(breadth)
	while #breadth>0 do
		for i,v in ipairs(breadth) do 
			if room_No_temp==breadth[i] then
			table.remove(breadth,i)
			break
			end
		end
		--print(room_No_temp)
		path,a,str=xkxGPS.search_path(room_No_temp,breadth)
		--print(path,a,str)
		if path~=nil then	--如果待搜索的房间能够到达，就加入路径
			--breadth_path=breadth_path..""..path..";"
			room_No_temp=a
			for i,v in ipairs(breadth) do 
				if a==breadth[i] then
				table.remove(breadth,i)
				break
				end
			end
			if #breadth>0 then str_link=str_link..str..">" else str_link=str_link..room_No_temp.."#over" end
			--print(str_link)
		else   --如果待搜索的房间是不可到达的房间，就删除这个房间
			--print("the path is null"..breadth[1])
			table.remove(breadth,1)
			--if #breadth==0 then str_link=str_link..room_No_temp.."#over" end
			--print("search next"..breadth[1])
		end
	end 
	run("score")
	--print(str_link,startid)
	return str_link,startid
end
function xkxGPS.search_path(startid,endid) -- 计算路径
	xkxGPS.connectDB()
	if type(endid)~="table" then
		local temp_endid={}
		table.insert(temp_endid,tostring( endid))
		endid=temp_endid
	else
		for i,v in ipairs(endid) do 
			endid[i]=tostring(v)
		end
	end
	local startid = tostring(startid)
	local nowid1=""
	local searchedRoom={} -- 存放已经搜索过的房间ID
		for i,v in ipairs(endid) do
			--if startid==endid[i] then
			if startid==v then
				table.insert(searchedRoom,v)
				return "isHere"
			end
		end
	local queue={}						-- 待处理的队列
	local queueT={}
	table.insert(queue, startid)							-- 把初始房间加入到待处理队列中
	queueT[startid]={}
	queueT[startid]["Direction"]="none"
	queueT[startid]["RoomNo"]=0

	while #queue>=1 do												-- 循环待处理房间队列
		local nowid=tostring(queue[1])
		table.remove(queue, 1)
		if searchedRoom[nowid]==nil then														-- 从队列取出第一个房间ID,并从队列中删除，并放入已经处理过的队列
			searchedRoom[nowid]=1
		else
			print("无法确定路线")
			break
		end
		local links=xkxGPS.Forward_Search(nowid)								-- 取得当前房间的所有出口信息	
		for i,link in ipairs(links)	do							-- 循环当前房间的每一个出口
			local pp = tostring(link["LinkRoomNo"])
			if searchedRoom[pp]==nil and queueT[pp]==nil then	-- 如果目标房间没有被处理过，加到待处理房间队列里
				table.insert(queue, pp)
				queueT[pp]={}
				queueT[pp]["Direction"]=link["Direction"]
				queueT[pp]["RoomNo"]=nowid
			end
		end
		for i,v in ipairs(endid) do
			--print()
			if queueT[endid[i]] ~= nil then
				nowid1=tostring(endid[i])
			--	print("跳出循环")
				break
			end
		end
		if nowid1~="" then
			break 
		end
	end
	nowid=nowid1  -- 反向从队列里面找出路径
	local path={}
	local str
	--if nowid=="" then print("目标房间不可达") end
	while nowid~=startid do
		if queueT[nowid]==nil then
			path=nil
			break
		end
		if queueT[nowid]["Direction"]=="none" then
			break
		end
		if queueT[nowid]["Direction"]=="" or queueT[nowid]["Direction"]==nil then
			queueT[nowid]["Direction"]="say"
		end
		table.insert(path, 1, queueT[nowid]["Direction"])
		if str==nil then str=nowid.."#"..queueT[nowid]["Direction"] else str=nowid.."#"..queueT[nowid]["Direction"]..">"..str end
		nowid=queueT[nowid]["RoomNo"]
	end
	if path~=nil then path = table.concat(path, ";") end
	return path,nowid1,str
end
function xkxGPS.Addroom(roomname,desc,entrance,no)
	xkxGPS.connectDB()
	if tonumber(no)=="" or tonumber(no)==nil then
		print("输入的房间编号："..no.." 无效，请使用数字房间编号，用于录入数据库")
		return
	end
	local sql="INSERT INTO Room VALUES('"..desc.."','"..entrance.."','','','"..roomname.."',"..no..",'',0)"
	conn:exec(sql)
	xkxGPS.DelAddroomAlias()
end
function xkxGPS.Linkroom(a,b)
	xkxGPS.connectDB()
	print('使用方法："linkroom 方向 链接的房间"。')
	if a~=nil and a~="" and tonumber(b)~=nil and tonumber(b)>0 then print("格式正确，方向："..a.."链接编号："..b) end
	if a~=nil and a~="" and tonumber(b)~=nil and tonumber(b)>0 and tonumber(roomno_now)~=nil and tonumber(roomno_now)>0 then
		if tonumber(entrance_ID)==nil then 
			print("表单Entrance中ID序列未知，请从数据库确认ID序列，并使用ID number输入ID序列")
			AddAlias("linkroomID","^ID (%d+)","if tonumber('%1')~=nil then entrance_ID='%1' end;xkxGPS.Linkroom('"..a.."',"..b..")",alias_flag.Enabled + alias_flag.Replace + alias_flag.RegularExpression + alias_flag.OneShot ,"")
			SetAliasOption("linkroomID","send_to",12)
			return 
		end
		local sql="INSERT INTO Entrance VALUES('"..a.."',"..entrance_ID..","..b..","..roomno_now..",'')"
		conn:exec(sql)
		print("房间链接关系添加成功")
		entrance_ID=entrance_ID+1
		tprint(xkxGPS.Forward_Search(roomno_now))
	elseif tonumber(roomno_now)~=nil and tonumber(roomno_now)>0 then
		print("当前房间编号："..roomno_now)
		tprint(xkxGPS.Forward_Search(roomno_now))
	else
		print("请先确认当前房间关系")
	end
end
function xkxGPS.DelAddroomAlias()
	DeleteGroup("addroom")
end