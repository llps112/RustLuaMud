-------------------------------
--小号练功模块
--me.sex判断性别 ture男 false女
-------------------------------
function basic_skills.force(n,l,w)
	--local _f
	wait.make(function()
	a,b,c=string.find(l,"数码世界，数字地图，(.+)就是这里！") 
	if tonumber(c)==356 then	--雷洞坪ID
		alias.resetidle()
		run("hp")
		alias.checkbusy("say")
	elseif tonumber(c)==405 then --报国寺禅房
		alias.resetidle()
		run("cha;sleep")
	elseif tonumber(c)==401 then	--女房
		alias.resetidle()
		run("open door;nu;cha;sleep")
	elseif findstring(l,"你目前还没有任何为 busyover=say 的变量设定。") then
		alias.resetidle()
		if hp.neili>=20 then
			if hp.qi<skillslist["force"]["lvl"]*2 then
				run("yun recover;hp;set busyover=say")
			elseif hp.jing<skillslist["force"]["lvl"]*2 then 
				if have.swjing>0 then run("fu shouwu") end
				run("yun regenerate;hp;set busyover=say")
			else
				run("say;hp;set busyover=say")
			end
		elseif (hp.qi>skillslist["force"]["lvl"]*2) and (hp.jing>skillslist["force"]["lvl"]*2) then
			run("say;hp;set busyover=say")
		elseif os.time()-always.sleeptimes>180 then
			if me.menpai=="gb" then
				run("sleep")
			else
				if me.sex then alias.flytoid(405) else alias.flytoid(401) end
			end
		else
			print("睡觉过于频繁，等待20秒自然恢复")
			wait.time(20);run("hp");alias.checkbusy("say")
		end
	elseif findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。") then
		alias.resetidle()
		always.sleeptime=os.time()
		run("open door;sd")
		alias.startxue()
	end
	end)
end
function basic_skills.cuff(n,l,w)	--全真打沙袋
	--local _f
	wait.make(function()
	a,b,c=string.find(l,"数码世界，数字地图，(.+)就是这里！") 
	if tonumber(c)==809 then	--重阳宫打沙袋
		alias.resetidle()
		run("hp")
		alias.checkbusy("da_shadai")
	elseif tonumber(c)==803 or tonumber(c)==800 then --重阳宫睡房
		alias.resetidle()
		run("cha;sleep")
	elseif findstring(l,"你目前还没有任何为 busyover=da_shadai 的变量设定。") then
		if isopen("dazuo") then alias.tdz() end
		if have.swjing>0 and hp.jingli<31 then
			run("fu shouwu")
		elseif have.swjing<1 and hp.jingli<hp.maxjingli/3 and hp.neili>=20 then
			run("yun refresh")
		elseif hp.qi<31 and hp.neili>=20 then
			run("yun recover")
		elseif hp.neili<20 and (hp.jingli<hp.maxjingli/3 or hp.qi<31) then
			if os.time()-always.sleeptimes>180 then
				if me.sex then alias.flytoid(803) else alias.flytoid(800) end
			else
				nextJobGodazuobase=0
				alias.dz(190)
				wait.time(20);run("hp");alias.checkbusy("da_shadai")
			end
			return
		else
			run("da shadai")
		end
		run("hp;set busyover=da_shadai")
	elseif findstring(l,"你打了一会，发现自己没有什么进步，看来该去弄点实战经验了。") then
		alias.startworkflow()
	elseif findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。") then
		alias.resetidle()
		always.sleeptime=os.time()
		alias.startxue()
	end
	end)
end
function basic_skills.strike(n,l,w)  --全真拍木人
	--local _f
	wait.make(function()
	a,b,c=string.find(l,"数码世界，数字地图，(.+)就是这里！") 
	if tonumber(c)==780 then	--重阳宫打木头人
		alias.resetidle()
		run("hp")
		alias.checkbusy("strike_muren")
	elseif tonumber(c)==803 or tonumber(c)==800 then --重阳宫睡房
		alias.resetidle()
		run("cha;sleep")
	elseif findstring(l,"你目前还没有任何为 busyover=strike_muren 的变量设定。") then
		if have.swjing>0 and hp.jingli<31 then
			run("fu shouwu")
		elseif have.swjing<1 and hp.jingli<hp.maxjingli/3 and hp.neili>=20 then
			run("yun refresh")
		elseif hp.qi<31 and hp.neili>=20 then
			run("yun recover")
		elseif hp.neili<20 and (hp.jingli<hp.maxjingli/3 or hp.qi<31) then
			if os.time()-always.sleeptimes>180 then
				if me.sex then alias.flytoid(803) else alias.flytoid(800) end
			else
				print("睡觉过于频繁，等待20秒自然恢复")
				wait.time(20);run("hp");alias.checkbusy("strike_muren")
			end
			return
		else
			run("strike mutouren")
		end
		run("hp;set busyover=strike_muren")
	elseif findstring(l,"你打了一会，发现自己没有什么进步，看来该去弄点实战经验了。") then
		alias.startworkflow()
	elseif findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。") then
		alias.resetidle()
		always.sleeptime=os.time()
		alias.startxue()
	end
	end)
end
function basic_skills.dodge(n,l,w)
	wait.make(function()
	a,b,c=string.find(l,"数码世界，数字地图，(.+)就是这里！") 
	if tonumber(c)==1404 or tonumber(c)==1422 then	--终南山爬悬崖
		alias.resetidle()
		basic_skills.paya=1
		run("hp")
		nextJobGodazuobase=0
		alias.dz(set_neili_global)
		--alias.checkbusy("paya")
	elseif tonumber(c)==803 then --重阳宫男睡房
		alias.resetidle()
		basic_skills.paya=0
		run("cha;sleep")
	elseif basic_skills.paya==0 then
		return
	elseif findstring(l,"你目前还没有任何为 busyover=paya 的变量设定。") then
		alias.resetidle()
		run("hp")
		if hp.neili<hp.maxneili*set_neili_job/100 then
			basic_skills.paya=0
			if jifa.dodge~=nil and jifa.dodge>=135 then
				alias.flytoid(1422)
			else
				alias.flytoid(1404)
			end
		elseif havefj>0 then
			alias.startworkflow()
		elseif skillslist.dodge.lvl>=300 or skillslist.dodge.lvl>=me.maxlvl or have.swjing<1 then
			alias.startworkflow()
		elseif have.swjing>0 and hp.jingli<300 then
			run("fu shouwu;hp")
			alias.checkbusy("paya")
		elseif have.swjing<1 and hp.jingli<hp.maxjingli/4 and hp.neili>=hp.maxneili then
			run("yun refresh")
		elseif hp.neili<hp.maxneili and hp.jingli<hp.maxjing/3 and have.swjing<1 then
			nextJobGodazuobase=0
			alias.dz(set_neili_global)
			return
		else
			run("climb up")
		end
	elseif findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		alias.checkbusy("paya")
	elseif findstring(l,"你爬了上来。","你爬了下来。") then
		alias.checkbusy("paya")
	elseif findstring(l,"四面光溜溜的崖陡如壁，你轻功不够，怎么也爬不上去。","那个方向没法爬。") then
		run("climb down")
	elseif findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。") then
		alias.resetidle()
		basic_skills.paya=0
		always.sleeptime=os.time()
		alias.startxue()
	end
	end)
end
function basic_skills.xtjf(n,l,w)
	wait.make(function()
	if findstring(l,"你目前还没有任何为 busyover=dufeng 的变量设定。") then
		alias.resetidle()
		if 	havefj>0 then
			alias.startfj()
		elseif always.where=="茶花山" then
			if jifa.swordname~="xuantie-jianfa" and needzhongjian()~=nil and needzhongjian()==1 then
				run("jifa sword xuantie-jianfa;jifa")
			end
				run("s;n")
				wait.time(2)
				alias.checkbusy("dufeng")
		end						
	elseif findstring(l,"数码世界，数字地图，234就是这里！") then
		if always.where=="茶花山" then
			run("wield zhongjian")
			alias.checkbusy("dufeng")
		end
	end
	end)
end
function basic_skills.update()
	local _tb
	-------------------------雷洞坪say force
	_tb={
	"数码世界，数字地图，(.+)就是这里！",
	"你目前还没有任何为 busyover=say 的变量设定。",
	"你一觉醒来，只觉精力充沛。该活动一下了。",
	}
	local  basic_skills_triggerlist={
	       {name="basic_skills_force",regexp=linktri(_tb),script=function(n,l,w)    basic_skills.force(n,l,w)  end,},
	}
	for k,v in pairs(basic_skills_triggerlist) do
		addtri(v.name,v.regexp,"basic_skills_force",v.script,v.line)
	end
	closeclass("basic_skills_force")
	-------------------------爬崖
	_tb={
	"数码世界，数字地图，(.+)就是这里！",
	"你目前还没有任何为 busyover=paya 的变量设定。",
	"你目前还没有任何为 dazuo=over 的变量设定。",
	"你爬了上来。","你爬了下来。",
	"四面光溜溜的崖陡如壁，你轻功不够，怎么也爬不上去。","那个方向没法爬。",
	"你一觉醒来，只觉精力充沛。该活动一下了。",
	}
	local  basic_skills_triggerlist={
	       {name="basic_skills_dodge",regexp=linktri(_tb),script=function(n,l,w)    basic_skills.dodge(n,l,w)  end,},
	}
	for k,v in pairs(basic_skills_triggerlist) do
		addtri(v.name,v.regexp,"basic_skills_dodge",v.script,v.line)
	end
	closeclass("basic_skills_dodge")
	------------------------全真木头人
	_tb={
	"数码世界，数字地图，(.+)就是这里！",
	"你目前还没有任何为 busyover=strike_muren 的变量设定。",
	"你打了一会，发现自己没有什么进步，看来该去弄点实战经验了。",
	"你一觉醒来，只觉精力充沛。该活动一下了。",
	}
	local  basic_skills_triggerlist={
	       {name="basic_skills_strike",regexp=linktri(_tb),script=function(n,l,w)    basic_skills.strike(n,l,w)  end,},
	}
	for k,v in pairs(basic_skills_triggerlist) do
		addtri(v.name,v.regexp,"basic_skills_strike",v.script,v.line)
	end
	closeclass("basic_skills_strike")
	-----------------------全真沙袋
	_tb={
	"数码世界，数字地图，(.+)就是这里！",
	"你目前还没有任何为 busyover=da_shadai 的变量设定。",
	"你打了一会，发现自己没有什么进步，看来该去弄点实战经验了。",
	"你一觉醒来，只觉精力充沛。该活动一下了。",
	}
	local  basic_skills_triggerlist={
	       {name="basic_skills_cuff",regexp=linktri(_tb),script=function(n,l,w)    basic_skills.cuff(n,l,w)  end,},
	}
	for k,v in pairs(basic_skills_triggerlist) do
		addtri(v.name,v.regexp,"basic_skills_cuff",v.script,v.line)
	end
	closeclass("basic_skills_cuff")
	-------------------------234打蜜蜂加玄铁剑法
	_tb={
	"数码世界，数字地图，234就是这里！",
	"你目前还没有任何为 busyover=dufeng 的变量设定。",
	}
	local  basic_skills_triggerlist={
	       {name="basic_skills_xtjf",regexp=linktri(_tb),script=function(n,l,w)    basic_skills.xtjf(n,l,w)  end,},
	}
	for k,v in pairs(basic_skills_triggerlist) do
		addtri(v.name,v.regexp,"basic_skills_xtjf",v.script,v.line)
	end
	closeclass("basic_skills_xtjf")
end
basic_skills.update()