function alias.gblianwu(a)
	run("enter dong")
	roomno_now=2033
	if havefj>0 then 
		alias.startworkflow() 
	elseif ybLimited==0 and ybjob.waitlimit>0 then
		alias.startyb() 
	elseif workflow.cm>0 and gb.needchongmai>0 then 
		me.chongmaiBaseid=roomno_now
		alias.startcm()
	else
		alias.uw()
		skills_num=1
		alias.lianwu()
	end
end
function alias.dealwithName()
	sx.name=string.gsub(sx.name,"【大理段家】","")
	sx.name=string.gsub(sx.name,"【全真教】","")
	sx.name=string.gsub(sx.name,"【武当派】","")
	sx.name=string.gsub(sx.name,"【少林派】","")
	sx.name=string.gsub(sx.name,"【桃花岛】","")
	sx.name=string.gsub(sx.name,"【峨嵋派】","")
	sx.name=string.gsub(sx.name,"【华山派】","")
	sx.name=string.gsub(sx.name,"【星宿派】","")
	sx.name=string.gsub(sx.name,"【白驼山】","")
	sx.name=string.gsub(sx.name,"【雪山派】","")
	sx.name=string.gsub(sx.name,"【密宗】","")
	sx.name=string.gsub(sx.name,"【丐帮】","")
	sx.name=string.gsub(sx.name,"【明教】","")
	sx.name=string.gsub(sx.name,"【青城派】","")
end
function alias.searchNextGoldRoom()
    if flytoidx<flytosum then --搜索下一个地点
        alias.flytonext()
    else
        if findstring(gold.roomName,"山路") then
            if findstring(gold.roomzone,"福建泉州") then
                gold.roomzone="杭州"
                alias.flyto("山路",gold.roomzone)
            elseif findstring(gold.roomzone,"杭州") then
                gold.roomzone="云南大理城"
                alias.flyto("山路",gold.roomzone)
            elseif findstring(gold.roomzone,"云南大理城") then
                if havefj>0 then 
                    alias.startworkflow() 
                elseif ybLimited==0 and ybjob.waitlimit>0 then
                    alias.startyb() 
                else 
                    gold.fujiaid=""
                    if havefj>0 then 
                        alias.startworkflow() 
                    elseif ybLimited==0 and ybjob.waitlimit>0 then
                        alias.startyb()
                    else 
                        alias.dz(set_neili_global) 
                    end
                end
            end
        else
            gold.fujiaid=""
            if havefj>0 then 
                alias.startworkflow() 
            elseif ybLimited==0 and ybjob.waitlimit>0 then
                alias.startyb()
            else 
                alias.dz(set_neili_global) 
            end
        end
    end
end
function alias.goldid(a)
	local _tb,_tb2
	_tb=Split(goldidList,"|")
	_tb2=Split(goldNameList,"|")
	for i=0,#_tb2,1 do
		if a==_tb2[i] then
			return _tb[i]
		end
	end
	return ""
end
function alias.fujiaid(a)
	local _tb,_tb2
	_tb=Split(fujiaidList,"|")
	_tb2=Split(fujiaNameList,"|")
	for i=0,#_tb2,1 do
		if a==_tb2[i] then
			return _tb[i]
		end
	end
	return ""
end
------------------------------------------------------------------------------------
-- mp_gb_watch
------------------------------------------------------------------------------------
function mp_gb_watch.dosomething1(n,l,w)
	--[[local a,b,c,d=string.find(l,"  丐帮.+袋弟子(.+)%((%w+)%)")
		if c~=nil then
			for i,k in ipairs(gold.givegold) do
				a=string.lower(k[1])
				if findstring(c,k[2]) then print("本来可以塞宝物的，出于仁慈，还是算了吧");addlog("塞入一个宝石");run("get "..k[1].." from dai;give "..d.." "..a);table.remove(gold.givegold,i) break end
			end
		end]]
	if findstring(l,"一边打架一边要饭？你真是活腻了！") then
		if mpweapon~=nil and string.len(mpweapon)>0 then
			alias.wi(mpweapon)
			run("jiajin max")
			alias.yjl()
		else run("jiali max") end
	end
	if findstring(l,"[> ]*"..gold["a"].."鬼鬼祟祟的对你道：鲁长老让你找的是这个吧，快快收好，别被巫师看到了。") then
		gold["false"]=1
		gold.ip[#gold.ip+1]=gold.a
	--	run("drop zuan shi;drop zhen zhu;drop ma nao;drop hetian yu;drop shui jing;drop yu shi;drop fei cui")
	end
	a,b,c=string.find(l,"你鬼鬼祟祟的对(.+)道：鲁长老让你找的是这个吧，快快收好，别被巫师看到了。")
	if c~=nil then
		print(c)
		--table.inster(gold.ip,c)
		gold["false"]=1
		gold.ip[#gold.ip+1]=c
	end

	if findstring(l,"你伸手往怀中一摸，惊觉密函不见了！") then
		sx.name=""
		sx.id=""
	end
end
------------------------------------------------------------------------------------
-- mp_gb_pre
------------------------------------------------------------------------------------
function mp_gb_pre.dosomething1(n,l,w)
	local _f,_tb,a,b,c
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		alias.resetidle()
		if gold.place~="" then alias.startgbresume()
		elseif tonumber(roomno_now)==me.menpaiJobStart then run("h;ask lu youjiao about gold") 
		else alias.flytoid(me.menpaiJobStart) 
		end
	end
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil and tonumber(c)==me.menpaiJobStart then
		alias.resetidle()
		if gold.needfriend==nil then 
			gold.needfriend=1
			--run("menpai;menpai 各勘察大队：寒潮将至，请注意保暖。家中安好，勿挂念！") 
		end
		if gb.Limited1>0 and gb.Limited2>0 then 
			run("h;sorry lu youjiao")
			alias.startworkflow()
		else
			run("h;ask lu youjiao about gold")
		end
	end
	if findstring(l,"你目前还没有任何为 checkmihan=yes 的变量设定。") then
		if sx.name~=nil and string.len(sx.name)>0 then
			closeclass("mp_gb_pre")
			openclass("mp_gb_sx")
			alias.flytonpc(sx.name)
		else run("set sx=over") end
	end
	a,b,c=string.find(l,"密函上面写着：(.-)[壮士|大师]+亲启。")
	if c~=nil then
		sx.name=c
		alias.dealwithName()
		sx.id=""
	end
	if findstring(l,"你目前还没有任何为 sx=over 的变量设定。") then
		alias.resetidle()
		if havefj>0 then 
			alias.startworkflow() 
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb()
		else 
			alias.gblianwu(2) 
		end
	end
	if findstring(w[0],"你向鲁有脚打听有关「job」的消息。\n鲁有脚说道：我现在没要事让你去干，待会儿你再来吧。") then
		alias.resetidle()
		run("set sx=over")
	end
	if findstring(w[0],"你向鲁有脚打听有关「job」的消息。\n鲁有脚说道：你还没完成我交待的工作，怎麽又来问我","你向鲁有脚打听有关「job」的消息。\n鲁有脚点了点头。\n鲁有脚说道：你来得正巧，我有件事要你去办！\n鲁有脚伸手入怀取出一封信笺。\n鲁有脚对你说道：你把这封密函交给.+，务必亲自送到！") then
		alias.resetidle()
		sx.name=""
		sx.id=""
		run("look mihan")
		run("set checkmihan=yes")
	end
	if findstring(l,"你目前还没有任何为 checkhp=addneili 的变量设定。") then
		if havefj>0 and hp.neili>(hp.maxneili*set_neili_job/100) then alias.tdz() end
	end
	if findstring(l,"你目前还没有任何为 checkexpover=beg1 的变量设定。") then
		alias.resetidle()
		--if add.exp>10 and mpLimited.MarkExp<me.menpaiLimited then --2017.10.10注释
		if add.exp>10 and mpLimited.beg1<7000 then --2017.10.10修改，替换上句
			mpJobLimited=0
			gb.Limited1=0
			--mpLimited.MarkExp=tonumber(me.menpaiLimited)
		elseif add.exp>10 and tonumber(mpLimited.beg1-add.exp)>7000 then 
			mpJobLimited=0
			gb.Limited1=0
			mpLimited.beg1=1
			mpLimited.MarkTimebeg1=os.time()
		else
			if gold["false"]~=nil and gold["false"]>0 then
				print("出现beg到同ip丐帮玩家给你的gold")
				gold["false"]=0
			else
				--if mpLimited.mpexp>me.menpaiLimited then
				--	print("设置为上限点。")
					
					gb.Limited1=1
					if (add.exp<10 and mpLimited.beg1<7000) or gb.Lted1==0 then
						if gb.Lted1==0 then gb.Lted1=1 end
						gb.Limited1=0
						mpLimited.beg1=1
					end
					if gb.Limited2>0 then 
					--	mpJobLimited=0	--注释掉这条，不用jobLimited控制是否讨饭。
					--	gb.Limited2=0 
						gold.num=gold.setnum+1 --两项beg都到达上限，停止beg
					end
					print("统计到的beg1上限为："..mpLimited.beg1)
					--mpLimited.MarkExp=tonumber(mpLimited.mpexp)
					if mpLimited.MarkTimebeg1<(os.time()-3600) then
						if de_bug>0 then print("到gold时间却仍然busy，推迟2分钟") end
						mpLimited.MarkTimebeg1=os.time()-3600+120
					end
				--end	
			end
		end
		gold.num=gold.num+1
		print("上次FJ后完成gold任务"..gold.num.."/"..gold.setnum.."次。")
		alias.startworkflow()
	end
	if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『武庙』立马到达！") then
		run("put 5 silver in xiang;put 5 silver in xiang;put 5 silver in xiang;put 5 silver in xiang;put 5 silver in xiang;get silver from xiang;east")
		run("drop zuan shi;drop zhen zhu;drop ma nao;drop hetian yu;drop shui jing;drop yu shi;drop fei cui")
		closeclass("mp_gb_pre")
		openclass("mp_gb_gold")
		if gb.Limited1==nil then gb.Limited1=0 end
		if gb.Limited2==nil then gb.Limited2=0 end
		if os.time()-gb.starttime<300 then
			alias.flytoid(gold.roomNo)
		elseif mpLimited.beg1==0 then 
			gold.place=""
			alias.startworkflow()
		elseif gb.Limited2==0 then
			alias.flytoid(gold.roomNo)
		else
			gold.place=""
			alias.startworkflow()
		end
		--alias.startworkflow() --_f=function() alias.startworkflow() end
		--if cmd.nums<cmd.setnums then _f() else wait.time(1);_f() end
	end
	if findstring(l,"这里没有 lu youjiao 这个人。") then
		alias.resetidle()
		gb.needchongmai=1
		alias.gblianwu(2)
	end
	if findstring(l,"你目前还没有任何为 lian=full 的变量设定。","你目前还没有任何为 lian=over 的变量设定。") then
		alias.resetidle()
		if havefj>0 then 
			alias.startworkflow() 
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb()
		else
			alias.dz(set_neili_global)
			--if roomno_now==me.menpaiJobStart then
			--	if gold.id~=nil and string.len(gold.id)>0 then run("ask lu youjiao about here") else run("ask lu youjiao about gold") end
			--else alias.flytoid(me.menpaiJobStart) end
		end
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		print("gb_mp_pre")
		alias.startworkflow()
	end
	if findstring(l,"对方正忙着呢，你等会儿在问话吧。") then
		alias.resetidle()
		wait.make(function()
			_f=function() run("ask lu youjiao about gold") end
			wait.time(1);_f()
		end)
	end
	if findstring(w[0],"鲁有脚对你说道：这里是土地庙，其它的在下不便多说。") then
		alias.resetidle()
		run("give "..gold.id.." to lu youjiao")
		gold.id=""
	--	gold.place=""
	end
	if findstring(w[0],"你向鲁有脚问道：这位.+，.+初到贵宝地，不知这里有些什麽风土人情？\n但是很显然的，鲁有脚现在的状况没有办法给你任何答覆。") then
		alias.resetidle()
		run("give "..gold.id.." to lu youjiao")
		gold.id=""
		--gold.place=""
	--	_f=function() run("give "..gold.id.." to lu youjiao");gold.id="";gold.place="" end
	--	wait.time(1);_f()
	end
	if findstring(w[0],"值不少两黄金，你此行收获甚大，辛苦了，快下去歇息吧。") then
		alias.resetidle()
		gold.roomNo=0
		gold.place=""
		run("drop zuan shi;drop zhen zhu;drop ma nao;drop hetian yu;drop shui jing;drop yu shi;drop fei cui")
		alias.checkexp("beg1")
	end
	if findstring(w[0],"好像不是你所有吧？想蒙混过关，当我是大傻蛋？","交给一名小叫化，吩咐他放入地底密室。") then
		alias.resetidle()
		--gold.place=""
		alias.startworkflow()
	end
	if findstring(w[0],"你向鲁有脚打听有关「gold」的消息。\n鲁有脚说道：我不是已经吩咐你去筹措黄金了吗？") then
		alias.resetidle()
		run("sorry lu youjiao")
		gold.place=""
		if havefj>0 then 
			alias.startworkflow() 
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb()
		else
			if sx.open>0 then 
				run("ask lu youjiao about job") 
			else 
				gb.needchongmai=1
				alias.gblianwu(2) 
			end
		end
	end
	if findstring(w[0],"你向鲁有脚打听有关「gold」的消息。\n鲁有脚说道：你先把.+练好了再说吧。") then
		alias.resetidle()
		gold.place=""
		if havefj>0 then 
			alias.startworkflow() 
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb()
		else
			--if sx.open>0 then run("ask lu youjiao about job") else alias.dz("addneili") end
			if sx.open>0 then run("ask lu youjiao about job") else gb.needchongmai=1;alias.gblianwu(2) end
		end
	end
	if findstring(w[0],"你向鲁有脚打听有关「gold」的消息。\n鲁有脚说道：目前没有什么任务，.+请先稍事歇息罢。","你向鲁有脚打听有关「gold」的消息。\n鲁有脚说道：最近好像没什么富贾的消息","你向鲁有脚打听有关「gold」的消息。\n但是很显然的，鲁有脚现在的状况没有办法给你任何答覆。") then
		alias.resetidle()
		gold.place=""
		gb.needchongmai=1
		if havefj>0 then 
			alias.startworkflow() 
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb() 
		else 
			alias.gblianwu(2) 
		end
	end
	a,b,c=string.find(w[0],"你向鲁有脚打听有关「gold」的消息。\n鲁有脚在你的耳边悄声说道：.+\n鲁有脚说道：你去(.+)附近打听看看，看看是否有富贾经过，向其讨一些黄金来。")
	if c~=nil then
		alias.resetidle()
		gold.place=c
		gb.starttime=os.time()
		gold.searchTimes=1
		gb.gotobeg()
	end
	--end)
end
function gb.gotobeg()
	gold.index=1
	--gold.searchTimes=1
	gold.have=0
	gold.over=0
	gb.searchshanlu=0
	gb.searchqinshidadao=0
	gb.bangzhongnum=1
	gb.bangzhongerr=0
	gold.begPlayerNum=-100
	gold.ownerName=""
	if gb.starttime==nil then gb.starttime=os.time() end
	if findstring(gold.place,"泉州") then
		gold.roomNameList=goldqzh.roomName
		gold.roomNoList=goldqzh.roomNo
		gold.askNameList=goldqzh.askName
		gold.askidList=goldqzh.askid
	end
	if findstring(gold.place,"大理") then
		gold.roomNameList=golddl.roomName
		gold.roomNoList=golddl.roomNo
		gold.askNameList=golddl.askName
		gold.askidList=golddl.askid
	end
	if findstring(gold.place,"杭州") then
		gold.roomNameList=goldhz.roomName
		gold.roomNoList=goldhz.roomNo
		gold.askNameList=goldhz.askName
		gold.askidList=goldhz.askid
	end
	if findstring(gold.place,"佛山") then
		gold.roomNameList=goldfs.roomName
		gold.roomNoList=goldfs.roomNo
		gold.askNameList=goldfs.askName
		gold.askidList=goldfs.askid
	end
	_tb=Split(gold.askNameList,"|")
	gold.askName=_tb[gold.index]
	_tb=Split(gold.askidList,"|")
	gold.askid=_tb[gold.index]
	_tb=Split(gold.roomNoList,"|")
	gold.roomNo=tonumber(_tb[gold.index])
	openclass("mp_gb_pre")
	closeclass("mp_gb_gold")
	alias.flyto("武庙")
end
------------------------------------------------------------------------------------
-- mp_gb_gold
------------------------------------------------------------------------------------
function mp_gb_gold.dosomething1(n,l,w)
	local _f,_tb,a,b,c,d
	if findstring(l,"你目前还没有任何为 searchgold=next 的变量设定。","对方正忙着呢，你等会儿在问话吧。","你忙着呢，你等会儿在问话吧。","但是很显然的，"..gold.askName.."现在的状况没有办法给你任何答覆。","你目前还没有任何为 gps=false 的变量设定。") then
		alias.resetidle()
		mp_gb_gold.ask_next()
		return
	elseif findstring(l,"有一天，你踩着七色云彩来迎娶『鲁有脚』") then
		alias.resetidle()
		closeclass("mp_gb_gold")
		openclass("mp_gb_pre")
		if gold.id==nil or string.len(gold.id)==0 then
		--	run("sorry lu youjiao")
			run("ask lu youjiao about gold")
			gold.place=""
		else 
			run("ask lu youjiao about here") 
		end
	elseif findstring(l,"你目前还没有任何为 searchgold=over 的变量设定。") then
		alias.resetidle()
		closeclass("mp_gb_gold_ti")
		alias.flytonpc("鲁有脚")
	elseif findstring(l,"你目前还没有任何为 busyover=begover 的变量设定。") then
		alias.resetidle()
		closeclass("mp_gb_gold_ti")
		if gold.have==0 and gold.over>0 then run("get "..alias.goldid(gold.Name)) end
		run("set searchgold=over")
	elseif findstring(l,"你对.+道：此物乃是一位受你恩惠的.+托我给你的，请收好。") then
		gold.ownerName=""
		gb.givegold=1
	elseif findstring(l,"你目前还没有任何为 checkbeg 的变量设定。") then
		if gb.givegold>0 then
			alias.checkexp("beg2")
			gb.givegold=0
		--elseif gold.begPlayerNum~=nil and gold.begPlayerNum>0 then
		--	print("出现我beg到别人的，别人beg到我的，给别人gold后等待别人给我gold")
		else
			--if #gold.givegold<3 then table.insert(gold.givegold,gold.a) end
			if havefj>0 then 
				alias.startworkflow() 
			elseif ybLimited==0 and ybjob.waitlimit>0 then
				alias.startyb()
			else 
				alias.startworkflow() 
			end
		end
	elseif findstring(l,"你目前还没有任何为 checkexpover=beg2 的变量设定。") then
		alias.resetidle()
		----------------------------------------------------------------------------------------------------------
		if add.exp>10 then 
			mpJobLimited=0
			gb.Limited2=0
			if tonumber(mpLimited.beg2-add.exp)<10 then
				mpLimited.beg2=add.exp
				mpLimited.MarkTimebeg2=os.time()
			elseif gb.Lted2>0 and tonumber(mpLimited.beg2-add.exp)>7000 then
				mpJobLimited=0
				gb.Limited2=0
				mpLimited.beg2=add.exp
				mpLimited.MarkTimebeg2=os.time()
				print("重新统计beg2")
			elseif gb.Lted2>0 and tonumber(mpLimited.beg2)>7000 then
				gb.Limited2=1
				print("统计到的beg2上限为："..mpLimited.beg2)
			elseif gb.Lted2==0 then
				mpLimited.beg2=add.exp
			end
		else
		--if add.exp<=10 then
			if gold["false"]~=nil and gold["false"]>0 then
				print("出现beg到同ip丐帮玩家给你的gold")
				gold["false"]=0
			else
				gb.Lted2=1
				gb.Limited2=1
				if mpLimited.beg2<7000 then
					gb.Limited2=0
					mpLimited.beg2=1
				end
				if gb.Limited1>0 then 
					gold.num=gold.setnum+1 --两项beg都到达上限，停止beg
				end
				print("统计到的beg2上限为："..mpLimited.beg2)
				--mpLimited.MarkExp=tonumber(mpLimited.mpexp)
				if mpLimited.MarkTimebeg2<(os.time()-3600) then
					mpLimited.MarkTimebeg2=os.time()-3600+120
				end
				--end
			end
		end
		gold.num=gold.num+1
		print("上次FJ后完成gold任务"..gold.num.."/"..gold.setnum.."次。")
		--if gold.begPlayerNum~=nil and gold.begPlayerNum>0 then
		--	print("出现我beg到别人的，别人beg到我的，给别人gold后等待别人给我gold")
		--else
			if havefj>0 then 
				alias.dz(set_neili_global) 
			elseif gb.Limited1>0 and gb.Limited2>0 then
				alias.flytonpc("鲁有脚")
			else 
				alias.startworkflow() 
			end
		--end
		----------------------------------------------------------------------------------------------------------
	elseif findstring(l,"你目前还没有任何为 busyover=giveowner 的变量设定。") then
		alias.resetidle()
		gb.givegold=0
	--	for i,k in ipairs(gold.ip) do
	--		if gold.a==k then run("drop "..gold.givegoldid) end
	--	end
		if gold.block>0 then run("drop "..gold.givegoldid) end
		run("give "..gold.givegoldid.." to "..gold.ownerid)
		run("drop "..gold.givegoldid)
		run("set checkbeg")
		gold.givegoldid=""
		gold.have=0
	elseif findstring(l,"你目前还没有任何为 checkgoldrobber=yes 的变量设定。") then
		alias.resetidle()
		gold.begPlayerNum=1
		if gb.Limited1>0 or gold.robberid=="" then
			alias.startworkflow()
			gold.begPlayerNum=-100
		else
			run("beg1 "..gold.robberid..";unset no_accept")
		end
	elseif findstring(l,"你要对谁做 beg1 这个动作？") then
		alias.resetidle()
		if gold.begPlayerNum>0 then
			closeclass("mp_gb_gold_robber")
			-- #say "和~(~@gold.fujiaName~给你一~{颗|块~}~(%x~)。一起进行双触发，因为有可能对方不给你"
			gold.id=""
			gold.begPlayerNum=-100
			if havefj>0 then 
				alias.startworkflow() 
			elseif ybLimited==0 and ybjob.waitlimit>0 then
				alias.startyb()
			else 
				alias.dz(set_neili_global) 
			end
		end
	elseif findstring(l,"你说道：「.+，我求你一件事，你肯答允么？」") then
		alias.resetidle()
		gold.begPlayerNum=gold.begPlayerNum+1
		if gold.begPlayerNum~=nil and gold.begPlayerNum>=30 then
			closeclass("mp_gb_gold_robber")
			gold.id=""
			gold.begPlayerNum=-100
			run("set no_accept 1")
			if havefj>0 then 
				alias.startworkflow() 
			elseif ybLimited==0 and ybjob.waitlimit>0 then
				alias.startyb()
			else alias.dz(set_neili_global) end
		else
			if gold.begPlayerNum>0 then
			--	DoAfterSpecial(1, 'run("beg1 "..gold.robberid)',12)
				wait.make(function()
				_f=function() run("beg1 "..gold.robberid) end
				wait.time(1);_f()
				end)
			end
		end
	elseif findstring(l,"这是那人的随身家伙，肯定不会给你。") then 
		alias.resetidle()
		gold.goldindex=gold.goldindex+1
		if gold.goldindex>7 then gold.goldindex=1 end
		_tb=Split(goldNameList,"|")
		gold.Name=_tb[gold.goldindex]
		_tb=Split(goldidList,"|")
		gold.id=_tb[gold.goldindex]
		mp_gb_gold_ti.timer()
	elseif not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		if havefj>0 then 
			if gb.Limited2>0 then
				alias.flytonpc("鲁有脚") --别人的饭讨满了，先放弃讨饭再做FJ
			else
			    print("gb_gold")
				alias.startworkflow()
			end
		else
			gold.searchTimes=gold.searchTimes+1
			if gold.searchTimes<=10 then 
				alias.flytoid(gold.roomNo)
			else
				-- 搜索富贾失败
				gold.id=""
				run("set searchgold=over")
			end
		end
	end
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil and tonumber(c)==gold.roomNo then
		alias.resetidle()
		run("h;ask "..gold.askid.." about 富贾;h")
	end
	a,b,c=string.find(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『(.+)』立马到达！")
	if c~=nil and c==gold.roomName then
		alias.resetidle()
		run("follow "..gold.fujiaid)
	end
	a,b,c=string.find(l,"浮云朵朵飘，飘到了 %d+ 个『(.+)』中的第 %d+ 个～～")
	if c~=nil and c==gold.roomName then
	alias.resetidle()
		run("follow "..gold.fujiaid)
	end
	a,b,c=string.find(l,"这里没有 (.+)")
	if c~=nil and not isopen("gps_start") then
		alias.resetidle()
		if findstring(c,"du dajin") then
			gb.bangzhongnum=0
			gb.bangzhongerr=0
			run("enter;ask figure about 富贾;h")
			gold.askName="蒙面人"
			gold.askid="figure"
			gold.roomNo=1248
			roomno_now=1248
			--mp_gb_gold.ask_next()
		elseif findstring(c,gold.askid) then
			if (gold.askid=="bangzhong" or gold.askid=="figure") then gb.bangzhongnum=0;gb.bangzhongerr=1 end
			--run("set searchgold=next")
			mp_gb_gold.ask_next()
		elseif findstring(c,gold.fujiaid) then
			if havefj>0 then 
				alias.startworkflow() 
			elseif ybLimited==0 and ybjob.waitlimit>0 then
				alias.startyb()
			else 
				alias.searchNextGoldRoom() 
			end
		end
	end
	a,b,c=string.find(l,"你决定开始跟随(.+)一起行动。")
	if c~=nil then
		alias.resetidle()
		if hp.water<(hp.maxwater-40) then run("drink jiudai") end
		if c==gold.fujiaName then
			gold.goldindex=1
			_tb=Split(goldNameList,"|")
			gold.Name=_tb[gold.goldindex]
			_tb=Split(goldidList,"|")
			gold.id=_tb[gold.goldindex]
		--	run("set no_accept 0;set brief 1")
			run("set brief 1")
			openclass("mp_gb_gold_ti")
		else
			-- Zhang gui有茶庄掌柜和绸缎庄掌柜两个，第一个不对则follow下一个
			gold.zhangguiid=gold.zhangguiid+1
			run("follow "..gold.fujiaid.." "..gold.zhangguiid)
		end
	end
	a,b,c,d=string.find(l,"[> ]*(.+)低头想了一会，又看了看你，摇摇头，叹了口气，丢给你一[颗|块]+(.+)。")
	if c~=nil and d~=nil then
		gold.searchTimes=1
		gold.fujiaName=c
		alias.resetidle()
		gold.Name=d
		gold.id=alias.goldid(gold.Name)
		gold.have=1
		closeclass("mp_gb_gold_ti")
	end
	a,b,c,d=string.find(l,"[> ]*(.+)说道：当年我曾受过(.+)的恩惠，这.+算是我的一番心意，请代[为转告|我交给他吧]+。")
	if c~=nil and d~=nil and c==gold.fujiaName then
		alias.resetidle()
		print("讨饭计数：",gold.num,"讨饭1历时：",os.time()-tonumber(mpLimited.MarkTimebeg1),"上限：",gb.Limited1,"经验：",mpLimited.beg1,"讨饭2历时：",os.time()-tonumber(mpLimited.MarkTimebeg2),"上限：",gb.Limited2,"经验：",mpLimited.beg2)
		for i,k in ipairs(gold.ip) do	--判断是否为同ip玩家
			gold.block=0 
			if d==k then 
				gold.block=1
				break 
			end
		end
		--if gold.ownerName=="" then gold.ownerName=d end
		gold.ownerName=d
		if d==me.charname then
			-- 等待别人给你珠宝
			closeclass("mp_gb_gold_ti")
			gold.robberid=""
			openclass("mp_gb_gold_robber")
			run("id here;set checkgoldrobber=yes")
			gold.a=c
		else
			if gold.have>0 and findstring("|黄帮主|乔帮主|简长老|梁长老|一位不愿留名的丐帮侠士|洪老前辈|鲁长老|","|"..d.."|") then
				closeclass("mp_gb_gold_ti")
				alias.checkbusy("begover")
				gold.over=1
				gold.a=""
			else
				if gold.have>0 and gold.over==0 then
					-- 等待给别人珠宝
					closeclass("mp_gb_gold_ti")
					gold.givegoldid=gold.id
					gold.a=d  --临时保存对象名称
					gold.ownerid=""
					gold.id=""
					openclass("mp_gb_gold_owner")
					run("id here")
					alias.checkbusy("giveowner")
				else
					gold.a=""
					gold.ownerName=""
					gold.givegoldid=""
					-- npc给了别人珠宝，不关我事
				end
			end
		end
	end
	a,b,c,d=string.find(l,"[> ]*(.+)给你一[颗|块]+(.+)。")
	if c~=nil and d~=nil and c==gold.robberName then
		alias.resetidle()
		closeclass("mp_gb_gold_robber")
		gold.Name=d
		gold.id=alias.goldid(gold.Name)
		gold.begPlayerNum=-100
		gold.have=1
		gold.over=1
		closeclass("mp_gb_gold_ti")
		if gold.givegoldid~=nil and gold.givegoldid~="" and string.len(gold.givegoldid)>0 then
			print("出现我beg到别人的，别人beg到我的，别人给我gold后等待给别人gold")
			print(gold.givegoldid)
		else 
			alias.checkbusy("begover") 
		end
	end
	a,b,c=string.find(l,"你装出可怜巴巴的样子，慢慢地向(.+)走过去，伸出双手，想要[些|杯]")
	if c~=nil then
		alias.resetidle()
		gold.goldindex=gold.goldindex+1
		if gold.goldindex>7 then gold.goldindex=1 end
		_tb=Split(goldNameList,"|")
		gold.Name=_tb[gold.goldindex]
		_tb=Split(goldidList,"|")
		gold.id=_tb[gold.goldindex]
	end
	a,b,c,d=string.find(l,"你装出可怜巴巴的样子，慢慢地向(.+)走过去，伸出双手，想要[颗|块]+(.-)%.%.%.")
	if c~=nil and d~=nil and c==gold.fujiaName then
		gold.Name=d
		gold.id=alias.goldid(gold.Name)
	end
	if findstring(l,"你目前还没有任何为 checkfujiaid=yes 的变量设定。") then
		alias.resetidle()
		-- 检查身边的富贾id
		if gold.fujiaid~=nil and string.len(gold.fujiaid)>0 then
			run("follow "..gold.fujiaid)
		else
			run("h;ask "..gold.askid.." about 富贾;h")
		--	wait.make(function()
		--	_f=function() run("h;ask "..gold.askid.." about 富贾") end
		--	wait.time(1);_f()
		--	end)
		end
	end
	a,b,c,d=string.find(l,"[> ]*(.+)丢下一[颗|块]+(.+)。")
	if c~=nil and d~=nil and c==gold.robberName then
		alias.resetidle()
		if gold.begPlayerNum~=nil and gold.begPlayerNum>0 then
			gold.Name=d
			gold.id=""
			gold.begPlayerNum=-100
			gold.have=0
			gold.over=1
			closeclass("mp_gb_gold_ti")
			if gold.givegoldid~=nil and string.len(gold.givegoldid)>0 then
				-- 出现我beg到别人的，别人beg到我的，别人给我gold后等待给别人gold
			else alias.checkbusy("begover") end
		end
	end
	a,b,c,d=string.find(l,"[> ]*(.+)对着(.+)说了声「告辞」，转身渐渐走远了。")
	if c~=nil and d~=nil and c==gold.fujiaName then
		alias.resetidle()
		if gold.block>0 then
			gold.givegoldid=""
			gold.robberName=""
			alias.startworkflow()
		elseif d~="你" then 
			gold.robberName=d 
		end
	end
	a,b,c=string.find(l,"你捡起一[颗|块]+(.+)。")
	if c~=nil then
		alias.resetidle()
		gold.Name=c
		gold.id=alias.goldid(gold.Name)
		gold.have=1
	end
	a,b,c=string.find(l,"  (.+)%(%w+ %w+%)")
	if c~=nil and gold.fujiaid=="" then
		alias.resetidle()
		gold.fujiaName=c
		gold.fujiaid=alias.fujiaid(gold.fujiaName)
		gold.zhangguiid=1
		if gold.fujiaid~="" then
			run("follow "..gold.fujiaid)
			print("这里就有一个富贾"..gold.fujiaid)
			return
		end
	end
end
function mp_gb_gold.restart(n,l,w)
	--local _f,_tb,a,b,c,d
	if findstring(w[0],"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？\n.+说道：你先瞪大眼睛看看这里是什么地界再问我吧.+","睁大眼睛望着你，显然不知道你在说什么.+","摇摇头，说道：没听说过.+",	"耸了耸肩，很抱歉地说：无可奉告.+",	"这我可不清楚，你最好问问别人吧。",	"想了一会儿，说道：对不起，你问的事我实在没有印象.+") then
		alias.resetidle()
		gold.roomNo=0
		gold.place=""
		gold.id=""
		gold.have=0
		gold.over=0
		alias.startworkflow()
	end
end
function mp_gb_gold.dosomething2(n,l,w)
	local _f,_tb,a,b,c,d
	--print("test")
-------------------------------------------------------------------
	a,b,c,d=string.find(w[0],"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？\n.+说道：刚才倒是有个(.+)从这里经过，好像是往(.+)那边去了.+\n.+") -- 下次从下一个询问的npc开始
	if c~=nil and d~=nil then
		alias.resetidle()
		alias.setmpLimitedMark() 
		if (findstring(w[0],"这附近没见到什么富贾。") and gb.Limited2>0) or (not findstring(w[0],"这附近没见到什么富贾。") and gb.Limited1>0) then 
			mp_gb_gold.ask_next()
		else
			gold.have=0
			gold.over=0
			_tb=Split(gold.roomNoList,"|")
			if gold.index<=#_tb then
				_tb=Split(gold.askNameList,"|")
				gold.askName=_tb[gold.index]
				_tb=Split(gold.askidList,"|")
				gold.askid=_tb[gold.index]
				_tb=Split(gold.roomNoList,"|")
				gold.roomNo=tonumber(_tb[gold.index])
			else
				gold.searchTimes=gold.searchTimes+1
				gold.index=1
				_tb=Split(gold.askNameList,"|")
				gold.askName=_tb[gold.index]
				_tb=Split(gold.askidList,"|")
					gold.askid=_tb[gold.index]
				_tb=Split(gold.roomNoList,"|")
				gold.roomNo=tonumber(_tb[gold.index])
			end
			gold.fujiaName=c
			gold.fujiaid=alias.fujiaid(gold.fujiaName)
			gold.roomName=d
			gold.zhangguiid=1
			if gold.roomName=="青竹林" then alias.flyto("青竹林","大理")
			elseif gold.roomName=="山路" then 
				gb.searchshanlu=gb.searchshanlu+1
				if gb.searchshanlu<2 then alias.flyto("山路","泉州") else mp_gb_gold.ask_next() end
			elseif gold.roomName=="青石大道" then
				gb.searchqinshidadao=gb.searchqinshidadao+1
				if gold.place=="杭州" and gb.searchqinshidadao<2 then alias.flyto("青石大道","杭州") else mp_gb_gold.ask_next() end
			elseif gold.roomName=="大道" then alias.flyto("大道","杭州")
			elseif gold.roomName=="土地庙" then alias.flyto("土地庙","泉州")
			elseif gold.roomName=="密林" then alias.flyto("密林","大理")
			elseif gb.Limited2==0 then alias.flyto(gold.roomName) 
			else alias.flyto(gold.roomName,gold.place)end
		end
		return
	end
	a,b,c=string.find(w[0],"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？\n.+说道：踏遍铁鞋无觅处，得来全部费功夫。你看不是有个(.+)正往这里走来了吗.+") 
	if c~=nil then
		alias.resetidle()
		gold.fujiaName=c
		gold.fujiaid=alias.fujiaid(gold.fujiaName)
		gold.zhangguiid=1
		run("follow "..gold.fujiaid)
		return
	end
	a,b,c=string.find(w[0],"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？\\n一个.+朝这边走了过来。\\n.+说道：踏遍铁鞋无觅处，得来全部费功夫。你看不是有个(.+)正往这里走来了吗.+")
	if c~=nil then
		alias.resetidle()
		gold.fujiaName=c
		gold.fujiaid=alias.fujiaid(gold.fujiaName)
		gold.zhangguiid=1
		run("follow "..gold.fujiaid)
		return
	end
	a,b,c,d=string.find(w[0],"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？\n(.+)")
	if c~=nil then
		alias.resetidle()
		if findstring(c,"这附近没见到什么富贾","你跟我套近乎不会是看上我了吧") then
			if gold.askid=="bangzhong" or gold.askid=="figure" then 
				run("ask "..gold.askid.." "..gb.bangzhongnum.." about 富贾;h")
			else 
				run("h;ask "..gold.askid.." about 富贾;h") 
			end
		elseif findstring(c,"你身边不是就有一个吗") then
			-- 检查身边的富贾id
			gold.fujiaid=""
			openclass("mp_gb_gold_fujia")
			run("look;set checkfujiaid=yes")
		elseif findstring(c,"你怀中的金银财宝都快掉出来了","你先瞪大眼睛看看") then
			-- 搜索富贾失败
			run("drop ma nao;drop zhen zhu;drop yu shi;drop hetian yu;drop zuan shi;drop fei cui;drop shui jing")
			gold.roomNo=0
			gold.id=""
			gold.have=0
			gold.over=0
			run("set searchgold=over")
		end
	end
end
function mp_gb_gold.ask_next()
	alias.resetidle()
	if havefj>0 then 
		alias.startworkflow() 
	elseif ybLimited==0 and ybjob.waitlimit>0 then
		alias.startyb()
	elseif (gold.askid=="bangzhong" or gold.askid=="figure") and gb.bangzhongerr==0 and roomno_now==gold.roomNo then
		gb.bangzhongnum=gb.bangzhongnum+1
		run("ask "..gold.askid.." "..gb.bangzhongnum.." about 富贾;h")
		--return
	else
		if gb.bangzhongerr>0 then gb.bangzhongerr=0 end
		if gb.bangzhongnum>1 then gb.bangzhongnum=1 end
		gold.index=gold.index+1
		_tb=Split(gold.roomNoList,"|")
		if gold.index<=#_tb then
			_tb=Split(gold.askNameList,"|")
			gold.askName=_tb[gold.index]
			_tb=Split(gold.askidList,"|")
			gold.askid=_tb[gold.index]
			_tb=Split(gold.roomNoList,"|")
			gold.roomNo=tonumber(_tb[gold.index])
			--if havefj>0 then alias.startworkflow()
			if gold.roomNo==roomno_now then
				run("h;ask "..gold.askid.." about 富贾;h")
			else
				alias.flytoid(gold.roomNo)
			end
		else
			gold.searchTimes=gold.searchTimes+1
			if gold.searchTimes<=10 then
				gold.index=1
				_tb=Split(gold.askNameList,"|")
				gold.askName=_tb[gold.index]
				_tb=Split(gold.askidList,"|")
				gold.askid=_tb[gold.index]
				_tb=Split(gold.roomNoList,"|")
				gold.roomNo=tonumber(_tb[gold.index])
				alias.dz(set_neili_global)
			else
				-- 搜索富贾失败
				gold.id=""
				run("set searchgold=over")
			end
		end
	end
end
------------------------------------------------------------------------------------
-- mp_gb_gold_fujia
------------------------------------------------------------------------------------
function mp_gb_gold_fujia.dosomething1(n,l,w)
	if findstring(fujiaNameList,w[2]) then
		gold.fujiaName=w[2]
		gold.fujiaid=alias.fujiaid(gold.fujiaName)
		gold.zhangguiid=1
		closeclass("mp_gb_gold_fujia")
	end
end
------------------------------------------------------------------------------------
-- mp_gb_gold_owner
------------------------------------------------------------------------------------
function mp_gb_gold_owner.dosomething1(n,l,w)
	if w[3]==gold.ownerName then
		gold.ownerid=w[4]
		closeclass("mp_gb_gold_owner")
	end
end
------------------------------------------------------------------------------------
-- mp_gb_gold_robber
------------------------------------------------------------------------------------
function mp_gb_gold_robber.dosomething1(n,l,w)
	if w[3]==gold.robberName then
		gold.robberid=w[4]
		closeclass("mp_gb_gold_robber")
	end
end
------------------------------------------------------------------------------------
-- mp_gb_gold_ti
------------------------------------------------------------------------------------
function mp_gb_gold_ti.dosomething1(n,l,w)
	if findstring(l,"看来还是走吧，这家伙身上已经没有多少油水可榨了。","你[想乞讨的对象不在这里|要向谁乞讨]+","太可惜了，你要乞讨的人已经走了") then
		alias.resetidle()
		-- 丢失富贾行踪！
		gold.id=""
		closeclass("mp_gb_gold_ti")
		if havefj>0 then 
			alias.startworkflow() 
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb()
		else 
			alias.dz(set_neili_global) 
		end
	end
	if findstring(l,"你丢下一[颗|块]+.+。") then
		alias.resetidle()
		gold.Name=""
		gold.id=""
		gold.have=0
	end
end
function mp_gb_gold_ti.timer()
	run("h;beg "..gold.id.." from "..gold.fujiaid)
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function mp_gb.update()
	local _tb
	_tb={
		"看来还是走吧，这家伙身上已经没有多少油水可榨了。",
		"你(想乞讨的对象不在这里|要向谁乞讨)",
		"你丢下一(颗|块)(.+)。",
		"太可惜了，你要乞讨的人已经走了",
	}
	local  mp_gb_gold_ti_triggerlist={
	       {name="mp_gb_gold_ti_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold_ti.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_ti_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_gold_ti",v.script,v.line)
	end
	AddTimer("mp_gb_gold_ti_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_gb_gold_ti.timer")
	SetTimerOption("mp_gb_gold_ti_timer", "group", "mp_gb_gold_ti")
	closeclass("mp_gb_gold_ti")
	
	_tb={
		"(\\S+)\\s+=\\s+(\\w+)",
	}
	local  mp_gb_gold_robber_triggerlist={
	       {name="mp_gb_gold_robber_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold_robber.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_robber_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_gold_robber",v.script,v.line)
	end
	closeclass("mp_gb_gold_robber")
	
	_tb={
		"(\\S+)\\s+=\\s+(\\w+)",
	}
	local  mp_gb_gold_owner_triggerlist={
	       {name="mp_gb_gold_owner_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold_owner.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_owner_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_gold_owner",v.script,v.line)
	end
	closeclass("mp_gb_gold_owner")
	
	_tb={
		"(.+)\\s+=\\s+(.+),",
	}
	local  mp_gb_gold_fujia_triggerlist={
	       {name="mp_gb_gold_fujia_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold_fujia.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_fujia_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_gold_fujia",v.script,v.line)
	end
	closeclass("mp_gb_gold_fujia")
	--> 你向潇湘子打听有关「富贾」的消息。
	--你凑到潇湘子身边，向潇湘子问道：不知壮士可看到有富贾在附近经过？
	--一个茶庄掌柜朝这边走了过来。
	--潇湘子说道：踏遍铁鞋无觅处，得来全部费功夫。你看不是有个茶庄掌柜正往这里走来了吗？
	local _tb={
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：你怀中的金银财宝都快掉出来了，还瞎打听什么.+\\n.+\\Z",
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：你跟我套近乎不会是看上我了吧.*\\n.+\\Z",
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：你身边不是就有一个吗，还问我.*\\n.+\\Z",
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：踏遍铁鞋无觅处，得来全部费功夫。你看不是有个(.+)正往这里走来了吗.+\\n.+\\Z",
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n一个.+朝这边走了过来。\\n.+说道：踏遍铁鞋无觅处，得来全部费功夫。你看不是有个(.+)正往这里走来了吗.+\\Z",
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：刚才倒是有个(.+)从这里经过，好像是往(.+)那边去了.+\\n.+\\Z",
	}
	local  mp_gb_gold_m_triggerlist={
	       {name="mp_gb_gold_m_dosth1",line=3,regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_gb_gold",v.script,v.line)
	end
	
	local _tb={
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：怎么老有.+打探消息，烦不烦啦！.*\\Z",
		"你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？.*\\n.+说道：这附近没见到什么富贾。.*\\Z",
	}
	local  mp_gb_gold_m_triggerlist={
	       {name="mp_gb_gold_m_dosth2",line=2,regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold.ask_next()  end,},
	}
	for k,v in pairs(mp_gb_gold_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_gb_gold",v.script,v.line)
	end
	local _tb={
		--"你向.+打听有关「富贾」的消息。\\n你凑到.+身边，向.+问道：不知.+可看到有富贾在附近经过？\\n.+说道：你先瞪大眼睛看看这里是什么地界再问我吧。\\Z",
		"你向.+打听有关「富贾」的消息。\\n(.+)\\n.*",
	}
	local  mp_gb_gold_m_triggerlist={
	       {name="mp_gb_gold_m_dosth3",line=3,regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold.restart(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_gb_gold",v.script,v.line)
	end
	
	_tb={
	--	"查找房间失败！",
		"你目前还没有任何为 gps=false 的变量设定。",
		"数码世界，数字地图，(\\d+)就是这里！",
		"你口念咒语『神马都是浮云,虾米都是尘土』，『(.+)』立马到达！",
		"浮云朵朵飘，飘到了 \\d+ 个『(.+)』中的第 \\d+ 个～～",
		"有一天，你踩着七色云彩来迎娶『鲁有脚』",
		"对方正忙着呢，你等会儿在问话吧。",
		"你忙着呢，你等会儿在问话吧。",
		"但是很显然的，(.+)现在的状况没有办法给你任何答覆。",
		"你目前还没有任何为 searchgold=next 的变量设定。",
		"这里没有 (.+)",
		--"这里没有 (.+) 这个人。",
		--"这里没有 (.+)。",
		--"这里没有 (.+)%s+(%d+)。",
		--"这里没有 (.+)\\s+(.+)。",
		"你目前还没有任何为 searchgold=over 的变量设定。",
		"你决定开始跟随(.+)一起行动。",
		"你目前还没有任何为 busyover=begover 的变量设定。",
		".+低头想了一会，又看了看你，摇摇头，叹了口气，丢给你一.+。",
		".+说道：当年我曾受过.+的恩惠，这.+算是我的一番心意，请代.+。",
		--"你目前还没有任何为 checkgoldowner=yes 的变量设定。",
		"你目前还没有任何为 checkgoldrobber=yes 的变量设定。",
		"你要对谁做 beg1 这个动作？",
		"你说道：「.+，我求你一件事，你肯答允么？」",
		"你对.+道：此物乃是一位受你恩惠的.+托我给你的，请收好。",
		"你目前还没有任何为 checkexpover=.+ 的变量设定。",
		"(.+)给你一(颗|块)(.+)。",
		"你装出可怜巴巴的样子，慢慢地向(.+)走过去，伸出双手，想要(些|杯)",
		"这是那人的随身家伙，肯定不会给你。",
		"你装出可怜巴巴的样子，慢慢地向(.+)走过去，伸出双手，想要(颗|块)(.+)...",
		"你目前还没有任何为 busyover=giveowner 的变量设定。",
		"你目前还没有任何为 checkbeg 的变量设定。",
		"你目前还没有任何为 dazuo=over 的变量设定。",
		"  (.+)\\(\\w+ \\w+\\)",
		"你目前还没有任何为 checkfujiaid=yes 的变量设定。",
		"(.+)丢下一(颗|块)(.+)。",
		"(.+)对着(.+)说了声「告辞」，转身渐渐走远了。",
		"你捡起一(颗|块)(.+)。",
	}
	local  mp_gb_gold_triggerlist={
	       {name="mp_gb_gold_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_gold.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_gold_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_gold",v.script,v.line)
	end
	closeclass("mp_gb_gold")
	
	local _tb={
		"你向鲁有脚问道：这位.+，.+初到贵宝地，不知这里有些什麽风土人情？\\n鲁有脚对你说道：这里是土地庙，其它的在下不便多说。\\Z",
		"你从怀中取出筹措来的.+交给了鲁有脚。\\n鲁有脚说道：这.+值不少两黄金，你此行收获甚大，辛苦了，快下去歇息吧。\\Z",
		"你从怀中取出.+交给了鲁有脚。\\n鲁有脚说道：这.+好像不是你所有吧？想蒙混过关，当我是大傻蛋？\\Z",
		"你从怀中取出.+交给了鲁有脚。\\n鲁有脚冷冷的看了你一眼，转头将.+交给一名小叫化，吩咐他放入地底密室。\\Z",
		"你向鲁有脚问道：这位.+，.+初到贵宝地，不知这里有些什麽风土人情？\\n但是很显然的，鲁有脚现在的状况没有办法给你任何答覆。\\Z",
		"你向鲁有脚打听有关「job」的消息。\\n鲁有脚说道：你还没完成我交待的工作，怎麽又来问我？\\Z",
		"你向鲁有脚打听有关「job」的消息。\\n鲁有脚说道：我现在没要事让你去干，待会儿你再来吧。\\Z",
		"你向鲁有脚打听有关「gold」的消息。\\n鲁有脚说道：我不是已经吩咐你去筹措黄金了吗？\\Z",
		"你向鲁有脚打听有关「gold」的消息。\\n鲁有脚说道：目前没有什么任务，.+请先稍事歇息罢。\\Z",
		"你向鲁有脚打听有关「gold」的消息。\\n鲁有脚说道：你先把.+练好了再说吧。\\Z",
		"你向鲁有脚打听有关「gold」的消息。\\n鲁有脚说道：你还没完成我交待的工作，怎麽又来问我\\Z",
		"你向鲁有脚打听有关「gold」的消息。\\n鲁有脚说道：最近好像没什么富贾的消息。\\Z",
		"你向鲁有脚打听有关「gold」的消息。\\n但是很显然的，鲁有脚现在的状况没有办法给你任何答覆。\\Z",
	}
	local  mp_gb_pre_m_triggerlist={
	       {name="mp_gb_pre_m_dosth1",line=2,regexp=linktri(_tb),script=function(n,l,w)    mp_gb_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_pre_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_gb_pre",v.script,v.line)
	end
	
	local _tb={
		"你向鲁有脚打听有关「gold」的消息。\\n鲁有脚在你的耳边悄声说道：.+\\n鲁有脚说道：你去(.+)附近打听看看，看看是否有富贾经过，向其讨一些黄金来。\\Z",
	}
	local  mp_gb_pre_m3_triggerlist={
	       {name="mp_gb_pre_m3_dosth1",line=3,regexp=linktri(_tb),script=function(n,l,w)    mp_gb_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_pre_m3_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_gb_pre",v.script,v.line)
	end
	
	local _tb={
		"你向鲁有脚打听有关「job」的消息。\\n鲁有脚点了点头。\\n鲁有脚说道：你来得正巧，我有件事要你去办！\\n鲁有脚伸手入怀取出一封信笺。\\n鲁有脚对你说道：你把这封密函交给(.+)，务必亲自送到！\\Z",
	}
	local  mp_gb_pre_m2_triggerlist={
	       {name="mp_gb_pre_m2_dosth1",line=5,regexp=linktri(_tb),script=function(n,l,w)    mp_gb_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_pre_m2_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_gb_pre",v.script,v.line)
	end
	
	_tb={
		"你目前还没有任何为 sx=over 的变量设定。",
		"你目前还没有任何为 checkmihan=yes 的变量设定。",
		"你要看什么？",
		"密函上面写着：(.+)亲启。",
		"你目前还没有任何为 dealwithitems=over 的变量设定。",
		"数码世界，数字地图，(\\d+)就是这里！",
		"你目前还没有任何为 checkhp=addneili 的变量设定。",
		"你目前还没有任何为 dazuo=over 的变量设定。",
		"你目前还没有任何为 checkexpover=.+ 的变量设定。",
		"你目前还没有任何为 lian=over 的变量设定。",
		"这里没有 lu youjiao 这个人。",
		"你目前还没有任何为 lian=full 的变量设定。",
		"对方正忙着呢，你等会儿在问话吧。",
		"你口念咒语『神马都是浮云,虾米都是尘土』，『武庙』立马到达！",
	}
	local  mp_gb_pre_triggerlist={
	       {name="mp_gb_pre_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_pre_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_pre",v.script,v.line)
	end
	closeclass("mp_gb_pre")
	
	local noecho_trilist={
			"你正忙着呢",
			"你已经在向人家乞讨了！",
			}
	local _noechotri=linktri(noecho_trilist)

	addtri("mp_gb_watch_gag_dosth1",_noechotri,"mp_gb_watch","")
	SetTriggerOption("mp_gb_watch_gag_dosth1","omit_from_output",1)

	_tb={
		"一边打架一边要饭？你真是活腻了！",
		".+鬼鬼祟祟的对你道：鲁长老让你找的是这个吧，快快收好，别被巫师看到了。",
		"你鬼鬼祟祟的对.+道：鲁长老让你找的是这个吧，快快收好，别被巫师看到了。",
		"你伸手往怀中一摸，惊觉密函不见了！",
		"  丐帮.+袋弟子 .+\\(\\w+\\)",
		--"  丐帮\.+袋弟子(\.+)\\((\\w+)\\)",
	}
	local  mp_gb_watch_triggerlist={
	       {name="mp_gb_watch_dosth1",regexp=linktri(_tb),script=function(n,l,w)    mp_gb_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_gb_watch_triggerlist) do
		addtri(v.name,v.regexp,"mp_gb_watch",v.script,v.line)
	end
	closeclass("mp_gb_watch")
end
mp_gb.update()