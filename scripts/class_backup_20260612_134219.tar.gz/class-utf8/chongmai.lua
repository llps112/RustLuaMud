------------------------------------------------------------------------------------
-- chongmai_pre
------------------------------------------------------------------------------------
function chongmai_pre.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		if dummy.jyroom~="" and cm.havebuff==0 and cm.getdan>0 then 
			alias.flyto(dummy.jyroom)
		else
			run("set chongmai=start")
		end
	elseif findstring(l,".+%("..dummy['jy'].."%)告诉你：有通脉丹") then
		cm.getdan=1
		--print("testchongmai")
	elseif findstring(l,".+%("..dummy['jy'].."%)告诉你：没有通脉丹")then
		cm.getdan=0
	elseif findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『"..dummy['jyroom'].."』立马到达！") then
		cm.getdan=0
		run("unset no_accept;tell "..dummy['jy'].." give me tongmai dan")
	elseif findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『钱庄』立马到达！") then
		alias.resetidle()
		qugold.num=aoyao.needgold-100*(aoyao.buyno-1)-have.gold+5
		run("qu "..tostring(qugold.num).." gold;set check=qugold")
	elseif findstring(l,".+给你一丸紫金通脉丹。") then
		cm.getdan=0
		if os.time()>stat.cmbuff and os.time()>stat.drugbusy then
			run("fu tongmai dan")
		else
			run("give tongmai dan to "..dummy['jy'])
		end
		run("set chongmai=start")
	elseif findstring(l,"掌柜的笑着说道：提取这么多钱，您怕是拿不动了。") then
		qugold.success=0
	elseif findstring(l,"掌柜的点点头，从内屋里取出.+两黄金交到你手里。") then
		qugold.success=1
		have.gold=5
	elseif findstring(l,"你目前还没有任何为 check=qugold 的变量设定。") then
		alias.resetidle()
		if qugold.success>0 then alias.startay()
		else
			qugold.num=qugold.num-100
			run("qu "..tostring(qugold.num).." gold;set check=qugold")
		end
	elseif findstring(l,"你目前还没有任何为 aoyao=false 的变量设定。") then
		alias.resetidle()
		cm.havebuff=0
		alias.checkitems()
	elseif findstring(l,"你目前还没有任何为 aoyao=true 的变量设定。") then
		alias.resetidle()
		run("fu dan;set chongmai=start")
	elseif findstring(l,"穷光蛋，一边呆着去！") then
		alias.close_aoyao()
		alias.flyto("钱庄")
	elseif findstring(l,"你目前还没有任何为 chongmai=start 的变量设定。") then
		closeclass("chongmai_pre")
		openclass("chongmai_start")
		alias.flytoid(me.chongmaiBaseid)
	end
end
------------------------------------------------------------------------------------
-- chongmai_start
------------------------------------------------------------------------------------
function chongmai_start.dosomething1(n,l,w)
	local a,b,c
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil then
		alias.resetidle()
		alias.uw()
		if tonumber(c)==tonumber(me.chongmaiBaseid) then
		    if me.menpai=="xs" and tonumber(me.chongmaiBaseid)==1853 then run("get jing") end
			if me.menpai=="mj" then
				alias.dz(set_neili_job)
			else
				alias.dz(set_neili_global)
			end
		else
			cm.lifesave=0
			run("yun lifesave corpse")
			alias.startworkflow()
		end
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		if havefj>0 or cm.getdan>0 then alias.startworkflow();print("chongmai结束")
		--elseif cm.getdan>0 then alias.startworkflow()
		elseif me.menpai=="gb" and gb.needchongmai>0 then 
			cm.doing=1
			gb.needchongmai=0
			run("yun chongmai")
		elseif pdmpsj() and workflow.mp>0 then 
			alias.startworkflow()
		else alias.checkbusy("cm")
		end
	elseif findstring(l,".+%("..dummy['jy'].."%)告诉你：有通脉丹") then
		cm.getdan=1
	elseif findstring(l,".+%("..dummy['jy'].."%)告诉你：没有通脉丹")then
		cm.getdan=0
	elseif findstring(l,"你目前还没有任何为 busyover=cm 的变量设定。") then
		alias.resetidle()
		cm.doing=1
		run("yun chongmai")
	elseif findstring(l,"你感觉气息在.+运转受阻，急忙加大内力想要冲破这一关，结果受了点内伤。","你感觉内力不济，无法继续冲脉。") then
		alias.resetidle()
		run("set cm"..tostring(cm.mai).." "..tostring(cm.chong))
		cm.doing=0
		--alias.dz(190)
		alias.startworkflow()
	elseif findstring(l,"你当前脉络已通") then
		alias.resetidle()
		cm.mai=cm.mai+1
		run("set cm"..tostring(cm.mai).." "..tostring(cm.chong))
		cm.doing=0
		alias.dz(190)
	end
end
------------------------------------------------------------------------------------
-- chongmai_watch
------------------------------------------------------------------------------------
function chongmai_watch.dosomething1(n,l,w)
	local a,b,c,d,_t
	if findstring(l,"设定环境变量：cm%d+ = %d+") then
		alias.resetidle()
	end
	a,b,c=string.find(l,"您目前 cm%d+ 的变量设定为： (%d+)")
	if tonumber(c)~=nil then
		alias.resetidle()
		cm.chong=tonumber(c)
	end
	a,b,c=string.find(l,"你将丹田之内的气息于游走于已通的(.+)脉中，准备百尺竿头更进一步。")
	if c~=nil then
		--_t=math.floor(math.pow(d/1.618,1+count_force[c]/100)*20+1)
		alias.resetidle()
		cm.mai=ctonum(c)
		run("set cm"..tostring(cm.mai))
		--if hp.maxneili>_t+cm.mai*500 then
		--	workflow.cm=0
		--end
	end
	a,b,c,d=string.find(l,".+告诉你：(%S+) (%d+)$")
	if c~=nil and d~=nil and c=="救命" then
		cm.lifesave=tonumber(d)
	end
	if findstring(l,"你目前还没有任何为 cm%d+ 的变量设定。") then
		alias.resetidle()
		cm.chong=0
	elseif findstring(l,"你内息运转到.+，顿时感觉无比轻松。","你体内不同内功激荡，内息运转到.*调理不是很畅通，但是也不是很严重。") then
		alias.resetidle()
		cm.chong=cm.chong+1
		alias.setmpLimitedMark()
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function chongmai.update()
	local _tb
	_tb={
	--"你目前还没有任何为 dealwithitems=over 的变量设定。",
	"你口念咒语『神马都是浮云,虾米都是尘土』，『.+』立马到达！",
	"掌柜的笑着说道：提取这么多钱，您怕是拿不动了。",
	"掌柜的点点头，从内屋里取出.+两黄金交到你手里。",
	"你目前还没有任何为 .+ 的变量设定。",
	"穷光蛋，一边呆着去！",
	".+告诉你：有通脉丹",
	".+告诉你：没有通脉丹",
	".+给你一丸紫金通脉丹。",
	}
	local  chongmai_pre_triggerlist={
	       {name="chongmai_pre_dosth1",regexp=linktri(_tb),script=function(n,l,w)    chongmai_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(chongmai_pre_triggerlist) do
		addtri(v.name,v.regexp,"chongmai_pre",v.script,v.line)
	end
	closeclass("chongmai_pre")
	
	_tb={
	"数码世界，数字地图，\\d+就是这里！",
	"你目前还没有任何为 .+ 的变量设定。",
	--"你目前还没有任何为 busyover=cm 的变量设定。",
	".+告诉你：有通脉丹",
	".+告诉你：没有通脉丹",
	"你感觉气息在.+运转受阻，急忙加大内力想要冲破这一关，结果受了点内伤。","你感觉内力不济，无法继续冲脉。",
	"你当前脉络已通",
	}
	local  chongmai_start_triggerlist={
	       {name="chongmai_start_dosth1",regexp=linktri(_tb),script=function(n,l,w)    chongmai_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(chongmai_start_triggerlist) do
		addtri(v.name,v.regexp,"chongmai_start",v.script,v.line)
	end
	closeclass("chongmai_start")
	
	_tb={
	"设定环境变量：cm\\d+ \= \\d+",
	"您目前 cm\\d+ 的变量设定为： (\\d+)",
	"你内息运转到.+，顿时感觉无比轻松。","你体内不同内功激荡，内息运转到.*调理不是很畅通，但是也不是很严重。",
	"你将丹田之内的气息于游走于已通的(.+)脉中，准备百尺竿头更进一步。",
	".+告诉你：(\\S+) (\\d+)$",
	}
	local  chongmai_watch_triggerlist={
	       {name="chongmai_watch_dosth1",regexp=linktri(_tb),script=function(n,l,w)    chongmai_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(chongmai_watch_triggerlist) do
		addtri(v.name,v.regexp,"chongmai_watch",v.script,v.line)
	end
	closeclass("chongmai_watch")
end
chongmai.update()
