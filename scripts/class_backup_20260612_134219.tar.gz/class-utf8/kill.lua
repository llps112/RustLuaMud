-- 看不懂的话千万别乱改，谢谢罗~
------------------------------------------------------------------------------------
-- kill
------------------------------------------------------------------------------------
function kill.timer()
	run("look")
	run("hp;set check=kill")
end
function kill.dokill(id,name,class)
	if not stat.use_jinhua then
		if isopen("kill") or fjroomid>0 then
			alias.initialize_trigger()
			print("正在战斗！危险！退出重连！！")
			openclass("quit")
			stat.quiting=0
		end
	else
		if not isopen("gps_zeikou") then
			alias.initialize_trigger()
		end
		if cm.doing~=nil and tonumber(cm.doing)>0 then
			print("冲脉中")
			run("halt;yun recover")
		end
		run("unset no_parry;halt;halt")
		reyun=1
		npcfaint=false
		killRunSuccess=false
		openclass("kill")
		openclass("kill_pfm")
		--openclass("kill_"..me.menpai)
		closeclass("kill_run")
		AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
		SetTimerOption("kill_timer", "group", "kill")
		runaway=false
		if jifa["forcename"]=="zixia-gong" then --门派判断改成内功判断
			if stat.leidong>0 then
				pfmid=2
				if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
			else
				pfmid=1
				alias.uw()
			end
		elseif jifa["forcename"]=="hunyuan-yiqi" then --门派判断改成内功判断
			if stat.jingang>0 then
				pfmid=2
				if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
			else
				pfmid=1
				alias.uw()
			end
		else
			pfmid=1
			if string.len(fjweapon)>0 then
				if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
			else 
				alias.uw() 
			end
		end
		_tb=Split(fjyun,"|")
		for k,v in ipairs(_tb) do run(v) end
		killid=id
		killname=name
		killskill=fjweapon
		killpfm=fjpfm
		killyun=fjyun
		killjiali=fjjiali
		killjiajin=fjjiajin
		run("jiali "..killjiali..";jiajin "..killjiajin..";yield no;kill "..killid)
		if me.menpai=="bt" then run("convert staff;attack "..killid) end
		if me.menpai=="mj" then run("shoutfighter fighter;order fighter do attack "..killid..";order fighter 2 do attack "..killid) end
		alias.pfm()
		openclass(class)
	end
end
function kill.dosomething1(n,l,w)
	local _tb,_f,a,b,c,_t
	if killname==nil then killname="" end
	if reyun==nil then reyun=0 end
	if findstring(l,"你刚刚压制住身上伤势，还是不要妄动真气。") then yunbusy=yunbusy+1 end
	if findstring(l,"你目前还没有任何为 check=kill 的变量设定。") then
		check_battleidle=tonumber(check_battleidle)+1
	    print("战斗发呆计数["..check_battleidle.."]次")
		if check_battleidle~=nil and check_battleidle>180 then idle=1 else alias.resetidle() end
		--print(idle)
		if wieldweapon>0 and killskill~="" then			
			if have[_G["killskill"]]~=nil and have[_G["killskill"]]>0 then
				_tb=Split(killpfm,"|")
				if findstring(_tb[pfmid],"leidong") and stat.leidong==0 or findstring(_tb[pfmid],"jingang") and stat.jingang==0 then 
					alias.uw()
				else 
					if killskill=="staff" then alias.wi(staffid) else alias.wi(killskill) end
				end
			else
				if killid~=nil and killid~="" then rekill=1 end
				run("halt;get ".._G["killskill"]..";wield ".._G["killskill"])
			end
		end
		if rekill>0 then run("kill "..tostring(killid)) end 
		if hp.healthqi<60 then runaway=true;print("受伤严重") end
		if hp.jingli<(hp.maxjingli*2/3) and hp.neili<500 then runaway=true;print("没有精力") end
		if hp.neili<(hp.maxneili*2/10) and (#always.bei==0 or #always.bei==1 and always["bei"][1]~="六脉神剑" or #always.bei==2 and always["bei"][1]~="六脉神剑" and always["bei"][2]~="六脉神剑") then runaway=true;print("没有内力") end 
	  --if not runaway or npcfaint or isopen("mp_xs_npc1") then
	    if not runaway or isopen("mp_xs_npc1") then
		  --if me.menpai=="xx" and reyun>0 and not npcfaint then run("yun hua") end
		    if me.menpai=="xx" and reyun>0 then run("yun hua") end
			if hp.qi<(hp.maxqi*100/hp.healthqi/2) and jifa.forcename~="huagong-dafa" then run("yun recover") end
			if hp.jing<(hp.maxjing/2) then run("yun regenerate") end
			if hp.jingli<(hp.maxjingli*1/3) then
				run("jiajin basic")
				if hp.jiajin>50 then rejiajin=true end
			end
			if (me.menpai=="wd" and killskill=="jian") then -- 武当派用chan，运精力要特色处理
				if hp.jingli<(hp.maxjingli/3) then alias.yjl() end
			else
				if string.len(killskill)>0 then -- 使用武器时一般都jiajin max，所以要经常yjl
					if hp.jingli<(hp.maxjingli/2) then alias.yjl() end
				else -- 空手技能差不多没一半精力时再yjl
					if hp.jingli<(hp.maxjingli/2) then alias.yjl() end
				end
			end
			--if reyun~=nil and reyun>0 and not npcfaint then
			if reyun~=nil and reyun>0 then
				_tb=Split(killyun,"|")
				for k,v in ipairs(_tb) do run(v) end
			end
			alias.pfm()
		else
			if not isopen("kill_run") and not isopen("mp_mj_yudi") and not isopen("michen_yb_start") then
				print("准备逃跑")
				alias.close_kill()
				openclass("kill_run")
				run("halt")
				if jifa.forcename=="motian-yunqi" then run("yun shougong") end
				if me.menpai=="bt" then run("stop she;stop she;stop she;convert she") end
				run("go "..safego..";18mo "..killid)
			end
		end
	end
	if not isopen("kill_run") and findstring(l,"你转身不灵，难以闪避，只得挺右手相抵。到此地步，已是高手比拼真力。") then
		alias.close_kill()
		openclass("kill_run")
		if jifa.forcename=="motian-yunqi" then run("yun shougong") end
		run("halt;go "..safego..";18mo "..killid)
	end
	--a,b,c=string.find(l,"你(.+)")
	--if c~=nil and not findstring(c,"变量设定") then
	--	alias.resetidle()
	--end
	if findstring(l,"你目前还没有任何为 busyover=killover 的变量设定。") then
		alias.resetidle()
		if skillslist["cuff"]==nil then skillslist["cuff"]={} end
		if skillslist["cuff"]["lvl"]==nil then skillslist["cuff"]["lvl"]=1 end
		if (me.xtbl+skillslist["cuff"]["lvl"]/10)==me.bl then stat.leidong=0;stat.jingang=0 end
		if jifa.forcename=="motian-yunqi" then run("yun shougong") end
		if me.shen<-100 and ((me.menpai=="wd" and me.master=="张三丰") or (me.menpai=="em" and me.master~="周芷若") or (me.menpai=="qz" and me.master=="丘处机")) then
			alias.close_kill()
			openclass("quit")
			openclass("quitdis")
		elseif me.shen>0 and me.menpai=="xx" then
			alias.close_kill()
			openclass("quit")
			openclass("quitdis")
		else alias.killover() end
	end
	if findstring(l,"你所使用的外功中没有这种功能。") then
		_tb=Split(killpfm,"|")
		if findstring(_tb[pfmid],"leidong","jingang","jingmo","nian","qiankun","piaomiao") then alias.uw();return end
		alias.uw()
		if killskill=="staff" then alias.wi(staffid) else alias.wi(killskill) end
	end
	if fjjf~=nil and fjjf~="" and findstring(l,"你.+麻木，无力再使.+", "你请先用 enable 指令选择你要使用的外功。") then
		alias.jf(fjjf)
	end
	if findstring(l,"你伸了伸腰，长长地吸了口气。") then
		if rejiajin then
			run("jiajin "..killjiajin)
			rejiajin=false
		end
	end
	--if findstring(l,"你将.+剑插回剑鞘。","你将.+剑绕回腰间。","你将.+剑插入了剑鞘。") then alias.resetidle() end
	a,b,c=string.find(l,"只听见.+一声，你手中的(.+)已经断为两截！")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
	end
	a,b,c=string.find(l,"你只觉得“神门穴”上一阵酸麻，手指无力，(.+)拿捏不稳，抛在地下！")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="玄铁重剑" then have.xuantiejian=0;have.jian=have.jian-1
		elseif c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
		getweapon=1
	end
	a,b,c=string.find(l,"你手中(.+)已在外围，情急之下只好放弃(.+)，双手当胸，挡开这一招。")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="玄铁重剑" then have.xuantiejian=0;have.jian=have.jian-1
		elseif c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
		getweapon=1
	end
	a,b,c=string.find(l,"你猛觉得劲风罩来，心知不妙，手中(.+)脱手飞出，赶紧也是双掌向前平推。")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="玄铁重剑" then have.xuantiejian=0;have.jian=have.jian-1
		elseif c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
		getweapon=1
	end
	a,b,c=string.find(l,"你只觉得手中(.+)把持不定，脱手飞出！")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="玄铁重剑" then have.xuantiejian=0;have.jian=have.jian-1
		elseif c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
		getweapon=1
	end
	a,b,c=string.find(l,"你只觉虎口一热，(.+)顿时脱手而出")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="玄铁重剑" then have.xuantiejian=0;have.jian=have.jian-1
		elseif c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
		getweapon=1
	end
	a,b,c=string.find(l,"你.+麻木，哐当一声，(.+)掉到了地上。")
	if c~=nil then
		if findstring(c,"扁担","瑶琴","杖","法杵") then have.staff=have.staff-1 end
		if c=="玄铁重剑" then have.xuantiejian=0;have.jian=have.jian-1
		elseif c=="重剑" then have.zhongjian=have.zhongjian-1;have.jian=have.jian-1
		elseif findstring(c,"剑") then have.jian=have.jian-1 end
		if findstring(c,"箫") then have.xiao=have.xiao-1 end
		if findstring(c,"刀") then have.dao=have.dao-1 end
		if findstring(c,"棒") then have.stick=have.stick-1 end
		wieldweapon=1
		getweapon=1
	end
	if findstring(l,"这里没有这个人。") then
		if isopen("ftb_start") and not isopen("gps_dealwith") then
			-- 只有在做斧头帮时才处理这个。
			closeclass("kill")
			ftbnpcindex=ftbnpcindex+1
			_tb=Split(ftbnpcid,"|")
			if ftbnpcindex<=#_tb then
				npcid=_tb[ftbnpcindex]
				_tb=Split(ftbnpcname,"|")
				npcname=_tb[ftbnpcindex]
				run("ask "..npcid.." about 刺客")
			else
				npcfind=0
				ftbnpcindex=1
				--if cmd.nums<cmd.setnums then
					if string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
			--[[	else
					wait.make(function()
					_f=function()
						if string.len(flytoarealist_backpath)==0 then alias.searchareastep() else alias.searchareaback() end
					end
					wait.time(1);_f()
					end)
				end]]
			end
		end
	end
	if findstring(l,"这里没有 "..tostring(killid).."。","你想杀谁？") then alias.checkbusy("killover") end
	if findstring(l,".+只能在战斗中使用。",".+只能对战斗中的对手使用。") then 
		if me.menpai=="em" and workflow.nowjob=="yb" then
			run("attack "..killid)
		elseif me.menpai=="sl" and workflow.nowjob=="mp" then
			run("fight "..killid) 
		end
	end
	a,b,c=string.find(l,"[> ]*(.+)深深吸了几口气，强行压制住了身上的伤势。")
	if c~=nil and c==killname and not findstring(c,"幻影","->","：") then
		run("jiajin "..killjiajin..";jiali "..killjiali)
	end
	a,b,c=string.find(l,"[> ]*(.+)倒在地上，挣扎了几下就死了。")
	if c~=nil and c==killname and not findstring(c,"幻影","->","：") then
		--run("jiajin basic")
		if always["bei"][1]=="六脉神剑" and #always.bei==1 then	run("jiali 100") end
		run("score")
		npcfaint=true
		alias.checkbusy("killover")
		if skillslist["tiandi-fenglei"]~=nil and (weapon_now=="jian" or weapon_now=="zhongjian" or weapon_now=="xiao") and fjjf~=nil and fjjf~="" and workflow.nowjob=="fj" then run(fjjf) end
		if skillslist["shenghuo-ling"]~=nil and weapon_now=="dao" and fjjf~=nil and fjjf~="" and workflow.nowjob=="fj" then run(fjjf) end
	end
	a,b,c=string.find(l,"[> ]*(.+)已经陷入半昏迷状态，随时都可能摔倒晕去。")
  --if c~=nil and c==killname and not findstring(c,"幻影","->","：") and not npcfaint then
    if c~=nil and c==killname and not findstring(c,"幻影","->","：") then
		if me.menpai=="sl" then run("jiajin 50") end
	end
	a,b,c=string.find(l,"[> ]*(.+)慢慢睁开眼睛，清醒了过来。")
	if c~=nil and c==killname and not findstring(c,"幻影","->","：") then
		npcfaint=false
		run("jiajin "..killjiajin..";jiali "..killjiali)
	end
	a,b,c=string.find(l,"[> ]*(.+)脚下一个不稳，跌在地上昏了过去。")
	if c~=nil and c==killname and not findstring(c,"幻影","->","：") then
		npcfaint=true
		if always["bei"][1]=="六脉神剑" and #always.bei==1 then run("jiali 100") end
		if workflow.nowjob=="fj" and me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter 2;wavefighter fighter") end
		if skillslist["tiandi-fenglei"]~=nil and (weapon_now=="jian" or weapon_now=="zhongjian" or weapon_now=="xiao") and fjjf~=nil and fjjf~="" and workflow.nowjob=="fj" and jifa.swordname~="tiandi-fenglei" then run("jifa sword tiandi-fenglei") end
		--if skillslist["shenghuo-ling"]~=nil and weapon_now=="dao" and fjjf~=nil and fjjf~="" and workflow.nowjob=="fj" and jifa.bladename~="shenghuo-ling" then run("jifa blade shenghuo-ling") end
		--rekill=1  --此处取消rekill,为了防止fj的时候误kill 别人的fj npc。但不知道会不会引起其他任务错误，留下注释，以后备查
		reyun=0
	end
	if findstring(l,"你这招内劲所注，力道强横之极，.+竟将"..tostring(killname).."拦腰削成了上下两截！") then
		run("score")
		alias.checkbusy("killover")
	end
	if findstring(l,"你对著"..tostring(killname).."喝道：「.+」") then
		rekill=0
	end
	--if findstring(l,"你所使用的外功中没有这种功能。") then
	--	alias.resetidle()
	--	alias.uw(staffid)
	--	alias.uw("jian")
	--	alias.uw("dao")
	--	alias.uw("stick")
	--	alias.uw("qin")
	--end
	if findstring(l,"你捡起一.+杖。","你捡起一根法杵。","你捡起一.+瑶琴。") then have.staff=have.staff+1 
	elseif findstring(l,"你捡起一.+剑。") then have.jian=have.jian+1 
	elseif findstring(l,"你捡起一.+刀。") then have.dao=have.dao+1 
	elseif findstring(l,"你捡起一.+棒。") then have.stick=have.stick+1 
	elseif findstring(l,"你捡起一.+箫。") then have.xiao=have.xiao+1 
	end
	if findstring(l,"你.+握在手中","你.+取出白龙剑","你已经装备著了","你必须先放下你目前装备的武器") then
		wieldweapon=0
		if have[_G["killskill"]]~=nil and have[_G["killskill"]]>0 then
			
		else
			have[_G["killskill"]]=1
		end
	end
	if findstring(w[0],"看来该找机会逃跑了%.%.%.\n(%S+) %-") then
		-- 逃离打架现场，关闭Kill模块
		alias.yjl()
		run("yun recover")
		alias.close_kill()
		alias.startworkflow()
	end
end
------------------------------------------------------------------------------------
-- kill_run
------------------------------------------------------------------------------------
function kill_run.dosomething1(n,l,w)
	local _f,_tb,a,b,c
	wait.make(function()
		a,b,c=string.find(l,"^%s+这里唯一的出口是 (.+)。")
		if c~=nil then
			entrance=c
			xkxGPS.setEntrance(entrance)
		end
		a,b,c=string.find(l,"^%s+这里明显的出口是 (.+)。")
		if c~=nil then
			entrance=c
			xkxGPS.setEntrance(entrance)
		end
		if findstring(l,"草寇向你一阵阴笑：爽快的将宝贝交出来，不然叫你后悔莫及！","山贼大吼道：赶快将宝贝交出来，不然你就别指望活着离开！","星宿派弟子恶狠狠地威胁道：快将宝贝交出来，否则取你狗命！") then
			alias.initialize_trigger()
			print("无法逃，需要退出。")
			openclass("quit")
			stat.quiting=0
		end
		if findstring(l,"你哼了一声，问(.+)道：「你会唱“十八摸”罢？唱一曲来听听。」") then
			_f=function()
				run("halt")
				alias.yjl()
				if isopen("mp_th_start") and hp.pot>10 then run("cun all;hp") end
				run(safego..";18mo "..killid)
			end
			wait.time(0.2);_f()
		end
		if findstring(l,"你目前还没有任何为 resetSafe=yes 的变量设定。") then
			_tb=Split(xkxGPS.entrance,"|")
			safego=_tb[math.random(#_tb)]
			SafeBack=invDirection(safego)
		end
		if findstring(l,"你要对谁做 18mo 这个动作？") then
			if not killRunSuccess then
				print("逃跑成功！")
				alias.close_kill()
				if isopen("mp_dl_start") then dl.needquit=1 end
				if isopen("mp_th_start") then yp.goto=0 end
				if isopen("fj_start") then 
					openclass("fj_escape")
					alias.checkbusy("escape")
				else
					alias.startworkflow()
				end
			end
		end
		if findstring(l,"你在.+的耳边悄声说道：等着瞧，兔子！","有话慢慢说, 不要着急") then
			_f=function()
				_tb=Split(killid," ")
				run("halt;"..safego..";whisper ".._tb[1].." 等着瞧，兔子！")
			end
			wait.time(0.2);_f()
		end
		if findstring(l,"这个方向没有出路。") then
			if runaway then run("look;set resetSafe=yes") end
		end
	end)
end
------------------------------------------------------------------------------------
-- kill_pfm		分门派判断pfm,改成全部合并
------------------------------------------------------------------------------------
function kill_pfm.dosomething1(n,l,w)
	local _tb,a,b,c
	if findstring(l,"你脸色转白","你微觉疲惫","你感到丹田真气混浊","你只觉真气运转不畅","你玉女心经心法渐渐散去","你的龙象之力运行完毕","你的混天气功运行完毕") then
		reyun=1
	end
	if findstring(l,"你已经催动","你双掌合十","你已在运转枯荣心法","只听你嘿嘿嘿几声奸笑","你脸上青气大盛","你正在运用","你微一凝神","你面色陡变","你已经在运用化功大法","忽见你眼中红光时隐时现","你所聚太阴炼形法之气已散开","你刚刚才使用了太阴炼形法","只见你微微一笑","你口中默念大明六字真言","你已经在运龙象之力","你凝神默然运功","你微一凝神","你已在使用混天神罡了") then
		reyun=0
	end
	if findstring(l,"你龙行虎步，隐有君王之色，信手点去，一指戳在了","你向前疾跨一步，左手需晃一招，右手双指直戳，点中了") then
		if dl.useailao>0 then alias.dl_with_ailao() end
		if dl.usefeiyun>0 then killpfm="perform feiyun" end
	end
	--if findstring(l,".+目前正自顾不暇，放胆攻击吧。","你龙行虎步，隐有君王之色，信手点去，一指戳在了","你面色凝重，气贯丹田，单指缓缓戳出，一股内力破空而出，正中","你向前疾跨一步，左手需晃一招，右手双指直戳，点中了","你一指点出，这招后发先至，一阳指指力已锁住了","你不闪躲亦不招架，一道指力点在","然而你莞尔一笑，信手出指点在","你凌空出指，一道指气快速射向","但见你面色凝重，看准.+的破绽，单指缓缓戳出，竟使出一指乾坤") then
	--	if dl.useailao>0 then alias.dl_with_ailao() end
	--	if dl.usefeiyun>0 then run("perform feiyun "..killid) end
	--end
	--if findstring(l,"你的混天气功运行完毕，将内力收回丹田。") then
	--	stat.huntianup=0
	--	reyun=1
	--end
	if findstring(l,"[> ]*(.+)目前正自顾不暇","你长啸一声","你挥出一拳","你连续几拳","你轻轻挥出一拳","你纵跃退後",".+在空中旋转飞行之势已弱",".+在你身旁绕了个圈子","只听.+闷哼了一声, 后心已被你指力戳中.") then
		_tb=Split(killpfm,"|")
		if not findstring(killpfm,"qiankun") or (stat.qiankun>=2 and workflow.nowjob~="mp") then pfmid=pfmid+1 end
		if pfmid>#_tb then pfmid=1 end
	end
	if findstring(l,"你当即将紫霞神功都运到了.+剑上，呼的一剑，朝.+当头直劈！","你微一运劲，只觉丹田内息紊乱，无力使出绝招！","你正在使用「雷动九天」，无法分神使用其他招数。","你正在使用气宗绝技，不能施展「夺命连环三仙剑」。") then
		pfmid=pfmid+1
	end
	if findstring(l,"只听得你一声大喝，拳风突然变得猛劲之极，身法却更加飘忽难测！","你已在使用雷动九天了！") then
		pfmid=pfmid+1
		if killskill~=nil and string.len(killskill)>0 then
			wieldweapon=1
			if killskill=="staff" then alias.wi(staffid) else alias.wi(killskill) end
		end
	end
	if findstring(l,"你缓缓吸了一口气，将内劲收回丹田。") then
	  	if findstring(killpfm,"leidong") then
			wieldweapon=0
			alias.uw()
			run("perform leidong")
			pfmid=1
		end
	end
	if findstring(l,"你双手合十念佛，刹那间四周地动山摇，发出隆隆巨响！","你已经发动了金刚神通！") then
		pfmid=pfmid+1
		if killskill~=nil and string.len(killskill)>0 then
			wieldweapon=1
			if killskill=="staff" then alias.wi(staffid) else alias.wi(killskill) end
		end
	end
	if findstring(l,"你缓缓吸了一口气，收回金刚神通，身形又恢复了原状。") then
		if findstring(killpfm,"jingang") then
			wieldweapon=0
			alias.uw()
			run("perform jingang")
			pfmid=1
		end
	end
	if me.menpai=="hs" and findstring(l,"你「唰」的一声抽出一.+剑握在手中。","你已经装备著了。") then
		if me.master=="风清扬" then run("jifa dodge dugu-jiujian") else run("jifa parry huashan-jianfa") end
	end
	if me.menpai=="hs" and findstring(l,"你将手中的.-剑插回剑鞘。") then
		if me.master=="风清扬" then run("jifa dodge dugu-jiujian") else run("jifa parry pishi-poyu") end
	end
	if findstring(l,"经过一阵调息运气，你觉得丹田中原本紊乱的内息恢复了正常。") then
		_tb=Split(killpfm,"|")
		for k,v in ipairs(_tb) do
			if findstring(v,"sanxian") then pfmid=k end
		end
	end
	if findstring(l,"你大喝一声，剑招突变，.+剑逼出雪亮光芒，一剑化为.+剑") then
		pfmid=pfmid+1
		_tb=Split(killpfm,"|")
		if pfmid>#_tb then pfmid=1 end
		st=0
	end
	if findstring(l,"你运起纯阳神通功，片刻之间，白气笼罩全身，双眼精光四射，身手分外矫健，进退神速，与平时判若两人。") then
		st=st+1
		if st>=2 then pfmid=pfmid+1 end
		_tb=Split(killpfm,"|")
		if pfmid>#_tb then pfmid=1 end
	end
	if findstring(l,"你凌空出指，一股内力击中.+的.+，.+急忙运气与你的内劲对抗，虽然大耗内力，但是终于没有被点中穴道。") then
		stat.qiankun=stat.qiankun+1
		print("大耗内力第"..stat.qiankun.."次")
		if stat.qiankun>=dl.need_qiankun then pfmid=pfmid+1;alias.pfm() end
		_tb=Split(killpfm,"|")
		if pfmid>#_tb then pfmid=1 end
	end
	if findstring(l,"你面色凝重，气贯丹田，单指缓缓戳出，一股内力破空而出，正中.+的.+！") then
		--if dl.useailao>0 then alias.dl_with_ailao() end
		--if dl.usefeiyun>0 then killpfm="perform feiyun" end
		if workflow.nowjob~="mp" then
		    stat.qiankun=2
		    pfmid=pfmid+1
		end
		_tb=Split(killpfm,"|")
		if pfmid>#_tb then pfmid=1 end
		alias.pfm()
	end
	if findstring(l,"你吸了一口气，将内力收回丹田，剑招也恢复正常！") then
		pfmid=1
	end
	if findstring(l,"你此时心念空明，悟彻佛家神通，刀锋过处，招数就如一叶一叶的莲花花瓣自手中源源不断地弹出！","你内息运转不断，功力节节提升，出手越来越快，“混元一气功”催在刀上所发出的热浪把.+压得喘不过气来！","你手中.+刀连环不断向前劈出，却都以弧形收回，刀势犹若片片莲花花瓣。") then
		alias.yjl()
	end
	if findstring(l,"你需要五个轮子才能使用「五轮大转」。") then
		alias.uw()
		pfmid=pfmid+1
		_tb=Split(killpfm,"|")
		if pfmid>#_tb then pfmid=1 end
	end
	if findstring(l,"佛光普照乃是内家功夫，你现在内力不足，使不出这一招。","佛光普照乃是内家功夫，掌上不带内力使不出来") then
		alias.max()
	end
	if findstring(l,"紧接着，你御剑成风，剑招快闪绝伦，闪电般攻出了峨嵋.+绝剑。") then
		alias.yjl()
	end
	if findstring(l,"你已经在双剑和璧了。","你的左右互搏不够熟练，不能很好的使出双剑合璧的精妙之处！","必须持有双剑才能和璧左右互搏！","你的剑法修为不够！","你突然间左手抽出另一把剑，双手使出截然不同的剑法，正是左右互搏绝技。") then
		pfmid=pfmid+1
		_tb=Split(killpfm,"|")
		if pfmid>#_tb then pfmid=1 end
	end
	if findstring(l,"这不是你的蛇，它不会听从你的指挥的。") then
		run(safego)
		run("convert she")
	end
	if findstring(l,"怪蛇看了看你，突然似箭一般跃起，准确地落在蛇杖上，盘了起来。","蛇杖上已有一条蛇了，怪蛇挤不上去！") then
		closeclass("kill")
		closeclass("kill_pfm")
		--print("test")
		run("set killover="..killaction)
		killaction=""
	end
	if findstring(l,"你有放蛇出来吗？") then
		run("convert staff;attack "..killid)
	end
	if findstring(l,"你只能在战斗中与怪蛇配合。") then
		alias.checkbusy("killover")
	end
	if findstring(l,"怪蛇正在战斗中，无法收入蛇杖之上。") then
		run("stop she "..sheid)
		wait.make(function()
			local _f=function() run("convert she") end
			wait.time(1);_f()
		end)
	end
	if me.menpai=="bt" and findstring(l,"[> ]*"..killname.."脚下一个不稳，跌在地上昏了过去。") then
		run("kill "..killid)
		sheid=1
		run("stop she "..sheid)
		if skillslist["hamagong"]==nil then skillslist["hamagong"]={} end
		if skillslist["hamagong"]["lvl"]==nil then skillslist["hamagong"]["lvl"]=1 end
		if addforce~=nil and addforce>0 and skillslist["hamagong"]~=nil and skillslist["hamagong"]["lvl"]~=nil and skillslist["hamagong"]["lvl"]<me.maxlvl and skillslist["hamagong"]["lvl"]<751 then
			addforce=0
			alias.uw()
			run("perform puji")
		end
	end
	if findstring(l,"你的毒功不够，不能化对方的丹元！") then xx.suck=0 end
	if findstring(l,"你觉得.+的内力自手掌源源不绝地流了进来。") then
		xx.suck=2
	end
	if findstring(l,".+已经内力涣散，你已经无法从他体内吸取任何真气了！") then
		xx.suck=2
		run("yun huagong "..killid)
	end
	if findstring(l,"你吸取的内力充塞全身，无法再吸取内力！") then
		xx.suck=0
		run("yun jiexin "..killid..";yun huagong "..killid)
	end
	if findstring(l,"你觉得.+的真气自手掌源源不绝地流了进来。") then
		xx.suck=1
	end
	if findstring(l,".+已经真气涣散，你已经无法从他体内吸取真气了！") then
		if suckLimited==0 then
			xx.suck=1
			run("yun huagong "..killid)
		end
		run("yun jiemai "..killid)
	end
	--if findstring(w[0],".+已经内力涣散，你已经无法从他体内吸取任何真气了！",".+已经真气涣散，你已经无法从他体内吸取真气了！") then
	--	xx.suck=2
	--	if always.xxblow>0 and workflow.nowjob=="fj" and fjweapon=="" then run("perform quhuo "..killid) end
	--	if workflow.nowjob=="yb " then xx.suck=0 else run("yun huagong "..killid) end
	--end
	if findstring(w[0],"你转手间已经将连环化功施展开来，但见人影交错间你精神瞬时振奋") then
		xx.suck=2
		if always.xxblow>0 and workflow.nowjob=="fj" and fjweapon=="" then run("perform quhuo "..killid) end
		--if workflow.nowjob=="yb" or suckLimited==1 then xx.suck=0;run("yun jiexin "..killid) else run("yun huagong "..killid) end
		if suckLimited==1 then xx.suck=0;run("yun jiexin "..killid) else run("yun huagong "..killid) end
	end
	if findstring(l,"你挥剑而上，迎着"..yp.name.."的这招.+直劈过去，直震的.+手臂发麻，再也提不起半分力气。","护法喇嘛口中默念大明六字真言，手结摩利支天愤怒印，运起.+龙.+象之力！","你赶紧向後跃开数丈，躲开他的攻击。") and findstring(killpfm,"yield yes") then
		_tb=Split(killpfm,"|")
		if pfmid<#_tb then pfmid=pfmid+1 end
		if killskill~=nil and string.len(killskill)>0 then
			wieldweapon=1
			if killskill=="staff" then alias.wi(staffid) else alias.wi(killskill) end
		end
	end
	if findstring(l,"你已在使用逍遥游了","你已经使出了逍遥回旋步","你身法突然加快","突然你跃起，大袖飞舞") then
		_tb=Split(killpfm,"|")
		if pfmid<#_tb then pfmid=pfmid+1 end
	end
end
function kill_pfm.dosomething2(n,l,w)
	local _tb
	if findstring(w[0],"你使出打狗棒法「缠」字诀，幻出连山棒影，将.+吞没！\n结果他被你缠了个手忙脚乱，一时无法还招进攻！") then
		_tb=Split(killpfm,"|")
		if pfmid<#_tb then pfmid=pfmid+1 end
	end
end
function kill_pfm.dosomething3(n,l,w)
	if findstring(w[0],"你用蛇杖示意怪蛇停下来。\n可是怪蛇理都不理。") then
		sheid=sheid+1
		run("stop she "..sheid)
	end
	if findstring(w[0],"从现在起你用零点内力伤敌。\n什么？") then
		-- #if @debug {#say 出现蛇已在staff上，但还要继续收蛇}
		--closeclass("kill_"..me.menpai)
		closeclass("kill")
		closeclass("kill_pfm")
		run("set killover="..killaction)
	end
	if findstring(w[0],"你发现(.+)的身法中有些许破绽。\n如果这时偷袭成功，可以打的对手全无还手之力。") then
		if xy.pfm()>0 then run("perform shoot") end
	end
end
function kill_pfm.dosomething4(n,l,w)
	if findstring(l,"突然你阴阴一笑，瞅准机会，右手猛地向.+拍去！\n.+转身不灵，难以闪避，只得挺右手相抵。到此地步，已是高手比拼真力") then
		xx.suck=2
	end
end
function kill_pfm.getflood()  --flood技能判断普通攻击出招后再刷，多输出一轮平A
	local _tb 
	_tb=Split(killpfm,"|")
	if _tb[pfmid]=="qklm" then
		--AddTrigger ("change_clour","(少商剑|商阳剑|中冲剑|关冲剑|少冲剑|少泽剑|你张牙舞爪)","print('大风云飞出招')", 1+8+32+1024+32768, custom_colour.Custom1, 0, "", "", 12, 100)
		AddTrigger("fylm", "(少商剑|商阳剑|中冲剑|关冲剑|少冲剑|一条气流从少冲穴中激射而出|少泽剑|你张牙舞爪)", "", 1+8+32+1024+32768, custom_colour.NoChange, 0, "", "kill_pfm.doflood1")
		SetTriggerOption("fylm","group","doflood")
	elseif _tb[pfmid]=="pfmxtjf" then
		AddTrigger("pfmxtjf","你吸了一口气，将内力收回丹田，剑招也恢复正常！", "", 1+8+32+1024+32768, custom_colour.NoChange, 0, "", "kill_pfm.doflood1")
		SetTriggerOption("pfmxtjf","group","doflood")
	end
end
function kill_pfm.doflood1()
	local _tb 
	_tb=Split(killpfm,"|")
	if _tb[pfmid]=="qklm" then
		run("set pfmflood")
		AddTrigger("floodpfm", "你目前还没有任何为 pfmflood 的变量设定。", "", 1+8+32+1024+32768, custom_colour.NoChange, 0, "", "kill_pfm.doflood")
		SetTriggerOption("floodpfm","group","doflood")
	elseif _tb[pfmid]=="pfmxtjf" then
		run("jifa sword quanzhen-jian;perform sanqing;jifa")
	end
end
function kill_pfm.doflood()
  --if npcfaint then return end  --如果NPC已经晕倒，就不再pfm
	local _tb 
	_tb=Split(killpfm,"|")
	if _tb[pfmid]=="qklm" and skillslist["dafeng-yunfei"]~=nil and jifa.strikename=="dafeng-yunfei" and skillslist["dafeng-yunfei"]["lvl"]>280 then
		--print("大风云飞出招")
		run("bei none;bei dafeng-yunfei liumai-shenjian;perform feiyun;bei none;bei liumai-shenjian")
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function kill.update()
	local _tb,_tb2
	_tb={
		"你刚刚压制住身上伤势，还是不要妄动真气。",
		"你目前还没有任何为 .+ 的变量设定。",
		"你转身不灵，难以闪避，只得挺右手相抵。到此地步，已是高手比拼真力。",
		"你所使用的外功中没有这种功能。",
		"你.+麻木，无力再使.+", 
		"你请先用 enable 指令选择你要使用的外功。",
		"你伸了伸腰，长长地吸了口气。",
		"只听见.+一声，你手中的(.+)已经断为两截！",
		"你只觉得“神门穴”上一阵酸麻，手指无力，.+拿捏不稳，抛在地下！",
		"你手中.+已在外围，情急之下只好放弃.+，双手当胸，挡开这一招。",
		"你猛觉得劲风罩来，心知不妙，手中.+脱手飞出，赶紧也是双掌向前平推。",
		".+你只觉得手中.+把持不定，脱手飞出！",
		".+你只觉虎口一热，.+顿时脱手而出",
		"你.+麻木，哐当一声，.+掉到了地上。",
		"这里没有这个人。",
		"这里没有 .+。",
		"你想杀谁？",
		".+只能在战斗中使用。",".+只能对战斗中的对手使用。",
		".+深深吸了几口气，强行压制住了身上的伤势。",
		".+倒在地上，挣扎了几下就死了。",
		".+已经陷入半昏迷状态，随时都可能摔倒晕去。",
		".+慢慢睁开眼睛，清醒了过来。",
		".+脚下一个不稳，跌在地上昏了过去。",
		"你这招内劲所注，力道强横之极，.+竟将.+拦腰削成了上下两截！",
		"你对著.+喝道：「.+」",
		"你捡起.+。",
		"你.+握在手中","你.+取出白龙剑","你已经装备著了","你必须先放下你目前装备的武器",
		}
	local  kill_triggerlist={
	       {name="kill_dosth1",regexp=linktri(_tb),script=function(n,l,w)    kill.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(kill_triggerlist) do
		addtri(v.name,v.regexp,"kill",v.script,v.line)
	end
	local  kill_m_triggerlist={
	       {name="kill_m_dosth1",line=2,regexp="^(> > > |> > |> |)看来该找机会逃跑了\\.\\.\\.\\n\\S+ -\\Z",script=function(n,l,w)    kill.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(kill_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"kill",v.script,v.line)
	end
	closeclass("kill")
	
	_tb={
	"\\s+这里唯一的出口是 .+。",
	"\\s+这里明显的出口是 .+。",
	"草寇向你一阵阴笑：爽快的将宝贝交出来，不然叫你后悔莫及！","山贼大吼道：赶快将宝贝交出来，不然你就别指望活着离开！","星宿派弟子恶狠狠地威胁道：快将宝贝交出来，否则取你狗命！",
	"你哼了一声，问.+道：「你会唱“十八摸”罢？唱一曲来听听。」",
	"你目前还没有任何为 resetSafe=yes 的变量设定。",
	"你要对谁做 18mo 这个动作？",
	"你在.+的耳边悄声说道：等着瞧，兔子！","有话慢慢说, 不要着急",
	"这个方向没有出路。",
	}
	local  kill_run_triggerlist={
	       {name="kill_run_dosth1",regexp=linktri(_tb),script=function(n,l,w)    kill_run.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(kill_run_triggerlist) do
		addtri(v.name,v.regexp,"kill_run",v.script,v.line)
	end
	closeclass("kill_run")
	
	_tb={
	"你脸色转白","你微觉疲惫","你感到丹田真气混浊","你只觉真气运转不畅","你玉女心经心法渐渐散去","你的龙象之力运行完毕","你的混天气功运行完毕",
	"你已经催动","你双掌合十","你已在运转枯荣心法","只听你嘿嘿嘿几声奸笑","你脸上青气大盛","你正在运用","你微一凝神","你面色陡变","你已经在运用化功大法","忽见你眼中红光时隐时现","你所聚太阴炼形法之气已散开","你刚刚才使用了太阴炼形法","只见你微微一笑","你口中默念大明六字真言","你已经在运龙象之力","你凝神默然运功","你微一凝神","你已在使用混天神罡了",
	"你龙行虎步，隐有君王之色，信手点去，一指戳在了","你面色凝重，气贯丹田，单指缓缓戳出，一股内力破空而出，正中","你向前疾跨一步，左手需晃一招，右手双指直戳，点中了",
	".+目前正自顾不暇","你长啸一声","你挥出一拳","你连续几拳","你轻轻挥出一拳","你纵跃退後",".+在空中旋转飞行之势已弱",".+在你身旁绕了个圈子","只听.+闷哼了一声, 后心已被你指力戳中.",
	"你当即将紫霞神功都运到了.+剑上，呼的一剑，朝.+当头直劈！","你微一运劲，只觉丹田内息紊乱，无力使出绝招！","你正在使用「雷动九天」，无法分神使用其他招数。","你正在使用气宗绝技，不能施展「夺命连环三仙剑」。",
	"只听得你一声大喝，拳风突然变得猛劲之极，身法却更加飘忽难测！","你已在使用雷动九天了！",
	"你缓缓吸了一口气，将内劲收回丹田。",
	"你双手合十念佛，刹那间四周地动山摇，发出隆隆巨响！","你已经发动了金刚神通！",
	"你缓缓吸了一口气，收回金刚神通，身形又恢复了原状。",
	"你身法突然加快，身形更加飘忽！在敌招中仍然逍遥自在，游刃有余！","你已在使用逍遥游了！",
	"突然你跃起，大袖飞舞，东纵西跃，双手绞成蛇行,身法轻灵之极,回旋往复，真似一只玉燕、一只大鹰翩翩飞舞一般。","你已经使出了逍遥回旋步！",
	"你「唰」的一声抽出一.+剑握在手中。","你已经装备著了。",
	"你将手中的.-剑插回剑鞘。",
	"经过一阵调息运气，你觉得丹田中原本紊乱的内息恢复了正常。",
	"你大喝一声，剑招突变，.+剑逼出雪亮光芒，一剑化为.+剑",
	"你运起纯阳神通功，片刻之间，白气笼罩全身，双眼精光四射，身手分外矫健，进退神速，与平时判若两人。",
	"你凌空出指，一股内力击中.+的.+，.+急忙运气与你的内劲对抗，虽然大耗内力，但是终于没有被点中穴道。",
	"你面色凝重，气贯丹田，单指缓缓戳出，一股内力破空而出，正中.+的.+！",
	"你吸了一口气，将内力收回丹田，剑招也恢复正常！",
	"你此时心念空明，悟彻佛家神通，刀锋过处，招数就如一叶一叶的莲花花瓣自手中源源不断地弹出！","你内息运转不断，功力节节提升，出手越来越快，“混元一气功”催在刀上所发出的热浪把.+压得喘不过气来！","你手中.+刀连环不断向前劈出，却都以弧形收回，刀势犹若片片莲花花瓣。",
	"你需要五个轮子才能使用「五轮大转」。",
	"佛光普照乃是内家功夫，你现在内力不足，使不出这一招。","佛光普照乃是内家功夫，掌上不带内力使不出来",
	"紧接着，你御剑成风，剑招快闪绝伦，闪电般攻出了峨嵋.+绝剑。",
	"你已经在双剑和璧了。","你的左右互搏不够熟练，不能很好的使出双剑合璧的精妙之处！","必须持有双剑才能和璧左右互搏！","你的剑法修为不够！","你突然间左手抽出另一把剑，双手使出截然不同的剑法，正是左右互搏绝技。",
	"这不是你的蛇，它不会听从你的指挥的。",
	"怪蛇看了看你，突然似箭一般跃起，准确地落在蛇杖上，盘了起来。","蛇杖上已有一条蛇了，怪蛇挤不上去！",
	"你有放蛇出来吗？",
	"你只能在战斗中与怪蛇配合。",
	"怪蛇正在战斗中，无法收入蛇杖之上。",
	".+脚下一个不稳，跌在地上昏了过去。",
	"你的毒功不够，不能化对方的丹元！",
	"你觉得.+的内力自手掌源源不绝地流了进来。","你觉得.+的真气自手掌源源不绝地流了进来。",".+已经内力涣散，你已经无法从他体内吸取任何真气了！","你吸取的内力充塞全身，无法再吸取内力！",
	"你转手间已经将连环化功施展开来，但见人影交错间你精神瞬时振奋",".+已经内力涣散，你已经无法从他体内吸取任何真气了！",".+已经真气涣散，你已经无法从他体内吸取真气了！",	
	"你挥剑而上，迎着.+的这招.+直劈过去，直震的.+手臂发麻，再也提不起半分力气。",
	"护法喇嘛口中默念大明六字真言，手结摩利支天愤怒印，运起.+龙.+象之力！"
	}
	local  kill_pfm_triggerlist={
	       {name="kill_pfm_dosth1",regexp=linktri(_tb),script=function(n,l,w)    kill_pfm.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(kill_pfm_triggerlist) do
		addtri(v.name,v.regexp,"kill_pfm",v.script,v.line)
	end
	local  kill_gb_m_triggerlist={
	       {name="kill_gb_m_dosth1",line=2,regexp="^(> > > |> > |> |)你使出打狗棒法「缠」字诀，幻出连山棒影，将.+吞没！\\n结果他被你缠了个手忙脚乱，一时无法还招进攻！\\Z",script=function(n,l,w)    kill_pfm.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(kill_gb_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"kill_pfm",v.script,v.line)
	end
	_tb2={
		"你用蛇杖示意怪蛇停下来。\\n可是怪蛇理都不理。\\Z",
		"从现在起你用零点内力伤敌。\\n什么？\\Z",
		"你发现(.+)的身法中有些许破绽。\\n如果这时偷袭成功，可以打的对手全无还手之力。\\Z",
	}
	local  kill_bt_m_triggerlist={
	       {name="kill_bt_m_dosth2",line=2,regexp=linktri(_tb2),script=function(n,l,w)    kill_pfm.dosomething3(n,l,w)  end,},
	}
	for k,v in pairs(kill_bt_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"kill_pfm",v.script,v.line)
	end
	local  kill_xx_m_triggerlist={
	       {name="kill_xx_m_dosth1",line=2,regexp="^(> > > |> > |> |)突然你阴阴一笑，瞅准机会，右手猛地向.+拍去！\\n.+转身不灵，难以闪避，只得挺右手相抵。到此地步，已是高手比拼真力\\Z",script=function(n,l,w)    kill_pfm.dosomething4(n,l,w)  end,},
	}
	for k,v in pairs(kill_xx_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"kill_pfm",v.script,v.line)
	end
	closeclass("kill_pfm")
end
kill.update()