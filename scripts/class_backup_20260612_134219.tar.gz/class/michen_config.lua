function _isopen(a)
	if a~=nil and a>0 then return "����" else return "�ر�" end
end

-- cfg �����нӿڣ����ԭ MushClient InfoBox GUI ��ť����
cfg = cfg or {}

function cfg.idle()
	if setting_resetidle>0 then setting_resetidle=0 else setting_resetidle=1 end
	if setting_resetidle>0 then resetidle=1 else resetidle=0 end
	Note("������ ".._isopen(setting_resetidle))
end

function cfg.fj()
	if workflow.fj>0 then workflow.fj=0 else workflow.fj=1 end
	Note("FJģ�� ".._isopen(workflow.fj))
end

function cfg.mp()
	if workflow.mp>0 then workflow.mp=0 else workflow.mp=1 end
	Note("MPģ�� ".._isopen(workflow.mp))
end

function cfg.xf()
	if workflow.xf>0 then workflow.xf=0 else workflow.xf=1 end
	Note("XFģ�� ".._isopen(workflow.xf))
end

function cfg.cm()
	if workflow.cm>0 then workflow.cm=0 else workflow.cm=1 end
	Note("CMģ�� ".._isopen(workflow.cm))
end

function cfg.yb()
	if workflow.yb>0 then workflow.yb=0 else workflow.yb=1 end
	Note("YBģ�� ".._isopen(workflow.yb))
end

function cfg.ftb()
	if workflow.ftb>0 then workflow.ftb=0 else workflow.ftb=1 end
	Note("FTBģ�� ".._isopen(workflow.ftb))
end

function cfg.qzwd()
	if workflow.qzwd>0 then workflow.qzwd=0 else workflow.qzwd=1 end
	Note("QZWD ".._isopen(workflow.qzwd))
end

function cfg.set_neili_job(neili)
	if neili~=nil then
		set_neili_job=tonumber(neili) or set_neili_job
	end
	Note("�������� "..tostring(set_neili_job).."%")
end

function cfg.set_neili_global(neili)
	if neili~=nil then
		set_neili_global=tonumber(neili) or set_neili_global
	end
	Note("ȫ������ "..tostring(set_neili_global).."%")
end

function cfg.set_GbSecretWay()
	if set_GbSecretWay>0 then set_GbSecretWay=0 else set_GbSecretWay=1 end
	Note("�ܵ� ".._isopen(set_GbSecretWay))
end

function cfg.resetstatus()
	mark.time=os.time()
	mark.sTime=os.time()
	addneili.fj=0
	addneili.dazuo=0
	addneili.dahuandan=0
	addneili.putizi=0
	list.shizhe=""
	list.putizi=""
	list.pk=""
	cmd.waitcount=0
	sum.fj=0
	sum.mp=0
	sum.beg1=0
	sum.beg2=0
	sum.arrest=0
	sum.ftb=0
	sum.yb=0
	sum.war=0
	sum.death=0
	sum.lifesave=0
	count.fj=0
	count.mp=0
	count.ftb=0
	count.yb=0
	count.death=0
	count.lifesave=0
	resetExplist=""
	ErrList=""
	DeathList=""
	Note("ͳ��������")
end

function cfg.skill_xue(...)
	local args = {...}
	if args[1]~=nil and args[1]~="" then
		skills_xue = args[1]
	end
	Note("ѧϰ����: "..tostring(skills_xue or "δ����"))
end

function cfg.skill_lingwu(...)
	local args = {...}
	if args[1]~=nil and args[1]~="" then
		skills_lingwu = args[1]
	end
	Note("������: "..tostring(skills_lingwu or "δ����"))
end

function cfg.potuseC()
	if usepot=="xue" then return "ѧϰ"
	elseif usepot=="lingwu" then return "����"
	elseif usepot=="jingyao" then return "��Ҫ"
	else return "��ʹ��" end
end

function cfg.potuse()
	if usepot=="none" then usepot="xue"
	elseif usepot=="xue" then usepot="lingwu"
	elseif usepot=="lingwu" then usepot="jingyao"
	else usepot="none" end
	Note("Ǳ��: "..cfg.potuseC())
end

function cfg.xuelitC()
	if wantxuelit<2 then return "����"
	elseif wantxuelit==2 then return "ѧϰ"
	elseif wantxuelit==3 then return "��ѧ"
	end
end

function cfg.xuelit()
	if wantxuelit<2 then wantxuelit=2
	elseif wantxuelit==2 then wantxuelit=3
	elseif wantxuelit==3 then wantxuelit=1
	end
	Note("ѧ�Ļ� "..cfg.xuelitC())
end

function cfg.xuefirstC()
	if xuefirst>0 then return "����" else return "���" end
end

function cfg.xuefirst()
	if xuefirst==0 then xuefirst=1 else xuefirst=0 end
	Note("ѧϰ"..cfg.xuefirstC().."�ڹ�")
end

function cfg.lingwuatC()
	if lingwuat=="menpai" then return "����" else return "����" end
end

function cfg.lingwuat()
	if lingwuat=="menpai" then lingwuat="shaolin" else lingwuat="menpai" end
	Note("����ص� "..cfg.lingwuatC())
end

-- ���ݾɽű��� infobtn.xxx ���ã�ת���� cfg.xxx
infobtn = infobtn or {}
setmetatable(infobtn, {__index = function(_, key)
	if cfg[key] then
		return cfg[key]
	end
	return function() end
end})

-- cfg.status() -- ��ʾ����������ĵ�ǰ״̬
function cfg.status()
	Note("===== ����״̬���� =====")
	Note("")
	Note("-- ģ�鿪�� --")
	Note("  ������     : ".._isopen(setting_resetidle))
	Note("  FJģ��     : ".._isopen(workflow.fj))
	Note("  MPģ��     : ".._isopen(workflow.mp))
	Note("  XFģ��     : ".._isopen(workflow.xf))
	Note("  CMģ��     : ".._isopen(workflow.cm))
	Note("  YBģ��     : ".._isopen(workflow.yb))
	Note("  FTBģ��    : ".._isopen(workflow.ftb))
	Note("  QZWD       : ".._isopen(workflow.qzwd))
	Note("  �ܵ�       : ".._isopen(set_GbSecretWay))
	Note("")
	Note("-- ��ֵ���� --")
	Note("  ��������   : "..tostring(set_neili_job).."%")
	Note("  ȫ������   : "..tostring(set_neili_global).."%")
	Note("")
	Note("-- �������� --")
	Note("  Ǳ����;   : "..cfg.potuseC())
	Note("  ѧ�Ļ�     : "..cfg.xuelitC())
	Note("  ѧϰ����   : "..cfg.xuefirstC())
	Note("  ����ص�   : "..cfg.lingwuatC())
	Note("  ѧϰ����   : "..tostring(skills_xue or "δ����"))
	Note("  ������   : "..tostring(skills_lingwu or "δ����"))
	Note("")
	Note("========================")
end

-- ============================================================
-- Web UI ���� API��cfg.schema / cfg.data / cfg.update
-- ============================================================

-- cfg.schema: ������Ԫ���ݶ��壨�� Web UI ��Ⱦ������
cfg.schema = {
	-- ģ�鿪��
	{ key="setting_resetidle", label="������", type="boolean", category="����",
	  getter=function() return setting_resetidle and setting_resetidle>0 end,
	  setter=function(v) local n=v and 1 or 0; setting_resetidle=n; resetidle=n end },
	{ key="workflow.fj",       label="FJģ��",  type="boolean", category="����",
	  getter=function() return workflow.fj and workflow.fj>0 end,
	  setter=function(v) workflow.fj=v and 1 or 0 end },
	{ key="workflow.mp",       label="MPģ��",  type="boolean", category="����",
	  getter=function() return workflow.mp and workflow.mp>0 end,
	  setter=function(v) workflow.mp=v and 1 or 0 end },
	{ key="workflow.xf",       label="XFģ��",  type="boolean", category="����",
	  getter=function() return workflow.xf and workflow.xf>0 end,
	  setter=function(v) workflow.xf=v and 1 or 0 end },
	{ key="workflow.cm",       label="CMģ��",  type="boolean", category="����",
	  getter=function() return workflow.cm and workflow.cm>0 end,
	  setter=function(v) workflow.cm=v and 1 or 0 end },
	{ key="workflow.yb",       label="YBģ��",  type="boolean", category="����",
	  getter=function() return workflow.yb and workflow.yb>0 end,
	  setter=function(v) workflow.yb=v and 1 or 0 end },
	{ key="workflow.ftb",      label="FTBģ��", type="boolean", category="����",
	  getter=function() return workflow.ftb and workflow.ftb>0 end,
	  setter=function(v) workflow.ftb=v and 1 or 0 end },
	{ key="workflow.qzwd",     label="QZWD",    type="boolean", category="����",
	  getter=function() return workflow.qzwd and workflow.qzwd>0 end,
	  setter=function(v) workflow.qzwd=v and 1 or 0 end },
	{ key="set_GbSecretWay",   label="�ܵ�",    type="boolean", category="����",
	  getter=function() return set_GbSecretWay and set_GbSecretWay>0 end,
	  setter=function(v) set_GbSecretWay=v and 1 or 0 end },
	-- ��ֵ����
	{ key="set_neili_job",     label="��������%",   type="number", category="��ֵ", min=0, max=500,
	  getter=function() return set_neili_job end,
	  setter=function(v) set_neili_job=tonumber(v) or set_neili_job end },
	{ key="set_neili_global",  label="ȫ������%",   type="number", category="��ֵ", min=0, max=500,
	  getter=function() return set_neili_global end,
	  setter=function(v) set_neili_global=tonumber(v) or set_neili_global end },
	-- ����ѡ��
	{ key="usepot",            label="Ǳ����;",  type="option", category="ѡ��",
	  options={"none","xue","lingwu","jingyao"},
	  option_labels={"��ʹ��","ѧϰ","����","��Ҫ"},
	  getter=function() return usepot end,
	  setter=function(v) usepot=v end },
	{ key="wantxuelit",        label="ѧ�Ļ�",    type="option", category="ѡ��",
	  options={1,2,3}, option_labels={"��ѧ","ѧϰ","��ѧ"},
	  getter=function() return wantxuelit end,
	  setter=function(v) wantxuelit=tonumber(v) or wantxuelit end },
	{ key="xuefirst",          label="ѧϰ�ڹ�",  type="boolean", category="ѡ��",
	  getter=function() return xuefirst and xuefirst>0 end,
	  setter=function(v) xuefirst=v and 1 or 0 end },
	{ key="lingwuat",          label="����ص�",  type="option", category="ѡ��",
	  options={"menpai","shaolin"}, option_labels={"����","����"},
	  getter=function() return lingwuat end,
	  setter=function(v) lingwuat=v end },
	{ key="skills_xue",        label="ѧϰ����",  type="string", category="ѡ��",
	  getter=function() return skills_xue end,
	  setter=function(v) skills_xue=v end },
	{ key="skills_lingwu",     label="������",  type="string", category="ѡ��",
	  getter=function() return skills_lingwu end,
	  setter=function(v) skills_lingwu=v end },
}

-- cfg.data(): ������ǰ��������ֵ + Ԫ���ݣ��� Web UI / JSON ���л���
function cfg.data()
	local result = {}
	for _, field in ipairs(cfg.schema) do
		local entry = {
			key = field.key,
			label = field.label,
			type = field.type,
			category = field.category,
			value = field.getter(),
		}
		if field.type == "number" then
			entry.min = field.min
			entry.max = field.max
		elseif field.type == "option" then
			entry.options = field.options
			entry.option_labels = field.option_labels
		end
		table.insert(result, entry)
	end
	return result
end

-- cfg.update(changes): ���� key��value ӳ�������֤��Ӧ��
-- changes = { setting_resetidle = true, set_neili_job = 200, ... }
-- ���� { ok = true/false, errors = { key = "������Ϣ", ... } }
function cfg.update(changes)
	if type(changes) ~= "table" then
		return { ok=false, errors={ _global="���������� table" } }
	end
	local errors = {}
	local schema_map = {}
	for _, field in ipairs(cfg.schema) do
		schema_map[field.key] = field
	end
	for key, value in pairs(changes) do
		local field = schema_map[key]
		if not field then
			errors[key] = "δ֪������"
		else
			-- ���ͼ����ת��
			local ok, err = cfg._validate(field, value)
			if not ok then
				errors[key] = err
			else
				-- Ӧ��ֵ
				local success, apply_err = pcall(field.setter, value)
				if not success then
					errors[key] = "Ӧ��ʧ��: "..tostring(apply_err)
				end
			end
		end
	end
	if next(errors) then
		return { ok=false, errors=errors }
	end
	return { ok=true }
end

-- cfg._validate(field, value): �����ֶ���֤���ڲ�������
function cfg._validate(field, value)
	local t = field.type
	if t == "boolean" then
		if type(value) ~= "boolean" then
			return false, "��Ҫ����ֵ (true/false)"
		end
	elseif t == "number" then
		local n = tonumber(value)
		if n == nil then
			return false, "��Ҫ����"
		end
		if field.min ~= nil and n < field.min then
			return false, "��Сֵ "..tostring(field.min)
		end
		if field.max ~= nil and n > field.max then
			return false, "���ֵ "..tostring(field.max)
		end
	elseif t == "string" then
		if type(value) ~= "string" then
			return false, "��Ҫ�ַ���"
		end
	elseif t == "option" then
		local valid = false
		for _, opt in ipairs(field.options) do
			if tostring(opt) == tostring(value) then
				valid = true
				break
			end
		end
		if not valid then
			return false, "��Чѡ��"
		end
	end
	return true, nil
end

-- �һ�����/ֹͣ�������
function cfg.go()
	mark.gold=0
	mark.setpot=1
	ftbnpckilled=0
	weapon_id=1
	buzhen=false
	checkmove.NotGPSMove=1
	gpszeikou=""
	haveshizhe=0
	stat.reverse=0
	stat.powerup=0
	stat.daxiao=0
	stat.fengyun=0
	stat.tiandi=0
	stat.quiting=0
	stat.zhixin=0
	stat.huntianup=0
	stat.shengang=0
	stat.heji=0
	have.nousejy=0
	set_neili=set_neili_global
	set_GbSecretWay_err=0
	gold.roomNo=0
	burnnpc.have=0
	killaction=""
	gold.id=""
	alias.resetidle()
	run("hp;set rbt=start")
end

function cfg.stop()
	alias.initialize_trigger()
	print("��ֹͣ���й���")
end

-- ע�������б�����ͨ�� #cfg xxx ��������
AddAlias("cfg_idle",       "^#cfg idle$",                   "cfg.idle()",             33)
AddAlias("cfg_fj",         "^#cfg fj$",                     "cfg.fj()",               33)
AddAlias("cfg_mp",         "^#cfg mp$",                     "cfg.mp()",               33)
AddAlias("cfg_xf",         "^#cfg xf$",                     "cfg.xf()",               33)
AddAlias("cfg_cm",         "^#cfg cm$",                     "cfg.cm()",               33)
AddAlias("cfg_yb",         "^#cfg yb$",                     "cfg.yb()",               33)
AddAlias("cfg_ftb",        "^#cfg ftb$",                    "cfg.ftb()",              33)
AddAlias("cfg_qzwd",       "^#cfg qzwd$",                   "cfg.qzwd()",             33)
AddAlias("cfg_neili_job",  "^#cfg neili_job\\s*(.*)$",      "cfg.set_neili_job(%1)",  33)
AddAlias("cfg_neili_global","^#cfg neili_global\\s*(.*)$",   "cfg.set_neili_global(%1)",33)
AddAlias("cfg_secretway",  "^#cfg secretway$",              "cfg.set_GbSecretWay()",  33)
AddAlias("cfg_reset",      "^#cfg reset$",                  "cfg.resetstatus()",      33)
AddAlias("cfg_potuse",     "^#cfg potuse$",                 "cfg.potuse()",           33)
AddAlias("cfg_xuelit",     "^#cfg xuelit$",                 "cfg.xuelit()",           33)
AddAlias("cfg_xuefirst",   "^#cfg xuefirst$",               "cfg.xuefirst()",         33)
AddAlias("cfg_lingwuat",   "^#cfg lingwuat$",               "cfg.lingwuat()",         33)
AddAlias("cfg_skill_xue",      "^#cfg skill_xue$",                     "cfg.skill_xue()",             33)
AddAlias("cfg_skill_xue_set",  "^#cfg skill_xue\\s+(.+)$",             "cfg.skill_xue('%1')",         33)
AddAlias("cfg_skill_lingwu",      "^#cfg skill_lingwu$",                     "cfg.skill_lingwu()",             33)
AddAlias("cfg_skill_lingwu_set",  "^#cfg skill_lingwu\\s+(.+)$",             "cfg.skill_lingwu('%1')",         33)
AddAlias("cfg_go",         "^#go$",                          "cfg.go()",               33)
AddAlias("cfg_stop",       "^#stop$",                        "cfg.stop()",             33)
AddAlias("cfg_status",     "^#cfg status$",                   "cfg.status()",           33)
AddAlias("cfg_help",       "^#cfg$",                          "cfg.help()",             33)
AddAlias("cfg_help2",      "^#cfg help$",                     "cfg.help()",             33)

function cfg.help()
	Note("=== ���������б� ===")
	Note("#go             - �����һ�")
	Note("#stop           - ֹͣ�һ�")
	Note("#cfg idle        - ������ ��/��")
	Note("#cfg fj          - FJģ�� ��/��")
	Note("#cfg mp          - MPģ�� ��/��")
	Note("#cfg xf          - XFģ�� ��/��")
	Note("#cfg cm          - CMģ�� ��/��")
	Note("#cfg yb          - YBģ�� ��/��")
	Note("#cfg ftb         - FTBģ�� ��/��")
	Note("#cfg qzwd        - QZWD ��/��")
	Note("#cfg neili_job N - ��������ٷֱ�")
	Note("#cfg neili_global N - ȫ�������ٷֱ�")
	Note("#cfg secretway   - �ܵ� ��/��")
	Note("#cfg reset       - ����ͳ��")
	Note("#cfg potuse      - Ǳ����;�л�")
	Note("#cfg xuelit      - ѧ�Ļ�����")
	Note("#cfg xuefirst    - ѧϰ���ȼ��л�")
	Note("#cfg lingwuat    - ����ص��л�")
	Note("#cfg skill_xue [�����б�]   - ����ѧϰ���ܣ��� sword|blade|force��")
	Note("#cfg skill_lingwu [�����б�] - ���������ܣ��� sword|blade|parry��")
	Note("  �޲���ʱ��ʾ��ǰ�б�")
	Note("#cfg status      - �鿴�������õ�ǰ״̬")
	Note("===================")
end
