function alias.atconnect()
	print("Connecting...")
	alias.initialize_variable()
	alias.initialize_trigger()
	openclass("login")
	Execute("n")
	Execute(me.charid)
	accessing=1
end
function Split(szFullString, szSeparator)
  if szFullString==nil then 
	szFullString="" 
	print("������Ϊnil���˴�������")
  end
  local nFindStartIndex = 1
  local nSplitIndex = 1
  local nSplitArray = {}
  while true do
    local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
    if not nFindLastIndex then
      nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
      break
	end
    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
    nFindStartIndex = nFindLastIndex + string.len(szSeparator)
    nSplitIndex = nSplitIndex + 1
  end
  return nSplitArray
end
function alias.loop(a,b)	--����ģ��zmud ��"#"
	local _t,_t1
	if tonumber(a)==nil or b==nil then 
		print("ѭ�������ʽ����")
		return 
	elseif tonumber(a)>500 then
		print("ѭ�����ֲ��ó���500��")
		return
	end
	_t,_t1=string.find(b," i")
	if _t==nil or _t+1~=_t1 then
		for i=1,a,1 do run(b) end
	else
		for i=1,a,1 do run(string.sub(b,1,_t-1).." "..i) end
	end
	run("set loop=over")
end
function alias.setproxy(a,b,c) --�������ô���������
	if a~=nil and tonumber(b)~=nil and tonumber(c)~=nil then
		SetAlphaOption("proxy_server",a)
		SetOption("proxy_port",b)
		SetOption("proxy_type",c)
	else
		print("�����ʽ����ȷ,�밴��'setproxy ip port 0\1\\2'��ʽ��д(0-�رմ�����1-sock4��2-sock5")
	end
end
function alias.atdisconnect()
	if not IsConnected() then Connect() end
end
function sum.all()
	----if me.menpai=="xx" then 
		--return tonumber(sum.fj+sum.mp+sum.xxlingpai+sum.ftb+sum.yb+sum.death+sum.war)
	--else
		return tonumber(sum.fj+sum.mp+sum.ftb+sum.yb+sum.death+sum.war)
	--end
end
function avg.all()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	return math.floor(sum.all()*3600/a)
end
function avg.fj()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	return math.floor(sum.fj*3600/a)
end
function avg.mp()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	if me.menpai=="gb" then
		stat.avgbeg1=math.floor(sum.beg1*3600/a)
		stat.avgbeg2=math.floor(sum.beg2*3600/a)	
	end
	return math.floor(sum.mp*3600/a)
end
function avg.ftb()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	return math.floor(sum.ftb*3600/a)
end
function avg.yb()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	return math.floor(sum.yb*3600/a)
end
function avg.war()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	return math.floor(sum.war*3600/a)
end
function avg.death()
	local a
	if os.time()-mark.sTime==0 then a=1 else a=os.time()-mark.sTime end
	return math.floor(sum.death+sum.lifesave*3600/a)
end
function countTime()
	local a,b,c,d,e
	a=math.floor(((os.time()-mark.sTime)/60)/60)
	b=math.floor(a/24)
	e=math.floor(math.fmod((os.time()-mark.sTime)/60,60))
	c=""
	if a>0 then
		if b>0 then
			d=math.fmod(a,24)
			c=b.."��"..d.."ʱ"..e.."��"
		else
			c=a.."ʱ"..e.."��"
		end
	else
		c=e.."��"
	end
	return c
end
function alias.setstatus()
	local a,b,c,d,e,f
	a=""
	b=""
	if workflow.nowjob=="cm" and os.time()>stat.cmbuff then
		f=workflow.nowjob.."��"
	else
		f=workflow.nowjob
	end
	if havefj>0 then c="��FJ" else c="��FJ" end
	if workflow.nowjob=="war" and war.people_dead~=nil then
		if ybjob.needfangqi>0 then 
			d="Ѻ��ʧ�ܣ�"..war['people_dead'].."��"
		elseif ybLimited>0 then
			d="Ѻ�������ޣ�"..war['people_dead'].."��"
		else d="��"..war['people_dead'].."��"
		end
	elseif ybjob.needfangqi>0 then 
		d="Ѻ��ʧ��"	
	elseif ybjob.ybstatus==1 then 
		d="ȡ��·��"..os.time()-ybLimitedMarkTime.."��,���"..ybexp.."����"
	elseif ybjob.ybstatus==2 then
		d="�ͻ�·��"..os.time()-ybLimitedMarkTime.."��,���"..ybexp.."����"
	elseif ybjob.ybstatus==3 then
		d="���ھ�·��"..os.time()-ybLimitedMarkTime.."��,���"..ybexp.."����"
	elseif ybLimited>0 then
		d="Ѻ��������"
	else
		d=""
	end
	if workflow.nowjob=="fj" then a=fjzone..fjroom
	elseif workflow.nowjob=="yb" and ybjob.ybnpcname~=nil then 
		a=ybjob.ybnpcname
	else
		if workflow.nowjob=="ftb" or workflow.nowjob=="lzjob" then
			if ftbnpckilled<ftbnum then b=ftbnpckilled.."/"..ftbnum else b="���" end
			a=ftbzone..ftbroom.."("..tostring(ftbareanum)..") "..b
		end
	end
	if os.time()>war.ready then
		e="��"
	--elseif tonumber(wartime)~=nil and os.time()-wartime>3600 and sum.war>10000 then
	--	e="��"
	else
		e=""
	end
	if me.charname==nil then me.charname="" end
	if setting=="gb" then
		SetStatus("���� "..me.charname.." "..e.."ͳ:"..countTime().." ��:"..stat.addexp.." ��:"..stat.avgall.." (FJ:"..stat.avgfj.." MP:"..stat.avgmp.."(beg1:"..stat.avgbeg1.."beg2:"..stat.avgbeg2..") FTB:"..stat.avgftb.." YB:"..stat.avgyb.." WAR:"..stat.avgwar..") ����:"..stat.avgdeath.." "..stat.countdeath.."�� | ���� "..f.." "..a.." "..c.." "..d.." Ver."..version)
	elseif setting~="dm" then 
		SetStatus("���� "..me.charname.." "..e.."ͳ:"..countTime().." ��:"..stat.addexp.." ��:"..stat.avgall.." (FJ:"..stat.avgfj.." MP:"..stat.avgmp.." FTB:"..stat.avgftb.." YB:"..stat.avgyb.." WAR:"..stat.avgwar..") ����:"..stat.avgdeath.." "..stat.countdeath.."�� | ���� "..f.." "..a.." "..c.." "..d.." Ver."..version)
	else
		SetStatus("���� "..me.charname.." ͳ��:"..countTime().." �ƶ�����: "..dm.liaoshangtimes.." ������æ: "..dm.throwtimes.." ��������:"..dm.lifesavetimes)
	end
end

function alias.stat()
	local a,b
	a="		"
	b=""
	if workflow.nowjob=="fj" and fjzone~="" then a="�ص�:	"..fjzone..fjroom end
	if workflow.nowjob=="ftb" and ftbzone~="" then a="�ص�:	"..ftbzone..ftbroom end
	if workflow.nowjob=="yb" and ybjob.ybnpcname~="" then a="ǰ��:	  "..ybjob.ybnpcname end
	if gxd.type==1 then
		b="���׶�ģʽ		������	��				��"
	elseif gxd.type==2 then
		b="���׶�ģʽ		�̶�ֵ	�����׶��趨ֵ		"..gxd.value.."	��"
	else
		b="���׶�ģʽ		�ٷֱ�	�����׶��趨ֵ		"..gxd.percent.."%	��"
	end
	print("	ʹ���ߣ�"..me.charname.."("..me.charid..")����������"..countTime().."�������EXP��"..stat.addexp.."��ƽ��ÿСʱ��"..stat.avgall)
	print("������������������������������������������������������������������������������������������������������������������")
	--print("��FJ����	"..count.fj.."	��MP����	"..count.mp.."	��FTP/LZ����		"..count.ftb.."	����������		"..stat.countdeath.."	��")
	--print("��FJ�����ٶ�	"..stat.avgfj.."	��MP�����ٶ�	"..stat.avgmp.."	��FTP�����ٶ�		"..stat.avgftb.."	����������		"..stat.avgdeath.."	��")
	print("�������� "..workflow.nowjob.." ����	��"..a.."	����������		"..stat.countdeath.."	����������		"..stat.avgdeath.."	��")
	print("��FJ����	"..count.fj.."	��MP����	"..count.mp.."	��FTP/LZ����		"..count.ftb.."	��YB����		"..count.yb.."	��")
	print("��FJ�����ٶ�	"..stat.avgfj.."	��MP�����ٶ�	"..stat.avgmp.."	��FTP�����ٶ�		"..stat.avgftb.."	��YB�����ٶ�		"..stat.avgyb.."	��")
	print("��FJ��������	"..addneili.fj.."	��������������	"..addneili.dazuo.."	����Ѫ��/�󻹵���������	"..addneili.dahuandan.."	����������������	"..addneili.putizi.."	��")
	print("�����˹��׶�	"..gxd.me.."	�����ɹ��׶�	"..gxd.mp.."	��"..b)
	print("������������������������������������������������������������������������������������������������������������������")
end
function kmq()
	if findstring(killpfm,"perform kong","perform ming") then return true else return false end
end
function pdfjsj()	--xue fj mp ftb xf yb cm
	local a
	if workflow.fj>0 and gxd.type==2 and me.menpai~="gm" and me.menpai~="th" then
		a=fjwaittime-(os.time()-fjend)
		if fjwaittime==0 or fjend==0 or a>999 or gxd.me>1000 then a=999 end
		if a<0 then a=0 end
	else
		a=999
	end
	return a
end
function pdmpsj()
	--if (workflow.mp>0 and mpJobLimited==0 and mpdrutime>0) or (me.menpai=="mj" and mj.yudi>0 and mj.haveyd>0) or (me.menpai=="gb" and ((mpJobLimited>0 and 3600-(os.time()-mpLimited.MarkTime)<=30) or (mpJobLimited==0 and gold.num<gold.setnum))) then return true else return false end
	if (me.menpai=="mj" and mj.yudi>0 and mj.haveyd>0 and workflow.mp==0) 
		or (me.menpai=="gb" and ((gb.Limited2>0 and 3600-(os.time()-mpLimited.MarkTimebeg2)<=30) or (gb.Limited1>0 and 3600-(os.time()-mpLimited.MarkTimebeg1)<=30) or ((gb.Limited1==0 or gb.Limited2==0) and gold.num<gold.setnum))) then 
		return true 
	else 
		return false 
	end
end
--[[function dz()
	local a
	a=math.floor(math.abs(jifa.force/100*me.xtgg))
	if have.xinfa>0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*1.25) 
	elseif have.szjing>0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*2) 
	elseif roomno_now==1422 and daytime==false then a=math.floor(math.abs(jifa.force/100*me.xtgg)*2) 
	elseif me.menpai=="gm" and roomno_now==2077 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*2) 
	elseif me.menpai=="bt" and roomno_now==1801 and stat.reverse>0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*1.5) 
	end
	if a<10 then a=10 end
	return a
end]]
function dz()
	local a
	if jifa.force~=nil and jifa.force>0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)) else a=101;run("jifa") end
	if have.xinfa>0 then 
		if jifa.forcename=="xiantian-gong" and roomno_now==785 then a=a*2
		elseif jifa.forcename=="xiantian-gong" then a=a*1.5
		else a=a*1.25
		end
	elseif have.szjing>0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*2)
	elseif roomno_now==1422 and daytimes==0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*1.5)
	elseif me.menpai=="gm" and roomno_now==2077 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*2)
	elseif me.menpai=="qz" and roomno_now==785 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*1.25)
	elseif me.menpai=="em" and roomno_now==2052 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*2.25)
    elseif me.menpai=="bt" and roomno_now==1801 and stat.reverse>0 then a=math.floor(math.abs(jifa.force/100*me.xtgg)*1.5)
	end
	if havefj==0 and hp.qi~=nil and jifa.force~=nil and (hp.qi-10)>(a*10) and not isopen("boat") and jifa.force>150 and (a*10)<(hp.maxneili*set_neili_global/100-hp.neili) and not isopen("fj_pre") then 
		alias.resetidle()
			a=a*10 
	end
	if a<10 then a=10 end
	return a
end
function dz_xs()
	local a 
	alias.resetidle()
	a=hp.maxneili*2-hp.neili-10
	if a>hp.qi-100 then a=hp.qi-100 end
	return a
end
function alias.gg()
	if setting~="dm" and setting~="keep" then run("drop all;halt") end
	if me.menpai=="xs" then have.suyouguan=0 end
	for i=1,5,1 do run("get book") end
	if have.xinfa>0 then run("get canye;get xinfa") end
	if have.lxj>0 then run("get longxiang jing") end
	if (setting=="dl" or do_dl_job>0) and dl.zeiid~=nil and dl.zeiid~="" then 
		run("get "..dl.zeiid) 
		for i=1,3,1 do run("get 1 gold") end
	end
	if (setting=="dl" or setting=="dlhbmz" or do_dl_job>0) then run("get tie lian;get huachu")
	elseif setting=="xs" then run("get guan;get lubo;get rentou lian;get fa ling;get suyou guan")
	elseif setting=="th" then run("get tie bagua");if (fjweapon=="jian" and mpweapon=="jian") then run("get xiao;get xiao") end
	elseif setting=="hs" then run("get sheng zi")
	elseif setting=="em" then run("get yaodai")
	end
	--if do_dl_job>0 then run("get tie lian") end
	if have.szjing>0 then run("get shenzhao jing") end
	if have.jyzj>0 then run("get jiuyin zhenjing") end
	if me.menpai~="xs" and me.menpai~="wd" then run("get shi he") end	--ѩɽ���䵱����Ҫ�ƴ���ʳ��
	--if weapon_now=="lun" then run("get 5 lun") else for i=1,2,1 do run("get "..weapon_now) end end
	local function getsmthing(a)
		if a=="staff" and staffid~=nil then a=staffid end
		if me.menpai=="bt" then run("get guai shezhang") end
		run("get "..a)
	end
	if fjweapon~="" then 
		if fjweapon=="lun" then
			--for i=1,5,1 do run("get 1 lun") end
			run("get "..me.lun.." lun")
		elseif needzhongjian()~=nil and needzhongjian()==1 then
			getsmthing("zhongjian")
		else
			getsmthing(fjweapon)
			getsmthing(fjweapon)
			if fjpfm=="jzpfm" and fjweapon=="dao" then getsmthing(fjweapon);getsmthing(fjweapon);getsmthing(fjweapon) end
			if me.menpai=="th" and (fjweapon=="jian" and mpweapon=="jian") then getsmthing("xiao");getsmthing("xiao") end
		end
	end
	if mpweapon~=fjweapon and mpweapon~="" then 
		getsmthing(mpweapon)
		getsmthing(mpweapon)
	end
	if ftbweapon~=fjweapon and ftbweapon~=mpweapon and ftbweapon~="" then 
		getsmthing(ftbweapon)
		getsmthing(ftbweapon)
	end
	if yb.weapon~=fjweapon and yb.weapon~=mpweapon and yb.weapon~=ftbweapon and yb.weapon~="" then 
		getsmthing(yb.weapon)
		getsmthing(yb.weapon)
	end
	if needzhongjian()~=nil and needzhongjian()==1 then run("drop zhongjian;drop zhongjian;drop xuantie jian;get zhongjian") end
	
	if yb.weapon~="jian" and (needzhongjian()==nil or needzhongjian()==0) and fjweapon~="jian" and mpweapon~="jian" and ftbweapon~="jian" and (workflow.qzwd>0 or findstring(skills_lingwu,"sword")) then 
		getsmthing("jian")
		getsmthing("jian")
	end
	run("get fire;get jiudai;get gold;get silver;get coin;get jinchuang yao")	
	if me.menpai=="bt" then 
		for i=1,7,1 do run("stop guai she "..i) end
		run("convert guai she")
		run("look guai shezhang")
	end
	if have.swjing>0 then
		for i=1,have.swjing,1 do run("get shouwu") end
	end
	if have.chaoxue>0 then run("get chao xue") end --С��ѥ
	if have.toukui>0 then run("get tou kui") end --ͷ��
	if have.zhangxinding>0 then run("get ding") end --�������Ƕ�
	if have.jinhua>0 then run("get jinhua biao") end --����
	if have.bichuan>0 then run("get bi chuan") end --����
	--if have.diamondring>0 then run("get diamond ring") end --��ʯ��ָ
	--if have.diamondnecklace>0 then run("get diamond necklace") end --��ʯ����
	--if have.diamondearring>0 and not me.sex then run("get diamond earring") end --��ʯ����
	run("wear all")
end
function alias.tt()
	if isopen("dazuo") then alias.tdz() end
	if isopen("skills_lian") then alias.tlw() end
end
function case_weapon(a)
	a=tonumber(a)
	if a==1 then return "û����" end
	if a==2 then return "��" end
	if a==3 then return "��" end
	if a==4 then return "��" end
	if a==5 then return "��" end
	if a==6 then return "��" end
	if a==7 then return "��" end
	if a==8 then return "��" end
end
function startjob()
	mark.gold=0
	--mark.setexp=1
	mark.setpot=1
	ftbnpckilled=0
	weapon_id=1
	--havefj=0
	--fjzone=""
	--fjroom=""
	--fjarea=""
	--fjroomid=0
	buzhen=false
	checkmove.NotGPSMove=1
	gpszeikou=""
	haveshizhe=0
	stat.reverse=0
	stat.powerup=0
	stat.daxiao=0
	stat.fengyun=0
	stat.tiandi=0
	stat.quiting=0
	stat.zhixin=0
	stat.huntianup=0
	stat.shengang=0
	stat.heji=0
	have.nousejy=0
	set_neili=set_neili_global
	set_GbSecretWay_err=0
	gold.roomNo=0
	burnnpc.have=0
	--me.drugbusy=0
	killaction=""
	gold.id=""
	alias.resetidle()
	--run("cha;jifa;score")
	--alias.ch()
	run("hp;set rbt=start")
end
function alias.initialize_variable()
	DiscardQueue()
	DeleteTemporaryTimers()
	idle=0
	flytoname=""
	flytonamelistindex=0
	flytonamelistsum=0
	flytonpc=""
	flytonpclistindex=0
	flytonpclistsum=0
	killnpcnum=0
	gpserrnum=0
	buzhen=false
	checkmove.NotGPSMove=1
	gpszeikou=""
	flytoareastartid=0
	--mark.setexp=1
	mark.setpot=1
	mark.setgold=1
	me.expadd=0
	ftbnpckilled=0
	--havefj=0
	--fjzone=""
	--fjroom=""
	--fjarea=""
	--fjroomid=0
	haveshizhe=0
	addforce=0
	weapon_id=1
	stat.havedu=0
	stat.havehbdu=0
	stat.haveneiheal=0 --��ɽ��Ԫ��
	stat.haveyyz=0
	stat.leidong=0
	stat.jingang=0
	stat.sanhua=0
	stat.zixia=0
	stat.quiting=0
	mpJobLimited=0
	suckLimited=0 --xx suck Limited
	xy.xyLimited=0
	xy.limitedResume=0
	xy.biteLimited=0
	xy.checkfirstbite=1
	stat.reverse=0
	stat.powerup=0
	stat.daxiao=0
	stat.fengyun=0
	stat.tiandi=0
	stat.zhixin=0
	stat.huntianup=0
	stat.shengang=0
	stat.heji=0
	stat.longxiang=0
	gold.roomNo=0
	list.pk=""
	pk.name=""
	pk.id=""
	killaction=""
	have.nousejy=0
	set_neili=set_neili_global
	set_GbSecretWay_err=0
	gold.id=""
	--mpLimited.mpexp=0
	--ybexp=0
end
function alias.max()
	run("jiali max;jiajin max")
end
function alias.yjl()
	if me.menpai=="em" then run("yun longhe") end
	run("yun refresh")
end
--function alias.ch()
	--skillslist["literate"]={sld=0,name="����д��",lvl=0,}
	--skillslist["cuff"]={sld=0,name="����ȭ��",lvl=0,}
	--skillslist["kongming-quan"]={sld=0,name="����ȭ",lvl=0,}
	--run("cha;jifa")
--end
function alias.resetidle()
	alias.setstatus()
	idle=0
	ResetTimer("always_watch_timer60")
	--print("debug:idle_reset")
end
function alias.tc(a)
	if have.coin~=nil and have.coin>0 then run("throw coin at "..a) else
		if have.silver~=nil and have.silver>0 then run("throw silver at "..a) else
			if have.gold~=nil and have.gold>0 then run("throw gold at "..a) else
				--run("kill "..a)
				print("����ûǮ,���жϴ�������")
			end
		end
	end
end
function alias.uw(a,b,c)
	if a~=nil then
		if b==nil then
			run("unwield "..a)
		else
			if c==nil then
				run("unwield "..a);run("unwield "..a.." "..b)
			else
				run("unwield "..a);run("unwield "..a.." "..b.." "..c)
			end
		end
	else
		if weapon_id==1 then run("unwield "..weapon_now) else run("unwield "..weapon_now);run("unwield "..weapon_now.." "..weapon_id) end
	end
	weapon_id=weapon_id+1
	if weapon_id>9 then weapon_id=1 end
	if me.menpai=="th" then run("unwield xiao;unwield jian") end
	if me.menpai=="xs" then run("unwield lubo;unwield fa ling") end
	if me.menpai=="xx" then run("unwield bi") end
	if me.menpai=="dl" then run("unwield huachu;unwield chain") end
	if me.master=="������" then run("jifa dodge dugu-jiujian") end
end
function alias.wi(a,b,c)
	if a~=nil then
		if b==nil then
			weapon_now=a
		else
			if c==nil then
				weapon_now=a.." "..b
			else
				weapon_now=a.." "..b.." "..c
			end
		end
	end
	if weapon_now=="hammer" then weapon_now="lun" end
	if weapon_now=="jian" and jifa.swordname~=nil and ((jifa.swordname=="xuantie-jianfa" and jifa.parryname=="xuantie-jianfa") or findstring(killpfm,"pfmxtjf")) then
		if have.xuantiejian>0 then
			weapon_now="xuantie jian"
		elseif have.zhongjian>0 then
			weapon_now="zhongjian"
		end
	end
	if me.menpai=="th" and weapon_now=="jian"  and findstring(mppfm,"pfmyxjf") then
		if ((yp.name=="�ɹ��佫" or yp.name=="����") and workflow.nowjob=="mp") then 
			if skillslist["luoying-shenjian"]~=nil and skillslist["xuanfeng-saoye"]~=nil and skillslist["luoying-shenjian"]["lvl"]>=me.maxlvl*0.55 and skillslist["xuanfeng-saoye"]["lvl"]>=101 then
				weapon_now=""
				run("unwield xiao;unwield jian;jifa strike luoying-shenjian;jifa kick xuanfeng-saoye;bei none;bei xuanfeng-saoye luoying-shenjian")
			else
				weapon_now="jian"
			end
		else
			weapon_now="xiao"
		end
	end
	if weapon_now~="" then
		run("wield "..weapon_now)
	end
end
function alias.checkexp(a)
	openclass("check_exp")
	if a=="yudi" then run("hp")	else run("i;score;hp") end
	if a==nil or string.len(a)==0 then run("set checkexp=yes") else run("set checkexp="..a) end
end
function alias.checkdrugbusy(a)
	--if a~=nil and string.len(a)>0 and (stat.drugbusy<os.time() or stat.drugbusy==0) then
	if a=="jinchuang" and stat.jinchuangyao<os.time() then
		run("buy jinchuang yao;fu jinchuang yao")
	elseif stat.drugbusy<os.time() or stat.drugbusy==0 then
		run("buy "..a..";fu "..a)
	else
		print("ҩ�Ի�δ����")
	end
end
function alias.checkbusy(a)
	if string.len(a)==0 then setbusy="busy" else setbusy=a end
	openclass("checkbusy")
	run("eat "..setbusy)
end
function alias.clearitems()
	have.items=0
	have.gold=0
	have.silver=0
	have.coin=0
	have.jian=0
	have.xiao=0
	have.dao=0
	have.dan=0
	have.jcy=0
	have.fire=0
	have.jiudai=0
	have.he=0
	have.jinhe=0
	have.chain=0
	have.armor=1
	have.bagua=0
	have.ji=0
	have.xinfa=0
	have.szjing=0
	have.staff=0
	have.ling=0
	have.jinhua=0
	have.shengzi=0
	have.whip=0
	have.club=0
	have.yaodai=0
	have.fuling=0
	have.zhongjian=0
	have.xuantiejian=0
	have.jingyao=0
	have.stick=0
	have.stick_zhu=0
	have.stick_tong=0
	have.stick_huangzhu=0
	have.heshouwu=0
	have.yufengjiang=0
	have.chuanbei=0
	have.shengdi=0
	have.jinyinhua=0
	have.jugeng=0
	have.huanglian=0
	have.gouzhizi=0
	have.canye=0
	have.faling=0
	have.lubo=0
	have.kulouguan=0
	have.rentoulian=0
	have.lun=0
	have.syguan=0
	have.bi=0
	have.xueteng=0
	have.danggui=0
	have.swjing=0
	have.suyouguan=0
	have.tyl=0
	have.chaoxue=0
	have.toukui=0
	have.zhangxinding=0
	have.bichuan=0
	have.tongmaidan=0
end
function alias.checkitems()
	local _f,_tb
	openclass("check_items")
	alias.uw()
	run("drop ya;drop jiuping;inventory")
	if me.menpai=="bt" and nowjob~="mp" and nowjob~="xue" and nowjob~="cm" then
		have.guaishe=0
		for i=1,10,1 do run("stop guai she "..i) end
		run("convert guai she")
		run("look guai shezhang")
	end
end
function alias.dealwithitems()
	local _f
	openclass("dealwith_item")
	if have.he>1 then for i=1,have.he,1 do run("drop shi he") end;run("get shi he") end
	if have.fire>1 then for i=1,have.fire,1 do run("drop fire") end;run("get fire") end
	if have.shengzi>2 then for i=1,have.shengzi,1 do run("drop sheng zi") end;run("get sheng zi;get sheng zi") end
	if have.yaodai>1 then for i=1,have.yaodai,1 do run("drop yaodai") end;run("get yaodai") end
	if have.jian>2 then for i=1,have.jian,1 do run("drop jian") end;run("get jian;get jian") end
	if needzhongjian()~=nil and needzhongjian()==1 then 
		if have.zhongjian>1 then for i=1,have.zhongjian,1 do run("drop zhongjian") end;run("get zhongjian") end
	end
	if have.xiao>2 then for i=1,have.xiao,1 do run("drop xiao") end;run("get xiao;get xiao") end
	if have.dao>5 then for i=1,have.dao,1 do run("drop dao") end;run("get dao;get dao") end
	if have.lun>me.lun then run("drop lun;drop lun;get "..me.lun.." lun") end
	if have.staff>1 then for i=1,have.staff,1 do run("drop staff") end;if staffid~=nil then run("get "..staffid) else run("get staff") end end
	if have.whip>1 then for i=1,have.whip,1 do run("drop whip") end;run("get whip") end
	if have.club>1 then for i=1,have.club,1 do run("drop club") end;run("get club") end
	if have.stick>1 then for i=1,have.stick,1 do run("drop stick") end;run("get stick") end
	if have.bi>1 then for i=1,have.bi,1 do run("drop bi") end;run("get bi") end
	if have.chain>1 then for i=1,have.chain,1 do run("drop chain") end;run("get chain") end
	if have.canye>0 and dummy.jy~="" then
		print("ȥ�;�Ҫ��ҳ")
		openclass("dealwith_canye")
		alias.flyto(dummy["jyroom"])
	elseif stat.need_jinhua>0 and have.jinhua<1000 and dummy.jy~="" then	
		openclass("dealwith_jinhua")
		print("ȥ�ý�")
		alias.flyto(dummy["jyroom"])
	elseif not isopen("chongmai_pre") and daytime and ((have.gold>20 and me.menpai~="th") or (have.gold>50 and me.menpai=="th")) and workflow.nowjob~="war" then
		openclass("dealwith_gold")
		alias.flytonpc("����")
	elseif have.silver>300 and daytime and workflow.nowjob~="war" then
		openclass("dealwith_gold")
		alias.flytonpc("����")
	elseif have.coin<10 and daytime and workflow.nowjob~="war" then
		openclass("dealwith_gold")
		alias.flytonpc("����")
	elseif have.gold<1 then
		openclass("dealwith_gold")
		if daytime and me.gold>5 then alias.flytonpc("����") else alias.flytonpc("����") end
	elseif have.he<1 and daytime and me.menpai~="wd" and me.menpai~="dl" and me.menpai~="xs" then	--ѩɽ����ʳ��
		openclass("dealwith_he")
		alias.flytonpc("������")
	elseif have.fire<1 and workflow.nowjob~="war" then
		openclass("dealwith_he")
		alias.flyto(615)
	elseif have.jiudai<1 and workflow.nowjob~="war" and me.menpai~="xs" then
		openclass("dealwith_jiudai")
		alias.flytoid(948)
	elseif workflow.nowjob~="war" and me.menpai~="th" and (have.water==nil or have.water<1) then
		openclass("dealwith_jiudai")
		if me.menpai=="bt" then alias.flytoid(1805)
		elseif me.menpai=="xs" then alias.flytoid(437)
		elseif me.menpai=="xx" then alias.flytoid(1447)
		elseif me.menpai=="mj" then alias.flytoid(537)
		else alias.flytonpc("С�") end
	elseif have.he>0 and have.ji<1 and me.menpai~="wd" and me.menpai~="dl" and me.menpai~="xs" then	--ѩɽ����������
		openclass("dealwith_ji")
		alias.flytonpc("���ϰ�")
	elseif workflow.qzwd>0 and have.jinhe<1 then
		openclass("dealwith_he")
		alias.flytoid(1767)
	elseif me.menpai=="th" and have.bagua<1 then
		if roomno_now==1470 then
			run("ask lu chengfeng about �һ���")
			roomno_now=0
			alias.checkitems()
		else
			openclass("dealwith_shengzi")
			alias.flytoid(1278)
		end
	elseif have.shengzi<1 and me.menpai=="hs" and lingwuat=="menpai" then
		openclass("dealwith_shengzi")
		alias.flytoid(837)
	elseif have.yaodai<1 and me.menpai=="em" and do_dl_job==0 and per.roomno~=841 then
		openclass("dealwith_yaodai")
		alias.flytonpc("����")
	elseif have.yaodai>0 and have.fuling==0 and me.menpai=="em" and per.roomno~=841 then
		openclass("dealwith_fuling")
		alias.flytonpc("��ͨ��")
	elseif workflow.nowjob~="war" and have.tyl<1 and me.menpai=="mj" then
		openclass("dealwith_tyl")
		if me.tyl==nil then alias.flytonpc("��ǫ") else alias.flytonpc("�����") end
	elseif have.xueteng>0 or have.danggui>0 or (have.swjing>9 and me.menpai=="dl") or (have.jcy<0 and workflow.nowjob~="war") then
		openclass("dealwith_sellyao")
		alias.flytonpc("�κ�ҩ")
	elseif (have.faling<1 or have.lubo<1 or have.kulouguan<1 or have.rentoulian<1) and me.menpai=="xs" and workflow.mp>0 then
		openclass("dealwith_xs")
		run("set check=burn")
	else
		closeclass("dealwith_item")
		alias.dealwithitems_weapon()
	end
end
function alias.dealwithitems_weapon()
	local _f=2
	openclass("dealwith_item")
	if me.menpai=="th" and (needzhongjian()==nil or needzhongjian()==0) and have.xiao<2 and (fjweapon=="jian" or mpweapon=="jian" or ftbweapon=="jian" or war.weapon=="jian" or yb.weapon=="jian" or findstring(skills_lingwu,"sword") or workflow.qzwd>0) then
		openclass("dealwith_jian")
		alias.flyto(1739)
		return
	end
	if have.jian<1 and jifa.forcename=="bitao-xuangong" and (findstring(fjpfm,"pfmyxjf","jianmang") or findstring(mppfm,"pfmyxjf","jianmang") or findstring(ftbpfm,"pfmyxjf","jianmang") or findstring(war.pfm,"pfmyxjf","jianmang") or findstring(yb.pfm,"pfmyxjf","jianmang")) and (fjweapon=="jian" or mpweapon=="jian" or ftbweapon=="jian" or war.weapon=="jian" or yb.weapon=="jian" or findstring(skills_lingwu,"sword")) then
		--�ý�â��������ֽ�
		openclass("dealwith_jian")
		jiannpc="������"
		alias.flyto(1017)
		return
	end
	if findstring(fjpfm,"pfmxyfh","feihua") or findstring(mppfm,"pfmxyfh","feihua") or findstring(ftbpfm,"pfmxyfh","feihua") or findstring(war.pfm,"pfmxyfh","feihua") or findstring(yb.pfm,"pfmxyfh","feihua") then
		--��feihua�����ý���,�״ε�½���޷��ж�stat.need_jinhua�������������ã��������checkitems()������
		stat.use_jinhua=true
		if have.jinhua<1000 or have.jinhua>12000 then
			print("ȥ������")
			stat.need_jinhua=1
			openclass("dealwith_jinhua")
			alias.flyto(dummy["jyroom"])
			return
		else
			stat.need_jinhua=0
		end
	end
	if skillslist["xuantie-jianfa"]~=nil then _f=1 end  --�����������ĺţ�ֻ��һ�ѽ�
	if have.jian<_f and (fjweapon=="jian" or mpweapon=="jian" or ftbweapon=="jian" or war.weapon=="jian" or yb.weapon=="jian" or findstring(skills_lingwu,"sword") or (workflow.qzwd>0 and skillslist["qianzhu-wandu"] and skillslist["qianzhu-wandu"]["lvl"]>78)) and not (findstring(fjpfm,"pfmyxjf","jianmang") or findstring(mppfm,"pfmyxjf","jianmang") or findstring(ftbpfm,"pfmyxjf","jianmang") or findstring(war.pfm,"pfmyxjf","jianmang") or findstring(yb.pfm,"pfmyxjf","jianmang")) then	
		openclass("dealwith_jian")
		jiannpc="������ʿ"
		alias.flyto(1017)
		--alias.flytonpc(jiannpc)
		return
	end
	--if have.dao<2 and me.menpai=="sl" then
	if (have.dao<2 and (fjweapon=="dao" or mpweapon=="dao" or ftbweapon=="dao" or war.weapon=="dao" or yb.weapon=="dao" or findstring(skills_lingwu,"blade"))) or (have.dao<5 and mppfm=="jzpfm") then
		openclass("dealwith_dao")
		if me.menpai=="sl" then alias.flytonpc("����") else alias.flytoid(964) end 
		return
	end
	if have.staff<1 and (fjweapon=="staff" or mpweapon=="staff" or ftbweapon=="staff" or war.weapon=="staff" or yb.weapon=="staff" or findstring(skills_lingwu,"staff")) then
		openclass("dealwith_staff")
		--if me.menpai=="bt" then alias.flytoid(926) else alias.flytoid(1425) end
		if me.menpai=="bt" then alias.flytoid(926) else alias.flytoid(428) end
		return
	end
	if have.whip<1 and (fjweapon=="bian" or mpweapon=="bian" or ftbweapon=="bian" or war.weapon=="bian" or yb.weapon=="bian" or findstring(skills_lingwu,"whip")) then
		openclass("dealwith_bian")
		alias.flytoid(312)
		return
	end
	if have.club<1 and findstring(skills_lingwu,"club") then
		openclass("dealwith_gun")
		alias.flytonpc("����")
		return
	end
	if have.stick<1 and (fjweapon=="stick" or mpweapon=="stick" or ftbweapon=="stick" or war.weapon=="stick" or yb.weapon=="stick" or findstring(skills_lingwu,"stick"))  then
		openclass("dealwith_stick")
		alias.flytoid(1118)
		return
	end
	if have.bi<1 and (fjweapon=="bi" or mpweapon=="bi" or ftbweapon=="bi" or war.weapon=="bi" or yb.weapon=="bi" or findstring(skills_lingwu,"stroke"))then
		openclass("dealwith_bi")
		alias.flytoid(1101)
		return
	end
	if have.lun<me.lun and (fjweapon=="lun" or mpweapon=="lun" or ftbweapon=="lun" or war.weapon=="lun" or yb.weapon=="lun" or findstring(skills_lingwu,"hammer"))then
		openclass("dealwith_xs")
		run("set check=lun")
		return
	end
	if me.menpai=="bt" and have.guaishe==0 then
		openclass("dealwith_staff")
		run("drop staff")
		alias.flytoid(926)
		return
	end
	if ((have.chain<1 and me.menpai=="dl") or (have.chain<1 and do_dl_job==1)) and workflow.mp>0 then
		openclass("dealwith_chain")
		alias.flytonpc("����̩")
		return
	end
	closeclass("dealwith_item")
	run("set dealwithitems=over")
end
function alias.killover()
	--local _t
	--if findstring(workflow.nowjob,"mp","ftb") then _t=workflow.nowjob else _t="fj" end
	--if string.len(_G[_t.."weapon"])>0 then alias.uw() end
	--if getweapon>0 then
	--	for i=1,2,1 do run("get ".._G[_t.."weapon"]) end
	--end
	if string.len(_G["killskill"])>0 then alias.uw() end
	if getweapon>0 then
		for i=1,2,1 do run("get ".._G["killskill"]) end
	end
	wieldweapon=0
	getweapon=0
	yunbusy=0
	runaway=false
	npcfaint=false
	pfmid=1
	rejiajin=false
	run("jiajin basic")
	if #always.bei==1 and always["bei"][1]=="������" or #always.bei==2 and (always["bei"][1]=="������" or always["bei"][2]=="������") then
		run("jiali "..killjiali)
	else
		run("jiali 0")
	end
	if findstring(killpfm,"perform kong","perform ming") then run("bei none;bei kongming-quan") end
	if string.len(killaction)==0 then killaction="yes" end
	if me.menpai=="bt" then run("convert she") end
	--closeclass("kill_"..me.menpai)
	closeclass("kill_pfm")
	closeclass("kill")
	run("set killover="..killaction)
	killaction=""
	if stat.zixia>0 then run("yun sangong") end
	if me.master=="������" and fjweapon=="jian" then run("jifa dodge dugu-jiujian") end
end
function alias.KillNextNPC()
	killnpcnum=tonumber(killnpcnum+1)
	print(":::KillNextNPC:::"..killnpcover..":"..killnpcnum..","..killnpcsum)
	if string.len(killnpcover)>0 then
		run(killnpcover)
	end
end
function alias.fj_startkill()
	if jifa.forcename=="hunyuan-yiqi" and (fjselectnpc.menpai=="xx" or fjselectnpc.menpai=="dl") and fjselectnpc.weapon>1 then
		run("yun sangong")
	else
		_tb=Split(fjyun,"|")
		for k,v in ipairs(_tb) do run(v) end
	end
	reyun=0
	if fjselectnpc.menpai=="sl" and mpweapon~="zhongjian" then
		run("set no_parry")
	else
		run("unset no_parry")
	end
	openclass("kill")
	openclass("kill_pfm")
	closeclass("kill_run")
	AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
	SetTimerOption("kill_timer", "group", "kill")
	runaway=false
	npcfaint=false
	killRunSuccess=false
	if findstring(fjpfm,"leidong") then
		if stat.leidong>0 then
			pfmid=2
			if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
			wieldweapon=1
		else
			pfmid=1
			alias.uw()
		end
	elseif findstring(fjpfm,"jingang") then
		if stat.jingang>0 then
			pfmid=2
			if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
			wieldweapon=1
		else
			pfmid=1
			alias.uw()
		end
    else				
		if findstring(fjpfm,"qiankun") and stat.qiankun==2 then
			pfmid=2
		else
			pfmid=1
		end
		if string.len(fjweapon)>0 then
			if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
		else alias.uw() end
	end
	if fjselectnpc.menpai=="bt" and weapon_now=="xiao" then run("halt;unwield xiao;wield jian");weapon_now="jian" end
	if fjroomid==609 then
		print("��ֹ����per��ǿ�����´�������")
		_tb=Split(me.fjnpcid," ")
		killid=_tb[1]
		run("kill ".._tb[1])
	else
		killid=me.fjnpcid
		run("kill "..me.fjnpcid)
	end
	if me.menpai=="bt" then run("convert staff;attack "..me.fjnpcid) end
	if me.menpai=="mj" then run("order fighter do attack "..me.fjnpcid..";order fighter 2 do attack "..me.fjnpcid) end
	if me.menpai=="xx" then	xx.suck=0;run("blow di") end
	alias.pfm()
	run("set checkkillstart=yes")
end
function alias.fjskillskill(var)
	local _tb
	-- ��һ��������killaction������vchar��������������������Ӣ��id������Ӣ��id���ؿ�ʡ
	_tb=Split(var," ")
	killaction=_tb[1]
	killname=_tb[2]
	if _tb[4]==nil then killid=_tb[3] else killid=_tb[3].." ".._tb[4] end
	_tb=Split(fjyun,"|")
	for k,v in pairs(_tb) do run(v) end
	reyun=0
	killRunSuccess=false
	openclass("kill")
	openclass("kill_pfm")
	--openclass("kill_"..me.menpai)
	AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
	SetTimerOption("kill_timer", "group", "kill")
	closeclass("kill_run")
	runaway=false
	npcfaint=false
	--if me.menpai=="hs" then
	if jifa["forcename"]=="zixia-gong" then --�����жϸĳ��ڹ��ж�
		if stat.leidong>0 then
			pfmid=2
			if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
		else
			pfmid=1
			alias.uw()
		end
	elseif jifa["forcename"]=="hunyuan-yiqi" then --�����жϸĳ��ڹ��ж�
		if stat.jingang>0 then
			pfmid=2
			if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
		else
			pfmid=1
			alias.uw()
		end
	else
		pfmid=1
		if string.len(fjweapon)==0 then
			if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
		else alias.uw() end
	end
	killskill=fjweapon
	killpfm=fjpfm
	killyun=fjyun
	killjiali=fjjiali
	killjiajin=fjjiajin
	run("jiali "..killjiali..";jiajin "..killjiajin..";kill "..killid)
	--if me.menpai=="bt" then run("convert staff;attack "..killid) end
	if me.menpai=="bt" then run("convert staff") end
	if me.menpai=="mj" then run("shoutfighter fighter;order fighter do attack "..killid..";order fighter 2 do attack "..killid) end
	--_tb=Split(fjpfm,"|")
	--if pfmid<=#_tb then if kmq() then alias.kmq() else run(_tb[pfmid].." "..killid) end end
	--_tb=Split(killpfm,"|")
	alias.pfm()
end
------------------------------------------------------------------------------------
-- class ���
------------------------------------------------------------------------------------
function alias.initialize_trigger()
	alias.open_always()
	alias.open_fj()
	alias.close_common()
	alias.close_pk()
	alias.close_check()
	alias.close_boat()
	alias.close_gps()
	alias.close_ftb()
	alias.close_fj()
	alias.close_xinfa()
	alias.close_mp()
	alias.close_xue()
	alias.close_qzwd()
	alias.close_kill()
	alias.close_dz()
	alias.close_login()
	alias.close_shizhe()
	alias.close_liaoshang()
	alias.close_quit()
	alias.close_cm()
	alias.close_aoyao()
	alias.close_war()
	alias.close_yb()
	alias.close_basicskills()
	closeclass("dm")  --dummy����
	closeclass("keep")  --keep����
	closeclass("eating") --��ʳ��
	closeclass("dm_war_getweapon") --war����������
	closeclass("checkbusy")
	war_update_var()
	allcmd={}
	cmd_flag=true
end
function alias.close_basicskills()
	closeclass("basic_skills_force")
	closeclass("basic_skills_dodge")
	closeclass("basic_skills_strike")
	closeclass("basic_skills_cuff")
end
function alias.open_gps()
	openclass("gps_watch")
	openclass("gps_start")
end
function alias.close_gps()
	closeclass("gps_watch")
	closeclass("gps_start")
	alias.close_gps_dealwith()
end
function alias.close_boat()
	openclass("common")
	closeclass("boat")
	closeclass("skills_lian")
	closeclass("boat_yell")
end
function alias.open_ftb_search()
	openclass("ftb")
	openclass("ftb_start")
	openclass("gps")
	openclass("ftb_watch")
	npcfind=0
	flytoarealist_backpath=""
end
function alias.close_kill()
	closeclass("kill")
	closeclass("kill_run")
	closeclass("kill_pfm")
end
function alias.close_ftb()
	closeclass("gps_dealwith")
	closeclass("ftb_start")
	closeclass("ftb_watch")
	closeclass("ftb_ask")
	closeclass("ftb_pre")
	flytoareastartid=0
end
function alias.open_always()
	openclass("always_daytime")
	openclass("always_gag")
	closeclass("gag_set")
	openclass("always_gpsalias")
	openclass("always_hp")
	openclass("always_skills")
	openclass("always_watch")
	closeclass("watch_death")
	closeclass("godie")
end
function alias.open_boat()
	openclass("boat")
end
function alias.close_check()
	closeclass("check_busy")
	closeclass("check_items")	
	closeclass("check_items2")
	closeclass("check_exp")
	closeclass("dealwith_item")
	closeclass("dealwith_gold")
	closeclass("dealwith_he")
	closeclass("dealwith_ji")
	closeclass("dealwith_jian")
	closeclass("dealwith_jiudai")
	closeclass("dealwith_dao")
	closeclass("dealwith_shengzi")
	closeclass("dealwith_staff")
	closeclass("dealwith_bian")
	closeclass("dealwith_bi")
	closeclass("dealwith_gun")
	closeclass("dealwith_fuling")
	closeclass("dealwith_yaodai")
end
function alias.close_xue()
	openclass("skills")
	closeclass("skills_lian")
	closeclass("skills_lingwu")
	closeclass("skills_xue")
	closeclass("skills_xue2")
	closeclass("skills_ask")
	closeclass("skills_jingyao")
	alias.close_dz()
end
function alias.open_fj()
	openclass("fj")
	openclass("fj_watch")
end
function alias.close_fj()
	closeclass("fj_pre")
	closeclass("fj_start")
	closeclass("fj_escape")
	closeclass("fj_close")
	closeclass("fj_other")
end
function alias.close_yb()
	closeclass("michen_yb_pre")
	closeclass("michen_yb_watch")
	closeclass("michen_yb_start")
	closeclass("michen_yb_start_t")
end
function alias.open_yb()
	openclass("michen_yb_pre")
	openclass("michen_yb_watch")
	closeclass("michen_yb_start")
	closeclass("michen_yb_start_t")
end
function alias.close_qzwd()
	closeclass("qzwd")
	closeclass("qzwd_start")
	closeclass("qzwd_pre")
	closeclass("qzwd_watch")
end
function alias.close_mp()
	closeclass("mp_sl")
	closeclass("mp_sl_pre")
	closeclass("mp_sl_start")
	closeclass("mp_sl_watch")
	closeclass("mp_dl")
	closeclass("mp_dl_pre")
	closeclass("mp_dl_start")
	closeclass("mp_dl_watch")
	closeclass("mp_dl_work")
	closeclass("mp_dl_dowork")
	closeclass("mp_wd")
	closeclass("mp_wd_pre")
	closeclass("mp_wd_start")
	closeclass("mp_wd_watch")
	closeclass("mp_hs")
	closeclass("mp_hs_pre")
	closeclass("mp_hs_start")
	closeclass("mp_hs_watch")
	closeclass("mp_bt")
	closeclass("mp_bt_pre")
	closeclass("mp_bt_start")
	closeclass("mp_bt_watch")
	closeclass("mp_th")
	closeclass("mp_th_pre")
	closeclass("mp_th_start")
	closeclass("mp_th_watch")
	closeclass("mp_qz")
	closeclass("mp_qz_pre")
	closeclass("mp_qz_boyao_ti")
	closeclass("mp_qz_boyao")
	closeclass("mp_qz_start")
	closeclass("mp_qz_watch")
	closeclass("mp_em")
	closeclass("mp_em_pre")
	closeclass("mp_em_start")
	closeclass("mp_em_watch")
	closeclass("mp_em_permmr")
	closeclass("mp_xs")
	closeclass("mp_xs_lzjob")
	closeclass("mp_xs_pre")
	closeclass("mp_xs_npc1")
	closeclass("mp_xs_npc2")
	closeclass("mp_xs_start")
	closeclass("mp_xs_watch")
	closeclass("mp_gb_pre")
	closeclass("mp_gb_sx")
	closeclass("mp_gb_gold")
	closeclass("mp_gb_gold_ti")
	closeclass("mp_gb_gold_fujia")
	closeclass("mp_gb_gold_owner")
	closeclass("mp_gb_gold_robber")
	closeclass("mp_gb_watch")
	closeclass("mp_xx")
	closeclass("mp_xx_pre")
	closeclass("mp_xx_start")
	closeclass("mp_xx_watch")
	closeclass("mp_xx_pre_sandu")
	closeclass("mp_xx_pre_suck")
	closeclass("mp_xx_start_catch")
	closeclass("mp_xx_start_sandu")
	closeclass("mp_xx_start_search")
	closeclass("mp_xx_xiulian")
	closeclass("mp_xx_kmmr")
	closeclass("mp_gm")
	closeclass("mp_gm_caimi")
	closeclass("mp_gm_caimi_t")
	closeclass("mp_gm_pre")
	closeclass("mp_gm_watch")
	closeclass("mp_gm_job3")
	closeclass("mp_mj")
	closeclass("mp_mj_pre")
	closeclass("mp_mj_yudi")
	closeclass("mp_mj_wxq")
	closeclass("mp_mj_wxqjob")
	closeclass("mp_mj_tyjob")
	closeclass("mp_mj_watch")
end
function alias.close_dz()
	openclass("common")
	closeclass("dazuo")
	closeclass("dazuo_resetidle")
end
function alias.close_shizhe()
	openclass("common")
	closeclass("shizhe")
end
function alias.close_liaoshang()
	openclass("common")
	closeclass("liaoshang")
end
function alias.close_login()
	openclass("common")
	closeclass("login")
end
function alias.close_xinfa()
	openclass("xinfa")
	closeclass("xf_sl")
	closeclass("sl_sj")
	closeclass("sl_zc")
	closeclass("xf_wd")
	closeclass("wd_xtjf")
	closeclass("wd_xtjf_fight")
	closeclass("xf_em")
	closeclass("xf_em_resetidle")
	closeclass("xf_hs")
	closeclass("xf_mj")
end
function alias.close_pk()
	openclass("pk")
	closeclass("blockpk_pre")
	closeclass("blockpk_start")
end
function alias.close_quit()
	stat.quiting=0
	closeclass("quitdis")
	closeclass("quit")
end
function alias.close_aoyao()
	openclass("common")
	closeclass("aoyao")
	closeclass("buyinwan")
end
function alias.close_cm()
	openclass("chongmai")
	closeclass("chongmai_pre")
	closeclass("chongmai_start")
	closeclass("chongmai_watch")
end
function alias.close_common()
	openclass("common")
	closeclass("aoyao")
	closeclass("bidu")
	closeclass("xuan")
	closeclass("boat")
	closeclass("boat_yell")
	closeclass("dazuo")
	closeclass("dazuo_resetidle")
	closeclass("fang")
	closeclass("liaoshang")
	closeclass("login")
	closeclass("quit")
	closeclass("quitdis")
	closeclass("shizhe")
	closeclass("tongmai")
	closeclass("yinyun")
end
function alias.close_gps_dealwith()
	closeclass("gps_dealwith")
	closeclass("gps_zeikou")
	closeclass("gps_99guai")
	closeclass("gps_climbxy")
	closeclass("gps_dl_fsg")
	closeclass("gps_em_killjm")
	closeclass("gps_lsd_back")
	closeclass("gps_lsd_go")
	closeclass("gps_nanyang")
	closeclass("gps_qzh_mcx")
	closeclass("gps_qzh_sl")
	closeclass("gps_qzh_xmdq")
	closeclass("gps_sgy_sd")
	closeclass("gps_sl_gate")
	closeclass("gps_sl_sl")
	closeclass("gps_slh")
	closeclass("gps_thd_back")
	closeclass("gps_thd_go")
	closeclass("gps_thd_ms")
	closeclass("gps_thd_sg")
	closeclass("gps_thd_thl")
	closeclass("gps_thrownpc")
	closeclass("gps_waitrelease")
	closeclass("gps_xxmap")
	closeclass("gps_xydcy")
	closeclass("gps_xydcy_sl")
	closeclass("gps_yz_lts")
	closeclass("gps_yz_ym")
	closeclass("gps_yztd_1_2")
	closeclass("gps_yztd_2_1")
	closeclass("gps_yztd_2_3")
	closeclass("gps_yztd_3_2")
	closeclass("gps_zhou")
end
function alias.close_war()
	closeclass("war_pre")
	closeclass("war_start")
	closeclass("war_pre_time")
	closeclass("war_start_timer")
	closeclass("war_restart_timer")
	workflow.nowjob="mp"
end
------------------------------------------------------------------------------------
-- gps ���
------------------------------------------------------------------------------------
function alias.SafeEntrance(a)
	local _tb
	_t=xkxGPS.findSafeExit(a)
	if _t=="" then return "east" end
	--print(a)
	--if tonumber(a)==1271 then return "west" end
	--local _tb=Split(_t,"|")
	_tb=Split(_t,"|")
	return _tb[1]
	--return _tb[math.random(1,#_tb)]
end
function alias.searcharea()
	alias.close_gps()
	alias.open_ftb_search()
	alias.searchareastep()
end
function alias.searchareanextpath()
	local _tb,_t
	-- #if @debug {#say ��ftbʱ����������ܵȴ�������ȥ��·���������һ·������}
	flytoarealistindex=flytoarealistindex+1
	flytoarealist_searchindex=1
	if flytoarealistindex>flytoarealistsum then
		print("����������")
		run("set searcharea=over")
	else
		_tb=Split(flytoarealist,"|")
		_t=_tb[flytoarealistindex]
		_tb=Split(_t,"#")
		flytoareastartid=tonumber(_tb[1])
		alias.flytoid(flytoareastartid)
	end
end
function alias.searchareastep()
	local _tb={}
	local _t
	ftbnpcname=""
	ftbnpcid=""
	getgold=0
	if search_steps==nil then search_steps=0 else search_steps=search_steps+1 end	--�Ʋ���
	if gpserrnum>0 then
		-- �����·���ִ��󣬷ɵ��ö�·������ʼ��
		flytoarealist_searchindex=1
		alias.flytoid(flytoareastartid)
		return
	end
	if flytoarealistindex<=flytoarealistsum then
		_tb=Split(flytoarealist,"|")
		flytoarealist_searchlist=_tb[flytoarealistindex]
		_tb=Split(flytoarealist_searchlist,">")
		flytoarealist_searchlistsum=tonumber(#_tb)
		flytoarealist_searchroom=_tb[flytoarealist_searchindex]
		_tb=Split(flytoarealist_searchroom,"#")
		flytoarealist_searchdict=_tb[2]
		flytoarealist_searchid=tonumber(_tb[1])
		roomno_now=flytoarealist_searchid
		safego=alias.SafeEntrance(roomno_now)
		SafeBack=invDirection(safego)
		if flytoarealist_searchdict=="over" then
			flytoarealistindex=tonumber(flytoarealistindex+1)
			flytoarealist_searchindex=1
			if flytoarealistindex>flytoarealistsum then
				print("����������")
				run("set searcharea=over")
			else
				_tb=Split(flytoarealist,"|")
				_t=_tb[flytoarealistindex]
				_tb=Split(_t,"#")
				flytoareastartid=_tb[1]
				_t=xkxGPS.search(flytoarealist_searchid,flytoareastartid)
				flytoarealist_backpath=string.gsub(_t,";","|")
				flytoarealist_searchlistindex=1
				_tb=Split(flytoarealist_backpath,"|")
				flytoarealist_searchlistsum=#_tb
				alias.searchareaback()
			end
		else
			Simulate("\n·��������Զ�⣬�ڡ�"..flytoarealistsum.."���еĵڡ�"..flytoarealistindex.."���� �ڡ�"..flytoarealist_searchindex.."����\n")
			flytoarealist_searchindex=tonumber(flytoarealist_searchindex+1)
			if search_steps>10 then alias.yjl();search_steps=0 end	--�߳���10����һ�ξ���
			run("halt;"..flytoarealist_searchdict)
			if string.find("|look|e|w|n|s|ne|se|sw|nw|eu|wu|su|nu|ed|wd|nd|sd|u|d|enter|out|","|"..flytoarealist_searchdict.."|") then run("set checknpc=yes") end
		end
	else
		run("set searcharea=over")
	end
end
function alias.searchareastep2()
	local _tb,_t
	ftbnpcname=""
	ftbnpcid=""
	getgold=0
	if flytoarealistindex<=flytoarealistsum then
		_tb=Split(flytoarealist,"|")
		flytoarealist_searchlist=_tb[flytoarealistindex]
		_tb=Split(flytoarealist_searchlist,">")
		flytoarealist_searchlistsum=tonumber(#_tb)
		flytoarealist_searchroom=_tb[flytoarealist_searchindex]
		_tb=Split(flytoarealist_searchroom,"#")
		flytoarealist_searchdict=_tb[2]
		flytoarealist_searchid=tonumber(_tb[1])
		roomno_now=flytoarealist_searchid
		safego=alias.SafeEntrance(roomno_now)
		SafeBack=invDirection(safego)
		if flytoarealist_searchdict=="over" then
			flytoarealistindex=tonumber(flytoarealistindex+1)
			flytoarealist_searchindex=1
			if flytoarealistindex>flytoarealistsum then
				print("����������")
				run("set searcharea=over")
			else
				_tb=Split(flytoarealist,"|")
				_t=_tb[flytoarealistindex]
				_tb=Split(_t,"#")
				flytoareastartid=_tb[1]
				_t=xkxGPS.search(flytoarealist_searchid,flytoareastartid)
				flytoarealist_backpath=string.gsub(_t,";","|")
				flytoarealist_searchlistindex=1
				_tb=Split(flytoarealist_backpath,"|")
				flytoarealist_searchlistsum=#_tb
				alias.searchareaback2()
			end
		else
			Simulate("\n·��������Զ�⣬�ڡ�"..flytoarealistsum.."���еĵڡ�"..flytoarealistindex.."���� �ڡ�"..flytoarealist_searchindex.."����\n")
			if flytoarealist_searchindex==1 then
				-- ��ʼ�㲻�ܵ��������ʼ�㣬�����߳�������Ҫ�ɵ���ʼ��ʱ�ᷴ��������
				_tb=Split(flytoarealist,"|")
				_t=_tb[flytoarealistindex]
				_tb=Split(_t,">")
				_t=_tb[flytoarealist_searchindex+1]
				_tb=Split(_t,"#")
				flytoareastartid=_tb[1]
			end
			flytoarealist_searchindex=tonumber(flytoarealist_searchindex+1)
		end
	else
		run("set searcharea=over")
	end
end
function alias.searchareastep3()
	local _tb,_t
	ftbnpcname=""
	ftbnpcid=""
	getgold=0
	if tonumber(flytoarealistindex)<=tonumber(flytoarealistsum) then
		_tb=Split(flytoarealist,"|")
		flytoarealist_searchlist=_tb[flytoarealistindex]
		_tb=Split(flytoarealist_searchlist,">")
		flytoarealist_searchlistsum=#_tb
		_tb=Split(flytoarealist_searchlist,">")
		flytoarealist_searchroom=_tb[flytoarealist_searchindex]
		_tb=Split(flytoarealist_searchroom,"#")
		flytoarealist_searchdict=_tb[2]
		_tb=Split(flytoarealist_searchroom,"#")
		flytoarealist_searchid=_tb[1]
		roomno_now=tonumber(flytoarealist_searchid)
		safego=alias.SafeEntrance(roomno_now)
		SafeBack=invDirection(safego)
		if flytoarealist_searchdict=="over" then
			flytoarealistindex=tonumber(flytoarealistindex)+1
			flytoarealist_searchindex=1
			if tonumber(flytoarealistindex)>tonumber(flytoarealistsum) then
				print("����������")
				run("set searcharea=over")
			else
				_tb=Split(flytoarealist,"|")
				_t=_tb[flytoarealistindex]
				_tb=Split(_t,"#")
				flytoareastartid=tonumber(_tb[1])
				_t=xkxGPS.search(flytoarealist_searchid,flytoareastartid)
				flytoarealist_backpath=string.gsub(_t,";","|")
				flytoarealist_searchlistindex=1
				_tb=Split(flytoarealist_backpath,"|")
				flytoarealist_searchlistsum=#_tb
				alias.searchareaback2()
			end
		else
			Simulate("·��������Զ�⣬�ڡ�"..tostring(flytoarealistsum).."���еĵڡ�"..tostring(flytoarealistindex).."���� �ڡ�"..tostring(flytoarealist_searchindex).."����\n")
			if tonumber(flytoarealist_searchindex)==1 then
				-- #if @debug {#say ��ʼ�㲻�ܵ��������ʼ�㣬�����߳�������Ҫ�ɵ���ʼ��ʱ�ᷴ��������}
				_tb=Split(flytoarealist,"|")
				_t=_tb[flytoarealistindex]
				_tb=Split(_t,">")
				_t=_tb[tonumber(flytoarealist_searchindex)+1]
				_tb=Split(_t,"#")
				flytoareastartid=_tb[1]
			end
			flytoarealist_searchindex=tonumber(flytoarealist_searchindex)+2
		end
	else run("set searcharea=over") end
end
function alias.searchareaback()
	local _tb={}
	ftbnpcname=""
	ftbnpcid=""
	getgold=0
	if flytoarealist_searchlistindex<=flytoarealist_searchlistsum then
		_tb=Split(flytoarealist_backpath,"|")
		flytoarealist_searchdict=_tb[flytoarealist_searchlistindex]
		flytoarealist_searchlistindex=tonumber(flytoarealist_searchlistindex+1)
		run("halt")
		if flytoarealist_searchdict=="isHere" then
			-- ��������һ��·����ʼ����ԭ��
			flytoarealist_searchlistindex=1
			flytoarealist_backpath=""
			alias.searchareastep()
		else
			run(flytoarealist_searchdict)
			if string.find("|e|w|n|s|ne|se|sw|nw|eu|wu|su|nu|ed|wd|nd|sd|u|d|enter|out|","|"..flytoarealist_searchdict.."|") then run("set checknpc=yes") end
		end
	else
		flytoarealist_searchlistindex=1
		flytoarealist_backpath=""
		alias.searchareastep()
	end
end
function alias.searchareaback2()
	local _tb
	ftbnpcname=""
	ftbnpcid=""
	getgold=0
	if flytoarealist_searchlistindex<=flytoarealist_searchlistsum then
		_tb=Split(flytoarealist_backpath,"|")
		flytoarealist_searchdict=_tb[flytoarealist_searchlistindex]
		flytoarealist_searchlistindex=flytoarealist_searchlistindex+1
	else
		flytoarealist_searchlistindex=1
		flytoarealist_backpath=""
		alias.searchareastep2()
	end
end
function alias.searcharea_research()
	-- ɱnpcʱfollow��npc�ƶ�����Ҫflyto���ĵ㣬���µ�ǰ·�������������ʼ������
	flytoarealist_searchindex=1
	alias.searcharea()
end
function alias.goto(n,l,w)
	if w[1]==nil or w[1]=="" then print("��ˣ�����أ�����") end
	local a=Split(w[1]," ")
	if tonumber(a[1])~=nil and tonumber(a[1])>0 then
		alias.flytoid(tonumber(a[1]))
	else
		alias.flyto(a[1],a[2])
	end
end
function alias.flyto(a,b)
	if string.len(gpszeikou)==0 and gpserrnum==0 and isopen("gps_start") then print("��ʲô����GPSģ�����������У������ظ�����")
	else
		if type(a)=="number" or tonumber(a)~=nil then alias.flytoid(tonumber(a));return end
		if b~=nil then flytozone=b else flytozone="none" end
		if a~=nil then
			flytoname=a
			alias.flytoname(flytoname,flytozone)
		end
	end
end
function alias.flytoarea(a,b,c)		--ftbroom,ftbzone,tonumber(ftbareanum)+1
	local _tb,_t
	if string.len(gpszeikou)==0 and gpserrnum==0 and isopen("gps_start") then 
		print("��ʲô����GPSģ�����������У������ظ�����")
	else
		alias.initialize_gps()
		alias.open_gps()
		if b~=nil then flytozone=b else flytozone="none" end 
		if a~=nil and c~=nil then
			flytoname=a
			flytoareanum=tonumber(c)
			gps_cmd=alias.flytoarea
			gps_cmd_dest=flytoname
			gps_cmd_zone=flytozone
			gps_cmd_num=flytoareanum
			--gps_cmd="/alias.flytoarea("..flytoname..","..flytozone..","..flytoareanum..")"
			--flytoarealist,startid=xkxGPS.findroomarea(flytoname,flytozone,flytoareanum)
			flytoarealist,startid=trversal(flytoname,flytozone,flytoareanum)
			--print("����·��Ϊ��"..tostring(flytoarealist))
			if string.len(flytoarealist)==0 then
				Simulate("�����������ĵ㷿�����ʧ�ܣ�\n")
				flytoname=""
				run("set gps=false")
				---------------����ftb
				--ftbfail=1
				table.insert(ftbfail_table,{ftbzone,ftbroom,})
				if #ftbarea_table<2 then  
					ftbzone=""
					ftbroom=""
					alias.startworkflow()
				else
					alias.close_gps()
					table.remove(ftbarea_table,1)
					ftbarea=ftbzone..""..ftbarea_table[1]
					ftb_start_search()
				end
				-------------------
			else
				if string.len(flytoarealist)==0 then
					print("���� "..flytozone.." ���� "..flytoname.." ���� "..flytoareanum.." ������ʧ��")
					run("set gps=false")
				else
					-- ��Χ·��Ϊ��@flytoarealist
					flytoarealistindex=1
					_tb=Split(flytoarealist,"|")
					flytoarealistsum=#_tb
					_t=_tb[flytoarealistindex]
					_tb=Split(_t,"#")
					flytoareastartid=tonumber(_tb[1])
					flytoarealist_searchindex=1
					-- ��ʼ����Ϊ%word( %item( @flytoarealist, 1), 1, "#"������@flytoarealistsum ��·��
					alias.close_gps()
					--alias.flytoid(flytoareastartid)
					alias.flyto(startid)
				end
			end
		else
			print("����ȷ���뷿����������������Χ��")
		end	
	end
end
function alias.flytoname(a,b)
	local _tb
	if string.len(gpszeikou)==0 and gpserrnum==0 and isopen("gps_start") then print("��ʲô����GPSģ�����������У������ظ�����")
	else
		alias.initialize_gps()
		alias.open_gps()
		flytonpc=""
		flytoid=0
		if b~=nil then flytozone=b else flytozone="none" end
		if a~=nil then
			flytoname=a
			gps_cmd=alias.flytoname
			gps_cmd_dest=flytoname
			gps_cmd_num=nil
			if flytozone=="none" then
				gps_cmd_zone=nil
				-- gps_cmd="/alias.flytoname("..flytoname..")"
			else
				gps_cmd_zone=flytozone
				--gps_cmd="/alias.flytoname("..flytoname..","..flytozone..")"
			end
			flytonamelist=xkxGPS.findroomno(flytoname,flytozone)
			if string.len(flytonamelist)==0 then
				print("���ҷ���ʧ��")
				Simulate("���ҷ���ʧ�ܣ�\n")
				run("set gps=false")
			else
				flytonamelistindex=1
				_tb=Split(flytonamelist,"|")
				flytonamelistsum=#_tb
				-- ��@flytoname������������@flytonamelistsum��
				print("��"..flytoname.."������������"..flytonamelistsum.."��")
				if flytonamelistsum>1 then alias.flytoid_name(_tb[flytonamelistindex]) else alias.flytoid_name(flytonamelist) end
			end
		else
			print("����ȷ���뷿����������")
		end
	end
end
function alias.flytonpc(a,b)
	local _tb
	if string.len(gpszeikou)==0 and gpserrnum==0 and isopen("gps_start") then print("��ʲô����GPSģ�����������У������ظ�����")
	else
		alias.initialize_gps()
		alias.open_gps()
		flytoname=""
		flytoid=0
		if b~=nil then flytozone=b else flytozone="none" end
		if a~=nil then
			flytonpc=a
			gps_cmd=alias.flytonpc
			gps_cmd_dest=flytonpc
			gps_cmd_num=nil
			if flytozone=="none" then
				gps_cmd_zone=nil
				--gps_cmd="/alias.flytonpc("..flytonpc..")"
			else
				gps_cmd_zone=flytozone
				--gps_cmd="/alias.flytonpc("..flytonpc..","..flytozone..")"
			end
			flytonpclist=xkxGPS.findroomnpc(flytonpc,flytozone)
			if string.len(flytonpclist)==0 then
				print("����NPCʧ�ܣ�")
				run("set gps=false")
			else
				flytonpclistindex=1
				_tb=Split(flytonpclist,"|")
				flytonpclistsum=#_tb
				-- ��@flytonpc������������@flytonpclistsum��
				if flytonpclistsum>1 then alias.flytoid_npc(_tb[flytonpclistindex]) else alias.flytoid_npc(flytonpclist) end
			end
		else
			print("����ȷ����NPC��������")
		end
	end
end
function alias.flytoid_npc(a)
	flytoid=tonumber(a)
	killnpcover=""
	killnpcnum=0
	if flytoid>0 then alias.gps() else Simulate("��������ȷ�ķ���ID\n") end
end
function alias.flytoid_name(a)
	alias.initialize_gps()
	killnpcover=""
	killnpcnum=0
	flytoid=tonumber(a)
	if flytoid>0 then alias.gps() else Simulate("��������ȷ�ķ���ID\n") end
end
function alias.walkover_flytoid()
	local _tb,_f
	if string.len(gpszeikou)==0 then
		alias.close_gps()
		if gpserrnum==0 then
			if flytoareastartid==0 then
				roomno_now=flytoid
				safego=alias.SafeEntrance(roomno_now)
				SafeBack=invDirection(safego)
				flyto=tonumber(flytoid)
				flytoid=0
				Simulate("\n�������磬���ֵ�ͼ��"..flyto.."�������\n")
			else 
				alias.searcharea() 
			end
		else
			wait.make(function()
				_f=function()
							gpserrnum=0
							checkmove.NotGPSMove=1
							alias.close_gps()
							pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)
							-- Execute(gps_cmd)
					end
				wait.time(2)
				_f()
			end)
		end	
	else
		if me.menpai=="em" then
			_tb=Split(gpszeikou," ")
			run("kill ".._tb[3]..";halt;persuade ".._tb[3])
		else alias.fjskillskill(gpszeikou) end
	end
end
function alias.walkover_flytoname()
	local _f,_tb
	wait.make(function()
		if flytonamelistsum==1 then
			if string.len(gpszeikou)==0 then
				-- û��������·
				alias.close_gps()
				if gpserrnum==0 then
--				and flytoname==always.where then
					roomno_now=flytoid
					safego=alias.SafeEntrance(roomno_now)
					SafeBack=invDirection(safego)
					flyto=flytoname
					flytoname=""
					flytonamelistsum=0
					flytoid=0
					Simulate("\n���������������Ǹ���,Ϻ�׶��ǳ���������"..flyto.."���������\n")
				else
					_f=function()
								gpserrnum=0
								dropweapon=0
								checkmove.NotGPSMove=1
								alias.close_gps()
								pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)
								-- Execute(gps_cmd)
						end
					wait.time(2);_f()
				end
			else
				-- ��������·
				if me.menpai=="em" then
					_tb=Split(gpszeikou," ")
					run("kill ".._tb[3]..";halt;persuade ".._tb[3])
				else alias.fjskillskill(gpszeikou) end
			end
		else
			if string.len(gpszeikou)==0 then
				-- û��������·
				alias.close_gps()
				if gpserrnum==0 then
					_tb=Split(flytonamelist,"|")
					roomno_now=tonumber(_tb[flytonamelistindex])
					safego=alias.SafeEntrance(roomno_now)
					SafeBack=invDirection(safego)
					flyto=flytoname
					flytosum=flytonamelistsum
					flytoidx=flytonamelistindex
					if flytonamelistindex==flytonamelistsum then
						flytoname=""
						flytonamelistindex=0
						flytonamelistsum=0
						print("ȫ���ص�������ϣ�")
					end
					flytoid=0
					Simulate("\n���ƶ��Ʈ��Ʈ���� "..flytosum.." ����"..flyto.."���еĵ� "..flytoidx.." ������\n")
				else
					if fjroomid==0 then
						-- print("��ֹflytonext��ʱ�����fj����·���ִ�����ʯ�׳���seng��gpserr=1��ʱ��")
						_f=function()
									gpserrnum=0
									checkmove.NotGPSMove=1
									alias.close_gps()
									pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)
									-- Execute(gps_cmd)
							end
						wait.time(2);_f()
					end
				end
			else
				-- ��������·
				if me.menpai=="em" then
					_tb=Split(gpszeikou," ")
					run("kill ".._tb[3]..";halt;persuade ".._tb[3])
				else alias.fjskillskill(gpszeikou) end
			end
		end
	end)
end
function alias.walkover_flytonpc()
	local _f,_tb
	wait.make(function()
		if flytonpclistsum==1 then
			if string.len(gpszeikou)==0 then
				-- û��������·
				alias.close_gps()
				if gpserrnum==0 then
					roomno_now=flytoid
					safego=alias.SafeEntrance(roomno_now)
					SafeBack=invDirection(safego)
					flyto=flytonpc
					flytonpc=""
					flytonpclistsum=0
					flytoid=0
					Simulate("\n��һ�죬�������ɫ�Ʋ���ӭȢ��"..flyto.."��\n")
				else
					_f=function()
								gpserrnum=0
								checkmove.NotGPSMove=1
								alias.close_gps()
								pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)
								-- Execute(gps_cmd)
						end
					wait.time(2);_f()
				end
			else
				-- ��������·
				if me.menpai=="em" then
					_tb=Split(gpszeikou," ")
					run("kill ".._tb[3]..";halt;persuade ".._tb[3])
				else alias.fjskillskill(gpszeikou) end
			end
		else
			if string.len(gpszeikou)==0 then
				-- û��������·
				alias.close_gps()
				if gpserrnum==0 then
					_tb=Split(flytonpclist,"|")
					roomno_now=tonumber(_tb[flytonpclistindex])
					safego=alias.SafeEntrance(roomno_now)
					SafeBack=invDirection(safego)
					flyto=flytonpc
					flytosum=flytonpclistsum
					flytoidx=flytonpclistindex
					if flytonpclistindex==flytonpclistsum then
						flytonpc=""
						flytonpclistindex=0
						flytonpclistsum=0
						print("ȫ��NPC������ϣ�")
					end
					flytoid=0
					Simulate("\n˫�ɣ����ɣ����һ��ɣ��ȡ�"..flytosum.." ���� "..flyto.." ���еĵ� "..flytoidx.." ������\n")
				else
					if fjroomid==0 then
						-- print("��ֹflytonext��ʱ�����fj����·���ִ�����ʯ�׳���seng��gpserr=1��ʱ��")
						_f=function()
									gpserrnum=0
									checkmove.NotGPSMove=1
									alias.close_gps()
									pcall(gps_cmd,gps_cmd_dest,gps_cmd_zone,gps_cmd_num)
									-- Execute(gps_cmd)
							end
						wait.time(2);_f()
					end
				end
			else
				-- ��������·
				if me.menpai=="em" then
					_tb=Split(gpszeikou," ")
					run("kill ".._tb[3]..";halt;persuade ".._tb[3])
				else alias.fjskillskill(gpszeikou) end
			end
		end
	end)
end
function alias.initialize_gps()
	entrance="none"
	xkxGPS.setEntrance(entrance)
end
function alias.gps(a)
	alias.initialize_gps()
	alias.open_gps()
	if a==nil or a=="" then
		--if checkmove.NotGPSMove>0 then run("look;set gps=start") else run("look;set gps=end") end
		run("look;set gps=start")
	else
		run("look "..a..";set gps=check")	
	end
end
function alias.flytoid(id)
	if string.len(gpszeikou)==0 and gpserrnum==0 and isopen("gps_start") then
		print("��ʲô����GPSģ�����������У������ظ�����")
	else
		alias.initialize_gps()
		alias.open_gps()
		flytoname=""
		flytonamelistindex=0
		flytonamelistsum=0
		flytonpc=""
		flytonpclistindex=0
		flytonpclistsum=0
		killnpcover=""
		killnpcnum=0
		flytoid=tonumber(id)
		if flytoid~=nil and flytoid>0 then
			gps_cmd=alias.flytoid
			gps_cmd_dest=flytoid
			gps_cmd_num=nil
			gps_cmd_zone=nil
			--gps_cmd="/alias.flytoid("..tostring(flytoid)..")"
			alias.gps()
		else Simulate("��������ȷ�ķ���ID\n") end
	end
end
function alias.fn()
	alias.flytonext()
end
function alias.flytonext()
	local _tb
	if string.len(gpszeikou)==0 and gpserrnum==0 and isopen("gps_start") then
		print("��ʲô����GPSģ�����������У������ظ�����")
	else
		alias.open_gps()
		if flytonamelistsum>0 then
			flytonamelistindex=flytonamelistindex+1
			if flytonamelistsum>=flytonamelistindex then
				_tb=Split(flytonamelist,"|")
				path=xkxGPS.search(roomno_now,_tb[flytonamelistindex])
				-- print("����·��Ϊ��"..path)
				xkxGPS.pathlist(path)
				pathindex=0
				run("halt")
				run(xkxGPS.pathArray2(pathindex))
			else print("���еص�����������") end
		end
		if flytonpclistsum>0 then
			flytonpclistindex=flytonpclistindex+1
			if flytonpclistsum>=flytonpclistindex then
				_tb=Split(flytonpclist,"|")
				path=xkxGPS.search(roomno_now,_tb[flytonpclistindex])
				-- print("����·��Ϊ��"..path)
				xkxGPS.pathlist(path)
				pathindex=0
				run("halt")
				run(xkxGPS.pathArray2(pathindex))
			else print("���еص�����������") end
		end
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- always_gpsalias
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function alias.trymove(a)
	if string.len(a)>0 then
		trymovesuccess=true
		run(a..";set checkmove=yes")
	end
end
function alias.movefinish()
	killnpcnum=0
	killnpcover=""
	if pathindex==(xkxGPS.pathListNum2-1) and xkxGPS.pathArray2(xkxGPS.pathListNum2)=="set walk over" then
		pathindex=tonumber(pathindex+1)
		run(xkxGPS.pathArray2(pathindex))
	else 
		run("set walk off") 
	end
end
function alias.guohe()
	alias.open_boat()
	gps_gyz_go_e_boat=0
	tunanum=0
	tuna=1
	checkyell=0
	if skillslist["shaolin-shenfa"]==nil then skillslist["shaolin-shenfa"]={} end
	if skillslist["shaolin-shenfa"]["lvl"]==nil then skillslist["shaolin-shenfa"]["lvl"]=1 end
	if skillslist["hunyuan-yiqi"]==nil then skillslist["hunyuan-yiqi"]={} end
	if skillslist["hunyuan-yiqi"]["lvl"]==nil then skillslist["hunyuan-yiqi"]["lvl"]=1 end
	if me.menpai=="sl" and me.master=="����" and tonumber(skillslist["shaolin-shenfa"]["lvl"])>=200 and tonumber(skillslist["hunyuan-yiqi"]["lvl"])>=160 and tonumber(hp.maxneili)>=2000 and jifa["forcename"]=="hunyuan-yiqi" then
		yunbusy=0
		run("yun du;set checkyunbusy=yes")
	else 
		run("yell boat;set checkyell=yes") 
	end
end
function alias.xxgg1xxgg2()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_xxmap")
	gps_xxgg_dict=1432
	run("look")
end
function alias.xxgg2xxgg1()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_xxmap")
	gps_xxgg_dict=1433
	run("look")
end
function alias.wdxymwdsj()
	-- �䵱�����ŵ��䵱ʯ�ף�������֪�͵������������
	killnpcsum=1
	killnpcover="wdxym-wdsj"
	openclass("gps")
	openclass("gps_dealwith")
	if findstring(me.menpai,"wd","em","qz","dl","sl") then alias.trymove("su") else
		if killnpcnum<killnpcsum then
			--killnpcover="wdxym-wdsj"
			if pfmkill() then alias.fjskillskill("GPS ������� lingxu daozhang") else run("kill lingxu daozhang") end
		else 
			alias.trymove("su") 
		end
	end
end
function alias.dmkzcc()
	openclass("boat")
	alias.uw()
	gps_dmkz_cc=1
	run("w")
end
function alias.ccdmkz()
	openclass("boat")
	alias.uw()
	gps_dmkz_cc=0
	run("e")
end
function alias.wdyzgwdbl()
	-- �䵱���湬���䵱���֣�����������������������
	killnpcsum=1
	killnpcover="wdyzg-wdbl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="wd" then alias.trymove("su") else
		if killnpcnum<killnpcsum then
			--killnpcover="wdyzg-wdbl"
			if pfmkill() then alias.fjskillskill("GPS ������� lingxu daozhang") else run("kill lingxu daozhang") end
		else alias.trymove("su") end
	end
end
function alias.opendoorsouth()
	run("open door;s")
	alias.movefinish()
end
function alias.followhudie() --��������
	run("follow hudie")
	alias.movefinish()
end
function alias.greethu() --������ţ
	run("greet hu;e")
	alias.movefinish()
end
function alias.opendoornorth()
	run("open door;n")
	alias.movefinish()
end
function alias.opendoorwest()
	run("open door;w")
	alias.movefinish()
end
function alias.opendooreast()
	if always.where=="Ů������Ϣ��" then run("open ����") end
	run("open door;e")
	alias.movefinish()
end
function alias.opendoorse()
	run("open door;se")
	alias.movefinish()
end
function alias.opendoorsw()
	run("open door;sw")
	alias.movefinish()
end
function alias.opendoorne()
	run("open door;ne")
	alias.movefinish()
end
function alias.opendoornw()
	run("open door;nw")
	alias.movefinish()
end
function alias.wdhdzlwdhy()
	-- �䵱������ȵ��䵱��Ժ���������䵱����������Ϫ
	killnpcsum=1
	killnpcover="wdhdzl-wdhy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="wd" then 
		alias.trymove("s") 
	else
		if killnpcnum<killnpcsum then
			--killnpcover="wdhdzl-wdhy"
			--if pfmkill() then alias.fjskillskill("GPS ����Ϫ zhang songxi") else run("kill zhang songxi") end
			if hp.exp<1000000 then alias.startworkflow() else alias.fjskillskill("GPS ����Ϫ zhang songxi") end
		else 
			alias.trymove("s") 
		end
	end
end
function alias.wdhdzlwdxxzl()
	-- �䵱������ȵ��������ȣ��������䵱����������Ϫ
	killnpcsum=1
	killnpcover="wdhdzl-wdxxzl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="wd" then alias.trymove("w") else
		if killnpcnum<killnpcsum then
			--killnpcover="wdhdzl-wdxxzl"
			--if pfmkill() then alias.fjskillskill("GPS ����Ϫ zhang songxi") else run("kill zhang songxi") end
			if hp.exp<1000000 then alias.startworkflow() else alias.fjskillskill("GPS ����Ϫ zhang songxi") end
		else alias.trymove("w") end
	end
end
function alias.wdhdzlwddxzl()
	-- �䵱������ȵ��������ȣ��������䵱����������Ϫ
	killnpcsum=1
	killnpcover="wdhdzl-wddxzl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="wd" then 
		alias.trymove("e") 
	else
		if killnpcnum<killnpcsum then
			---killnpcover="wdhdzl-wddxzl"
			--if pfmkill() then alias.fjskillskill("GPS ����Ϫ zhang songxi") else run("kill zhang songxi") end
			if hp.exp<1000000 then alias.startworkflow() else alias.fjskillskill("GPS ����Ϫ zhang songxi") end
		else 
			alias.trymove("e") 
		end
	end
end
function alias.xydsmhyl()
	-- �����ɳĮ��������
	for i=1,10,1 do run("w") end
	alias.yjl()
	if me.menpai=="xs" then
		run("drink lubo")
	else
		run("drink jiudai") 
	end
	alias.movefinish()
end
function alias.hylxydsm()
	-- �����ֵ������ɳĮ
	for i=1,10,1 do run("e") end
	alias.yjl()
	if me.menpai=="xs" then
		run("drink lubo")
	else
		run("drink jiudai") 
	end
	alias.movefinish()
end
function alias.btssmqy()
	-- ����ɽɽ�ŵ�ǰԺ����������ɽ���Ĵ�����
	killnpcsum=2
	killnpcover="btssm-qy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="bt" then alias.trymove("wu") else
		if killnpcnum<killnpcsum then
			--killnpcover="btssm-qy"
			if pfmkill() then alias.fjskillskill("GPS �Ҷ� jiading") else run("kill jiading") end
		else alias.trymove("wu") end
	end
end
function alias.xydsmsczl()
	-- �����ɳĮ��˿��֮·
	for i=1,10,1 do run("e") end
	alias.yjl()
	if me.menpai=="xs" then
		run("drink lubo")
	else
		run("drink jiudai") 
	end
	alias.movefinish()
end
function alias.byjybykt()
	-- ���������Ժ�������ҿ������������� ����ү
	killnpcsum=1
	killnpcover="byjy-bykt"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("e") else
		if killnpcnum<killnpcsum then
			--killnpcover="byjy-bykt"
			if pfmkill() then alias.fjskillskill("GPS ����ү hu laoye") else run("kill hu laoye") end
		else alias.trymove("e") end
	end
end
function alias.clbdmclbdt()
	-- ���ְ���ŵ����ְ�������������������� ��ɽ��
	killnpcsum=1
	killnpcover="clbdm-clbdt"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" or hp.exp~=nil and hp.exp<100000 then 
		alias.trymove("enter") 
	else
		if killnpcnum<killnpcsum then
			--killnpcover="clbdm-clbdt"
			if pfmkill() then alias.fjskillskill("GPS ��ɽ�� qiu shanfeng") else run("kill qiu shanfeng") end
		else 
			alias.trymove("enter") 
		end
	end
end
function alias.clbxtclbws()
	-- ���ְ�С�������ְ����ң���������צ������˾ͽ��
	killnpcsum=1
	killnpcover="clbxt-clbws"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="clbxt-clbws"
			if pfmkill() then alias.fjskillskill("GPS ˾ͽ�� situ heng") else run("kill situ heng") end
		else alias.trymove("n") end
	end
end
function alias.clbydclbss()
	-- ���ְ��������ְ�ʯ�ң����������� ����
	killnpcsum=1
	killnpcover="clbyd-clbss"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("e") else
		if killnpcnum<killnpcsum then
			killnpcover="clbyd-clbss"
			if pfmkill() then alias.fjskillskill("GPS ���� changle bangzhong") else run("kill changle bangzhong") end
		else 
			alias.trymove("e") 
		end
	end
end
function alias.dladfxy()
	-- ������������СԺ�������������佫 ��˼��
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_dl_fsg")
	openclass("gps_thrownpc")
	thrownpcfaint=false
	alias.trymove("s")
end
function alias.enterdong()
	if me.menpai=="th" and yp.goto>0 then run("s;w;order stay;e;n");yp.stay_room=983;print("�Ҷ������ݶĳ�����") end
	run("enter dong")
	alias.movefinish()
end
function alias.enterpicture()
	if skillslist.lamaism~=nil and skillslist.lamaism.lvl>=150 then
		run("enter picture")
	else
		run("e;s;s;w")
	end
	alias.movefinish()
end
function alias.xxgg1tsysd()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_xxmap")
	gps_xxgg_dict=1434
	run("look")
end
function alias.tsysdxxgg1()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_xxmap")
	gps_xxgg_dict=1433
	run("look")
end
function alias.emhcazdemhcagc()
	-- ���һ�������������ֹ㳡����������ʦ̫
	killnpcsum=1
	killnpcover="emhcazd-emhcagc"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="em" then alias.trymove("s") else
		if killnpcnum<killnpcsum then
			--killnpcover="emhcazd-emhcagc"
			if pfmkill() then alias.fjskillskill("GPS ���� jing xin") else run("kill jing xin") end
		else alias.trymove("s") end
	end
end
function alias.emjld99guai()
	-- ���Ҿ��϶��ڵ���ʮ�ŵ���
	cmdonsuccess="northeast"
	yinshecmd="halt;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw"
	cmdonsheexist="down;wu"
	openclass("gps_dealwith")
	openclass("gps_99guai")
	run("set ��������ڲ���")
end
function alias.emqfa99guai()
	-- ����ǧ���ֵ���ʮ�ŵ���
	cmdonsuccess="southwest"
	yinshecmd="halt;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne;sw;ne"
	cmdonsheexist="down;wu"
	openclass("gps_dealwith")
	openclass("gps_99guai")
	run("set ��������ڲ���")
end
function alias.gbqzlgbtdm()
	run("e;n;w;n;e;w;n")
	alias.movefinish()
end
function alias.gbkilljian()
	-- ؤ������С��������С����������ִ�����ϡ�����
	killnpcsum=1
	killnpcover="gb-killjian"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="gb" then 
		alias.trymove("e") 
	else
		if killnpcnum<killnpcsum then
--			killnpcover="gb-killjian"
			--print(killnpcnum)
			if pfmkill() then alias.fjskillskill("GPS ���� jian zhanglao") else run("kill jian zhanglao") end
		else 
			alias.trymove("e") 
		end
	end
end
function alias.gyzguohe()
	if me.menpai~="th" then run("ask lu about ����ׯ;decide") end
	alias.guohe()
end
function alias.gyzdmqy()
	-- ����ׯ���ŵ�����ׯǰԺ�����Ҷ�����
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="th" then alias.trymove("enter") else
		run("give ding xin")
		alias.trymove("enter")
	end
end
function alias.hslwchskt()
	-- ��ɽ���䳡����ɽ�����������͵�ŵ
	killnpcsum=1
	killnpcover="hslwc-hskt"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("s") else
		if killnpcnum<killnpcsum then
			--killnpcover="hslwc-hskt"
			if pfmkill() then alias.fjskillskill("GPS �͵�ŵ lao denuo") else run("kill lao denuo") end
		else alias.trymove("s") end
	end
end
function alias.hslwchsbqf()
	-- ��ɽ���䳡����ɽ�������������͵�ŵ
	killnpcsum=1
	killnpcover="hslwc-hsbqf"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("w") else
		if killnpcnum<killnpcsum then
			--killnpcover="hslwc-hsbqf"
			if pfmkill() then alias.fjskillskill("GPS �͵�ŵ lao denuo") else run("kill lao denuo") end
		else alias.trymove("w") end
	end
end
function alias.hsdlhssy()
	-- ��ɽ���ȵ���ɽ��Ժ����������
	killnpcsum=1
	killnpcover="hsdl-hssy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("e") else
		if killnpcnum<killnpcsum then
			--killnpcover="hsdl-hssy"
			if pfmkill() then alias.fjskillskill("GPS ���� liang fa") else run("kill liang fa") end
		else alias.trymove("e") end
	end
end
function alias.hshyhszl()
	-- ��ɽ��Ժ����ɽ���ȣ�����½����
	killnpcsum=1
	killnpcover="hshy-hszl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("s") else
		if killnpcnum<killnpcsum then
			--killnpcover="hshy-hszl"
			if pfmkill() then alias.fjskillskill("GPS ½���� lu dayou") else run("kill lu dayou") end
		else alias.trymove("s") end
	end
end
function alias.hslwjggk()
	run("enter ������")
	alias.movefinish()
end
function alias.hspthsdlgf()
	-- ��ɽƫ������ɽ��������������������
	killnpcsum=1
	killnpcover="hspt-hsdlgf"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("e") else
		if killnpcnum<killnpcsum then
			--killnpcover="hspt-hsdlgf"
			if pfmkill() then alias.fjskillskill("GPS ������ ning zhongze") else run("kill ning zhongze") end
		else alias.trymove("e") end
	end
end
function alias.hspthsqs()
	-- ��ɽƫ������ɽ���ң�����������
	killnpcsum=1
	killnpcover="hspt-hsqs"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("s") else
		if killnpcnum<killnpcsum then
			--killnpcover="hspt-hsqs"
			if pfmkill() then alias.fjskillskill("GPS ������ ning zhongze") else run("kill ning zhongze") end
		else alias.trymove("s") end
	end
end
function alias.hspthsxlgf()
	-- ��ɽƫ������ɽ��������������������
	killnpcsum=1
	killnpcover="hspt-hsxlgf"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("w") else
		if killnpcnum<killnpcsum then
			--killnpcover="hspt-hsxlgf"
			if pfmkill() then alias.fjskillskill("GPS ������ ning zhongze") else run("kill ning zhongze") end
		else alias.trymove("w") end
	end
end
function alias.openzhumenwest()
	run("open ����;w")
	alias.movefinish()
end
function alias.openzhumeneast()
	run("open ����;e")
	alias.movefinish()
end
function alias.hsxlhscf()
	-- ��ɽ���ȵ���ɽ���������������
	killnpcsum=1
	killnpcover="hsxl-hscf"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("w") else
		if killnpcnum<killnpcsum then
			--killnpcover="hsxl-hscf"
			if pfmkill() then alias.fjskillskill("GPS ����� yue lingshan") else run("kill yue lingshan") end
		else alias.trymove("w") end
	end
end
function alias.hsxslhsxz()
	-- ��ɽСɽ·����ɽ��ɽС��������ʩ����
	killnpcsum=1
	killnpcover="hsxsl-hsxz"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("w") else
		if killnpcnum<killnpcsum then
			--killnpcover="hsxsl-hsxz"
			if pfmkill() then alias.fjskillskill("GPS ʩ���� shi daizi") else run("kill shi daizi") end
		else alias.trymove("w") end
	end
end
function alias.hztyjdmqsl()
	-- ������ӥ�̴��ŵ���ʯ·��������ӥ������
	killnpcsum=2
	killnpcover="hztyjdm-qsl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="mj" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="hztyjdm-qsl"
			if pfmkill() then alias.fjskillskill("GPS ��ӥ������ shou wei") else run("kill shou wei") end
		else alias.trymove("n") end
	end
end
function alias.klmlmsj()
	-- ����ɽĦ���ŵ�ʯ�ף�����˵����
	killnpcsum=1
	killnpcover="klmlm-sj"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="mj" then alias.trymove("up") else
		if killnpcnum<killnpcsum then
			--killnpcover="klmlm-sj"
			if pfmkill() then alias.fjskillskill("GPS ˵���� shuo bude") else run("kill shuo bude") end
		else alias.trymove("up") end
	end
end
function alias.kljssk()
	run("push dashi;enter")
	alias.movefinish()
end
function alias.lmbjxy()
	-- ���������ھֵ�СԺ�����������
	killnpcsum=1
	killnpcover="lmbj-xy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("enter") else
		if killnpcnum<killnpcsum then
			--killnpcover="lmbj-xy"
			if pfmkill() then alias.fjskillskill("GPS ����� du dajin") else run("kill du dajin") end
		else alias.trymove("enter") end
	end
end
function alias.lsddytgk()
	-- ���ߵ���������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_lsd_back")
	run("yell chuan;enter;start;w")
	alias.dz(200)
end
function alias.tgklsddy()
	-- �����ڵ����ߵ�
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_lsd_go")
	run("yell chuan;enter;start;s")
	alias.dz(200)
end
function alias.qzqcjy()
	-- ȫ����ǵ���Զ
	--run("n;e;s;w;n;n")
	run("e;s;w;n")
	alias.movefinish()
end
function alias.qzqcxy()
	-- ȫ����ǵ�����
	--run("n;e;e;e;e;e")
	run("e;e;e;e")
	alias.movefinish()
end
function alias.qzxyqc()
	-- ȫ�����µ����
	--run("w;w;w;w;w;s")
	run("w;w;w;w")
	alias.movefinish()
end
function alias.qzjyqc()
	-- ȫ�澸Զ�����
	--run("s;s;e;n;w;s")
	run("s;e;n;w")
	alias.movefinish()
end
function alias.lzbmcf()
	-- �������ݱ��ŵ��񷿣������ʹ���ʿ
	killnpcsum=2
	killnpcover="lzbm-cf"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then
		run("open door")
		alias.trymove("w")
	else
		if killnpcnum<killnpcsum then
			--killnpcover="lzbm-cf"
			if pfmkill() then alias.fjskillskill("GPS �ʹ���ʿ wei shi") else run("kill wei shi") end
		else
			run("open door")
			alias.trymove("w")
		end
	end
end
function alias.lzdjjfjjfdy()
	-- �������ݴ󽫾�������������Ժ������Уξ
	killnpcsum=2
	killnpcover="lzdjjf-jjfdy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("s") else
		if killnpcnum<killnpcsum then
			--killnpcover="lzdjjf-jjfdy"
			if pfmkill() then alias.fjskillskill("GPS Уξ xiao wei") else run("kill xiao wei") end
		else alias.trymove("s") end
	end
end
function alias.movegang()
	run("move gang")
	alias.movefinish()
end
function alias.nantianyuhuang()
	--run("ask jiang about ��ɽ;nu")
	--alias.movefinish()
	openclass("gps")
	openclass("gps_dealwith")
	killnpcsum=1
	killnpcover="kill jiang baisheng"
	run("ask jiang about ��ɽ")
	alias.trymove("nu")
end
function alias.nycjnynm()
	-- �����ǽ����������ţ������سǹٱ�
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_nanyang")
	openclass("gps_thrownpc")
	thrownpcfaint=false
	alias.trymove("enter")
end
function alias.opengatesouth()
	run("open gate;s")
	alias.movefinish()
end
function alias.qcsdw()
	-- ��ǵ�÷����ʯ����
	--run("n;e;s")
	run("e;s")
	alias.movefinish()
end
function alias.sdwqc()
	-- ÷����ʯ���⵽���
	--run("n;w;s")
	run("n;w")
	alias.movefinish()
end
function alias.qcqzsm()
	-- ��ǵ�ȫ��ɳĮ
	run("n")
	alias.movefinish()
end
function alias.qzsmqc()
	-- ȫ��ɳĮ�����
	--run("n;w;w;w;w;w;s")
	run("n;w;w;w;w;w;s")
	alias.movefinish()
end
function alias.qzsmxy()
	-- ȫ��ɳĮ������
	run("n;e;e;e;e;e")
	alias.movefinish()
end
function alias.xyqzsm()
	-- ���µ�ȫ��ɳĮ
	run("w;w;w;w;w")
	alias.movefinish()
end
function alias.qzxyclimbup()
	-- ȫ�����µ��¶�
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_climbxy")
	run("climb up")
end
function alias.qzxyclimbdown()
	-- �¶���ȫ������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_climbxy")
	run("climb down")
end
function alias.qlqtfsd()
	-- ����ɽ����嵽�������ɽ��
	run("move stone;enter")
	alias.movefinish()
end
function alias.qldtht()
	-- ������̴��õ��������������������ʿ
	killnpcsum=2
	killnpcover="qldt-ht"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="qldt-ht"
			if pfmkill() then alias.fjskillskill("GPS ���������ʿ rysj weishi") else run("kill rysj weishi") end
		else alias.trymove("n") end
	end
end
function alias.qlxtdl()
	-- ������̴��õ����Σ��������������ʿ
	killnpcsum=2
	killnpcover="qlxt-dl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then
		run("open door")
		alias.trymove("d") else
		if killnpcnum<killnpcsum then
			--killnpcover="qlxt-dl"
			if pfmkill() then alias.fjskillskill("GPS ���������ʿ rysj weishi") else run("kill rysj weishi") end
		else
			run("open door")
			alias.trymove("d")
		end
	end
end
function alias.qldlxt()
	-- ������̴��ε������������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_waitrelease")
end
function alias.qztjqzyxd()
	-- ȫ��̨�׵����ĵ������־��
	killnpcsum=1
	killnpcover="qztj-qzyxd"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="qz" then alias.trymove("wu") else
		if killnpcnum<killnpcsum then
			--killnpcover="qztj-qzyxd"
			if pfmkill() then alias.fjskillskill("GPS ��־�� zhang zhiguang") else run("kill zhang zhiguang") end
		else alias.trymove("wu") end
	end
end
function alias.qlycmgdcy()
	-- �������ɹŴ��ԭ
	run("n;n;n;n;n;n;n;n;e;e;n;n;n;e;n;n;n")
	alias.yjl()
	alias.movefinish()
end
function alias.qlmgdcyyc()
	-- �ɹŴ��ԭ������
	run("s;s;s;s;s;s;s;s;s;s;s;s;s;s;s")
	alias.yjl()
	alias.movefinish()
end
function alias.qzlcmcx()
	-- Ȫ�����ֵ��ײ�������ٱ����佫
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_qzh_mcx")
	openclass("gps_thrownpc")
	thrownpcfaint=false
	alias.trymove("ne")
end
function alias.slgatesl()
	-- Ȫ��ʩ�Ž��������������������ٱ����佫
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_qzh_sl")
	openclass("gps_thrownpc")
	thrownpcfaint=false
	alias.trymove("n")
end
function alias.yzhyyzwf()
	-- ���ݺ�Ժ��Ѿ���Է�����������˼
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_yz_lts")
	openclass("gps_thrownpc")
	thrownpcfaint=false
	alias.trymove("w")
end
function alias.gumuenter()
	run("wd")
	alias.movefinish()
end
function alias.turnleft()
	run("turn left")
	alias.movefinish()
end
function alias.enterguan()
	run("enter guan")
	alias.movefinish()
end
function alias.yzymymzt()
	-- �������ŵ�������������������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_yz_ym")
	openclass("gps_thrownpc")
	thrownpcfaint=false
	alias.trymove("s")
end
function alias.ynfslynfxj()
	-- ��ɽ��Ů��ɽ·����ɽ��Ů��С���������߸���
	killnpcsum=1
	killnpcover="ynfsl-ynfxj"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="hs" then alias.trymove("nu") else
		if killnpcnum<killnpcsum then
			--killnpcover="ynfsl-ynfxj"
			if pfmkill() then alias.fjskillskill("GPS �߸��� gao genming") else run("kill gao genming") end
		else alias.trymove("nu") end
	end
end
function alias.slssj()
	-- ������2�鵽ʯ�ף�������ͨ����
	killnpcsum=2
	killnpcover="sls-sj"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="sl" then alias.trymove("eu") else
		if killnpcnum<killnpcsum then
			--killnpcover="sls-sj"
			run("kill xu")
		else alias.trymove("eu") end
	end
end
function alias.slqfdslzl()
	-- ����ǧ�����֣�������۱���
	killnpcsum=1
	killnpcover="slqfd-slzl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="sl" then
		run("open door")
		alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="slqfd-slzl"
			if pfmkill() then alias.fjskillskill("GPS ��۱��� biqiu") else run("kill biqiu") end
		else
			run("open door")
			alias.trymove("n")
		end
	end
end
function alias.xssmxsdgc()
	-- ѩɽɽ�ŵ�ѩɽ��㳡���������ײ�
	killnpcsum=2
	killnpcover="xssm-xsdgc"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="xs" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="xssm-xsdgc"
			if pfmkill() then alias.fjskillskill("GPS ���ײ� ge lunbu") else run("kill ge lunbu") end
		else alias.trymove("n") end
	end
end
function alias.xsjgyxshy()
	-- ѩɽ���Ժ��ѩɽ��Ժ��������ľ���
	killnpcsum=1
	killnpcover="xsjgy-xshy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="xs" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="xsjgy-xshy"
			if pfmkill() then alias.fjskillskill("GPS ��ľ��� samu huofo") else run("kill samu huofo") end
		else alias.trymove("n") end
	end
end
function alias.xsclxsdd()
	-- ѩɽ���ȵ�ѩɽ����������ɮ
	killnpcsum=2
	killnpcover="xscl-xsdd"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="xs" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="xscl-xsdd"
			if pfmkill() then alias.fjskillskill("GPS ����ɮ jielv seng") else run("kill jielv seng") end
		else alias.trymove("n") end
	end
end
function alias.xxysdxxh()
	-- ������ɽ�������޺�������ʨ����
	killnpcsum=1
	killnpcover="xxysd-xxh"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="xx" then alias.trymove("nd") else
		if killnpcnum<killnpcsum then
			--killnpcover="xxysd-xxh"
			if pfmkill() then alias.fjskillskill("GPS ʨ���� shihou zi") else run("kill shihou zi") end
		else alias.trymove("nd") end
	end
end
function alias.xxysdxxxw()
	-- ������ɽ����Сľ�ݣ�����ʨ����
	killnpcsum=1
	killnpcover="xxysd-xxxw"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="xx" then alias.trymove("w") else
		if killnpcnum<killnpcsum then
			--killnpcover="xxysd-xxxw"
			if pfmkill() then alias.fjskillskill("GPS ʨ���� shihou zi") else run("kill shihou zi") end
		else alias.trymove("w") end
	end
end
function alias.xxsdxxxyd()
	-- ����ʯ������ң���������ɻ���
	killnpcsum=1
	killnpcover="xxsd-xxxyd"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="xx" then alias.trymove("enter") else
		if killnpcnum<killnpcsum then
			--killnpcover="xxsd-xxxyd"
			if pfmkill() then alias.fjskillskill("GPS �ɻ��� caihua zi") else run("kill caihua zi") end
		else alias.trymove("enter") end
	end
end
function alias.xxyptdmyptdy()
	-- ����һƷ�ô��ŵ�һƷ�ô�Ժ������һƷ����ʿ
	killnpcsum=4
	killnpcover="xxyptdm-yptdy"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="xxyptdm-yptdy"
			if pfmkill() then alias.fjskillskill("GPS һƷ����ʿ wu shi") else run("kill wu shi") end
		else alias.trymove("n") end
	end
end
function alias.xxyptdydyq()
	-- ����һƷ�ô�Ժ�������죬����һƷ����ʿ
	killnpcsum=4
	killnpcover="xxyptdy-dyq"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("open door;w") else
		if killnpcnum<killnpcsum then
			--killnpcover="xxyptdy-dyq"
			if pfmkill() then alias.fjskillskill("GPS һƷ����ʿ wu shi") else run("kill wu shi") end
		else alias.trymove("open door;w") end
	end
end
function alias.yzxlyzxsq()
	-- ����С·��ŷ���˵�Сɽ�𣬴����Ů
	killnpcsum=2
	killnpcover="yzxl-yzxsq"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="bt" then alias.trymove("wu") else
		if killnpcnum<killnpcsum then
			--killnpcover="yzxl-yzxsq"
			if pfmkill() then alias.fjskillskill("GPS �Ů binu") else run("kill binu") end
		else alias.trymove("wu") end
	end
end
function alias.gyzdmqy2()
	-- ����ׯ���ŵ�����ׯǰԺ�������Ҷ�
	killnpcsum=2
	killnpcover="gyzdm-qy2"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="th" then alias.trymove("enter") else
		if killnpcnum<killnpcsum then
			--killnpcover="gyzdm-qy2"
			if pfmkill() then alias.fjskillskill("GPS �Ҷ� jia ding") else run("kill jia ding") end
		else alias.trymove("enter") end
	end
end
function alias.yzsclknshp()
	-- ���ݽ�������·�ڵ�Ůɽ���ϣ������ɹž���
	killnpcsum=1
	killnpcover="yzsclk-nshp"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then alias.trymove("se") else
		if killnpcnum<killnpcsum then
			--killnpcover="yzsclk-nshp"
			if pfmkill() then alias.fjskillskill("GPS �ɹž��� junguan") else run("kill junguan") end
		else alias.trymove("se") end
	end
end
function alias.qzcjgcjg3l()
	-- ȫ��ؾ����¥����¥������̷����
	killnpcsum=1
	killnpcover="qzcjg-cjg3l"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="qz" then
		run("ask tan about ����")
		alias.trymove("u")
	else
		if killnpcnum<killnpcsum then
			--killnpcover="qzcjg-cjg3l"
			if pfmkill() then alias.fjskillskill("GPS ̷���� tan chuduan") else run("kill tan chuduan") end
		else
			run("ask tan about ����")
			alias.trymove("u")
		end
	end
end
function alias.slcsfzl()
	-- ���ֲ��ҵ�����¥���������ֱ���
	killnpcsum=1
	killnpcover="slcs-fzl"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="sl" then alias.trymove("n") else
		if killnpcnum<killnpcsum then
			--killnpcover="slcs-fzl"
			if pfmkill() then alias.fjskillskill("GPS ���ֱ��� qingle biqiu") else run("kill qingle biqiu") end
		else alias.trymove("n") end
	end
end
function alias.xxyptdtyptms()
	-- ����һƷ�ô�����һƷ�����ң�����һƷ����ʿ
	killnpcsum=2
	killnpcover="xxyptdt-yptms"
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="" then
		run("open door")
		alias.trymove("w")
	else
		if killnpcnum<killnpcsum then
			--killnpcover="xxyptdt-yptms"
			if pfmkill() then alias.fjskillskill("GPS һƷ����ʿ wu shi") else run("kill wu shi") end
		else
			run("open door")
			alias.trymove("w")
		end
	end
end
function alias.xydcy1xydcy2()
	-- ������ԭ
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_xydcy")
	gps_xydcy_reachdest=0
	run("east;set checkxydcy=yes")
end
function alias.sgyydsgymd()
	run("use fire;left")
	alias.movefinish()
end
function alias.sgyydsgysd()
	alias.wi("jian")
	run("strike wall;out")
	alias.uw()
	alias.movefinish()
end
function alias.sgysdsgyyd()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_sgy_sd")
	gps_checkmianbi=false
	for i=1,10,1 do run("mianbi") end
	run("set checkmianbi=yes")
end
function alias.qzxmlsg()
	openclass("gps_dealwith")
	openclass("gps_qzh_xmdq")
	run("look;set checklook=yes")
end
function alias.qzlsgxm()
	openclass("gps_dealwith")
	openclass("gps_qzh_xmdq")
	run("look;set checklook=yes")
end
function alias.slgcslsmd()
	-- ���ֹ㳡��ɽ�ŵ��������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_sl_gate")
	run("knock gate")
end
function alias.slzlsldmd()
	-- �������ֵ���Ħ��
	run("sw;se;n;s;w;e;w;e;e;s;w;n;nw;n")
	alias.movefinish()
end
function alias.slslslsl()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_sl_sl")
	run("look")
end
function alias.slqypslsj()
	-- ��������ƺ������ʯ��
	run("sd;w;e;n;e;s;n;e;w;s")
	alias.movefinish()
end
function alias.slsslslqyp()
	-- ���������ֵ���������ƺ
	run("w;e;s;e;n;n;e;w;s")
	alias.movefinish()
end
function alias.slhdaslhxa()
	-- ���պӶ���������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_slh")
	alias.wi("jian")
	run("chop shuzhi")
end
function alias.xydcysl()
	-- ������ԭ������
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_xydcy_sl")
	gps_xydcy_reachdest=0
	run("north;set checkxydcy=yes")
end
function alias.kldsmhks()
	-- ���ش�ɳĮ������ɽ
	run("se;s")
	alias.movefinish()
end
function alias.yzjwslyzjwxf()
	-- ���ݽ������ֵ���������
	run("pa shang;pa zuo;pa shang;pa zuo;pa shang;pa zuo;pa shang;pa zuo;pa xia;pa xia;pa xia;pa xia;w")
	wait.make(function()
		local _f=function() alias.movefinish() end
		wait.time(2)
		_f()
	end)
end
function alias.yzjwxfyzjwsl()
	-- ���ݽ����������ŵ�����
	run("halt;e;pa shang;pa shang;pa shang;pa shang;pa you;pa xia;pa you;pa xia;pa you;pa xia;pa you;pa xia")
	wait.make(function()
		local _f=function() alias.movefinish() end
		wait.time(2)
		_f()
	end)
end
function alias.yztd1yztd2()
	-- ������ش���
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_yztd_1_2")
	run("look")
end
function alias.yztd2yztd1()
	-- ������ش���
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_yztd_2_1")
	run("look")
end
function alias.yztd2yztd3()
	-- ������ش���
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_yztd_2_3")
	run("look")
end
function alias.yztd3yztd2()
	-- ������ش���
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_yztd_3_2")
	run("look")
end
function alias.zsthdht()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_thd_go")
	run("yell chuan")
end
function alias.thdthlxj()
	thlfinish="xiaojing"
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_thd_thl")
	trymovesuccess=false
	run("time")
end
function alias.thdthlsc()
	thlfinish="shidong"
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_thd_thl")
	trymovesuccess=false
	run("time")
end
function alias.thjsslx()
	openclass("gps")
	openclass("gps_dealwith")
	if me.menpai=="th" and (me.master=="��Ӣ" or me.master=="��ҩʦ") then
		alias.trymove("enter")
	else
		run("ask gu about ��;agree")
		wait.make(function()
			local _f=function() alias.trymove("enter") end
			wait.time(2)
			_f()
		end)
	end
end
function alias.thxzdd()
	run("push left;push left;push left;push right;push right;push right;push front")
	wait.make(function()
		local _f=function()
			run("enter")
			alias.movefinish()
		end
		wait.time(1)
		_f()
	end)
end
function alias.thddms()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_thd_ms")
	run("press ǫ")
end
function alias.thdhtzs()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_thd_back")
	run("yell chuan")
end
function alias.emkilljumang()
	openclass("gps")
	openclass("gps_dealwith")
	openclass("gps_99guai")
	mangsheexist=1
	alias.checkbusy("jm")
end
function alias.findway()
	run("find way")
	alias.movefinish()
end
function alias.qzsmqzqc()
	-- ȫ��ɳĮ�����
	run("s")
	alias.movefinish()
end
function alias.hsxypt()
	-- ��ɽ���µ������ƽ̨
	if have.shengzi then
		run("zha stone;climb down;guanmo jianhen")
		alias.movefinish()
	else alias.checkitems() end
end
function alias.hsptxy()
	-- ��ɽ�����ƽ̨������
	run("climb up")
	alias.movefinish()
end
function alias.pressstone()
	run("press stone;down")
	alias.movefinish()
end
function alias.tangcoffin()
	run("tang coffin")
	alias.movefinish()
end
function alias.fengqy()
	run("feng")
	alias.movefinish()
end
function alias.opendoordown()
	run("open door;d")
	alias.movefinish()
end
function alias.opendoorup()
	run("open door")
	if roomno_now==2026 then run("release yuanshi") end
	run("u")
	alias.movefinish()
end
function alias.knockqz()
	run("knock door;n")
	alias.movefinish()
end
function alias.askwangsd()
	--run("ask wang about miji")
	run("sd")
	alias.movefinish()
end
function alias.askwangn()
	--run("ask wang about miji")
	run("n")
	alias.movefinish()
end
function alias.gbmdcenter()
	run("say ������·�㲻��ѽ;down")
	alias.movefinish()
	run("set checkGbSecretWay=err")
end
function alias.gbmddgc()
	-- ��ȳ���ؤ���ص�
	run("enter gudui")
	alias.movefinish()
end
function alias.gbmdtdm()
	-- ���������ص�
	run("enter dong")
	alias.movefinish()
end
function alias.gbmdslcf()
	-- ����ɽ�ų������ص�
	run("enter dong")
	alias.movefinish()
end
function alias.gbmdsc()
	-- ˿��֮·���ص�
	run("push shibei")
	alias.movefinish()
end
function alias.gbmdtfw()
	-- �䵱�����ѵ��ص�
	run("halt;enter dong")
	alias.movefinish()
end
function alias.gbmdqzhtdm()
	-- Ȫ��������
	run("enter dong")
	alias.movefinish()
end
function alias.gbmdemcp()
	-- ���Ҳ��ﵽ�ص�
	run("move lid")
	alias.movefinish()
end
function alias.gbmdxssl()
	-- ѩɽɽ·���ص�
	run("jump ѩ��")
	alias.movefinish()
end
function alias.nxsjump()
	-- ������ţ��ʯ
	run("jump ţ��ʯ")
	alias.movefinish()
end
function alias.nxsback()
	-- ţ��ʯ��������
	run("jump back")
	alias.movefinish()
end
function alias.leave9ld()
	-- �뿪���Ҿ��϶�
	run("leave")
	alias.movefinish()
end
function alias.yellzhou()
	-- ���϶��ڵ�������
	openclass("gps_dealwith")
	openclass("gps_zhou")
	run("kill monkey;kill monkey 2;kill monkey 3")
	run("yell ���º���")
end
function alias.qzhntms()
	-- Ȫ��ҩ�����õ�����
	run("turn ball;down")
	alias.movefinish()
end
function alias.qzhmsnt()
	-- Ȫ��ҩ�����ҵ�����
	run("turn ball;up")
	alias.movefinish()
end
function alias.tsthsup()
	-- ̩ɽ̽��ʯ��ȥ
	run("jump up")
	alias.movefinish()
end
function alias.tsthsdown()
	-- ̩ɽ̽��ʯ����
	run("jump down")
	alias.movefinish()
end
------------------------------------------------------------------------------------
-- startworkflow ��������
------------------------------------------------------------------------------------
function alias.startay()
	print("��ͨ����")
	alias.setaoyao_tongmaidan()
	openclass("common")
	openclass("aoyao")
	zjd_buylist()
	alias.flytonpc("��ͨ��")
end
function alias.startaobadan()
	print("���˵�")
	alias.setaoyao_badan()
	openclass("common")
	openclass("aoyao")
	alias.flytonpc("��ͨ��")
end
function alias.startxue()
	local _tb
	alias.initialize_trigger()
	workflow.nowjob="xue"
	nextJobGodazuobase=1
	if me.menpai=="gm" and skillslist["force"]["lvl"]<400 and skillslist["force"]["lvl"]<me.maxlvl then usepot="xue" end --��Ĺ���force�ȼ�����400�����ȹ�Ħ��
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��xue") end
	--if (pdfjsj()<0 or havefj>0) and not isopen("boat") then
	if havefj>0 and not isopen("boat") then
		--print("����ʱ�䲻��10��,ȥ�ȴ�fj")
		alias.startfj()
	elseif hp.healthqi==100 and have.jcy>1 and skillslist.force~=nil and skillslist.force.lvl<101 and skillslist.force.lvl<me.maxlvl then	--С��force����100������ǰ�ȼ�С�ڿ���֧�ֵ����ȼ�
		openclass("basic_skills_force")
		alias.flytoid(356)
	elseif hp.healthqi==100 and have.jcy>1 and jifa.strikename~=nil and skillslist.strike~=nil and skillslist.strike.lvl<101 and skillslist.strike.lvl>10 and skillslist.strike.lvl<me.maxlvl then	--С��strike����100������ǰ�ȼ�С�ڿ���֧�ֵ����ȼ�
		openclass("basic_skills_strike")
		alias.flytoid(780)
	elseif hp.healthqi==100 and have.jcy>1 and jifa.cuffname~=nil and skillslist.cuff~=nil and skillslist.cuff.lvl<101 and skillslist.cuff.lvl>10 and skillslist.cuff.lvl<me.maxlvl then  --С��fcuff����100������ǰ�ȼ�С�ڿ���֧�ֵ����ȼ�
		print("test")
		openclass("basic_skills_cuff")
		alias.flytoid(809)
	elseif skillslist["xuantie-jianfa"]~=nil and workflow.fj>0 and (have.zhongjian>0 or have.xuantiejian>0) and skillslist["xuantie-jianfa"]["lvl"]<tonumber(me.maxlvl-3) and skillslist["xuantie-jianfa"]["lvl"]<skillslist["sword"]["lvl"] then
		print("���۷����������")
		run("jiali 0")
		if jifa.parryname~="xuantie-jianfa" then run("jifa parry xuantie-jianfa;jifa") end
		openclass("basic_skills_xtjf")
		run("jiali 0")
		alias.flytoid(234)
	elseif skillslist.dodge~=nil and have.jcy>1 and skillslist.dodge.lvl<300 and skillslist.dodge.lvl<me.maxlvl and have.swjing>0 then --�������ھ��Զ�����
		print("��ʼ������")
		openclass("basic_skills_dodge")
		basic_skills.paya=0
		if jifa.dodge~=nil and jifa.dodge>=135 then
			alias.flytoid(1422)
		else
			alias.flytoid(1404)
		end
	--elseif (me.menpai~="th" and hp.pot<50) or (me.menpai=="th" and hp.thpot<50 and hp.pot<50) then
	--	if de_bug>0 then print("û��Ǳ�ܣ�����������") end
	--	alias.dz("addneili")
	else
		-- ��ʼxue
		wx.taiji=0
		wx.zhixin=0
		--skillsfull=0
		skills_num=1
		if do_gm_job3==nil then do_gm_job3=0 end
		if have.jingyao>0 or have.jyzj>0 or (have.cstlnj>0 and hp.pot>50) or (have.lxj>0 and hp.pot>50) then
			if de_bug>0 then print("�о�Ҫ���ȶ�") end
			openclass("skills_jingyao")
			if me.jingyaoBaseid>0 then alias.flytoid(me.jingyaoBaseid) else alias.flytoid(me.fjbaseid) end
		--elseif xuelit>0 and daytime and hp.pot<hp.maxpot+200 then
		elseif xuelit>0 and (daytime or skillslist["literate"]["lvl"]<100) then
			if me.menpai=="th" and roomno_now==1470 then run("ask lu chengfeng about abandon;ask lu chengfeng about Ҫ������");fjend=0 end
			if de_bug>0 then print("��������ѧ����д��") end
			openclass("skills_xue")
			alias.checklitmaster()
			--alias.flytonpc(me.litmaster)
			alias.flytoid(me.litmasterroom)
		elseif dummy.laopo~=nil and dummy.laopo~="" then 
			run("tell "..dummy.laopo.." go")
			alias.flyto("�����Ϣ��")
			openclass("skills_xue")
		elseif usepot=="xue" and (me.menpai~="mj" or mj.haveyd<1) then
			if de_bug>0 then print("ȥѧϰ") end
			-- if de_bug>0 then print("��ѧϰ������ţ�ȥѧʦ����������") end
			--daytime=false
			openclass("skills_xue")
			if me.menpai=="th" and roomno_now==1470 and always.where=="�鷿" then run("ask lu chengfeng about abandon;ask lu chengfeng about Ҫ������");fjend=0 end
			if me.masterroom~=nil and me.masterroom~="" then alias.flytoid(me.masterroom)
			elseif me.menpai=="gm" then	alias.flytoid(2078)
			else alias.flytonpc(me.master) 
			end
		elseif usepot=="lingwu" or (me.menpai=="mj" and mj.lvl~=nil and mj.lvl>1) then
			openclass("skills_lingwu")
			if de_bug>0 then print("ȥ����") end
			if me.menpai=="th" then
				if roomno_now==1470 then run("ask lu chengfeng about abandon;ask lu chengfeng about Ҫ������");fjend=0 end
			elseif me.menpai=="mj" then
				if have.tyl<1 then alias.checkitems() end
			end
			if lingwuat=="shaolin" then alias.flyto("��ĦԺ��¥") else alias.flyto(me.menpailingwuid) end
		else
			if de_bug>0 then print("��ѧϰ������û�о�Ҫ������������") end
			alias.dz("addneili")
		end
	end
end
function alias.startxinfa()
	alias.initialize_trigger()
	workflow.nowjob="xinfa"
	nextJobGodazuobase=0
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��xinfa") end
	if (pdfjsj()<0 or havefj>0) and not isopen("boat") then
		--print("����ʱ�䲻��10��,ȥ�ȴ�fj")
		if me.menpai=="th" then alias.startfj() else alias.startxue() end
	else
		if workflow.xf>0 then
			--if have.zhongjian>0 and skillslist["xuantie-jianfa"]~=nil and skillslist["xuantie-jianfa"]["lvl"]>=0 then
			if workflow.xf>1 then
				openclass("xf_wd")
				openclass("wd_xtjf")
				alias.flytonpc("ͭ��")
			elseif me.menpai=="sl" and skillslist["buddhism"]~=nil and skillslist["buddhism"]["lvl"]>=400 then
				if zuochan>0 then
					print("�����ӷ���ö���")
					openclass("xinfa")
					openclass("xf_sl")
					openclass("sl_zc")
					zuochan_checkchui=1
					alias.flytoid(1703)
				elseif songjingtime~=nil and songjingtime>0 then
					print("�����ӷ���ö���")
					openclass("xinfa")
					openclass("xf_sl")
					openclass("sl_sj")
					alias.flytoid(1131)
				else
					print("�����㿪ʼ����")
					alias.close_xinfa()
					alias.startworkflow()
				end
			elseif me.menpai=="em" then
				openclass("xf_em")
				alias.flyto(370)
			elseif me.menpai=="hs" then
				openclass("xf_hs")
				alias.flyto("����̨")
			elseif me.menpai=="mj" and skillslist["manicheism"]["lvl"]<500 then
				openclass("xf_mj")
				alias.flytoid(1)
			elseif me.menpai=="mj" and skillslist["shenghuo-ling"]~=nil and ((skillslist["shenghuo-ling"]["lvl"]>=51 and skillslist["shenghuo-ling"]["lvl"]<=100) or (skillslist["shenghuo-ling"]["lvl"]>=151 and skillslist["shenghuo-ling"]["lvl"]<=200) or (skillslist["shenghuo-ling"]["lvl"]>=251 and skillslist["shenghuo-ling"]["lvl"]<=300) or (skillslist["shenghuo-ling"]["lvl"]>=351 and skillslist["shenghuo-ling"]["lvl"]<=400) or (skillslist["shenghuo-ling"]["lvl"]>=451 and skillslist["shenghuo-ling"]["lvl"]<=500) or (skillslist["shenghuo-ling"]["lvl"]>=550)) then
				print("shl fight")
				openclass("mj_shl")
				alias.flytonpc("ͭ��")
			else
				print("�����㿪ʼ����")
				alias.close_xinfa()
				alias.startworkflow()
			end
		else
			alias.close_xinfa()
			alias.startworkflow()
		end
	end
end
function alias.startcm()
	-- ��ʼcm
	alias.initialize_trigger()
	workflow.nowjob="cm"
	nextJobGodazuobase=0
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��chongmai") end
	if (pdfjsj()<0 or havefj>0) and not isopen("boat") then
		--print("����ʱ�䲻��10��,ȥ�ȴ�fj")
		if me.menpai=="th" then alias.startfj() else alias.startxue() end
	else
		openclass("chongmai")
		openclass("chongmai_pre")
		openclass("chongmai_watch")
		closeclass("chongmai_start")
		if dummy.jy~="" and (os.time()>stat.cmbuff and os.time()>stat.drugbusy) then 
			run("tell "..dummy.jy.." ��û�г�����") 
			cm.havebuff=0
		end
		alias.checkitems()
	end
end
function alias.startfjclose()
	alias.initialize_trigger()
	openclass("fj")
	openclass("fj_close")
	alias.flytoid(me.fjbaseid)
end
function alias.startgbresume()
	if de_bug>0 then print("��ʼstartgbresume") end
	alias.initialize_trigger()
	workflow.nowjob="mp"
	nextJobGodazuobase=0
	openclass("menpai")
	-- ����δ�����gold����
	openclass("mp_gb")
	closeclass("mp_gb_gold")
	openclass("mp_gb_pre")
	closeclass("mp_gb_sx")
	openclass("mp_gb_watch")
	--alias.flytoid(gold.roomNo)
	gb.gotobeg()
end
function alias.startftb()
	alias.initialize_trigger()
	workflow.nowjob="ftb"
	nextJobGodazuobase=1
	print("Լ"..pdfjsj().."�����ʱ��ftb")
	if (pdfjsj()<30 or havefj>0) and not isopen("boat") then
		print("����ʱ�䲻��30��,ȥ�ȴ�fj")
		if me.menpai=="th" then alias.startfj() else alias.startxue() end
	else
		if ftbjf~=nil and ftbjf~="" then alias.jf(ftbjf) end
		openclass("ftb")
		openclass("ftb_pre")
		closeclass("ftb_ask")
		closeclass("ftb_start")
		flytoareastartid=0
		alias.checkitems()
		--if tonumber(roomno_now)==1705 then alias.checkitems() else alias.flyto("����","����") end
	end
end
function alias.startqzwd()
	alias.initialize_trigger()
	workflow.nowjob="qzwd"
	nextJobGodazuobase=0
	print("Լ"..pdfjsj().."�����ʱ��qzwd")
	if (pdfjsj()<15 or havefj>0) and not isopen("boat") then
		print("����ʱ�䲻��15��,ȥ�ȴ�fj")
		if me.menpai=="th" then alias.startfj() else alias.startxue() end
	else
		--if not isopen("boat") then
			openclass("qzwd")
			openclass("qzwd_pre")
			openclass("qzwd_watch")
			openclass("qzwd_start")
			alias.checkitems()
		--else
		--	print("���Ӳ�ɧ��")
		--end
	end
end
function alias.startmp()
	alias.initialize_trigger()
	workflow.nowjob="mp"
	nextJobGodazuobase=0
	if (pdfjsj()<mpdrutime or havefj>0) and not isopen("boat") and me.menpai~="gm" and me.menpai~="xx" and not stat.use_jinhua then
		print("����ʱ�䲻��"..mpdrutime.."��,ȥ�ȴ�fj")
		if me.menpai=="th" or havefj>0 then 
			alias.startfj() 
		elseif hp.pot>50 then
			alias.startxue() 
		elseif workflow.cm>0 then
			alias.startcm()
		else
			alias.dz()
		end
	else
		openclass("menpai")
		if mpjf~=nil and mpjf~="" then alias.jf(mpjf) end
		if do_dl_job==1 then
			openclass("mp_dl")
			openclass("mp_dl_pre")
			openclass("mp_dl_watch")
		else
			openclass("mp_"..me.menpai)
			openclass("mp_"..me.menpai.."_pre")
			openclass("mp_"..me.menpai.."_watch")
		end
		alias.checkitems()
	end
end
function alias.startfj()
	if de_bug>0 then print("��ʼfj") end
	alias.initialize_trigger()
	workflow.nowjob="fj"
	if havefj>0 and fjroom~=nil and string.len(fjroom)>0 then
		nextJobGodazuobase=1
	else
		nextJobGodazuobase=0
	end
	openclass("fj")
	openclass("fj_pre")
	openclass("fj_watch")
	closeclass("fj_start")
	if fjjf~=nil and fjjf~="" then alias.jf(fjjf) end
	alias.checkitems()
end
function alias.startyb()
	-- print("��ʼyb")
	alias.initialize_trigger()
	workflow.nowjob="yb"
	nextJobGodazuobase=0
	ybjob.haveyixing=0
	print("Լ"..pdfjsj().."�����ʱ��yb(���ȿ���)")
	if havefj>0 and ybjob.ybstatus==0 and not isopen("boat") and not (ybjob.waitlimit>0 and ybLimited==0) then
		print("����ʱ�䲻��60��,ȥ�ȴ�fj")
		if me.menpai=="th" then alias.startfj() else alias.startxue() end
	elseif pdfjsj()<20 and not (ybjob.waitlimit>0 and ybLimited==0) then
		if me.menpai=="mj" then alias.startmp() else alias.startxue() end
	else
		openclass("michen_yb")
		alias.open_yb()
		if me.menpai=="th" and roomno_now==1470 then 
			if havefj>0 then
				alias.startfj()
			else
				run("ask lu chengfeng about Ҫ������;ask lu about ����")
				fjend=0 
				yp.goto=0
				yp.stay_room=0
			end
		end
		--if yb.jf~=nil and yb.jf~="" then alias.jf(yb.jf) end  --�ŵ���������ټ���
		alias.checkitems()
	end
end
function alias.startwar()
	--if de_bug>0 then print("��ʼwar") end
	print("��ʼwar")
	alias.initialize_trigger()
	workflow.nowjob="war"
	nextJobGodazuobase=0
	openclass("war_pre")
	closeclass("war_start")
	if war.jf~=nil and war.jf~="" then alias.jf(war.jf) end
	if war.waring==0 then
		alias.checkitems()
	elseif stat.haveyyz>0 then 
		alias.starttongmai()
	elseif stat.havedu>0 then 
		alias.startliaoshang()
	elseif war.waring==1 then
		alias.flytoid(1945)
	elseif war.waring==2 then
		alias.flytoid(1933)
	end
	--alias.dealwithitems_weapon()
end
function alias.start_teamwith()
    if shouldActivateTeamwith() then
		openclass("war_start_timer")
		closeclass("war_pre_time")
    end	
end
function alias.starttongmai()
	alias.initialize_trigger()
	openclass("common")
	openclass("tongmai")
	alias.flytoid(950)
end
function alias.startliaoshang()
	alias.initialize_trigger()
	openclass("common")
	nextJobGodazuobase=1
	run("stand;dismiss")
	if jifa.forcename=="taiji-shengong" and me.menpai=="wd" then
		openclass("yinyun")
		alias.checkbusy("yinyun")
	elseif jifa.forcename=="xiantian-gong" and skillslist["xiantian-gong"]["lvl"]>299 then
		openclass("bidu")
		alias.checkbusy("bidu")
	elseif stat.havehbdu>0 and jifa.forcename=="xuanyin-zhenqi" and skillslist["xuanyin-zhenqi"]["lvl"]>79 then
		openclass("xuan")
		alias.checkbusy("xuan")
	elseif jifa.forcename=="hamagong" then
		openclass("qudu")
		alias.checkbusy("qudu")
	elseif jifa.forcename=="kurong-changong" then
		openclass("cure")
		alias.checkbusy("cure")
	elseif jifa.forcename=="huagong-dafa" and me.menpai=="xx" then
		alias.startmp()
	else
		openclass("liaoshang")
		if me.menpai=="th" then for i=1,3,1 do run("fu qingxin san") end end
		alias.flytonpc("�κ�ҩ")
		--if hp.healthjing<85 then alias.flytonpc("�κ�ҩ") else alias.flyto("�����Ϣ��") end
	end
	--if me.menpai=="sl" or me.menpai=="hs" or me.menpai=="em" or me.menpai=="gb" or me.menpai=="gm" or me.menpai=="th" or me.menpai=="xs" then
	--	openclass("liaoshang")
	--	run("stand")
	--	alias.flyto("����")
	--end
	--if me.menpai=="wd" then
	--	openclass("yinyun")
	--	alias.checkbusy("yinyun")
	--end
	--if me.menpai=="qz" then
	--	openclass("bidu")
	--	alias.checkbusy("bidu")
	--end
	--if me.menpai=="bt" then
	--	openclass("qudu")
	--	alias.checkbusy("qudu")
	--end
	--if me.menpai=="dl" then
	--if me.menpai=="dl" or jifa.forcename=="kurong-changong" then
	--	openclass("cure")
	--	alias.checkbusy("cure")
	--end
	--if me.menpai=="xx" then
	--	alias.startmp()
	--end
end
------------------------------------------------------------------------------------
-- setmpLimitedMark
------------------------------------------------------------------------------------
function alias.setmpLimitedMark()
	local _t
	if gb.Limited1>0 then
		if os.time()>tonumber(mpLimited.MarkTimebeg1)+3600 or tonumber(mpLimited.beg1)<7000 then
			gb.Limited1=0
			mpLimited.beg1=0
		end
	end
	if gb.Limited2>0 then
		if os.time()>tonumber(mpLimited.MarkTimebeg2)+3600 or tonumber(mpLimited.beg2)<7000 then
			gb.Limited2=0
			mpLimited.beg2=0
		end
	end
	if mpJobLimited>0 then
		--mpJobLimited=mpLimited.stat()
		--if os.time()>tonumber(mpLimited.MarkTime)+3600 or (os.time()>tonumber(mpLimited.MarkTime)+3530 and (me.menpai=="th" or me.menpai=="mj")) or tonumber(mpLimited.mpexp)<tonumber(mpLimited.MarkExp) then
		if os.time()>tonumber(mpLimited.MarkTime)+3600 or tonumber(mpLimited.mpexp)<tonumber(mpLimited.MarkExp) then
			mpJobLimited=0
			suckLimited=0 --xx suck limited
		end
		if mpJobLimited==0 then
			mpLimited.mpexp=0
			if me.menpai=="bt" then
				xy.xyLimited=0
				xy.limitedResume=0
				xy.biteLimited=0
				xy.checkfirstbite=1
			end
		end
	end
	if (ybexp>100 or ybLimited>0) and (os.time()-tonumber(ybLimitedMarkTime))>=3600 then
		ybLimited=0
		ybexp=0
	end
	if (WarExp>1000 or WarLimited>0) and (os.time()-tonumber(WarLimitedMarkTime))>=3400 then
		WarLimited=0
		WarExp=0
	end
end
function alias.setmpReCountTime() --����ͳ������ʱ��
	if me.menpai=="gb" then --2017.10.10
		if (gb.Limited1==0 and (os.time()-mpLimited.MarkTimebeg1)>=3600) or (mpLimited.type=="beg1" and (gb.Limited1>0 or mpLimited.beg1<2) and add.exp>20) then
			mpLimited.beg1=0
			mpLimited.MarkTimebeg1=os.time()
			--print("chexpgb:"..mpLimited.type)
		end
		if (gb.Limited2==0 and (os.time()-mpLimited.MarkTimebeg2)>=3600) or (mpLimited.type=="beg2" and (gb.Limited2>0 or mpLimited.beg2<2) and add.exp>20) then
			mpLimited.beg2=0
			mpLimited.MarkTimebeg2=os.time()
			--print("chexpgb:"..mpLimited.type )
		end
		mpLimited.type=""
	end
	if add.exp>20 then
		if (mpJobLimited==0 and (os.time()-mpLimited.MarkTime)>=3600) or mpJobLimited>0 then
			--mpLimited.mpexp=add.exp
			mpLimited.mpexp=0
			mpLimited.MarkTime=os.time()
		end
	end
end
function alias.setybReCountTime() --����ͳ��Ѻ��ʱ��
	if add.exp>100 then
		if (ybLimited==0 and (os.time()-tonumber(ybLimitedMarkTime))>=3600) or ybLimited>0 then
			ybexp=0
			ybLimitedMarkTime=os.time()
			print("��ʼͳ��Ѻ��ʱ��")
		end
	end
end
function alias.setWarReCountTime() --����ͳ��Warʱ��
	if add.exp>1000 then
		if (WarLimited==0 and (os.time()-tonumber(WarLimitedMarkTime))>=3600) or WarLimited>0 then
			WarExp=0
			WarLimitedMarkTime=os.time()
			print("��ʼͳ��Warʱ��")
		end
	end
end
------------------------------------------------------------------------------------
-- setaoyao
------------------------------------------------------------------------------------
function alias.setaoyao_badan()
	-- ���ð������˵�
	aoyao.yaoName="�����˵�"
	aoyao.yaoid="badan"
	aoyao.buyNameList="����|�չ�|�ۻ�|����|������"
	aoyao.buyidList="fuling|jugeng|xionghuang|tianqi|heshouwu"
	aoyao.buyno=1
	aoyao.needgold=3
end
function alias.setaoyao_tongmaidan()
	-- ���ð��Ͻ�ͨ����
	aoyao.yaoName="�Ͻ�ͨ����"
	aoyao.yaoid="dan"
	aoyao.buyNameList="��ɽ��|¹��|����|ѩ��|����"
	aoyao.buyidList="lao shanshen|lurong|shexiang|xuelian|fuling"
	aoyao.buyno=1
	aoyao.needgold=401
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function alias.tdz()
	local _f
	closeclass("dazuo_resetidle")
	closeclass("dazuo")
	wait.make(function()
		_f=function()
			if me.menpai=="gm" and roomno_now==2077 then run("xiachuang") end
			run("yun recover;set dazuo=over")
			alias.resetidle()		
		end
		wait.time(2);_f()
	end)
end
function alias.tlw()
	closeclass("skills_lian")
	run("halt;set lian=over")
	alias.uw()
	tuna=0
end
function alias.lianwu()
	local _tb,a
	--print("test")
	openclass("skills")
	openclass("skills_lian")
	_tb=Split(skills_lingwu,"|")
	_t=function(a)
		if a>500 then 
			--return 0
			return 1
		else
			return 1
		end
	end
	alias.choose_liansk(_tb[skills_num])
	--if skills_num<#_tb and 
	if skills_num<=#_tb and (skillslist[_tb[skills_num]]==nil or skillslist[jifa[_tb[skills_num].."name"]]==nil or (jifa[_tb[skills_num].."name"]=="yunu-xinjing" and skillslist["yunu-xinjing"]["lvl"]>400) or jifa[_tb[skills_num].."name"]=="xuantie-jianfa" or (skillslist[_tb[skills_num]]["lvl"]<=skillslist[jifa[_tb[skills_num].."name"]]["lvl"] and tonumber(skillslist[jifa[_tb[skills_num].."name"]]["lvl"]+_t(skillslist[jifa[_tb[skills_num].."name"]]["lvl"]+1))^2<skillslist[jifa[_tb[skills_num].."name"]]["sld"]) or (_tb[skills_num]=="force" and skillslist[jifa["forcename"]]["lvl"]>=me.maxlvl) or (jifa[_tb[skills_num].."name"]=="hanbing-mianzhang")) then
		if _tb[skills_num]==nil then _tb[skills_num]="nil" end
		print("�����ڣ�"..skills_num.."�����ܡ�".._tb[skills_num].."��")
		if _tb[skills_num]=="force" then
			addforce=1
		end
		skills_num=skills_num+1
		alias.lianwu()
		return
	end
	if skills_num>#_tb then 
		a=1
		for k,v in ipairs(_tb) do --ѭ��һ�������б��������С�ڼ��ܵȼ����޵ģ���û�е���������
			if skillslist[v]~=nil and skillslist[v]["lvl"]<me.maxlvl and v~=force then
				a=0
				break
			end
		end
		if a>0 then skillsfull=1 end
	end
	run("hp;set lian")
end
function alias.startlianwu()
	skills_num=1
	alias.lianwu()
end
function alias.dz(a)
	openclass("dazuo")
	run("yun regenerate")
	resumejob=""
	if me.dazuobaseid~=0 and roomno_now~=me.dazuobaseid and me.jingyaoBaseid~=0 and roomno_now~=me.jingyaoBaseid and not isopen("fj_start") and not isopen("ftb_ask") and not isopen("boat") and not isopen("skills_lingwu") and not isopen("skills_xue") and not isopen("mp_qz_start") and nextJobGodazuobase>0 then
		if tonumber(a)~=nil then type_dz=tonumber(set_neili) else type_dz=a end
		if a==nil or tonumber(a)==nil then 
			alias.flytoid(me.dazuobaseid)
		else
			if hp.neili>(hp.maxneili*type_dz/100) then 
				alias.tdz()
				print("�Ƿ�˴���������")
			else
				if hp.neili>(hp.maxneili*(type_dz-15)/100) then
					run("hp;set checkhp="..a)
				else 
					alias.flytoid(me.dazuobaseid) 
				end
			end
		end
	else
		if a==nil or tonumber(a)==nil then run("set checkhp=addneili") else run("hp;set checkhp="..a) end
	end
	nextJobGodazuobase=0
end
function alias.dz1()
	type_dz=tonumber(set_neili)
	openclass("dazuo")
	openclass("dazuo_resetidle")
end
function alias.et()
	if have.he>0 then
		if hp.food<50 and hp.water<hp.maxwater or hp.food<hp.maxfood and hp.water<50 then
			run("get ji from shi he;drink ji;put ji in shi he")
		end
	end
end
function alias.checklitmaster()
	if skillslist["literate"]["lvl"]>=100 then
		me.litmaster="����"
		me.litmasterid="zhu"
		me.litmasterroom=1020
	elseif skillslist["literate"]["lvl"]>=30 then
		me.litmaster="ŷ��ղ"
		me.litmasterid="ouyang"
		me.litmasterroom=83
	else
		me.litmaster="�����"
		me.litmasterid="xiucai"
		me.litmasterroom=819
	end
end
function alias.xuemaster()
	local _tb
	alias.setmpLimitedMark()
	alias.close_dz()
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��xuemaster") end
	if (pdfjsj()<0 or havefj>0) and not isopen("boat") then
	--	print("����ʱ�䲻��10��,ȥ�ȴ�fj")
		alias.startfj()
	else
			if havefj>0 then 
				run("set startworkflow=yes")
			else
				if pdmpsj() and xuefirst==0 then
					alias.startmp()
				else
					if stat.zhixin==0 and jifa.forcename=="linji-zhuang" then run("yun zhixin") end
					if me.menpai=="gm" then	--��Ĺ�ɹ�Ħ̫�����Զ����Ħ˳�򣬲��ܼ��ܶ�������
						if skillslist["yunu-xinjing"]["lvl"]<150 and skillslist["yunu-xinjing"]["lvl"]<me.maxlvl then skills_xue="yunu-xinjing"	--���ȹ�Ħ150����Ů�ľ�
						elseif skillslist["meinu-quan"]==nil then skills_xue="meinu-quan"	--û����Ůȭ���͹�ĦһЩ
						elseif skillslist["gumu-shenfa"]==nil then skills_xue="gumu-shenfa" --û�й�Ĺ�������͹�ĦһЩ
						elseif skillslist["cuff"]==nil or skillslist["cuff"]["lvl"]<30 then skills_xue="cuff" --��Ħ30������ȭ��
						elseif skillslist["dodge"]==nil or skillslist["dodge"]["lvl"]<30 then skills_xue="dodge" --��Ħ30�������Ṧ
						elseif skillslist["parry"]==nil or skillslist["parry"]["lvl"]<30 then skills_xue="parry" --��Ħ30�������м�
						elseif skillslist["yunu-jianfa"]==nil then skills_xue="yunu-jianfa" --��ĦһЩ��Ů����
						elseif skillslist["sword"]==nil or skillslist["sword"]["lvl"]<30 then skills_xue="sword" --30����������
						elseif skillslist["force"]["lvl"]<400 and skillslist["force"]["lvl"]<me.maxlvl then skills_xue="force" --��Ħ�����ڹ�
						else skills_xue="suxin-jue" --���ڴ����򹤻��߾��鳬��2.7M ��Ħ���ľ�
						end
					end
					_tb=Split(skills_xue,"|")
					if skills_num>#_tb then skills_num=1 end
					if dummy.laopo~=nil and dummy.laopo~="" and roomname=="�����Ϣ��" then
						run("xue "..dummy.laopo.." ".._tb[skills_num].." 20")
					elseif me.menpai=="gm" and roomno_now==2078 then
						run("guanmo ".._tb[skills_num])
					elseif daytime and roomno_now~=nil and roomno_now==1020 or skillslist["literate"]["lvl"]<100 and (roomno_now==83 or roomno_now==819) then
						if xuelit>0 then
						    if hp.pot>0 and hp.pot<20 then run("xue "..me.litmasterid.." literate "..hp.pot) else run("xue "..me.litmasterid.." literate 20") end
						else
						    alias.startworkflow()
						end
					else
						if me.menpai=="mj" then
							if have.tyl<1 then openclass("mp_mj_pre");alias.checkitems()
							elseif mj.ask~=nil and mj.ask~="" then alias.checkbusy("ask")
							else run("qingjiao "..me.masterid.." ".._tb[skills_num].." 20") end
						else
							if master_skillslist["force"]==nil then run("cha "..me.masterid) end
							if #skillslist_need_up>0 then 
								_t=skillslist_need_up[1]
								run("xue "..me.masterid.." ".._t.." 1") --ѧһ������ļ���
							elseif usepots~=nil and tonumber(usepots)>0 and hp.pot>0 then
								run("xue "..me.masterid.." ".._tb[skills_num].." "..usepots)
							elseif hp.pot>0 and (hp.pot<30 or _tb[skills_num]=="poison") then
								run("xue "..me.masterid.." ".._tb[skills_num].." "..hp.pot)
							elseif usepots~=nil and tonumber(usepots)>0 then
								run("xue "..me.masterid.." ".._tb[skills_num].." "..usepots)
							else
								run("xue "..me.masterid.." ".._tb[skills_num].." 30")
							end
						end
					end
				end
			end
		--end
	end
end
function alias.lianskills()
	local _tb,a,_t,_t1
	alias.setmpLimitedMark()
	alias.close_dz()
	local function _t1(a)
		if a>500 then 
			--return 0
			return 1
		else
			return 1
		end
	end
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��lianskills") end
	if roomname=="��ĦԺ��¥" and me.menpai~="gb" and me.menpai~="sl" then a=10 else a=0 end
	if (pdfjsj()<a or havefj>0) and not isopen("boat") then
		print("����ʱ�䲻��"..a.."��,ȥ�ȴ�fj")
		alias.uw()
		if me.menpai=="bt" then run("release yuanshi") end
		if me.menpai=="qz" then run("return book") end
		if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
		if me.menpai=="dl" then run("dismiss") end
		if me.menpai=="gm" then run("halt;xiachuang") end
		alias.startfj()
	else
		_tb=Split(skills_lingwu,"|")
		alias.choose_liansk(_tb[skills_num])
		--if skills_num<#_tb and 
		if skills_num<=#_tb and (skillslist[_tb[skills_num]]==nil or skillslist[jifa[_tb[skills_num].."name"]]==nil or (skillslist[_tb[skills_num]]["lvl"]<=skillslist[jifa[_tb[skills_num].."name"]]["lvl"] and tonumber(skillslist[jifa[_tb[skills_num].."name"]]["lvl"]+1)^2<skillslist[jifa[_tb[skills_num].."name"]]["sld"]) or (_tb[skills_num]=="force" and skillslist[jifa["forcename"]]["lvl"]>=me.maxlvl) or (jifa[_tb[skills_num].."name"]=="hanbing-mianzhang")) then
			print("�����ڣ�"..skills_num.."������a")
			if _tb[skills_num]=="force" then
				addforce=1
			end
			skills_num=skills_num+1
			alias.lianskills()
			return
		end
		if skills_num>#_tb then
			if isopen("mp_gb_pre") then
				closeclass("skills_lian")
				alias.uw()
				run("u")
				--lianwunum=0
				roomno_now=1116
				skills_num=1
				run("set lian=full")
			else run("set lian=over") end
		else
			run("halt")
			if me.menpai=="th" and hp.pot<1 then run("huan 1") end
			if _tb[skills_num]=="sword" and jifa.swordname=="tiandi-fenglei" and skillslist["tiandi-fenglei"]["lvl"]>320 then
				run("lian ".._tb[skills_num].." 0")
			elseif (me.menpai=="dl" and roomno_now==194) or (me.menpai=="xs" and roomno_now==1853) then  --Ҫ����λ�����ɣ���������
				run("lian ".._tb[skills_num].." 10")
			else
				run("lian ".._tb[skills_num].." 30")
			end
		end
	end
end
function alias.choose_liansk(sk)  --�л�������ϰ��������
	local _f,a
	_f=1
	a=501  --������ϰ�ȼ�
	if (isopen("skills_lingwu") and isopen("skills_lian")) or (me.menpai=="th" and workflow.nowjob~="yb" and isopen("boat")) then --ֻ������ʱ�л�����
		local function _t(a)
			if a>500 then 
				return 1
			else
				return 1
			end
		end
		if sk=="finger" and skillslist[jifa.fingername]~=nil and skillslist["finger"]~=nil then --����ѡ��Ҫ��ϰ��ָ��
			if skillslist["liumai-shenjian"]~=nil and skillslist["liumai-shenjian"]["lvl"]~=201 and skillslist["liumai-shenjian"]["lvl"]~=401 and skillslist["liumai-shenjian"]["lvl"]~=601 and skillslist["liumai-shenjian"]["lvl"]~=801 and skillslist["liumai-shenjian"]["lvl"]~=1001 and skillslist["liumai-shenjian"]["lvl"]<me.maxlvl and (roomno_now==me["menpailingwuid"] or roomno_now==213 or skillslist["liumai-shenjian"]["lvl"]<skillslist["finger"]["lvl"]) then
					if jifa.fingername~="liumai-shenjian" then run("jifa finger liumai-shenjian;jifa") end
					--�������������
					jifa.fingername="liumai-shenjian"
			elseif skillslist[jifa.fingername]["lvl"]>=skillslist["finger"]["lvl"] and skillslist[jifa.fingername]["sld"]>=(skillslist[jifa.fingername]["lvl"]+_t(skillslist[jifa.fingername]["lvl"]))^2 then
				if skillslist["yiyang-zhi"]~=nil and skillslist["kurong-changong"]~=nil and skillslist["kurong-changong"]["lvl"]>=50 and skillslist["yiyang-zhi"]["lvl"]<skillslist["finger"]["lvl"] and skillslist["yiyang-zhi"]["lvl"]<a then
					run("jifa finger yiyang-zhi;jifa")
					--�����ϰһ��ָ
					jifa.fingername="yiyang-zhi"
				elseif skillslist["tiangang-zhi"]~=nil and skillslist["linji-zhuang"]~=nil and skillslist["linji-zhuang"]["lvl"]>=10 and skillslist["tiangang-zhi"]["lvl"]<skillslist["finger"]["lvl"] and skillslist["tiangang-zhi"]["lvl"]<a then
					run("jifa finger tiangang-zhi;jifa")
					--�ٴ���ϰ���ָѨ��
					jifa.fingername="tiangang-zhi"
				elseif skillslist["nianhua-zhi"]~=nil and skillslist["hunyuan-yiqi"]~=nil and skillslist["hunyuan-yiqi"]["lvl"]>=20 and skillslist["nianhua-zhi"]["lvl"]<skillslist["finger"]["lvl"] and skillslist["nianhua-zhi"]["lvl"]<a and skillslist["jingang-quan"]~=nil and skillslist["jingang-quan"]["lvl"]>=120 then
					run("jifa finger nianhua-zhi;jifa")
					--�ٴ���ϰ�����黨ָ
					jifa.fingername="nianhua-zhi"
				elseif skillslist["yizhi-chan"]~=nil and skillslist["hunyuan-yiqi"]~=nil and skillslist["hunyuan-yiqi"]["lvl"]>=20 and skillslist["yizhi-chan"]["lvl"]<skillslist["finger"]["lvl"] and skillslist["yizhi-chan"]["lvl"]<a and skillslist["banruo-zhang"]~=nil and skillslist["banruo-zhang"]["lvl"]>=180 then
					run("jifa finger yizhi-chan;jifa")
					--�ٴ���ϰ����һָ��
					jifa.fingername="yizhi-chan"
				end
			end
		elseif sk=="sword" and skillslist[jifa.swordname]~=nil and skillslist["sword"]~=nil then --����ѡ��Ҫ��ϰ�Ľ���
			if jifa.swordname=="xuantie-jianfa" or (skillslist[jifa.swordname]["lvl"]>=skillslist["sword"]["lvl"] and (skillslist[jifa.swordname]["sld"]>=(skillslist[jifa.swordname]["lvl"]+_t(skillslist[jifa.swordname]["lvl"]))^2 or skillslist[jifa.swordname]["lvl"]>=me.maxlvl)) then
				if  me.menpai=="gm" and skillslist["quanzhen-jian"]~=nil and skillslist["yunu-xinjing"]~=nil and skillslist["yunu-xinjing"]["lvl"]>=50 and skillslist["quanzhen-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["yunu-jianfa"]["lvl"]>skillslist["quanzhen-jian"]["lvl"] then
					--��Ĺ��ȫ�潣
					run("jifa sword quanzhen-jian;jifa")
					jifa.swordname="quanzhen-jian"
				elseif skillslist["quanzhen-jian"]~=nil and skillslist["xiantian-gong"]~=nil and skillslist["xiantian-gong"]["lvl"]>=10 and skillslist["quanzhen-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["quanzhen-jian"]["lvl"]<a and skillslist["quanzhen-jian"]["lvl"]<me.maxlvl then
					--��������ȫ�潣
					run("jifa sword quanzhen-jian;jifa")
					jifa.swordname="quanzhen-jian"
				elseif skillslist["tangshi-jian"]~=nil and skillslist["tangshi-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["tangshi-jian"]["lvl"]<a and skillslist["tangshi-jian"]["lvl"]<me.maxlvl then
					--��ʬ��
					run("jifa sword tangshi-jian;jifa")
					jifa.swordname="tangshi-jian"
				elseif skillslist["emei-jian"]~=nil and skillslist["linji-zhuang"]~=nil and skillslist["linji-zhuang"]["lvl"]>=20 and skillslist["emei-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["emei-jian"]["lvl"]<a and skillslist["emei-jian"]["lvl"]<me.maxlvl then
					--��ü����
					run("jifa sword emei-jian;jifa")
					jifa.swordname="emei-jian"
				elseif skillslist["baihong-jianfa"]~=nil and skillslist["motian-yunqi"]~=nil and skillslist["motian-yunqi"]["lvl"]>=20 and skillslist["baihong-jianfa"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["baihong-jianfa"]["lvl"]<a and skillslist["baihong-jianfa"]["lvl"]<me.maxlvl then
					--�׺罣��
					run("jifa sword baihong-jianfa;jifa")
					jifa.swordname="baihong-jianfa"
				elseif skillslist["huashan-jianfa"]~=nil and skillslist["zixia-gong"]~=nil and skillslist["zixia-gong"]["lvl"]>=25 and skillslist["huashan-jianfa"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["huashan-jianfa"]["lvl"]<a and skillslist["huashan-jianfa"]["lvl"]<me.maxlvl then
					--��ɽ����
					run("jifa sword huashan-jianfa;jifa")
					jifa.swordname="huashan-jianfa"
				elseif skillslist["bagua-jianfa"]~=nil and skillslist["huntian-qigong"]~=nil and skillslist["huntian-qigong"]["lvl"]>=20 and skillslist["bagua-jianfa"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["bagua-jianfa"]["lvl"]<a and skillslist["bagua-jianfa"]["lvl"]<me.maxlvl then
					--���Խ���
					run("jifa sword bagua-jianfa;jifa")
					jifa.swordname="bagua-jianfa"
				elseif skillslist["taiji-jian"]~=nil and skillslist["taiji-shengong"]~=nil and skillslist["taiji-shengong"]["lvl"]>=20 and skillslist["mian-zhang"]~=nil and skillslist["mian-zhang"]["lvl"]>=20 and skillslist["taiji-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["taiji-jian"]["lvl"]<a and skillslist["taiji-jian"]["lvl"]<me.maxlvl then
					--̫������
					run("jifa sword taiji-jian;jifa")
					jifa.swordname="taiji-jian"
				elseif skillslist["yuxiao-jian"]~=nil and skillslist["bitao-xuangong"]~=nil and skillslist["bitao-xuangong"]["lvl"]>=50 and skillslist["yuxiao-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["yuxiao-jian"]["lvl"]<a and skillslist["yuxiao-jian"]["lvl"]<me.maxlvl then
					--���｣��
					run("jifa sword yuxiao-jian;jifa")
					jifa.swordname="yuxiao-jian"
				elseif skillslist["duanjia-jian"]~=nil and skillslist["kurong-changong"]~=nil and skillslist["kurong-changong"]["lvl"]>=20 and skillslist["duanjia-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["duanjia-jian"]["lvl"]<a and skillslist["duanjia-jian"]["lvl"]<me.maxlvl then
					--�μҽ���
					run("jifa sword duanjia-jian;jifa")
					jifa.swordname="duanjia-jian"
				elseif skillslist["mingwang-jian"]~=nil and skillslist["longxiang-banruo"]~=nil and skillslist["longxiang-banruo"]["lvl"]>=20 and skillslist["mingwang-jian"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["mingwang-jian"]["lvl"]<a and skillslist["mingwang-jian"]["lvl"]<me.maxlvl then
					--������������
					run("jifa sword mingwang-jian;jifa")
					jifa.swordname="mingwang-jian"
				elseif skillslist["yunu-jianfa"]~=nil and skillslist["yunu-xinjing"]~=nil and skillslist["yunu-xinjing"]["lvl"]>=20 and skillslist["yunu-jianfa"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["yunu-jianfa"]["lvl"]<a and skillslist["yunu-jianfa"]["lvl"]<me.maxlvl then
					--��Ů����
					run("jifa sword yunu-jianfa;jifa")
					jifa.swordname="yunu-jianfa"
				--elseif skillslist["tiandi-fenglei"]~=nil and skillslist["tiandi-fenglei"]["lvl"]<skillslist["sword"]["lvl"] and skillslist["tiandi-fenglei"]["lvl"]<a and skillslist["tiandi-fenglei"]["lvl"]<me.maxlvl and skillslist["tiandi-fenglei"]["lvl"]>320 then
					--��ط��׽�
				--	run("jifa sword tiandi-fenglei;jifa")
				--	jifa.swordname="tiandi-fenglei"
				end
				--ʣ����߽���δ����
			end
		elseif sk=="strike" and skillslist[jifa.strikename]~=nil and skillslist["strike"]~=nil then --����ѡ��Ҫ��ϰ���Ʒ�	
			if skillslist[jifa.strikename]["lvl"]>=skillslist["strike"]["lvl"] and (skillslist[jifa.strikename]["sld"]>=(skillslist[jifa.strikename]["lvl"]+_t(skillslist[jifa.strikename]["lvl"]))^2 or skillslist[jifa.strikename]["lvl"]>=me.maxlvl) then
				if skillslist["banruo-zhang"]~=nil and skillslist["hunyuan-yiqi"]~=nil and skillslist["hunyuan-yiqi"]["lvl"]>=20 and skillslist["banruo-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["banruo-zhang"]["lvl"]<a and skillslist["nianhua-zhi"]~=nil and skillslist["nianhua-zhi"]["lvl"]>=150 then
					--���ְ�����
					run("jifa strike banruo-zhang")
					jifa.strikename="banruo-zhang"
				elseif skillslist["sanhua-zhang"]~=nil and skillslist["hunyuan-yiqi"]~=nil and skillslist["hunyuan-yiqi"]["lvl"]>=20 and skillslist["sanhua-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["sanhua-zhang"]["lvl"]<a and skillslist["weituo-gun"]~=nil and skillslist["weituo-gun"]["lvl"]>=90 then
					--����ɢ����
					run("jifa strike sanhua-zhang")
					jifa.strikename="sanhua-zhang"
				elseif skillslist["xuanpin-zhang"]~=nil and skillslist["xuanpin-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["xuanpin-zhang"]["lvl"]<a and skillslist["xuanpin-zhang"]["lvl"]<me.maxlvl then
					--������
					run("jifa strike xuanpin-zhang")
					jifa.strikename="xuanpin-zhang"
				elseif skillslist["dafeng-yunfei"]~=nil and skillslist["dafeng-yunfei"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["dafeng-yunfei"]["lvl"]<a and skillslist["dafeng-yunfei"]["lvl"]<me.maxlvl then
					--����Ʒ���
					run("jifa strike dafeng-yunfei")
					jifa.strikename="dafeng-yunfei"
				elseif skillslist["qingyan-zhang"]~=nil and skillslist["kurong-changong"]~=nil and skillslist["kurong-changong"]["lvl"]>=20 and skillslist["qingyan-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["qingyan-zhang"]["lvl"]<a then
					--����������
					run("jifa strike qingyan-zhang")
					jifa.strikename="qingyan-zhang"
				elseif skillslist["sanhua-juding"]~=nil and skillslist["xiantian-gong"]~=nil and skillslist["xiantian-gong"]["lvl"]>=20 and skillslist["sanhua-juding"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["sanhua-juding"]["lvl"]<a then
					--ȫ�������۶���
					run("jifa strike sanhua-juding")
					jifa.strikename="sanhua-juding"
				elseif skillslist["jinding-zhang"]~=nil and skillslist["linji-zhuang"]~=nil and skillslist["linji-zhuang"]["lvl"]>=20 and skillslist["jinding-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["jinding-zhang"]["lvl"]<a then
					--��ü������
					run("jifa strike jinding-zhang")
					jifa.strikename="jinding-zhang"
				elseif skillslist["mian-zhang"]~=nil and skillslist["mian-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["mian-zhang"]["lvl"]<a and skillslist["mian-zhang"]["lvl"]<me.maxlvl then
					--�䵱����
					run("jifa strike mian-zhang")
					jifa.strikename="mian-zhang"
				elseif skillslist["qiongtian-zhang"]~=nil and skillslist["qiongtian-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["qiongtian-zhang"]["lvl"]<a and skillslist["qiongtian-zhang"]["lvl"]<me.maxlvl then
					--�����
					run("jifa strike qiongtian-zhang")
					jifa.strikename="qiongtian-zhang"
				elseif skillslist["riyue-shenzhang"]~=nil and skillslist["riyue-shenzhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["riyue-shenzhang"]["lvl"]<a and skillslist["riyue-shenzhang"]["lvl"]<me.maxlvl then
					--��������
					run("jifa strike riyue-shenzhang")
					jifa.strikename="riyue-shenzhang"
				elseif skillslist["taigu-zhengyin"]~=nil and skillslist["taigu-zhengyin"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["taigu-zhengyin"]["lvl"]<a and skillslist["taigu-zhengyin"]["lvl"]<me.maxlvl then
					--̫��������
					run("jifa strike taigu-zhengyin")
					jifa.strikename="taigu-zhengyin"
				elseif skillslist["hunyuan-zhang"]~=nil and skillslist["zixia-gong"]~=nil and skillslist["zixia-gong"]["lvl"]>=20 and skillslist["hunyuan-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["hunyuan-zhang"]["lvl"]<a then
					--��ɽ��Ԫ��
					run("jifa strike hunyuan-zhang")
					jifa.strikename="hunyuan-zhang"
				elseif skillslist["pikong-zhang"]~=nil and skillslist["bitao-xuangong"]~=nil and skillslist["bitao-xuangong"]["lvl"]>=20 and skillslist["pikong-zhang"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["pikong-zhang"]["lvl"]<a then
					--�һ�������
					run("jifa strike pikong-zhang")
					jifa.strikename="pikong-zhang"
				elseif skillslist["luoying-shenjian"]~=nil and skillslist["bitao-xuangong"]~=nil and skillslist["bitao-xuangong"]["lvl"]>=20 and skillslist["luoying-shenjian"]["lvl"]<skillslist["strike"]["lvl"] and skillslist["luoying-shenjian"]["lvl"]<a then
					--�һ���Ӣ����
					run("jifa strike luoying-shenjian")
					jifa.strikename="luoying-shenjian"
				end
			end
		end
	end
end
function alias.lingwuskills()
	local _tb,a
	alias.setmpLimitedMark()
	alias.close_dz()
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��lingwuskills") end
	if roomname=="��ĦԺ��¥" and me.menpai~="gb" and me.menpai~="sl" then a=10 else a=0 end
		if (pdfjsj()<a or havefj>0) and not isopen("boat") then
			print("����ʱ�䲻��"..a.."��,ȥ�ȴ�fj")
			alias.startfj()
		else
			if havefj>0 then
				alias.uw()
				if me.menpai=="bt" then run("release yuanshi") end
				if me.menpai=="qz" then run("return book") end
				if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
				if me.menpai=="dl" then run("dismiss") end
				if me.menpai=="gm" then run("halt;xiachuang") end
				run("set startworkflow=yes")
			else
				if workflow.mp>0 and pdmpsj() and xuefirst==0 then
					alias.uw()
					if me.menpai=="bt" then run("release yuanshi") end
					if me.menpai=="qz" then run("return book") end
					if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
					if me.menpai=="dl" then run("dismiss") end
					if me.menpai=="gm" then run("halt;xiachuang") end
					alias.startmp()
				else
					_tb=Split(skills_lingwu,"|")
					if me.menpai=="em" and stat.zhixin==0 then run("yun zhixin") end
					if me.menpai=="dl" then run("gather") end
					if me.menpai=="mj" and (roomno_now==1972 or roomno_now==1970 or roomno_now==1974) then
						if lingwu_jf~=nil and lingwu_jf~="" then run(lingwu_jf) 
						elseif fjjf~=nil and fjjf~="" then run(fjjf)						
						end 
						_tb=Split(skills_lingwu,"|")
						for k,v in pairs(_tb) do
							if v~="force" and v~="parry" and v~="dodge" and skillslist["parry"]~=nil and type(skillslist["parry"])=="table" and skillslist["parry"]["lvl"]~=nil then
								if skillslist[jifa[v.."name"]]~=nil and type(skillslist[jifa[v.."name"]])=="table" and skillslist[jifa[v.."name"]]["lvl"]~=nil and skillslist[jifa[v.."name"]]["lvl"]>skillslist["parry"]["lvl"] then --���б�����˵��config���������˲����ڵļ���
									run("jifa parry "..jifa[v.."name"]..";jifa") 
									break
								end
							end
						end
						if     (_tb[skills_num]=="strike" and skillslist["strike"] and jifa.strikename~=nil and skillslist[jifa.strikename]~=nil and skillslist[jifa.strikename]["lvl"]>=skillslist["strike"]["lvl"]) 
							or (_tb[skills_num]=="cuff" and skillslist["cuff"] and jifa.cuffname~=nil and skillslist[jifa.cuffname]~=nil and skillslist[jifa.cuffname]["lvl"]>=skillslist["cuff"]["lvl"]) 
							or (_tb[skills_num]=="hand" and skillslist["hand"] and jifa.handname~=nil and skillslist[jifa.handname]~=nil and skillslist[jifa.handname]["lvl"]>=skillslist["hand"]["lvl"]) then
							if roomno_now==1972 then
								run("n;n;e;e")
							elseif roomno_now==1970 then
								run("e;e;e;e")
							end
							roomno_now=1974
						elseif     (_tb[skills_num]=="dodge" and skillslist["dodge"] and jifa.dodgename~=nil and skillslist[jifa.dodgename]~=nil and skillslist[jifa.dodgename]["lvl"]>=skillslist["dodge"]["lvl"]) 
							or (_tb[skills_num]=="parry" and skillslist["parry"] and jifa.parryname~=nil and skillslist[jifa.parryname]~=nil and skillslist[jifa.parryname]["lvl"]>=skillslist["parry"]["lvl"]) then
							-- _tb[skills_num]=="dodge" or _tb[skills_num]=="parry" then
							if roomno_now==1972 then
								run("n;n;w;w")
							elseif roomno_now==1974 then
								run("w;w;w;w")
							end
							roomno_now=1970
						elseif     (_tb[skills_num]=="sword" and skillslist["sword"] and jifa.swordname~=nil and skillslist[jifa.swordname]~=nil and skillslist[jifa.swordname]["lvl"]>=skillslist["sword"]["lvl"]) 
							or (_tb[skills_num]=="blade" and skillslist["blade"] and jifa.bladename~=nil and skillslist[jifa.bladename]~=nil and skillslist[jifa.bladename]["lvl"]>=skillslist["blade"]["lvl"]) 
							or (_tb[skills_num]=="stroke" and skillslist["stroke"] and jifa.strokename~=nil and skillslist[jifa.strokename]~=nil and skillslist[jifa.strokename]["lvl"]>=skillslist["stroke"]["lvl"])
							or (_tb[skills_num]=="staff" and skillslist["staff"] and jifa.staffname~=nil and skillslist[jifa.staffname]~=nil and skillslist[jifa.staffname]["lvl"]>=skillslist["staff"]["lvl"]) then
							-- _tb[skills_num]=="sword" or _tb[skills_num]=="blade" or _tb[skills_num]=="stroke" or _tb[skills_num]=="staff" then
							if roomno_now==1970 then
								run("e;e;s;s")
							elseif roomno_now==1974 then
								run("w;w;s;s")
							end
							roomno_now=1972
						end
					end
					if skills_num>#_tb then
						if me.menpai=="bt" then run("release yuanshi") end
						if me.menpai=="qz" then run("return book") end
						if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
						if me.menpai=="dl" then run("dismiss") end
						run("yun refresh")
						skills_num=1
						if me.menpai=="th" and lingwuat=="shaolin" then
							alias.startworkflow()
						else
							alias.startlianwu()
						end
					else
						if me.menpai=="th" then run("huan all") end
						if me.menpai=="gm" and roomno_now==2077 then run("n;w;w;w;enter guan;turn left")roomno_now=2065 end
						if me.menpai=="mj" and always.where=="��ĦԺ��¥" and findstring(_tb[skills_num],"strike","cuff","hand","dodge","parry","sword","blade","stroke","staff") then --����������ļ��ܣ�������������
							print("����������ļ��ܣ�����������������:".._tb[skills_num])
							skills_num=skills_num+1
							alias.lingwuskills()
						elseif gxd.type==1 then 
							run("lingwu ".._tb[skills_num].." 1")
						elseif tonumber(usepots)==nil then
							run("lingwu ".._tb[skills_num].." 20")
						else
							run("lingwu ".._tb[skills_num].." "..usepots)
						end
					end
				end
			end
		end
end
function alias.dujingyao()
	alias.setmpLimitedMark()
	alias.close_dz()
	if de_bug>0 then print("Լ"..pdfjsj().."�����ʱ��dujingyao") end
	if (pdfjsj()<0 or havefj>0) and not isopen("boat") then
	--	print("����ʱ�䲻��10��,ȥ�ȴ�fj")
		alias.startfj()
	elseif me.menpai=="mj" and mj_need_yudi() then alias.startmp()
	elseif hp.neili<(hp.maxneili*set_neili_job/100) then alias.dz(set_neili)
	else
		if wx.taiji==0 and me.menpai=="wd" and jifa.forcename=="taiji-shengong" then
			run("jifa parry taiji-quan")
			alias.uw()
			run("yun taiji")
			alias.checkbusy("taijistart")
		else
			if me.menpai=="em" and stat.zhixin==0 then run("yun zhixin") end
			if me.menpai=="th" then run("huan all") end
			if have.jyzj>0 then 
				run("du zhenjing 10") 
			elseif have.cstlnj>0 then
				run("du shu 99999")
			elseif have.lxj>0 then
				run("du jing 99999")
			else
				if gxd.type==1 then run("du book 1") else run("du book 10") end 
			end
		end
	end
end

function alias.fjarea(a)
	fjzone=""
	fjroom=""
	if string.find(a,"�رߴ�ѩɽ") then
		fjzone="�رߴ�ѩɽ"
		fjroom=string.gsub(a,"�رߴ�ѩɽ","",1)
	--end
	elseif string.find(a,"���ϴ���") then
		fjzone="���ϴ�����"
		fjroom=string.gsub(a,"���ϴ���","",1)
	--end
	elseif string.find(a,"�㶫��ɽ") then
		fjzone="�㶫��ɽ"
		fjroom=string.gsub(a,"�㶫��ɽ","",1)
	--end
	elseif string.find(a,"���ⳤ��ɽ") then
		fjzone="���ⳤ��ɽ"
		fjroom=string.gsub(a,"���ⳤ��ɽ","",1)
	--end
	elseif string.find(a,"����") then
		fjzone="����"
		fjroom=string.gsub(a,"����","",1)
	--end
	elseif string.find(a,"�ƺӱ�") then
		fjzone="�ƺӱ�"
		fjroom=string.gsub(a,"�ƺӱ�","",1)
	--end
	elseif string.find(a,"����ɽ") then
		fjzone="����ɽ"
		fjroom=string.gsub(a,"����ɽ","",1)
	--end
	elseif string.find(a,"����ɽ") then
		fjzone="����ɽ"
		fjroom=string.gsub(a,"����ɽ","",1)
	--end
	elseif string.find(a,"����Ȫ��") then
		fjzone="����Ȫ��"
		fjroom=string.gsub(a,"����Ȫ��","",1)
	--end
	elseif string.find(a,"��ɽ����") then
		fjzone="��ɽ����"
		fjroom=string.gsub(a,"��ɽ����","",1)
	--end
	elseif string.find(a,"ɽ��̩ɽ") then
		fjzone="ɽ��̩ɽ"
		fjroom=string.gsub(a,"ɽ��̩ɽ","",1)
	--end
	elseif string.find(a,"̫����") then
		fjzone="̫����"
		fjroom=string.gsub(a,"̫����","",1)
	--end
	elseif string.find(a,"�����䵱ɽ") then
		fjzone="�����䵱ɽ"
		fjroom=string.gsub(a,"�����䵱ɽ","",1)
	--end
	elseif string.find(a,"����") then
		fjzone="��������"
		fjroom=string.gsub(a,"����","",1)
	--end
	elseif string.find(a,"����") then
		fjzone="��������"
		fjroom=string.gsub(a,"����","",1)
	elseif string.find(a,"���ݽ���") then
		fjzone="���ݽ���"
		fjroom=string.gsub(a,"���ݽ���","",1)
	--end
	elseif string.find(a,"����") then
		fjzone="����"
		fjroom=string.gsub(a,"����","",1)
	--end
	elseif string.find(a,"����ɽ") then
		fjzone="����ɽ"
		fjroom=string.gsub(a,"����ɽ","",1)
	--end
	elseif string.find(a,"����") then
		fjzone="����"
		fjroom=string.gsub(a,"����","",1)
	--end
	elseif string.find(a,"����") then
		fjzone="����"
		fjroom=string.gsub(a,"����","",1)
	--end
	elseif string.find(a,"��ɽ������·") or string.find(a,"��ɽ�������·") then
		fjzone="��ɽ"
		fjroom="������·"
	--end
	elseif string.find(a,"��ɽ��") then
		fjzone="��ɽ��"
		fjroom=string.gsub(a,"��ɽ��","",1)
	--end
	elseif string.find(a,"��ɽ") then
		fjzone="��ɽ"
		fjroom=string.gsub(a,"��ɽ","",1)
	--end
	elseif string.find(a,"�Ĵ�����") then
		fjzone="�Ĵ�����"
		fjroom=string.gsub(a,"�Ĵ�����","",1)
	end
	fj.room=fjroom
	fj.zone=fjzone
end
region_names={
	["�رߴ�ѩɽ"]="�رߴ�ѩɽ",
	["���ⳤ��ɽ"]="���ⳤ��ɽ",
	["�����䵱ɽ"]="�����䵱ɽ",
	["���ϴ���"]="���ϴ�����",
	["�㶫��ɽ"]="�㶫��ɽ",
	["����Ȫ��"]="����Ȫ��",
	["��ɽ����"]="��ɽ����",
	["ɽ��̩ɽ"]="ɽ��̩ɽ",
	["���ݽ���"]="���ݽ���",
	["�Ĵ�����"]="�Ĵ�����",
	["�ƺ�����"]="�ƺӱ�",
	["������"]="���ϴ�����",
	["������"]="��ɽ����",
	["��ɽ��"]="��ɽ��",
	["����ɽ"]="����ɽ",
	["�ƺӱ�"]="�ƺӱ�",
	["����ɽ"]="����ɽ",
	["����ɽ"]="����ɽ",
	["̫����"]="̫����",
	["�䵱ɽ"]="�����䵱ɽ",
	["����ɽ"]="����ɽ",
	["����ɽ"]="����ɽ",
	["����"]="����",
	["����"]="����",
	["����"]="����",
	["����"]="��������",
	["����"]="����",
	["��ɽ"]="��ɽ",
	["��ɽ"]="�㶫��ɽ",
	["Ȫ��"]="����Ȫ��",
	["̩ɽ"]="ɽ��̩ɽ",
	["̫��"]="̫����",
	["����"]="����",
}

function alias.ftbarea(a)
	if a=="�������᷿" or a=="����Ů�᷿" then  --������ӥ�̵Ķ�λ�ص�
		a="����Ժ��"
	elseif a=="�Ĵ����Ҹ�����ի��" or a=="���Ҹ�����ի��" then  --�к��޷����룬������λ�ص�
		a="�Ĵ��������ĸ�"
	elseif a=="�Ĵ����ұ���������" or a=="���ұ���������" then  --Ů���޷�����
		a="�Ĵ����Ҵ��۵�"
	elseif a=="�Ĵ����һ�������Ϣ��" or a=="���һ�������Ϣ��" then --�к��޷�����
		a="�Ĵ����һ���������"
	elseif a=="����ɽŮ�᷿" or a=="����ɽ���᷿" then --�����޷�����
		a="����ɽ������"
	elseif a=="����ɽŮ����" or a=="����ɽ������" then --����ɽ����������λ�ص�
		a="����ɽǬ����"
	elseif a=="��ɽŮ������Ϣ��" or a=="��ɽ�е�����Ϣ��" then --��ɽ˯��������λ
		a="��ɽ����"
	elseif a=="̫��Ů�᷿" or a=="̫����Ů�᷿" or a=="̫�����᷿" or a=="̫�������᷿" then --����ׯ˯��������λ�ص�
		a="̫���߻���"
	elseif a=="�����䵱ɽ��Ϣ��" or a=="�䵱ɽ��Ϣ��" then 
		a="�����䵱ɽ�������"
	end
	ftbzone=""
	ftbroom=""
	if a=="��ɽ�������·" or a=="��ɽ������·" then
		ftbzone="��ɽ"
		ftbroom="������·"
		ftbarea_table[1]="������·"
		return
	end
	for k,v in pairs(region_names) do
		local _t=string.sub(a, 1, string.len(k))
		if _t==k then
			ftbzone=v
			ftbroom=string.sub(a,string.len(k)+1)
			ftbarea_table[1]=string.sub(a,string.len(k)+1)
			return
		end
	end
end
function alias.lzarea(a)
	ftbzone=""
	ftbroom=""
	if a=="�������᷿" or a=="����Ů�᷿" then  --������ӥ�̵Ķ�λ�ص�
		a="����Ժ��"
	elseif a=="�Ĵ����Ҹ�����ի��" or a=="���Ҹ�����ի��" then  --�к��޷����룬������λ�ص�
		a="�Ĵ��������ĸ�"
	elseif a=="�Ĵ����ұ���������" or a=="���ұ���������" then  --Ů���޷�����
		a="�Ĵ����Ҵ��۵�"
	elseif a=="�Ĵ����һ�������Ϣ��" or a=="���һ�������Ϣ��" then --�к��޷�����
		a="�Ĵ����һ���������"
	elseif a=="����ɽŮ�᷿" or a=="����ɽ���᷿" then --�����޷�����
		a="����ɽ������"
	elseif a=="����ɽŮ����" or a=="����ɽ������" then --����ɽ����������λ�ص�
		a="����ɽǬ����"
	elseif a=="��ɽŮ������Ϣ��" or a=="��ɽ�е�����Ϣ��" then --��ɽ˯��������λ
		a="��ɽ����"
	elseif a=="̫��Ů�᷿" or a=="̫����Ů�᷿" or a=="̫�����᷿" or a=="̫�������᷿" then --����ׯ˯��������λ�ص�
		a="̫���߻���"
	elseif a=="�����䵱ɽ��Ϣ��" or a=="�䵱ɽ��Ϣ��" then 
		a="�����䵱ɽ�������"
	end
	for k,v in pairs(regions_d) do
		if string.sub(a,1,string.len(v.old))==v.old then
			ftbzone=v.new
			ftbroom=string.gsub(a,v.old,"",1)
			print(a,ftbzone,ftbroom)
			break
		end
	end
end
regions_d={
	{old="�������ɽ",new="����",},
	{old="���ⳤ��ɽ",new="���ⳤ��ɽ",},
	{old="�����䵱ɽ",new="�����䵱ɽ",},
	{old="�رߴ�ѩɽ",new="�رߴ�ѩɽ",},
	{old="ؤ�����ڵ�",new="����",},
	{old="�������ߵ�",new="���ߵ�",},
	{old="�ɶ�������",new="none",},
	{old="�����һ���",new="none",},
	{old="���ϴ���",new="���ϴ�����",},
	{old="���ݽ���",new="����",},
	{old="�Ĵ�����",new="�Ĵ�����",},
	{old="�㶫��ɽ",new="�㶫��ɽ",},
	{old="����Ȫ��",new="����Ȫ��",},
	{old="��ɽ����",new="��ɽ����",},
	{old="ɽ��̩ɽ",new="ɽ��̩ɽ",},
	{old="�����置",new="none",},
	{old="���ջ�ɽ",new="none",},
	{old="�ƺӱ�",new="�ƺӱ�",},
	{old="����ɽ",new="����ɽ",},
	--{old="����ɽ",new="����ɽ",},
	{old="����ɽ",new="����ɽ",},
	{old="����ɽ",new="����ɽ",},
	{old="̫����",new="̫����",},
	{old="̫��",new="̫����",},
	{old="��ɽ��",new="��ɽ��",},
	{old="��ɽ",new="��ɽ",},
	{old="����ɽ",new="����ɽ",},
	{old="����ɽ",new="����ɽ",},
	{old="����",new="����",},
	{old="����",new="����",},
	{old="����",new="��������",},
	{old="����",new="����",},
	{old="����",new="����",},
	{old="����",new="����",},
	{old="�ɽ�",new="none",},
	{old="���͵�",new="none",},
	{old="����",new="none",},
	{old="����",new="none",},
	{old="����",new="none",},
}

function alias.setTargetNum()
	if mpLimited.mpexp<=4750 then
		mmr.targetNum=math.floor((4750-mpLimited.mpexp)/200)
		if mmr.targetNum==0 then mmr.targetNum=1 end
	end
	if mpLimited.mpexp>4750 and mpLimited.mpexp<=5000 then
		if (4750/mmr.oneexp)>27 then mmr.targetNum=math.floor(4750/mmr.oneexp-1) else mmr.targetNum=math.floor(4750-mmr.oneexp) end
		if hp.exp<20000000 then
			if mmr.targetNum>=30 then mmr.targetNum=30 end
		else
			if mmr.targetNum>=35 then mmr.targetNum=35 end
		end
	end
	if mpLimited.mpexp>5000 or mpJobLimited>0 then
		if hp.exp<20000000 then mmr.targetNum=24 else mmr.targetNum=30 end
	end
	if xuefirst==1 then mmr.targetNum=5 end
end
function workflow.xinfa()
	if me.menpai=="sl" and workflow.xf>0 and ((songjingtime~=nil and songjingtime>0) or (zuochan~=nil and zuochan>0)) then
		return 1
	elseif me.menpai=="wd" and workflow.xf>0 and have.zhongjian>0 and skillslist["xuantie-jianfa"]~=nil and skillslist["xuantie-jianfa"]["lvl"]~=nil and skillslist["xuantie-jianfa"]["lvl"]>0 then
		return 1
	elseif me.menpai=="hs" and workflow.xf>0 and guanyuntime and me.shen>hp.exp and skillslist["zhengqi-jue"]~=nil and skillslist["zhengqi-jue"]["lvl"]~=nil and skillslist["zhengqi-jue"]["lvl"]>200 and skillslist["ziyin-yin"]~=nil and skillslist["ziyin-yin"]["lvl"]~=nil and skillslist["ziyin-yin"]["lvl"]>200 and skillslist["zixia-gong"]~=nil and skillslist["zixia-gong"]["lvl"]~=nil and skillslist["zixia-gong"]["lvl"]>350 then
		return 1
	elseif me.menpai=="mj" and workflow.xf>0 and chaobaitime~=nil and chaobaitime>0  then
		return 1
	else
		return 0
	end
end
------------------------------------------------------------------------------------
-- yun or pfm
------------------------------------------------------------------------------------
function alias.yunheal()
	if hp.healthqi>=50 and hp.healthqi<100 then 
		if jifa["forcename"]=="zixia-gong" and stat.haveneiheal>0 then run("yun neiheal") end
		if jifa["forcename"]=="kurong-changong" and hp.healthqi<85 and hp.maxneili>=2000 then run("yun kurong") end
		run("yun heal")
		if always["bei"][1]=="������" and #always.bei==1 then
			run("jiali "..fjjiali)
		end
	else
		if jifa.forcename=="linji-zhuang" then run("yun daxiao;yun tiandi")
		elseif jifa.forcename=="hamagong" then run("yun powerup")
		elseif jifa.forcename=="kurong-changong" then run("yun kurong")
		elseif jifa.forcename=="huagong-dafa" then alias.startmp()
		else
			--alias.checkdrugbusy("jinchuang")
			run("fu jinchuang yao")
			--alias.startworkflow()
			alias.checkitems()
		end
	end
end
function alias.yunem()
	if me.menpai=="em" and (stat.daxiao==nil or stat.daxiao==0) then
		run("yun daxiao;yun recover")
	end
	if me.menpai=="em" and (stat.fengyun==nil or stat.fengyun==0) then
		run("yun fengyun")
	end
	if me.menpai=="em" and (stat.tiandi==nil or stat.tiandi==0) then
		run("yun tiandi")
	end
end
function alias.yunbt()
	if me.menpai=="bt" and (stat.reverse==nil or stat.reverse==0) then run("yun reverse") end
	if skillslist["hamagong"]==nil then skillslist["hamagong"]={} end
	if skillslist["hamagong"]["lvl"]==nil then skillslist["hamagong"]["lvl"]=0 end
	if me.menpai=="bt" and (stat.powerup==nil or stat.powerup==0) and skillslist["hamagong"]["lvl"]>200 then run("yun powerup")	end
end
function alias.dl_with_ailao()
	if have.jian~=nil and have.jian>0 and dl.useailao>0 then
		--wieldweapon=0
		alias.wi("jian")
		killskill="jian"
		killpfm="perform ailao"
		killjiali=0
		killjiajin="max"
		run("jiajin max;jiali 0")
	end
end

------------------------------------------------------------------------------------
-- jifa
------------------------------------------------------------------------------------
function alias.jfxx()
	run("jifa dodge zhaixinggong;jifa stroke duoming-bi;jifa parry duoming-bi;jifa claw sanyin-zhua;jifa strike chousui-zhang;bei none;bei chousui-zhang sanyin-zhua")
end
function alias.jfwd()
	run("jifa dodge tiyunzong;jifa parry taiji-jian;jifa sword taiji-jian;jifa cuff taiji-quan;jifa strike mian-zhang;bei none;bei taiji-quan;bei mian-zhang")
end
function alias.jfth()
	run("jifa dodge luoying-shenfa;jifa parry luoying-shenjian;jifa sword yuxiao-jian;jifa strike luoying-shenjian;jifa kick xuanfeng-saoye;jifa hand lanhua-fuxue;jifa finger tanzhi-shentong;bei none;bei xuanfeng-saoye luoying-shenjian")
end
function alias.jfsl()
	run("jifa dodge shaolin-shenfa;jifa blade ranmu-dao;jifa cuff jingang-quan;jifa finger yizhi-chan;jifa parry ranmu-dao;jifa strike banruo-zhang;jifa sword damo-jian;jifa whip heilong-bianfa;jifa claw longzhua-gong;jifa club weituo-gun;jifa hand fengyun-shou;jifa staff wuchang-zhang;bei none;bei banruo-zhang yizhi-chan")
end
function alias.jfqz()
	run("jifa dodge jinyangong;jifa parry quanzhen-jian;jifa sword quanzhen-jian;jifa strike sanhua-juding;jifa staff jinhua-zhang;jifa hand nilin-shou")
	if skillslist["kongming-quan"]~=nil and skillslist["kongming-quan"]["lvl"]>0 and findstring(fjpfm,"perform kong","perform ming") then
		run("jifa cuff kongming-quan;jifa parry sanhua-juding;bei none;bei kongming-quan")
	else
		run("jifa cuff chunyang-quan;bei none;bei chunyang-quan;bei sanhua-juding")
	end
end
function alias.jfhs()
	run("jifa cuff pishi-poyu;jifa blade liangyi-dao")
	if me.master=="������" then
		run("jifa dodge dugu-jiujian;jifa parry dugu-jiujian;jifa sword dugu-jiujian;jifa strike dugu-jiujian;jifa staff dugu-jiujian")
	else
		run("jifa dodge huashan-shenfa;jifa parry huashan-jianfa;jifa blade liangyi-dao;jifa sword huashan-jianfa;jifa strike hunyuan-zhang;jifa staff jinhua-zhang")
	end
	run("bei none;bei hunyuan-zhang;bei pishi-poyu")
end
function alias.jfhbmz()
	run("jifa strike hanbing-mianzhang;jifa parry hanbing-mianzhang;jifa dodge guifu-fei;bei none;bei hanbing-mianzhang")
end
function alias.jfgb()
	run("jifa strike xianglong-zhang;jifa dodge xiaoyaoyou")
	if fjweapon=="stick" then run("jifa parry dagou-bang") else run("jifa parry xianglong-zhang") end
	run("jifa cuff xiaoyaoyou;jifa stick dagou-bang;jifa hand jilin-shou;bei none;bei xianglong-zhang;bei xiaoyaoyou")
end
function alias.jfdl()
	if jifa.forcename~="xuanyin-zhenqi" then
		run("jifa dodge duanshi-shenfa;jifa parry yiyang-zhi;jifa finger yiyang-zhi;jifa strike qingyan-zhang;jifa cuff jinyu-quan;jifa staff duanjia-jian;jifa sword duanjia-jian")
		if findstring(killpfm,"perform piaomiao") then run("bei none;bei qingyan-zhang;bei jinyu-quan") else run("bei none;bei yiyang-zhi") end
	end
end
function alias.jfbt()
	run("jifa dodge chanchubu;jifa staff lingshe-zhang;jifa parry lingshe-zhang;jifa strike shentuo-zhang;jifa sword pixie-jian;bei none;bei shentuo-zhang;bei lingshe-quan")
end
function alias.jfgm()
	run("jifa dodge gumu-shenfa;jifa cuff meinu-quan;jifa whip yinsuo-jinling;jifa sword yunu-jianfa;jifa parry meinu-quan;bei none;bei meinu-quan")
end
function alias.jfxs()
	run("jifa parry huoyan-dao;jifa hammer riyue-lun;jifa dodge shenkongxing;jifa staff jingang-chu;jifa strike huoyan-dao;jifa hand dashou-yin;bei none;bei huoyan-dao")
end
function alias.jfem()
	run("jifa sword emei-jian;jifa parry emei-jian;jifa blade yanxing-dao;jifa strike jinding-zhang;jifa claw jiuyin-zhao;jifa finger qianzhu-wandu;jifa finger tiangang-zhi;jifa dodge zhutian-bu;bei none;bei jinding-zhang;bei tiangang-zhi")
end
function alias.jfxx()
	run("jifa dodge zhaixinggong;jifa stroke duoming-bi;jifa parry duoming-bi;jifa claw sanyin-zhua;jifa strike chousui-zhang;bei none;bei chousui-zhang sanyin-zhua")
end
function alias.jf(a)
	local _tb
	_tb=Split(a,";")
	for k,v in ipairs(_tb) do run(v) end
end
------------------------------------------------------------------------------------
-- startworkflow ��������
------------------------------------------------------------------------------------
function alias.startworkflow()
	alias.initialize_trigger()
	alias.setmpLimitedMark()
	workflowState.attempts = workflowState.attempts + 1
	if workflowState.attempts >= workflowState.maxAttempts then 
		print("����: �ﵽ����Դ������˳�������")  	--���������ƣ���ʱ����Ƶ������startworkflow��˵���Ѿ�������ѭ��
		return 
	end 
	if setting=="keep" then --keep����ȥ���������䷢��
		alias.resetidle()
		check_battleidle=0
		openclass("keep")
		if always.where==nil or always.where~=dummy["jyroom"] then
			print("ȥ��ȫ���䷢��~")
			alias.flyto(dummy["jyroom"])
		end
		run("unset no_accept;unset brief;inventory;drop jiuping;drop ya")
		return
	end
	if setting=="godie" then --��ɱģʽ
		if tonumber(godie_exp)==nil or tonumber(godie_exp)==0 then
			print("���������������پ��飬��ʽ����/godie_exp=1234567���������¿�ʼ����")
		else
			if godie_exp > hp.exp then
				closeclass("godie")
				alias.resetidle()
				print("�Ѿ�������ͷ��������ֹͣ���� ")
			--elseif me.death>949 then
				--print("������1000���ˣ�������ֹͣ����")
			else
				openclass("godie")
				alias.flyto("������")
			end
		end
		return
	end
	if me.bl<alias.checkbili() and alias.checkbili()>0 and setting~="dm" and setting~="keep" then   --�����������Ӧ���е����֣���quit
	    print("��⵽�������⣬��������")
		stat.quiting=2 
	end
	if me.menpai~=nil and me.menpai=="em" and workflow.mp>0 and workflow.nowjob~=nil and workflow.nowjob=="mp" and tonumber(mpLimited.mpexp)>100 and roomno_now~=372 then 
		print("��ʼ��������startworkflow") --��ֹem per����ˢ��
    else 
		run("cha;jifa;score;jiajin basic;yield no;set no_accept 1;set brief 2")
	end
	if #always.bei==1 and always["bei"][1]=="������" or #always.bei==2 and (always["bei"][1]=="������" or always["bei"][2]=="������") then
		run("jiali "..fjjiali)
	else
		run("jiali 0")
	end
	if dl.usefeiyun>0 then dl.usefeiyun=1 end
	if findstring(workflow.nowjob,"death","lzjob","yb") then workflow.nowjob="mp" end
	if stat.quiting==2 then stat.quiting=0;openclass("quit")
	elseif stat.haveyyz>0 then alias.starttongmai()
	elseif stat.havedu>0 and hp.healthjing<80 then alias.startliaoshang()
	elseif fjfinished>0 then
		openclass("fj_start")
		workflow.nowjob="fj"
		alias.flytoid(me.fjbaseid)
	elseif dummy.xueteng_dm~=nil and dummy.xueteng_dm~="" and dummy.xueteng_room~=nil and dummy.xueteng_room~="" and os.time()>stat.drugbusy then alias.startfuxueteng()
	elseif pxj_no~="" and pxj_needget_yyc>0 and hp.exp>1000000 and hp.neili>hp.maxneili and (yinyangcao_time>1200 or alias.yyc_no>=yinyangcao_num) then alias.getbuyinwan()	--pxj����������
	elseif skillslist.dodge~=nil and skillslist.dodge.lvl>120 and skillslist["xuanyin-zhenqi"]~=nil and ((skillslist["xuanyin-zhenqi"]["lvl"]<me.maxlvl and skillslist["xuanyin-zhenqi"]["lvl"]<750 and skillslist["xuanyin-zhenqi"]["sld"]>(skillslist["xuanyin-zhenqi"]["lvl"]+1)^2) or (skillslist["hanbing-mianzhang"]["lvl"]<me.maxlvl and skillslist["hanbing-mianzhang"]["sld"]>(skillslist["hanbing-mianzhang"]["lvl"]+1)^2)) and hp.healthjing==100 and hp.neili>hp.maxneili then alias.addxyzq()	--��������������ȥ���ȼ�
	elseif setting=="dm" then alias.startworkflow_dm()
	elseif me.menpai~=nil then Execute("/alias.startworkflow_"..me.menpai.."()")
	else print("workflow����ʧ�ܣ��Ƿ񿨵�½��")
	end
end
function alias.startworkflow_gm()
	if de_bug>0 then print("��Ĺ���̿�ʼ����ʷ����"..workflow.nowjob) end
	if (ybLimited==0 and ybjob.waitlimit>0) or ybjob.ybroom>0 then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
		print("�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���")
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 and skillsfull==0 then alias.startxue()
	elseif do_gm_job3>0 and hp.exp>500000 and (os.time()-gmjob3time)>500 then
		alias.flytoid(607)
		openclass("mp_gm_job3")
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 and skillsfull==0 then alias.startxue() 
		else alias.dz("addneili") end
	else
		if workflow.yb>0 and ybjob.needfangqi==0 and mpLimited.mpexp>100 and ybexp==0 then alias.startyb() --�Ѿ���������һ���������񣬻�û����Ѻ�ڣ���ȥѺ��һ��
		elseif workflow.mp>0 then alias.startmp() --���������������
		elseif workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 and skillsfull==0 then alias.startxue() 
		else alias.dz("addneili") end
	end
	if ftbfail>0 then ftbfail=0 end
end
function alias.startworkflow_mj()
	alias.setmpLimitedMark()  --�������һ������ʱ��
	openclass("always_checkmingjiao")
	run("checkling")
	mj.checkexp=0
	if de_bug>0 then print("�������̿�ʼ����ʷ����"..workflow.nowjob) end
	if workflow.mp>0 and (mj_need_yudi() or (mj.wxq>0 or mj.tyjob>0)) then
		mj.checklimited=0
		alias.startmp()
	elseif havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end 
	elseif ybjob.ybroom>0 or (havefj==0 and ybLimited>0 and ybjob.waitlimit==0 and workflow.yb>0) then alias.startyb()
	elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
	elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
	elseif skillslist["shenghuo-ling"]~=nil and skillslist["shenghuo-ling"]["lvl"]>550 and workflow.xf>0 then alias.startxinfa()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 and (mj.haveyd==0 or workflow.mp==0) then
		if workflow.xf>0 and skillslist["manicheism"]~=nil and daytimes>1 and daytimes<6 and hp.pot<=hp.maxpot then 
			if skillslist["manicheism"]["lvl"]>500 and skillslist["shenghuo-ling"]~=nil and skillslist["shenghuo-ling"]["lvl"]<550 then 
				workflow.xf=0			  --�������ʳ���500�����͹ر��ķ�ģ��
				alias.startworkflow()
			elseif skillslist["manicheism"]["lvl"]>199 and skillslist["manicheism"]["lvl"]<501 then
				alias.startxinfa()
			else 
				alias.startxue()
			end
		else 
			alias.startxue() 
		end
	elseif workflow.mp>0 and (mj.wxq>0 or mj.tyjob>0) then alias.startmp()
	elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
	elseif workflow.qzwd>0 then alias.startqzwd()
	elseif workflow.xf>0 and daytimes>1 and daytimes<6 and hp.pot>50 and skillslist["manicheism"]~=nil and skillslist["manicheism"]["lvl"]>200 then 
		if skillslist["manicheism"]["lvl"]>500 then 
			workflow.xf=0			  --�������ʳ���500�����͹ر��ķ�ģ��
			alias.startworkflow()
		else
			alias.startxinfa()
		end
	elseif workflow.cm>0 then alias.startcm()
	elseif hp.pot>50 then alias.startxue() 
	else alias.dz("addneili")
	end
	if ftbfail==1 then ftbfail=0 end
end
--���th�Ƿ���Ҫ����
function checkthlw()
		local a,_tb
		--a=1
		a=0
		_tb=Split(skills_lingwu,"|")
		if #_tb<1 then
			a=0
		else
			for k,v in pairs(_tb) do
				--if skillslist[v]~=nil and jifa[v.."name"]~=nil and skillslist[v]["lvl"]>skillslist[jifa[v.."name"]]["lvl"] and v~="parry" and v~="force" then
				if skillslist[v]~=nil and jifa[v.."name"]~=nil and v~="parry" and v~="force" then
					print(v)
					--a=0
					a=1
					break
				end
			end
		end
		return a
end
function alias.startworkflow_th()	--�Ѿ��޸���Ѻ���ж��Ƿ����񣬱�ע�˴�
	if de_bug>0 then print("�һ����̿�ʼ����ʷ����"..workflow.nowjob) end
	if hp.thpot==nil then hp.thpot=0 end
	run("unwield jian;unwield xiao;taohua")
	if (ybLimited==0 and ybjob.waitlimit>0) then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
		print("�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���")
	elseif havefj>0 then alias.startfj()
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and ((hp.pot>math.abs(hp.maxpot-100) and usepot=="xue" or usepot=="jingyao") or (usepot=="lingwu" and checkthlw()>0 and hp.pot>math.abs(hp.maxpot-100))) then 
		alias.startxue()
		fjend=0
	elseif workflow.mp>0 and mpJobLimited==0 and mpLimited.mpexp<100 then alias.startmp()
	elseif me["gold"]>500 and skillslist["literate"]["lvl"]<400 and wantxuelit<2 and daytime and hp.pot>math.abs(hp.maxpot-100) then alias.startxue();fjend=0
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
	    elseif xuefirst>0 then run("huan all;hp");alias.startxue();fjend=0
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.fj>0 and workflow.mp==0 and fjfinished==0 and xuefirst>0 and hp.thpot<math.abs(hp.maxpot-50) and hp.pot<10 then alias.startfj() 
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.cm>0 then alias.startcm()
		--elseif have.jingyao>0 and (hp.pot>50 or hp.thpot>hp.maxpot) then run("huan all");alias.startxue() 
		else alias.dz("addneili")
		end
	else
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) and (mpLimited.mpexp>100 or workflow.mp==0) then alias.startyb() --�Ѿ���������һ���������񣬻�û����Ѻ�ڣ���ȥѺ��
		elseif war.open>0 and stat.needwar()  and WarLimited==0 and (mpLimited.mpexp>100 or workflow.mp==0) then alias.startwar()
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.fj>0 and workflow.mp==0 and fjfinished==0 and xuefirst>0 and hp.thpot<math.abs(hp.maxpot-50) and hp.pot<10 then alias.startfj() 
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.cm>0 then alias.startcm()
		--elseif hp.pot>50 or hp.thpot>1000 then alias.startxue() else alias.dz("addneili") end
		else alias.dz("addneili") 
		end
	end
	ftbfail=0
end
function alias.startworkflow_bt()
	if de_bug>0 then print("�������̿�ʼ����ʷ����"..workflow.nowjob) end
	if ybLimited==0 and ybjob.waitlimit>0 then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
	elseif havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then alias.startxue()
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() else alias.dz("addneili") end
	else
		if workflow.yb>0 and ybjob.needfangqi==0 and mpLimited.mpexp>100 and ybexp==0 and ybjob.waitlimit==0 then alias.startyb() --�Ѿ���������һ���������񣬻�û����Ѻ�ڣ���ȥѺ��һ��
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() else alias.dz("addneili") end
	end
	ftbfail=0
end
function alias.startworkflow_xx()
	always.xxblow=0  --����blow di״̬
	have.suck=0		--�ж��Ƿ��л���״̬
	if de_bug>0 then print("�������̿�ʼ����ʷ����"..workflow.nowjob) end
	if (ybLimited==0 and ybjob.waitlimit>0) then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
	elseif havefj>0 then
		if workflow.fj>0 then workflow.nowjob="fj";alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 and xx.needsandu==0 then alias.startxue()
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	else
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) and (mpLimited.mpexp>100 or workflow.mp==0) and (WarExp>500 or not stat.needwar() or war.open==0) then 
			alias.startyb()--������һ��mp��war����ȥyb
		elseif war.open>0 and stat.needwar()  and (mpLimited.mpexp>100 or workflow.mp==0) and WarLimited==0 then 
			alias.startwar()--������һ��mp����ȥ��war
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	end
	ftbfail=0
end
function alias.startworkflow_em()
	if de_bug>0 then print("�������̿�ʼ����ʷ����"..workflow.nowjob) end
	if (ybLimited==0 and ybjob.waitlimit>0) then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
	elseif havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 and mpJobLimited==0 and mpLimited.mpexp>100 then alias.startyb() --yb;����fj�������ж��Ƿ�Ҫ��һ��mpexp����������
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then
		if hp.pot>50 then alias.startxue() 
		elseif skillsfull>0 then alias.dz("addneili") 
		else alias.startxinfa()
		end
	elseif mpJobLimited>0 then 
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		elseif skillsfull>0 then alias.dz("addneili") 
		else alias.startxinfa() 
		end
	else
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) and (mpLimited.mpexp>100 or workflow.mp==0) and (WarExp>500 or not stat.needwar() or war.open==0) then alias.startyb()--������һ��mp��war����ȥyb
		elseif war.open>0 and stat.needwar()  and (mpLimited.mpexp>100 or workflow.mp==0) and WarLimited==0 then alias.startwar()--������һ��mp����ȥ��war
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		elseif skillsfull>0 then alias.dz("addneili") 
		else alias.startxinfa()
		end
	end
	if ftbfail>0 then ftbfail=0 end
end
function alias.startworkflow_xs()
	if de_bug>0 then print("ѩɽ���̿�ʼ����ʷ����"..workflow.nowjob) end
	run("unwield lubo")
	if (ybLimited==0 and ybjob.waitlimit>0) then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
	elseif havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif hp.food<50 or hp.water<50 then alias.starteating() 
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and (hp.pot>hp.maxpot/2 or (have.cstlnj>0 and hp.pot>50) or (have.lxj>0 and hp.pot>50)) then alias.startxue()
	elseif mpJobLimited>0 then
		print("mpJobLimited>0����")
	    if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb() --�Ѿ���������һ����������,��ȥѺ��
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.mp>0 and me.suyou<49 then alias.startmp()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue()
		else alias.dz("addneili") 
		end
	else
		print("mpJobLimited=0����")
		if workflow.yb>0 and ybjob.needfangqi==0 and mpLimited.mpexp>100 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb() --�Ѿ���������һ����������,��ȥѺ��
		elseif workflow.mp>0 then alias.startmp() --���������������
		elseif workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue()
		else alias.dz("addneili")
		end
	end
	ftbfail=0
end
function alias.startworkflow_sl()
	if de_bug>0 then print("�������̿�ʼ����ʷ����"..workflow.nowjob) end
	if havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then alias.startxue()
	elseif workflow.xf==1 and workflow.xinfa()>0 then alias.startxinfa()
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() else alias.dz("addneili") end
	else
		if war.open>0 and stat.needwar() and WarLimited==0 and (mpLimited.mpexp>100 or workflow.mp==0) then alias.startwar()
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	end
	ftbfail=0
end
function alias.startworkflow_wd()
	if de_bug>0 then print("�䵱���̿�ʼ����ʷ����"..workflow.nowjob) end
	if havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif hp.food<hp.maxfood then alias.starteating() 
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>=hp.maxpot then alias.startxue()
	elseif workflow.mp>0 and (me.shen>hp.exp or do_dl_job>0) then alias.startmp()
	elseif war.open>0 and stat.needwar() and WarLimited==0 then alias.startwar()
	elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
	elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
	elseif workflow.qzwd>0 then alias.startqzwd()
	elseif workflow.xf>1 then alias.startxinfa()
	elseif workflow.cm>0 then alias.startcm()
	elseif hp.pot>50 then alias.startxue() else alias.dz("addneili")
	end
	ftbfail=0
end
function alias.startworkflow_qz()
	if de_bug>0 then print("ȫ�����̿�ʼ����ʷ����"..workflow.nowjob) end
	if havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then alias.startxue()
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() else alias.dz("addneili") end
	else
		if war.open>0 and stat.needwar() and WarLimited==0 and (mpLimited.mpexp>100 or workflow.mp==0) then alias.startwar()
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	end
	ftbfail=0
end
function alias.startworkflow_hs()
	if de_bug>0 then print("��ɽ���̿�ʼ����ʷ����"..workflow.nowjob) end
	if havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then alias.startxue()
	elseif workflow.xf==1 and workflow.xinfa()>0 then alias.startxinfa()
	elseif mpJobLimited>0 then
		if war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.mp>0 and tonumber(have.ling)<tonumber(mmr.targetNum) then alias.startmp()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	else
		if war.open>0 and stat.needwar()  and (mpLimited.mpexp>100 or workflow.mp==0) and WarLimited==0 then alias.startwar()--������һ��mp����ȥ��war
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	end
	ftbfail=0
end
function alias.startworkflow_dl()
	stat.qiankun=0
	if de_bug>0 then print("�������̿�ʼ����ʷ����"..workflow.nowjob) end
	if (ybLimited==0 and ybjob.waitlimit>0) then alias.startyb() --���Ƚ����ϸ�limit�������޺��ܵ�һ��yb
	elseif havefj>0 then
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif hp.food<hp.maxfood/2 and hp.water<hp.maxwater/2 and roomno_now~=1902 and roomno_now~=1903 then alias.starteating() --̫�ظ�ִ�����������ס
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then alias.startxue()
	elseif mpJobLimited>0 then
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	else
		if workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or ybjob.waitlimit==0) and (mpLimited.mpexp>100 or workflow.mp==0) and (WarExp>500 or not stat.needwar() or war.open==0) then 
			alias.startyb()--������һ��mp��war����ȥyb
		elseif war.open>0 and stat.needwar()  and (mpLimited.mpexp>100 or workflow.mp==0) and WarLimited==0 then 
			alias.startwar()--������һ��mp����ȥ��war
		elseif workflow.mp>0 then alias.startmp()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	end
	if ftbfail>0 then ftbfail=0 end
end
function alias.startworkflow_gb()
	if de_bug>0 then print("ؤ�����̿�ʼ����ʷ����"..workflow.nowjob) end
	if hp.pot<=50 then gold.num=0 end --ѧϰ�����ˣ������ַ����� 
	if (ybLimited==0 and ybjob.waitlimit>0) then --�ϸ�Ѻ����������ɣ����ǻ�û�н�����yb����ʱ���ѽ���  2017.2.27
		alias.startyb()
	elseif havefj>0 then
		gold.num=0
		if workflow.fj>0 then alias.startfj() else alias.startfjclose() end
	elseif ybjob.ybroom>0 then alias.startyb()
	elseif jifa.forcename=="bitao-xuangong" and workflow.yb>0 and ybjob.needfangqi==0 and (ybLimited==0 or (ybjob.waitlimit==0 and os.time()-tonumber(ybLimitedMarkTime)>=2000)) then alias.startyb()
	elseif xuefirst>0 and hp.pot>hp.maxpot/2 then alias.startxue()
	elseif gb.Limited1>0 and gb.Limited2>0 then
		mpJobLimited=1
		if workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	else
		mpJobLimited=0
		if workflow.mp>0 and (gold.num<gold.setnum or mpLimited.beg1==0 or mpLimited.beg2==0) then
			set_neili=set_neili_job
			if gold.place~="" then alias.startgbresume() else alias.startmp() end
		elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then alias.startyb()
		elseif war.open>0 and stat.needwar()  and WarLimited==0 then alias.startwar()
		elseif workflow.ftb>0 and ftbfail==0 then alias.startftb()
		elseif workflow.qzwd>0 then alias.startqzwd()
		elseif workflow.xf>1 then alias.startxinfa()
		elseif workflow.cm>0 then alias.startcm()
		elseif hp.pot>50 then alias.startxue() 
		else alias.dz("addneili") end
	end
	if ftbfail>0 then ftbfail=0 end
end
if pxj_no~=nil then  --����ű�ʱ������������������ֹ����ѡ��ʱ����
	local _tb
	_tb=Split(pxj_no,"|")
	alias.whg_no=0
	alias.yyc_no=0
	alias.khf_no=0
	for i=1,#_tb,1 do 
		if _tb[i]=="wuhua guo" then alias.whg_no=alias.whg_no+1 end
		if _tb[i]=="yinyang cao" then alias.yyc_no=alias.whg_no+1 end	
		if _tb[i]=="kuihua fen" then alias.khf_no=alias.khf_no+1 end
	end
else
	alias.yyc_no=0
end
function alias.addxyzq()
	openclass("addxyzq")
	alias.flytoid(461)
end
function alias.starteating()
	openclass("eating")
	if me.menpai=="wd" then
		alias.flytoid(682)
	elseif me.menpai=="dl" then
		dl_food={}
		alias.flytoid(288)
	else
		alias.flytoid(280) --��������ȥ���ϰ��ǳ�������
	end
end
function alias.startfuxueteng()
	alias.flytoid(dummy.xueteng_room)
end
function alias.getbuyinwan()
	local _tb
	openclass("buyinwan")
	_tb=Split(pxj_no,"|")
	alias.whg_no=0
	alias.yyc_no=0
	alias.khf_no=0
	for i=1,#_tb,1 do 
		if _tb[i]=="wuhua guo" then alias.whg_no=alias.whg_no+1 end
		if _tb[i]=="yinyang cao" then alias.yyc_no=alias.yyc_no+1 end	
		if _tb[i]=="kuihua fen" then alias.khf_no=alias.khf_no+1 end
	end
	if yinyangcao_time<1200 and yinyangcao_num<alias.yyc_no and findstring(pxj_no,"yinyang cao") then
		closeclass("buyinwan")
		alias.startworkflow()
	elseif yinyangcao_num<alias.yyc_no then
		alias.flytoid(1494) --ȥ�ڷ��
	elseif wuhuaguo_num<alias.whg_no then
		alias.flytoid(1084)  --̩ɽ���
	else
		alias.flytoid(4)   --Ȫ��ҩ��
	end
end
function alias.startworkflow_dm() -- ��������
	if hp.healthqi>50 then --�����˾Ͳ���������Ȼ�ָ�
		openclass("dm")
		if me.menpai=="gb" then
			alias.flytoid(1983)
		elseif (hp.food<hp.maxfood/2 or hp.water<hp.maxwater/2) and me.menpai=="dl" then 
			alias.starteating() 
		else
			alias.flytoid(282)
		end
	else
		run("yun kurong;hp")
	end
end
function alias.checkbili()
	local a=0
	if skillslist["strike"]~=nil and skillslist["strike"]["lvl"]~=nil then
		if a<math.floor(skillslist["strike"]["lvl"]/10) then a=math.floor(skillslist["strike"]["lvl"]/10) end
	end
	if skillslist["cuff"]~=nil and skillslist["cuff"]["lvl"]~=nil then
		if a<math.floor(skillslist["cuff"]["lvl"]/10) then a=math.floor(skillslist["cuff"]["lvl"]/10) end
	end
	if skillslist["finger"]~=nil and skillslist["finger"]["lvl"]~=nil then
		if a<math.floor(skillslist["finger"]["lvl"]/10) then a=math.floor(skillslist["finger"]["lvl"]/10) end
	end
	if skillslist["hand"]~=nil and skillslist["hand"]["lvl"]~=nil then
		if a<math.floor(skillslist["hand"]["lvl"]/10) then a=math.floor(skillslist["hand"]["lvl"]/10) end
	end
	if skillslist["claw"]~=nil and skillslist["claw"]["lvl"]~=nil then
		if a<math.floor(skillslist["claw"]["lvl"]/10) then a=math.floor(skillslist["claw"]["lvl"]/10) end
	end
	if fjweapon~=nil and fjweapon=="" and always["bei"][1]~=nil and always["bei"][1]~="��������" and always["bei"][1]~="����ʮ����" then a=0 --���ÿ���ʱ����ʹ���˱���Ҳ��quit�������õ���hbmz��xlz
	elseif me.menpai=="sl" and workflow.mp>0 then a=0  --����ż�������������������Ǻܿ�ͻָ��ˣ�����Ҫquit
	elseif me.menpai=="bt" and findstring(fjpfm,"heji","bite") then a=0 --���տ��ߴ򣬱�����Ҳ����ν������Ҫquit
	elseif stat.use_jinhua and mj.lvl<6 then a=0 --�ɻ��ǻ�ѧ�˺���������Ҳ����ν������Ҫquit
	end
	if a>0 then a=a+me.xtbl end
	return a
end
function alias.clear_stat_bl()
	stat.jingang=0
	stat.leidong=0
	print("������pfm���׶�pfm״̬")
end
function alias.count_qiankun()
	if skillslist["yiyang-zhi"]~=nil then 
		dl.need_qiankun=math.ceil((hp["maxneili"]*14/15)/(skillslist["yiyang-zhi"]["lvl"]*200/30))
	else
		dl.need_qiankun=0
	end
end