function alias.checkburnnpc()
	local _tb
	if tonumber(hp.exp)<10000 then 
		burnnpc.nl="相士|相士"
		burnnpc.rl="1003|1003"
	elseif tonumber(hp.exp)<12000 then 
		burnnpc.nl="台夷猎人|猎人"
		burnnpc.rl="140|304"
	elseif tonumber(hp.exp)<15000 then 
		burnnpc.nl="戚芳|刀客"
		burnnpc.rl="627|1059"	
	elseif tonumber(hp.exp)<20000 then 
		burnnpc.nl="王通治|刀客"
		burnnpc.rl="627|1059"	
	elseif tonumber(hp.exp)<50000 then
		burnnpc.nl="小姗|祖千秋|马光佐"
		burnnpc.rl="1026|1304|925"
	elseif tonumber(hp.exp)<=70000 then
		burnnpc.nl="摆夷判官|小姗|马光佐"
		burnnpc.rl="292|1026|925"
	elseif tonumber(hp.exp)<=80000 then
		burnnpc.nl="江上游|小姗|马光佐"
		burnnpc.rl="1049|1026|925"
	elseif tonumber(hp.exp)<=90000 then
		burnnpc.nl="戚长发|游迅|江上游"
		burnnpc.rl="627|1321|1049"
	elseif tonumber(hp.exp)<=100000 then
		burnnpc.nl="方碧琳|日本浪人|日本浪人|日本浪人|江上游"
		burnnpc.rl="403|66|67|77|1049"
	elseif tonumber(hp.exp)<=150000 then
		burnnpc.nl="米横野|方碧琳|日本浪人|日本浪人|日本浪人"
		burnnpc.rl="1011|403|66|67|77"
	elseif tonumber(hp.exp)<=200000 then
		burnnpc.nl="钟万仇|左全|静真"
		burnnpc.rl="328|1983|399"
	elseif tonumber(hp.exp)<=250000 then
		burnnpc.nl="贝锦仪|静闲|静迦|李明霞"
		burnnpc.rl="380|343|361|350"
	--elseif tonumber(hp.exp)<=350000 then
	--	burnnpc.nl="静照|花铁干|陆天抒|刘承风"
	--	burnnpc.rl="400|418|419|647"
	elseif tonumber(hp.exp)<=500000 then
		burnnpc.nl="水岱|陆天抒|刘承风|静空|静虚|静玄"
		burnnpc.rl="419|419|647|397|367|363"
	elseif tonumber(hp.exp)<=550000 then
		burnnpc.nl="水岱|刘承风|静空|静虚|静玄|说不得|张中|冷谦"
		burnnpc.rl="419|647|397|367|363|556|586|584"
	elseif tonumber(hp.exp)<=600000 then
		burnnpc.nl="水岱|静空|静虚|说不得|张中|冷谦"
		burnnpc.rl="419|397|367|363|556|586|584"
	elseif tonumber(hp.exp)<=650000 then
		burnnpc.nl="静虚|说不得|张中|冷谦"
		burnnpc.rl="363|556|586|584"
	elseif tonumber(hp.exp)<=650000 then
		burnnpc.nl="曲三|说不得|张中|冷谦"
		burnnpc.rl="1278|556|586|584"
	elseif tonumber(hp.exp)<=700000 then
		burnnpc.nl="静玄|说不得|张中|冷谦"
		burnnpc.rl="363|556|586|584"
	elseif tonumber(hp.exp)<=750000 then
		burnnpc.nl="简长老|说不得|张中|冷谦"
		burnnpc.rl="1117|556|586|584"
	elseif tonumber(hp.exp)<=800000 then
		burnnpc.nl="殷无福|殷无寿|殷无禄|玄痛大师|玄苦大师|玄难大师|玉真子|李莫愁"
		burnnpc.rl="1234|1234|1216|1653|1620|1634|1707|1271"
	elseif tonumber(hp.exp)<=1200000 then
		burnnpc.nl="殷野王|渡难|渡劫|渡厄"
		burnnpc.rl="1230|1791|1791|1791"
	elseif tonumber(hp.exp)<=1700000 then
		burnnpc.nl="血刀老祖|萧远山"
		burnnpc.rl="416|1537"
	elseif tonumber(hp.exp)<=2000000 then
		--burnnpc.nl="血刀老祖|殷天正"
		burnnpc.nl="血刀老祖"
		--burnnpc.rl="416|1232"
		burnnpc.rl="416"
	elseif tonumber(hp.exp)>2000000 then
		burnnpc.nl="砸缸的"
		burnnpc.rl="439"
	end
	burnnpc.no=burnnpc.no+1
	_tb=Split(burnnpc.nl,"|")
	--if burnnpc.no>#_tb then burnnpc.no=1 end
	if burnnpc.no>#_tb then alias.startworkflow();return end
	closeclass("mp_xs_npc1")
	closeclass("mp_xs_npc2")
	closeclass("mp_xs_lzjob")
	closeclass("mp_xs_start")
	openclass("mp_xs_pre")
	run("hp;set goburnnpc")
end
function alias.checkburnitems()
	have.faling=0
	have.lubo=0
	have.kulouguan=0
	have.rentoulian=0
	mp_xs_start.givecorpse=0
	mp_xs_start.startfight=0
	mp_xs_start.startburn=0
	mp_xs_start.waitgive=""
	have.luboneedfill=1
	run("h;drop jiasha;remove all;unwield fa ling;unwield lubo")
	alias.uw()
	closeclass("mp_xs_npc1")
	closeclass("mp_xs_npc2")
	openclass("check_items")
	--openclass("check_items2")
	openclass("mp_xs_start")
	run("i;look lubo;set checkburnitems")
end
function alias.guanyou()
	run("sd;n;nu")
	--if me.suyou==nil then 
	--	me.suyou=0 
	--end
	if me.suyou>49 then
		for i=1,have.suyouguan+1,1 do run("pour suyou guan into gang;give suyou guan to zhiri lama") end
	else
		for i=1,have.suyouguan+1,1 do run("give suyou guan to zhiri lama") end
	end
	have.suyouguan=0
	me.suyou=0
	run("ask zhiri lama about 敬奉;sd;w;n;n")
	roomno_now=428
	alias.dz(set_neili_job)
end
------------------------------------------------------------------------------------
-- mp_xs_pre
------------------------------------------------------------------------------------
function mp_xs_pre.dosomething1(n,l,w)
	local _f,a,b,c,d
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") and not isopen("mp_xs_start") and not isopen("mp_xs_npc1") then
		alias.resetidle()
		openclass("fj_watch")
		burnnpc.no=0
		if havefj>0 then 
		    print("xs_pre")
			alias.startworkflow() 
		else
			print("目前酥油有 "..tostring(me.suyou).." 斛(多于48斛则开始烧尸体否则lzjob)")
			if me.suyou>=49 and mpJobLimited==0 and skillslist.lamaism~=nil and skillslist.lamaism.lvl>59 then 
				alias.checkburnnpc() 
			else
				closeclass("mp_xs_pre")
				openclass("mp_xs_lzjob")
				alias.flytoid(428)
			end
		end
	elseif findstring(l,"你目前还没有任何为 goburnnpc 的变量设定。") then
		alias.resetidle()
		_tb=Split(burnnpc.nl,"|")
		burnnpc.name=_tb[burnnpc.no]
		_tb=Split(burnnpc.rl,"|")
		burnnpc.room=tonumber(_tb[burnnpc.no])
		print("准备去烧"..burnnpc.name.."，地图id "..tostring(burnnpc.room))
		run("drop skeleton;drop corpse")
		closeclass("mp_xs_pre")
		if tonumber(burnnpc.room)==439 then openclass("mp_xs_npc1") else openclass("mp_xs_npc2") end
		alias.flytoid(burnnpc.room)
	elseif findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		alias.resetidle()
		--if tonumber(roomno_now)==424 then alias.flytoid(439) else alias.flytoid(417) end
		if hp.food<50 or hp.water<50 then 
			alias.flytoid(280) --去找宋老板吃汽锅鸡
		else
			alias.flytoid(417)
		end
	elseif findstring(l,"你目前还没有任何为 busyover=ke 的变量设定。") then
		alias.resetidle()
		run("halt;get suyou guan")
		if tonumber(roomno_now)==417 then alias.flytoid(420)
		elseif tonumber(roomno_now)==420 then alias.flytoid(443)
		elseif tonumber(roomno_now)==443 then alias.flytoid(424)
		--elseif tonumber(roomno_now)==424 then alias.flytoid(439) end
		elseif tonumber(roomno_now)==424 then alias.guanyou() 
		end
	elseif findstring(l,"数码世界，数字地图，417就是这里！","数码世界，数字地图，420就是这里！","数码世界，数字地图，443就是这里！","数码世界，数字地图，424就是这里！") then
		alias.resetidle()
		--closeclass("dazuo")
		run("halt;get suyou guan;kill jinxiang ke")
		--alias.checkbusy("ke")
	elseif findstring(l,"数码世界，数字地图，432就是这里！") then
		run("ask xiao lama about 酥油茶")
		for i=1,3,1 do run("drink suyou cha") end
		alias.flytoid(417)
	elseif findstring(l,"这里没有这个人。","进香客倒在地上，挣扎了几下就死了。") then
		alias.resetidle()
		alias.checkbusy("ke")
	end
end
------------------------------------------------------------------------------------
-- mp_xs_npc1
------------------------------------------------------------------------------------
function mp_xs_npc1.dosomething1(n,l,w)
	local _f,a,b,c,d,e
	--wait.make(function()
		alias.resetidle()
		a,b,c=string.find(l,"[> ]*(.+)说道：听说这里存放着喇嘛用的酥油，老子今天特地过来看看，识相的赶快给我滚开")
		if c~=nil then
			alias.resetidle()
			check_battleidle=0
		    havefj=0
			burnnpc.time=os.time()
		    closeclass("fj_watch")
			closeclass("skills_lian")
			alias.close_dz()
			alias.uw()
			burnnpc.name=c
			run("halt;yield no;yun refresh;yun regenerate;yun recover;id here")
			run(mpyun)
			--if jifa.forcename=="longxiang-banruo" then run("yun longxiang") end
			if string.len(mpweapon)>0 then
				if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
			else 
				alias.uw() 
			end
			return
		end
		a,b,c,d=string.find(l,"^"..burnnpc.name.."%s+=%s+(%w+)%s+(%w+),%s*")
		if c~=nil and d~=nil then
			burnnpc.id=string.lower(c).." "..string.lower(d)
			return
		end
		a,b,c,d,e=string.find(l,"^"..burnnpc.name.."%((%w+) (%w+)%)")
		if c~=nil and d~=nil and e~=nil then
			burnnpc.id=string.lower(d).." "..string.lower(e)
			return
		end
		a,b,c,d,e=string.find(l,"[> ]*(.+)对(.+)大声喝道：.+竟敢不识好歹？！")
		if c~=nil and d~=nil then
		    closeclass("fj_watch")
			if d=="你" then
			    havefj=0
		        closeclass("fj_watch")
				run("set killburnnpc")
			else
				burnnpc.name=""
				burnnpc.id=""
				burnnpc.time=os.time()
				alias.startlianwu()
			end
			return
		end
		----------------------------------------------------------------------------------------------
		if findstring(l,"数码世界，数字地图，"..tostring(burnnpc.room).."就是这里！") then
			burnnpc.name=""
			burnnpc.time=os.time()
			alias.startlianwu()
			run("du book 200")
		elseif tostring(burnnpc.name)=="" and (findstring(l,"倒在地上，挣扎了几下就死了。") or os.time()>(burnnpc.time+120)) then
				closeclass("skills_lian")
				alias.close_dz()
				burnnpc.time=os.time()
				alias.uw()
				run("halt;sd")
				if havefj>0 then
				   alias.startworkflow()
				else
				   run("halt;nu;du book 200")
				   alias.startlianwu()
				end
			--end
		elseif findstring(l,"你目前还没有任何为 killburnnpc 的变量设定。") then
		    havefj=0
		    closeclass("fj_watch")
			run("halt")
			_tb=Split(mpyun,"|")
			for k,v in ipairs(_tb) do run(v) end
			openclass("kill")
			openclass("kill_pfm")
			run("unset no_parry")
			closeclass("kill_run")
			AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
			SetTimerOption("kill_timer", "group", "kill")
			runaway=false
			npcfaint=false
			killRunSuccess=false
			killid=burnnpc.id
			killname=burnnpc.name
			killskill=mpweapon
			killpfm=mppfm
			killyun=mpyun
			killjiali=mpjiali
			killjiajin=mpjiajin
			run("jiali "..killjiali..";jiajin "..killjiajin)
			if string.len(mpweapon)>0 then
			if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
			else alias.uw() end
			run("kill "..burnnpc.id)
			_tb=Split(mppfm,"|")
			for k,v in ipairs(_tb) do run(v.." "..burnnpc.id) end
		elseif findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
			alias.resetidle()
			openclass("fj_watch")
			run("get all from corpse")
			alias.gg()
			run("get corpse;sd")
		elseif findstring(l,"你将"..burnnpc.name.."的尸体扶了起来背在背上。") then
			alias.initialize_trigger()
			alias.checkburnitems()
		elseif findstring(l,burnnpc.name.."的尸体对你而言太重了。") then
			alias.initialize_trigger()
			alias.startworkflow()
		end
	--end)
end
------------------------------------------------------------------------------------
-- mp_xs_npc2
------------------------------------------------------------------------------------
function mp_xs_npc2.dosomething1(n,l,w)
	local _f,a,b,c,d
	wait.make(function()
		a,b,c,d=string.find(l,"^"..burnnpc.name.."%s+=%s+(%w+)%s+(%w+),%s*")
		if c~=nil and d~=nil then
			burnnpc.id=string.lower(c).." "..string.lower(d)
			return
		end
		a,b,c,d=string.find(l,"^"..burnnpc.name.."%s+=%s+%w+,%s+(%w+)%s+(%w+)[,]-")
		if c~=nil and d~=nil then
			burnnpc.id=string.lower(c).." "..string.lower(d)
			return
		end
		a,b,c,d=string.find(l,"^"..burnnpc.name.."%s+=%s+(%w+)%s+(%w+)$")
		if c~=nil and d~=nil then
			burnnpc.id=string.lower(c).." "..string.lower(d)
			return
		end
		if findstring(l,"数码世界，数字地图，"..tostring(burnnpc.room).."就是这里！") then
			alias.resetidle()
			burnnpc.id=""
			_f=function() run("halt;yun refresh;yun regenerate;yun recover;id here;set killburnnpc") end
			wait.time(1.5);_f()
		elseif findstring(l,"你目前还没有任何为 killburnnpc 的变量设定。") then
			alias.resetidle()
			run("halt")
			if tostring(burnnpc.id)=="" then
				print(burnnpc.name.."已死，有事烧纸")
				if havefj>0 then alias.startworkflow() else alias.checkburnnpc() end
			else
				_tb=Split(mpyun,"|")
				for k,v in ipairs(_tb) do run(v) end
				check_battleidle=0
				openclass("kill")
				openclass("kill_pfm")
				run("unset no_parry")
				--openclass("kill_"..me.menpai)
				closeclass("kill_run")
				AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
				SetTimerOption("kill_timer", "group", "kill")
				runaway=false
				npcfaint=false
				killRunSuccess=false
				killid=burnnpc.id
				killname=burnnpc.name
				killskill=mpweapon
				killpfm=mppfm
				killyun=mpyun
				killjiali=mpjiali
				killjiajin=mpjiajin
				run("jiali "..killjiali..";jiajin "..killjiajin)
				if string.len(mpweapon)>0 then
					if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
				else alias.uw() end
				run("kill "..burnnpc.id)
				killaction="yes"
				_tb=Split(mppfm,"|")
				for k,v in ipairs(_tb) do run(v.." "..burnnpc.id) end
			end
		elseif findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
			alias.resetidle()
			run("get all from corpse")
			alias.gg()
			run("get corpse")
			--alias.checkburnitems()
		elseif findstring(l,"你将"..burnnpc.name.."的尸体扶了起来背在背上。") then
			alias.initialize_trigger()
			alias.checkburnitems()
		elseif findstring(l,"[> ]*"..burnnpc.name.."的尸体对你而言太重了。") then
			alias.initialize_trigger()
			alias.startworkflow()
		end
	end)
end
------------------------------------------------------------------------------------
-- mp_xs_start
------------------------------------------------------------------------------------
function mp_xs_start.dosomething1(n,l,w)		--单行触发在此
	local _f,a,b,c
	wait.make(function()
		a,b,c=string.find(l,"葛伦布说道：(.+)上人替.+上人把余下的法事做完吧。")
	    if c~=nil then
			alias.resetidle()
			if me.charname==c then
				run("h;drop corpse;light fa tan;wield lubo;spray tan;unwield lubo;dazuo;wield ling;wave ling;unwield ling")
				alias.close_dz()
				mp_xs_start.startburn=1
			else
				run("hp")
				mp_xs_start.startburn=0
				alias.checkbusy("burn")
			end
			return
		end
		a,b,c=string.find(l,"[> ]*(.+)给葛伦布一具.+的尸体。")
		if c~=nil then
			if c=="你" then 
				mp_xs_start.givecorpse=1
			elseif c~="你" and mp_xs_start.givecorpse>0 then --有人在我后面给了尸体
				alias.resetidle()
				run("halt")
				alias.startworkflow()
			elseif c~="你" and mp_xs_start.startfight>0 then
				alias.resetidle()
				run("halt;hp;give corpse to ge lunbu;yield yes;fight ge lunbu;fight ge lunbu 2")
			end
			return
		end
		a,b,c=string.find(l,"[> ]*(.+)对著葛伦布说道：.+，领教小师父的高招！")
		if c~=nil then
			if c~="你" and mp_xs_start.startfight>0 then
				alias.resetidle()
				mp_xs_start.waitgive=c
			elseif c=="你" then 
				alias.resetidle()
				mp_xs_start.startfight=1
				mp_xs_start.waitgive=""
			end
			return
		end
		a,b,c=string.find(l,"葛伦布说道：(.+)上人请为亡灵超度吧！")
		if c~=nil then
			if c==me.charname then
				alias.resetidle()
				mp_xs_start.givecorpse=0
				mp_xs_start.startfight=0
				mp_xs_start.startburn=1
				run("halt;yield no;hp;light tan")
				alias.uw()
				run("dazuo "..dz_xs()) 
			elseif mp_xs_start.givecorpse>0 or mp_xs_start.startfight>0 then
				alias.resetidle()
				mp_xs_start.startfight=0
				run("drop corpse")
				alias.startworkflow()
			end
			return
		end
		if findstring(l,"你身上没有这样东西。") and mp_xs_start.startfight>0 then 
			if mp_xs_start.givecorpse==0 then
				alias.resetidle()
				alias.startworkflow()
				run("halt;yield no")
			end
		elseif findstring(l,"你目前还没有任何为 checkburnitems 的变量设定。") then
			alias.resetidle()
			mp_xs_start.givecorpse=0
			closeclass("check_items")
			--closeclass("check_items2")
			if (have.faling<1 or have.lubo<1 or have.kulouguan<1 or have.rentoulian<1) then
				run("drop skeleton;drop corpse")
				alias.startworkflow()
			else
				-- #if @debug {#say 装备齐全，开始烧尸}
				alias.flytoid(437)
			end
		elseif findstring(l,"数码世界，数字地图，437就是这里！") then
			alias.resetidle()
			if have.luboneedfill~=nil and have.luboneedfill==1 then run("fill lubo") end
			alias.checkbusy("fill")
		elseif findstring(l,"你目前还没有任何为 busyover=fill 的变量设定。") then
			alias.resetidle()
				if hp.neili<700 then
					alias.dz(700/hp.maxneili*100)
				else
					alias.uw()
					run("yun recover;set dazuo=over")
				end
		elseif not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			alias.resetidle()
			--if tonumber(roomno_now)~=422 or tonumber(roomno_now)~=425 then alias.flytoid(422) end
			alias.flytoid(425)
		elseif findstring(l,"数码世界，数字地图，425就是这里！") then
		--if findstring(l,"数码世界，数字地图，422就是这里！","数码世界，数字地图，425就是这里！") then
			alias.resetidle()
			--burnnpc.corpse=0
			if havefj>0 then 
				run("drop skeleton;drop corpse")
				alias.startworkflow() 
			else
				_f=1
				run("unset brief;ask ge lunbu about 准备法事;wear all")
			end
		elseif findstring(l,"对方正忙着呢，你等会儿在问话吧。","你跟这儿凑什么热闹？","以你的禅宗和内功修为还不足以帮助别人护法！") then
			--,"你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道：.+正在做法事，这位.+请一旁稍候。"
			alias.resetidle()
			--alias.checkbusy("burn")
			--_f=function() 
			if _f==1 then 
				_f=2
				run("ask ge lunbu 2 about 准备法事")
			elseif tonumber(roomno_now)==425 then 
				_f=1
				roomno_now=422;run("s;ask ge lunbu about 准备法事") 
			else 
				_f=1
				roomno_now=425;run("n;ask ge lunbu about 准备法事") 
			end 
			--end
			--wait.time(0.15);_f()
		elseif findstring(l,"你盘腿打坐，神光内蕴，口中念念有辞，渐渐有一丝魂魄在你面前凝聚成形") then
			alias.resetidle()
		elseif findstring(l,"一丝魂魄升出祭坛，冉冉而起。魂魄受你佛法感召，徘徊不去。") then
			alias.resetidle()
			alias.close_dz()
			wait.time(1)
			run("halt;wield lubo;spray fa tan;unwield lubo;wield fa ling;dazuo")
		elseif findstring(l,"魂魄越聚越多，竟然呈出人形！ 你手指人形，口念真言，指引往生之路。") then
			alias.resetidle()
			run("wave fa ling;unwield fa ling")
		elseif findstring(l,"你双手抱拳朗声说道：这位上人安心做法事，让.+来为你护法","你口中朗朗诵出《不动明王经》！") then
			alias.resetidle()
		elseif findstring(l,"你跟这儿凑什么热闹？") then
			alias.resetidle()			
			alias.checkbusy("burn")
			run("halt;yield no")
		elseif findstring(l,"大院里光茫四起，一声巨响过后，又恢复了平静。超度完毕。","慢慢地一阵眩晕感传来，你终于又有了知觉","酥油灯慢慢熄灭了，你睁开双眼。。。。") and mp_xs_start.startburn>0 then
			alias.resetidle()
			--alias.checkexp("mp")
			alias.checkexp("burnnpc")
			alias.checkbusy("burn")
		elseif findstring(l,"你目前还没有任何为 busyover=burn 的变量设定。") then
			alias.resetidle()
			mp_xs_start.startburn=0
			run("yun refresh;yun recover;yun regenerate;drop skeleton;drop corpse")
			alias.startworkflow()
		elseif findstring(l,"你跟这儿凑什么热闹？") then
			alias.resetidle()
			mp_xs_start.startburn=0
			run("halt;drop corpse;drop skeleton") 		
			alias.startworkflow()
		elseif findstring(l,"你烧了太多尸体了，先去做些别的事情吧！") then
			print("烧过了头")
			mpLimited.mpexp=0
			mpJobLimited=1
		elseif findstring(l,"你目前还没有任何为 checkexpover=mp 的变量设定。") then
			alias.resetidle()
			if add.exp>10 and mpLimited.MarkExp<me.menpaiLimited then mpLimited.MarkExp=tonumber(me.menpaiLimited) end
			if mpLimited.mpexp>=7000 then
				--add.exp<10 or 
				mpJobLimited=1
				print("统计到的burn npc上限为："..mpLimited.mpexp)
				--mpLimited.MarkExp=mpLimited.mpexp
				if mpLimited.MarkTime<(os.time()-3600) then
					-- 到arrest时间却仍然busy，推迟2分钟
					mpLimited.MarkTime=tonumber(os.time()-3600+120)
				end
			end
			mp_xs_start.givecorpse=0
		end
	end)
end
function mp_xs_start.dosomething2(n,l,w)		--两行触发在此
	wait.make(function()
	if findstring(w[0],"你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道：上人请继续做法事。") then 
		run("h;drop corpse;light fa tan;wield lubo;spray tan;unwield lubo;dazuo;wield ling;wave ling;unwield ling")
		alias.close_dz()
		mp_xs_start.startburn=1
		return
	elseif findstring(w[0],"你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道："..me.charname..".+是要给哪位施主做法事呀？") then	 
		mp_xs_start.givecorpse=0  
		mp_xs_start.startfight=1 
		run("unset brief;yield yes;fight ge lunbu;fight ge lunbu 2")
			local _f=function() 
				if mp_xs_start.waitgive=="" and mp_xs_start.givecorpse==0 then 
					run("halt;hp;yield yes;give corpse to ge lunbu;fight ge lunbu;fight ge lunbu 2") 
				end 
			end
			wait.time(4.5)
				_f()		   
		--[[	local _f=function() 
				run("halt;yield no;hp;light tan;dazuo "..dz()) 
				burncorpse_temp=os.time()
			end
			wait.time(11);_f()]]
	elseif findstring(w[0],"你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道：.+在本寺敬奉的酥油太少了，先去弄些酥油来吧。","你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道：做法事用的酥油不够用了，请.+弄些酥油来吧。") then
		alias.resetidle()
		alias.checkbusy("burn")
	elseif findstring(w[0],"你向葛伦布打听有关「准备法事」的消息。\n但是很显然的，葛伦布现在的状况没有办法给你任何答覆。","你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道：.+正在做法事，这位.+请一旁稍候。","你向葛伦布打听有关「准备法事」的消息。\n葛伦布说道：.+刚做完法事，祭坛还未熄，待我等清理完後.+再来做法事吧。") then
		alias.resetidle()
		if havefj>0 then alias.startfj()
		elseif _f==1 then 
				_f=2
				run("ask ge lunbu 2 about 准备法事")
			elseif tonumber(roomno_now)==425 then 
				_f=1
				roomno_now=422;run("s;ask ge lunbu about 准备法事") 
			else 
				_f=1
				roomno_now=425;run("n;ask ge lunbu about 准备法事") 
			end 
		--else roomno_now=425;run("n;ask ge lunbu about 准备法事") end 
	end
	end)
end
------------------------------------------------------------------------------------
-- mp_xs_lzjob
------------------------------------------------------------------------------------
function mp_xs_lzjob.dosomething1(n,l,w)
	local _f
	if findstring(l,"区域搜索中心点房间查找失败","数码世界，数字地图，428就是这里！") then
		alias.resetidle()
		run("ask lingzhi shangren about abandon")
		alias.dz(set_neili_job)
		---alias.startlianwu()
	elseif not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
		alias.resetidle()
		closeclass("skills_lian")
		alias.close_dz()
		if havefj>0 then 
		    print("xs_lzjob")
			alias.startworkflow()
		else
			lzjob.name=""
			lzjob.area=""
			run("ask lingzhi shangren about job;set checklzjob")
		end
	elseif not isopen("boat") and findstring(l,"你目前还没有任何为 lian=over 的变量设定。") then 
		alias.resetidle()
		closeclass("skills_lian")
		alias.close_dz()
		alias.startworkflow()
	elseif findstring(l,"你目前还没有任何为 checklzjob 的变量设定。") then
		alias.resetidle()
		if lzjob.name=="" or lzjob.area=="" then 
			if havefj>0 then 
				alias.startworkflow()
			elseif mpJobLimited==0 and me.suyou>5 then
				closeclass("mp_xs_lzjob")
				alias.checkburnnpc()
			elseif workflow.cm>0 then 
				alias.startcm()
			elseif hp.pot>50 and #skillslist_need_up>0 then 
				alias.startxue()
			else
				alias.startlianwu()
			end
		else
			closeclass("mp_xs_lzjob")
			openclass("ftb")
			openclass("ftb_ask")
			closeclass("ftb_pre")
			closeclass("ftb_start")
			flytoareastartid=0
			workflow.nowjob="lzjob"
			nextJobGodazuobase=1
			ftbnum=1
			ftbarea=lzjob.area
			ftbarea_table={lzjob.area,}
			ftbareanum=9
			alias.lzarea(ftbarea)
			if lzjobtimes==nil then 
				lzjobtimes=1 
			else
				lzjobtimes=lzjobtimes+1
			end
			print("本次连线一共领取"..lzjobtimes.."个任务，成功"..count.ftb.."个任务，地点:"..ftbroom..","..ftbzone..",姓名:"..lzjob.name)
			if #ftbfail_table>0 then 
				tprint(ftbfail_table)
			end
			addlog("lzjob开始找人 地点:"..lzjob.area..","..ftbzone..","..ftbroom..",姓名:"..lzjob.name)
			if findstring(ftbroom,"丹凤洞") then ftbroom="羊肠小路" end
			run("halt")
			alias.uw()
			alias.flytoarea(ftbroom,ftbzone,tonumber(ftbareanum)+1)
		end
	end
end
function mp_xs_lzjob.dosomething4(n,l,w)
	local a,b,c,d
	a,b,c,d=string.find(w[0],"你向灵智上人打听有关「job」的消息。\n灵智上人轻轻地拍了拍你的头。\n灵智上人说道：(.+)偷了我们的酥油，据说他已经到了(.+)附近！\n灵智上人说道：请尽快给我解决他，我不想再看到这个人了！")
	if c~=nil and d~=nil then
		lzjob.name=c
		lzjob.area=d
	end
end
------------------------------------------------------------------------------------
-- mp_xs_watch
------------------------------------------------------------------------------------
function mp_xs_watch.dosomething1(n,l,w)
	if findstring(l,"[> ]*"..burnnpc.name.."脚下一个不稳，跌在地上昏了过去。","你不在战斗中。") then
		--run("kill "..burnnpc.id)
		rekill=1
	end
end
function mp_xs_watch.dosomething2(n,l,w)
	local a,b,c
	a,b,c=string.find(w[0],"你向值日喇嘛打听有关「敬奉」的消息。\n值日喇嘛说道：.+目前在本寺中敬奉的酥油量是满的，一共有(.+)斛")
	if c~=nil then me.suyou=ctonum(c) end
	a,b,c=string.find(w[0],"你向值日喇嘛打听有关「敬奉」的消息。\n值日喇嘛说道：.+目前在本寺中敬奉的酥油也就只剩下(.+)斛")
	if c~=nil then me.suyou=ctonum(c) end
	a,b,c=string.find(w[0],"你向值日喇嘛打听有关「敬奉」的消息。\n值日喇嘛.+道：你这个.+，在本寺中敬奉的酥油快用完了，现在只剩有聊聊(.+)斛")
	if c~=nil then me.suyou=ctonum(c) end
	a,b,c=string.find(w[0],"你向值日喇嘛打听有关「敬奉」的消息。\n值日喇嘛说道：.+目前在本寺中敬奉的酥油有(.+)斛")
	if c~=nil then me.suyou=ctonum(c) end
	if findstring(w[0],"你向值日喇嘛打听有关「敬奉」的消息。\n值日喇嘛说道：还敢问？.+将本寺供奉的酥油都用完了！") then
		me.suyou=0
	end
end
function mp_xs_watch.dosomething3(n,l,w)
	local a,b,c
	a,b,c=string.find(w[0],"你向值日喇嘛打听有关「敬奉」的消息。\n值日喇嘛对着你点了点头。\n值日喇嘛说道：.+目前在本寺中敬奉的酥油还剩(.+)斛")
	if c~=nil then me.suyou=ctonum(c) end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function mp_xs.update()
	local _tb
	local  mp_xs_pre_triggerlist={
	       {name="mp_xs_pre_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xs_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_pre_triggerlist) do
		addtri(v.name,v.regexp,"mp_xs_pre",v.script,v.line)
	end
	closeclass("mp_xs_pre")
	
	local  mp_xs_npc1_triggerlist={
	       {name="mp_xs_npc1_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xs_npc1.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_npc1_triggerlist) do
		addtri(v.name,v.regexp,"mp_xs_npc1",v.script,v.line)
	end
	closeclass("mp_xs_npc1")
	
	local  mp_xs_npc2_triggerlist={
	       {name="mp_xs_npc2_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xs_npc2.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_npc2_triggerlist) do
		addtri(v.name,v.regexp,"mp_xs_npc2",v.script,v.line)
	end
	closeclass("mp_xs_npc2")
	
	local  mp_xs_start_triggerlist={
	       {name="mp_xs_start_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xs_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_start_triggerlist) do
		addtri(v.name,v.regexp,"mp_xs_start",v.script,v.line)
	end
	local _tb2={
		"你向葛伦布打听有关「准备法事」的消息。\\n(.+)\\Z",
		--"不一会儿，一切准备停当。\\n葛伦布说道：(.+)上人请为亡灵超度吧！\\Z",
	}
	local  mp_xs_start_m_triggerlist={
	       {name="mp_xs_start_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_xs_start.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_xs_start",v.script,v.line)
	end
	closeclass("mp_xs_start")
	
	local  mp_xs_watch_triggerlist={
	       {name="mp_xs_watch_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xs_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_watch_triggerlist) do
		addtri(v.name,v.regexp,"mp_xs_watch",v.script,v.line)
	end
	local _tb2={
		"你向值日喇嘛打听有关「敬奉」的消息。\\n(.+)\\Z",
	}
	local _tb3={
		"你向值日喇嘛打听有关「敬奉」的消息。\\n(.+)\\n(.+)\\Z",
	}
	local  mp_xs_watch_m_triggerlist={
	       {name="mp_xs_watch_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_xs_watch.dosomething2(n,l,w)  end,},
	       {name="mp_xs_watch_m_dosth3",line=3,regexp=linktri2(_tb3),script=function(n,l,w)    mp_xs_watch.dosomething3(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_watch_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_xs_watch",v.script,v.line)
	end

	local noecho_trilist={
			"你身上没有这样东西",
			"你并没有装备这样东西",
			"你附近没有这样东西",
			"你丢下",
			"这位上人请一旁稍候",
			"走了过来",
			"急步往",
			}
	local _noechotri=linktri(noecho_trilist)

	addtri("mp_xs_watch_gag_dosth1",_noechotri,"mp_xs_watch","")
	SetTriggerOption("mp_xs_watch_gag_dosth1","omit_from_output",1)
	
	closeclass("mp_xs_watch")
	
	local  mp_xs_lzjob_triggerlist={
	       {name="mp_xs_lzjob_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xs_lzjob.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_lzjob_triggerlist) do
		addtri(v.name,v.regexp,"mp_xs_lzjob",v.script,v.line)
	end
--	local _tb2={
--		"你向灵智上人打听有关「job」的消息。\\n(.+)\\Z",
--	}
--	local _tb3={
--		"你向灵智上人打听有关「job」的消息。\\n(.+)\\n(.+)\\Z",
--	}
	local _tb4={
		"你向灵智上人打听有关「job」的消息。\\n(.+)\\n(.+)\\n(.+)\\Z",
	}
	local  mp_xs_lzjob_m_triggerlist={
--	       {name="mp_xs_lzjob_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_xs_lzjob.dosomething2(n,l,w)  end,},
--	       {name="mp_xs_lzjob_m_dosth3",line=3,regexp=linktri2(_tb3),script=function(n,l,w)    mp_xs_lzjob.dosomething3(n,l,w)  end,},
	       {name="mp_xs_lzjob_m_dosth4",line=4,regexp=linktri2(_tb4),script=function(n,l,w)    mp_xs_lzjob.dosomething4(n,l,w)  end,},
	}
	for k,v in pairs(mp_xs_lzjob_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_xs_lzjob",v.script,v.line)
	end
	closeclass("mp_xs_lzjob")
end
mp_xs.update()

