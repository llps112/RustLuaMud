local _tb
function selectfjnpc()
	local _tb
	if fj_select_npc~=nil and fj_select_npc==0 then
		return 1
	else
		_tb=Split(fjselectnpc[fjselectnpc.menpai],"|")
		return tonumber(_tb[fjselectnpc.weapon])
	end
end
function fangqivalue()
	local a,b,c
	a=math.fmod(gxd.me-gxd.value,10)
	if a>0 then b=1 else b=0 end
	c=(gxd.me-gxd.value)/10+b
	--if c>5 then c=5 end
	return math.floor(c)
end
function fangqipercent()
	local a,b,c
	a=math.fmod(gxd.me-gxd.mp*gxd.percent/100,10)
	if a>0 then b=1 else b=0 end
	c=(gxd.me-gxd.mp*gxd.percent/100)/10+b
	if c>5 then c=5 end
	return math.floor(c)
end
------------------------------------------------------------------------------------
-- fj_close
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil and tonumber(c)==me.fjbaseid then
		if not isopen("dazuo") then run("ask "..me.fjmasterid.." about 要事在身") end
	end
end
_tb={"数码世界，数字地图，(\\d+)就是这里！",}
maketri("fj_close_dosth",_tb,"fj_close",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,"你向(.+)打听有关「要事在身」的消息。")
	if c~=nil and c==me.fjmaster then
		alias.resetidle()
		havefj=0
		closeclass("fj_close")
		alias.startworkflow()
	end
end
_tb={"你向(.+)打听有关「要事在身」的消息。",}
maketri("fj_close_dosth",_tb,"fj_close",_ft)
closeclass("fj_close")
------------------------------------------------------------------------------------
-- fj_pre
------------------------------------------------------------------------------------
maketri_num=1
--_tb={"你目前还没有任何为 dealwithitems=over 的变量设定。","数码世界，数字地图，(\\d+)就是这里！","(.+)拍了拍你的肩膀，说道：好，我有任务时自然会派人去通知你。","你目前还没有任何为 dazuo=over 的变量设定。","你目前还没有任何为 checkhp=addneili 的变量设定。","对方正忙着呢，你等会儿在问话吧。","这里没有 (.+) 这个人。","你忙着呢，你等会儿在问话吧。",}
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	alias.resetidle()
	if fjroom~=nil and string.len(fjroom)>0 and fjzone~=nil and string.len(fjzone)>0 then
		alias.close_dz()
		closeclass("fj_pre")
		openclass("fj_start")
		alias.uw()
		fjarrived=0
		if me.menpai=="th" and roomno_now==1470 and yp.goto==0 and mpJobLimited==0 and havefj>0 and fjarea~="" and workflow.mp>0 then
			alias.close_fj()
			openclass("menpai")
			openclass("mp_"..me.menpai)
			openclass("mp_"..me.menpai.."_pre")
			openclass("mp_"..me.menpai.."_watch")
			alias.checkitems()
		elseif fjroomid~=nil and fjroomid>0 then 
			alias.flytoid(fjroomid) 
		else 
			alias.flytoname(fjroom,fjzone) 
		end
	else
		alias.flytoid(me.fjbaseid)
	end
end
_tb={"你目前还没有任何为 dealwithitems=over 的变量设定。",}
maketri("fj_pre_dosth",_tb,"fj_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil and not isopen("boat") and tonumber(c)==me.fjbaseid then
		alias.resetidle()
		run("h;ask "..me.fjmasterid.." about 门派任务")
		
		if me.menpai=="mj" then 
			if skillslist["qianzhu-wandu"]~=nil and skillslist["qianzhu-wandu"]["lvl"]~=nil then
				print("带有千蛛毒气，不能Ask force~")
			elseif not jifa["forcename"] or not skillslist[jifa["forcename"]] or type(skillslist[jifa["forcename"]])~="table" or not skillslist[jifa["forcename"]]["lvl"] then
				print("jifaforce数据抓取失败，不能Ask force~")
			elseif mj.haveyd==0 and mj.lvl==5 and hp.pot>hp.maxpot*0.5 and skillslist[jifa["forcename"]]["lvl"]<me.maxlvl then
				_tb=math.floor((hp.pot-hp.maxpot*0.5)/10)
				if _tb>30 then _tb=30 end
				if _tb>1 then alias.loop(_tb,"ask yang xiao about force") end
			else
				print("暂不Ask force")
			end		
			--alias.dz(set_neili_global) 			
			wait.make(function()
				_f=function()
					openclass("mp_mj_pre")
					alias.flytoid(596)  --改成飞到吴劲草打坐,杨逍处有yudi打坐会死
				end
				wait.time(2);_f()
			end)	

		elseif me.menpai=="th" then 
			wait.make(function()
				_f=function()
					alias.dz(set_neili_global)
				end
				wait.time(2);_f()
			end)
			if yp.goto==0 and mpJobLimited==0 and workflow.mp>0 then alias.close_fj();openclass("mp_th_pre") end
		
		else
			alias.dz(set_neili_global) 
		end
		
	end
end
_tb={"数码世界，数字地图，(\\d+)就是这里！",}
maketri("fj_pre_dosth",_tb,"fj_pre",_ft)
local function _ft(n,l,w)
	local _f,a,b,c,d,e,f,_tb
	if not isopen("boat") then
		alias.resetidle()
		alias.close_dz()
		closeclass("fj_pre")
		openclass("fj_start")
		fjarrived=0
		print("fj准备结束")
		wait.make(function()
			_f=function() alias.startworkflow() end
			wait.time(2);_f()
		end)
	end
end
_tb={"你目前还没有任何为 dazuo=over 的变量设定。","战斗中不能练内功，会走火入魔。",}
maketri("fj_pre_dosth",_tb,"fj_pre",_ft)
local function _ft(n,l,w)
	if hp.neili>hp.maxneili*set_neili_job/100 and not isopen("boat") and havefj>0 and fjroom~=nil and string.len(fjroom)>0 then 
		alias.tdz()
	end
end
_tb={"你运功完毕，深深吸了口气，站了起来。",}
maketri("fj_pre_dosth",_tb,"fj_pre",_ft)
closeclass("fj_pre")
------------------------------------------------------------------------------------
-- fj_start
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	havenot_luohanzhen=1
	alias.flytoid(me.fjbaseid)
end
_tb={"壮年僧人说道：这位施主请回罢，本寺不接待俗人。","壮年僧人说道：这位女施主还是请回罢，本寺从不接待女客。","刀尖对准你的胸口，横眉怒目地说道：你等邪魔外道，还不给我滚开！",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	alias.resetidle()
	stat.leidong=0		--pfm leidong重置
	stat.jingang=0		--pfm jingang重置	
	stat.qiankun=0		--pfm qiankun重置
	_tb=Split(fjpfm,"|")
	run("halt")
	if me.menpai=="xs" then run("yun daoqi") end
	if fjweapon~=nil and string.len(fjweapon)>0 and (not findstring(_tb[pfmid],"leidong") or not findstring(_tb[pfmid],"jingang")) then	--设置了fj武器，wield武器
		if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
	end
	if fjjf~=nil and fjjf~="" then
		alias.jf(fjjf)
	end
	_tb=Split(fjyun,"|")
	for k,v in ipairs(_tb) do run(v) end	--先运内功
	if hp.qi<(hp.maxqi*90/100) then run("yun recover") end		--后吸气
	killname=me.fjnpcname
	killskill=fjweapon
	killpfm=fjpfm
	killyun=fjyun
	killjiali=fjjiali
	killjiajin=fjjiajin
	run("jiali "..killjiali..";jiajin "..killjiajin)	
	if fjarrived>0 then		-- 找到目标，设定当前为fj地点，死后回来捡东西，同时停止搜索
		fjroomid=tonumber(roomno_now)
		fj.roomno=tonumber(roomno_now)
		escape=alias.SafeEntrance(roomno_now)
		looknpc=1
		if fj_select_npc~=nil and fj_select_npc==0 then print("不挑FJ NPC,通杀") else run("set checklooknpc=yes") end
		if tonumber(roomno_now)==1529 or tonumber(roomno_now)==1530 then  -- 少林寺的两个山路出口一定会变化，返回需要特殊处理
			escape_err=1
		else escape_err=0
		end
	else-- 出现未到达FJ搜索起始区域，但路过的地点是FJ地点情况，不设置fjroomid，等flytonext搜索到
		if fjweapon~=nil and string.len(fjweapon)>0 then	--判断fj weapon装备情况
			if jifa.forcename=="zixia-gong" then	--把上行门派判断，换成激发内功判断，因为其他门派也会有可能用紫霞功和雷动
				_tb=Split(fjpfm,"|")
				if findstring(_tb[pfmid],"leidong") or findstring(_tb[pfmid],"jingang") then
					alias.uw()
					if me.master=="风清扬" and fjweapon=="jian" then run("jifa dodge dugu-jiujian") else run("jifa parry pishi-poyu") end
				else
					if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
					wieldweapon=1
					if me.master=="风清扬" and fjweapon=="jian" then run("jifa dodge dugu-jiujian")
					else
						if fjweapon=="jian" then run("jifa parry huashan-jianfa")
						else
							if fjweapon=="staff" or fjweapon=="qin" then run("jifa parry jinhua-zhang") end
						end
					end
				end
			else
				if fjweapon=="staff" then alias.wi(staffid) else alias.wi(fjweapon) end
			end
		else 
			alias.uw() 
		end
	end
end
_tb={"你察觉四周好像有些不对劲",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local a,b,c,d
	a,b,c,d=string.find(l,"(.+)你(.+)！")
	if c~=nil and d~=nil and findstring(c,"强盗","江湖侠士","魔教弟子","邪派弟子","蒙古哒子") and findstring(d,"可恶，又是你","打了起来","冲了过来","我宰了你","看招") then
		print("fj地点已有fjnpc")
		alias.resetidle()
		alias.close_kill()
		openclass("fj_escape")
		run("halt")
		if me.menpai=="em" then run("persuade "..me.fjnpcid) end
		if always.where=="宝藏岭" then	--房间号1087，fj逃跑特殊处理
			run("wu;e") --此处返回路径需要特殊处理
		else
			run("go "..safego)
		end
		checkmove.notgpsmove=1
		selectRunSuccess=0
		if fjroomid==609 then
			print("防止峨嵋per的强盗导致触发紊乱")
			_tb=Split(me.fjnpcid," ")
			run("doufu ".._tb[1])
		else
			run("doufu "..me.fjnpcid)
		end
	end
end
_tb={"(.+)你(.+)！",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	stat.qiankun=2
end
_tb={"你面色凝重，气贯丹田，单指缓缓戳出，一股内力破空而出，正中.+的.+！",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb
	a,b,c,d=string.find(l,"“受死吧，(.+)！”(.+)大声吼道。")
	if c==me.charname and d==me.fjnpcname then
		alias.resetidle()
		check_battleidle=0
		fjnpc=""
		fj.checknpc=0
		if fjroomid==0 and fjarrived>0 then
			-- 你察觉四周好像有些不对劲.....这句话没有出现，比如九十九道拐找蟒蛇跑很多的情况下，设置当前房间为fj房间
			fjroomid=tonumber(roomno_now)
			fj.roomno=tonumber(roomno_now)
			escape=alias.SafeEntrance(roomno_now)
		end
		fjselectnpc.weapon=1
		if fj_select_npc~=nil and fj_select_npc==0 then --不挑NPC直接杀
			addlog("fj 地点="..fj.room.."|"..fj.zone..",NPC="..fjnpc)
			--  #if @explist.keephour {#add explist.tempinfo %concat( " NPC=", @fj.npc}
			alias.fj_startkill()
		elseif fjroomid==609 then --防止峨嵋per的强盗导致触发紊乱
			_tb=Split(me.fjnpcid," ")
			run("look ".._tb[1])
		else 
			run("look "..me.fjnpcid)
		end 
		alias.close_gps()
		if fjarrived==0 then
			print("路过的地方出现fjnpc，杀完后需要重新look地点定位")
			checkmove.NotGPSMove=1
		end
	end
end
_tb={"“受死吧，.+！”.+大声吼道。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if check_battleidle~=nil and check_battleidle<=180 then alias.resetidle() end
	alias.close_kill()
	if (hp.healthqi<90 or hp.neili<(hp.maxneili*set_neili_job/100)) and stat.qiankun<2 then
		print("健康状态不好，不杀")
		openclass("fj_escape")
		run("halt")
		if me.menpai=="em" then run("persuade "..me.fjnpcid) end
		--run("go "..escape)
		if always.where=="宝藏岭" then	--房间号1087，fj逃跑特殊处理
			run("wu;e") --此处返回路径需要特殊处理
		else
			run("go "..safego)
		end
		checkmove.notgpsmove=1
		selectRunSuccess=0
		if fjroomid==609 then
			print("防止峨嵋per的强盗导致触发紊乱")
			_tb=Split(me.fjnpcid," ")
			run("doufu ".._tb[1])
		else
			run("doufu "..me.fjnpcid)
		end
	else
		if fj_select_npc~=nil and fj_select_npc==0 then fjnpc="Unscreened" else fjnpc=fjselectnpc.menpai.." "..case_weapon(fjselectnpc.weapon) end --log用
		--#if @debug {#say NPC=@fj.npc，%if( selectfjnpc(, 杀, 不杀)}
		if selectfjnpc()>0 or stat.qiankun==2 then
			addlog("fj 地点="..fj.room.."|"..fj.zone..",NPC="..fjnpc)
			alias.fj_startkill()
		else
			print("点子不对啊~~")
			openclass("fj_escape")
			run("halt")
			if me.menpai=="em" then run("persuade "..me.fjnpcid) end
			--run("go "..escape)
			if always.where=="宝藏岭" then	--房间号1087，fj逃跑特殊处理
				run("wu;e") --此处返回路径需要特殊处理
			else
				run("go "..safego)
			end
			checkmove.notgpsmove=1
			selectRunSuccess=0
			if fjroomid==609 then
				print("防止峨嵋per的强盗导致触发紊乱")
				_tb=Split(me.fjnpcid," ")
				run("doufu ".._tb[1])
			else
				run("doufu "..me.fjnpcid)
			end
		end
	end
end
_tb={"你目前还没有任何为 checkmenpai=yes 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"(.+)弟子 (.+)%(.+%)$")
		if c~=nil and d~=nil and d==me.fjnpcname then
			if findstring(c,"大理段家") then fjselectnpc.menpai="dl" end
			if findstring(c,"全真教") then fjselectnpc.menpai="qz" end
			if findstring(c,"武当派") then fjselectnpc.menpai="wd" end
			if findstring(c,"少林派") then fjselectnpc.menpai="sl" end
			if findstring(c,"桃花岛") then fjselectnpc.menpai="th" end
			if findstring(c,"峨嵋派") then fjselectnpc.menpai="em" end
			if findstring(c,"华山派") then fjselectnpc.menpai="hs" end
			if findstring(c,"星宿派") then fjselectnpc.menpai="xx" end
			if findstring(c,"白驼山") then fjselectnpc.menpai="bt" end
			if findstring(c,"雪山派") then fjselectnpc.menpai="xs" end
			if findstring(c,"密宗") then fjselectnpc.menpai="xs" end
			if findstring(c,"丐帮") then fjselectnpc.menpai="gb" end
		end
end
_tb={"(.+)弟子 (.+)\\(.+\\)",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"浮云朵朵飘，飘到了 (%d+) 个『.+』中的第 (%d+) 个～～")
	wait.make(function()
	if c~=nil and d~=nil and tonumber(c)==tonumber(flytosum) and tonumber(d)==tonumber(flytoidx) then
		alias.resetidle()
		fjarrived=1
		killstart=0
		if me.menpai=="mj" then run("shoutfighter fighter") end
		if fjroomid~=nil and fjroomid>0 then
			fjroomid=tonumber(roomno_now)
			fj.roomno=tonumber(roomno_now)
			escape=alias.SafeEntrance(roomno_now)
		end
		_f=function()
			if fjroomid==0 then
				if flytoidx==flytosum then
					-- 最后一个房间也没找到fjnpc时从第一个开始走过
					alias.checkbusy("refly")
				else 
					alias.checkbusy("flytonext") 
				end
			end
		end
		wait.time(4);_f()
	end
	end)
end
_tb={"浮云朵朵飘，飘到了 (\\d+) 个『.+』中的第 (\\d+) 个～～",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
			alias.resetidle()
			fjarrived=1
			killstart=0
			fjroomid=tonumber(roomno_now)
			fj.roomno=tonumber(roomno_now)
			escape=alias.SafeEntrance(roomno_now)
			if me.menpai=="mj" then run("shoutfighter fighter") end
end
_tb={"你口念咒语『神马都是浮云,虾米都是尘土』，『.+』立马到达！",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"□(.+)%(.+%)")
	--print(l)
		if c~=nil then
			if not findstring(c,"皮背心") then
				if findstring(c,"剑") then fjselectnpc.weapon=2 end
				if findstring(c,"箫") then fjselectnpc.weapon=3 end
				if findstring(c,"刀") then fjselectnpc.weapon=4 end
				if findstring(c,"棒") then fjselectnpc.weapon=5 end
				if findstring(c,"轮") then fjselectnpc.weapon=6 end
				if findstring(c,"杖") then fjselectnpc.weapon=7 end
				if findstring(c,"鞭") then fjselectnpc.weapon=8 end
			end
			--print("门派"..fjselectnpc.menpai.." 武器"..fjselectnpc.weapon)
			if tonumber(fj.checknpc)==0 then
			if findstring(fjpfm,"qiankun") and not (fjselectnpc.menpai=="xx" and tonumber(fjselectnpc.weapon)==1) and not (fjselectnpc.menpai=="bt" and tonumber(fjselectnpc.weapon)==7) then 
				alias.uw()
				run("kill "..me.fjnpcid..";perform qiankun "..me.fjnpcid..";set checkmenpai=yes") 
			else
				run("set checkmenpai=yes")
			end
			fj.checknpc=fj.checknpc+1
			end
		end
end
_tb={"\\s+□(.+)\\(.+\\)",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
		fjfinished=1
		check_battleidle=0
		run("get gold from corpse;drop beixin;get beixin from corpse;wear all")
		if stat.use_jinhua then run("get jinhua") end
		if me.menpai=="mj" then run("order fighter do halt;order fighter 2 do halt;wavefighter fighter 2;wavefighter fighter") end
		fjzone=""
		fjroom=""
		fjarea=""
		fjroomid=0
		alias.yjl()
		if me.menpai=="xx" then 
			openclass("fj_other")
			alias.flytoid(1334) 
		elseif me.menpai=="th" then 
			if (yp.goto>0 or yp.stay_room>0) and workflow.mp>0 then
				alias.close_fj()
				workflow.nowjob="mp"
				closeclass("mp_th_start")
				openclass("mp_th_pre")
				--alias.flytoid(yp.goto)
				alias.dz(set_neili_job)
			else
				run("cun all")
				alias.flytoid(me.fjbaseid) 
			end
		elseif ybLimited==0 and ybjob.waitlimit>0 then
			alias.startyb()
		else 
			alias.flytoid(me.fjbaseid) 
		end
end
_tb={"你目前还没有任何为 killover=yes 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
		if c~=nil and tonumber(c)==me.fjbaseid then
			alias.resetidle()
			if havenot_luohanzhen>0 then
				havenot_luohanzhen=0
				run("halt;ask "..me.fjmasterid.." about 要事在身;ask "..me.fjmasterid.." about 门派任务") 
				havefj=0
				alias.startworkflow()
				return
			end
			--if me.menpai=="mj" then run("order fighter do halt;wavefighter fighter;order fighter do halt;wavefighter fighter") end
			if fjfinished==1 and fjroomid==0 then run("set checkfj=over") end--修正此处，会因发呆提前触发set checkfj=over，从而导致战斗时发呆被打死，加入了fj完成状态的判断
			checkfjover=0
			--print("test fj is over")
			return
		end
		if c~=nil and tonumber(c)==fjroomid then
			alias.resetidle()
			fjarrived=1
			fjroomid=tonumber(roomno_now)
			fj.roomno=tonumber(roomno_now)
			escape=alias.SafeEntrance(roomno_now)
			--if me.menpai=="mj" then run("shoutfighter fighter") end
		end
end
_tb={"数码世界，数字地图，(\\d+)就是这里！",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f,_t
	alias.resetidle()
	if gxd.type==1 then
		if me.menpai=="hs" and me.master~="风清扬" then run("nick $HIM$非风$HIW$不放弃MUSH：$HIR$"..gxd.me) end
	elseif gxd.type==2 then
		--if gxd.me==nil then gxd.me=0 end
		if gxd.me>gxd.value then
			if me.menpai=="hs" and me.master~="风清扬" then run("nick $HIM$非风$HIW$固定MUSH：$HIR$"..gxd.me) end
			_t=fangqivalue()
			if _t>0 then
				for i=1,_t,1 do
					run("h;ask "..me.fjmasterid.." about 要事在身;ask "..me.fjmasterid.." about 门派任务")
				end
				gxd.me=gxd.me-10*_t
			end
		end
	elseif gxd.type==3 then
		if gxd.me==nil then gxd.me=0 end
		if gxd.mp==nil then gxd.mp=100000 end
		if gxd.me>(gxd.mp*gxd.percent/100) then
			if me.menpai=="hs" and me.master~="风清扬" then run("nick $HIM$非风$HIW$保持MUSH：$HIR$"..gxd.percent.."%$HIW$值为$HIR$"..gxd.me) end
			_t=fangqipercent()
			if _t>0 then
				for i=1,_t,1 do
					run("h;ask "..me.fjmasterid.." about 要事在身;ask "..me.fjmasterid.." about 门派任务")
				end
				gxd.me=gxd.me-10*_t
			end					
		end
	end
	--if me.menpai=="mj" and hp.pot<hp.maxpot then run("ask yang xiao about 奖励") end
	if me.menpai=="th" then run("cun "..tonumber(hp.pot-1)..";taohua");yp.goto=0 end
	alias.checkexp("fj")
end
_tb={"你目前还没有任何为 checkgxd=yes 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	if war.open>0 then run("nick exp:"..hp.exp) end
	if me.menpai=="sl" then
		openclass("fj_other")
		alias.flytonpc("道象")
	elseif me.menpai=="bt" then
		if mpJobLimited>0 and ((add.exp-fjexp)>10 or mpLimited.mpexp<me.menpaiLimited) then		-- 说明bite or xy未满
			mpJobLimited=0
			xy.xyLimited=0
			xy.biteLimited=0
			if xy.limitedResume>=5 then xy.limitedResume=xy.limitedResume-1 end
		end
	elseif me.menpai=="mj" then 
		if skillslist["qianzhu-wandu"]~=nil and skillslist["qianzhu-wandu"]["lvl"]~=nil then
			print("带有千蛛毒气，不能Ask force~")
		elseif skillslist[jifa["forcename"]]["lvl"] ~= nil and skillslist[jifa["forcename"]]["lvl"] >= me.maxlvl then
			print("内功满了，不能Ask force~")
		elseif mj.haveyd==0 and mj.lvl==5 and hp.pot>hp.maxpot*0.5 then
			_tb=math.floor((hp.pot-hp.maxpot*0.5)/10)
			if _tb>10 then _tb=10 end
			if _tb>1 then alias.loop(_tb,"ask yang xiao about force") end
		else
			print("暂不Ask force")
		end
	elseif me.menpai=="th" and yp.killed>0 and roomno_now==1470 and always.where=="书房" and workflow.mp>0 then
		yp.killed=0
		run("ask lu chengfeng about yapu")
	end
	alias.startworkflow()
end
_tb={"你目前还没有任何为 checkexpover=fj 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if havefj>0 then alias.flytonext() else alias.startworkflow() end
end
_tb={"你目前还没有任何为 busyover=flytonext 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
			-- 等待获取任务完成经验
			wait.make(function()
			_f=function() 
				if havefj>0 then 
					if checkfjover<10 then 
						run("set checkfj=over");checkfjover=checkfjover+1 
					else 
						checkfjover=0;alias.startfj() 
					end 
				else 
					fjfinished=0
					if me.menpai=="th" and workflow.fj>0 and workflow.mp==0 and workflow.yb==0 and fjfinished==0 and xuefirst>0 and hp.thpot<math.abs(hp.maxpot-50) and hp.pot<10 then run("ask "..me.fjmasterid.." about 门派任务") end
					if gxd.type>1 then run("ask "..me.fjmasterid.." about 贡献度") end
					run("hp;set checkgxd=yes") 
				end 
			end
			wait.time(1);_f()
			end)
end
_tb={"你目前还没有任何为 checkfj=over 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
			if killstart==0 then
				_f=function() run("set checkmenpai=yes") end
				wait.time(2);_f()
			end
			killaction=""
	end)
end
_tb={"你目前还没有任何为 checkkillstart=yes 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if havefj>0 then alias.flytoname(fjroom,fjzone) else alias.startworkflow() end
end
_tb={"你目前还没有任何为 busyover=refly 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
			if looknpc==nil or looknpc==0 then
				-- 错过fj地点，从第一个开始走过
				alias.checkbusy("refly")
			end
		
end
_tb={"你目前还没有任何为 checklooknpc=yes 的变量设定。",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
			if not isopen("fj_escape") then
				looknpc=0
				print("网络卡，出npc的房间已经飞过了")
			end
		
end
_tb={"你要看什么？",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"你对著(.+)喝道：「.+」")
		if c~=nil and c==me.fjnpcname then
			killstart=1
		end
end
_tb={"你对著(.+)喝道：「.+」",}
maketri("fj_start_dosth",_tb,"fj_start",_ft)
closeclass("fj_start")

------------------------------------------------------------------------------------
-- fj_escape
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	alias.close_kill()
	selectRunSuccess=1
	checkmove.notgpsmove=1
	alias.checkbusy("escape")
	print("逃跑成功！")
end
_tb={"你身行向后一跃，跳出战圈不打了。\\n.+ \\-.*\\Z",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft,2)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
	a,b,c=string.find(l,"你在(.+)的耳边悄声说道：你不是我的菜！")
	if c~=nil and c==me.fjnpcname then
		alias.resetidle()
		if escape_err>0 then
			run("look;set resetSafe=yes")
			escape_err=0
		else
			_f=function() run("halt;go "..safego..";whisper "..me.fjnpcid.." 你不是我的菜！") end
			wait.time(0.2);_f()
		end
	end
	end)
end
_tb={"你在(.+)的耳边悄声说道：你不是我的菜！",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if selectRunSuccess==nil or selectRunSuccess==0 then
		alias.resetidle()
		alias.close_kill()
		alias.checkbusy("escape")
		print("逃跑成功！")
	end
end
_tb={"你要对谁做 doufu 这个动作？",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	if jifa.forcename=="motian-yunqi" then run("yun shougong") end
	closeclass("fj_pre")
	alias.dz(set_neili_job)
end
_tb={"你目前还没有任何为 busyover=escape 的变量设定。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
	if not isopen("boat") then
		alias.resetidle()
		_f=function()
			fjnpcleave=1
			lookgag=1
			--run("look "..tostring(invDirection(escape))..";set checknpcleave=yes")
			run("look "..tostring(invDirection(safego))..";set checknpcleave=yes")
		end
		wait.time(1);_f()
	end
	end)
end
_tb={"你目前还没有任何为 dazuo=over 的变量设定。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"%s+(.+)正在修炼内力。$")
		if c~=nil and string.find(c,me.fjnpcname) then
			fjnpcleave=0
			alias.resetidle()
		end
end
_tb={"\\s+(.+)正在修炼内力。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"%s+(.+)正在运功疗伤。$")
	if c~=nil and c==me.fjnpcname then
		fjnpcleave=0
		alias.resetidle()
	end
end
_tb={"\\s+(.+)正在运功疗伤。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"%s+.+弟子 (.+)%(.+%)")
	if c~=nil and c==me.fjnpcname then
		fjnpcleave=0
		alias.resetidle()
	end
end
_tb={"\\s+.+弟子 (.+)\\(.+\\)$",
	 "\\s+.+弟子 (.+)\\(.+\\) <昏迷不醒>$",
	 "\\s+.+弟子 (.+)\\(.+\\) <战斗中>$"
}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	wait.make(function()
	if escape_err~=nil and escape_err>0 then
		-- 出口发生改变，使用flytoid
		closeclass("fj_escape")
		_f=function()
			alias.flytoid(fjroomid)
			fjroomid=0
			escape_err=0
		end
		wait.time(10);_f()
	else
		if fjnpcleave>0 then
			run("halt")
			escapeback_err=0
			run("go "..invDirection(safego)..";set check=escapeback")
		else
			_f=function()
				fjnpcleave=1
				lookgag=1
				run("look "..invDirection(safego)..";set checknpcleave=yes")
			end
			wait.time(0.5);_f()
		end
	end
	end)
end
_tb={"你目前还没有任何为 checknpcleave=yes 的变量设定。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	escape_err=1
end
_tb={"你要看什么？","你要往哪个方向走？","这个方向没有出路。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.tdz()
end
_tb={"这里空气不好，不能打坐。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
	alias.resetidle()
	_f=function() alias.dz(set_neili_job) end
	wait.time(1);_f()
	end)
end
_tb={"战斗中不能练内功，会走火入魔。","你吐气纳息，硬生生地将内息压了下去，缓缓站了起来。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"%s+这里[唯一|明显]+的出口是 (.+)。$")
	if c~=nil then
		entrance=c
		xkxGPS.setEntrance(entrance)
		if lookgag~=nil and lookgag>0 then
			lookgag=0
		end
	end
end
_tb={"\\s+这里.{4}的出口是 (.+)。$",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	if selectRunSuccess==nil or selectRunSuccess==0 then
		_tb=Split(xkxGPS.entrance,"|")
		safego=_tb[math.random(#_tb)]
		SafeBack=invDirection(safego)
		run("halt;go "..safego)
		if tonumber(fjroomid)==609 then
			print("防止峨嵋per的强盗导致触发紊乱")
			_tb=Split(me.fjnpcid," ")
			run("doufu ".._tb[1])
		else
			run("doufu "..me.fjnpcid)
		end
	end
end
_tb={"你目前还没有任何为 resetSafe=yes 的变量设定。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	escapeback_err=1
end
_tb={"糟糕，你逃跑失败了！","你的动作还没有完成，不能移动。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
	if escapeback_err~=nil and escapeback_err>0 then
		_f=function()
			run("halt")
			escapeback_err=0
			--run("go "..invDirection(escape)..";set check=escapeback")
			run("go "..invDirection(safego)..";set check=escapeback")
		end
		wait.time(0.5);_f()
	else
		alias.resetidle()
		closeclass("fj_escape")
	end
	end)
end
_tb={"你目前还没有任何为 check=escapeback 的变量设定。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	run("giveup")
	escapeback_err=1
end
_tb={"少林弟子岂可贪生怕死，以坠本派声名！",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
		a,b,c=string.find(l,"你深情地对(.+)唱道：走千山万里路，读千册万卷书，都不如靠近吃你两块豆腐！")
		if c~=nil and c==me.fjnpcname then
			alias.resetidle()
			if escape_err~=nil and escape_err>0 then
				run("look;set resetSafe=yes")
				escape_err=0
			else
				if selectRunSuccess~=nil and selectRunSuccess>0 then
					print("逃离地点有同样的FJ NPC，不再处理逃跑")
				else
					_f=function()
						--run("halt;go "..escape)
						run("halt;go "..safego)
						if tonumber(fjroomid)==609 then
							print("防止峨嵋per的强盗导致触发紊乱")
							_tb=Split(me.fjnpcid," ")
							run("doufu ".._tb[1])
						else
							run("doufu "..me.fjnpcid)
						end
					end
					wait.time(0.2);_f()
				end
			end
		end
	end)
end
_tb={"你深情地对.+唱道：走千山万里路，读千册万卷书，都不如靠近吃你两块豆腐！",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	wait.make(function()
	closeclass("fj_escape")
	_f=function()
		alias.flytoid(fjroomid)
		fjroomid=0
		escape_err=0
	end
	wait.time(3);_f()
	end)
end
_tb={"忽然一阵腥风袭来，一条巨蟒从身旁大树上悬下，把你卷走了。",}
maketri("fj_escape_dosth",_tb,"fj_escape",_ft)

closeclass("fj_escape")
------------------------------------------------------------------------------------
-- fj_other
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	run("ask chanshi about 大还丹")
end
_tb={"有一天，你踩着七色云彩来迎娶『道象』",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	if me.master=="丁春秋" then
	run("buy liuhuang;put liuhuang in di")
	end
	alias.flytoid(me.fjbaseid)
end
_tb={"数码世界，数字地图，1334就是这里！",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.checkbusy("putizi")
end
_tb={"有一天，你踩着七色云彩来迎娶『渡难』",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	run("ask nan about 菩提子")
end
_tb={"你目前还没有任何为 busyover=putizi 的变量设定。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	run("fu zi")
	resetidle=0
end
_tb={"渡难惨然一笑，接著长叹一声，从树洞里取出个白玉磁瓶，倒出菩提子递给你。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f,_tmp
	wait.make(function()
		_f=function()
			if addneili.putizi==nil then addneili.putizi=0 end
			if mark.neili==nil then mark.neili=0 end
			addneili.putizi=addneili.putizi+(hp.maxneili-mark.neili)
			c=tonumber(hp.maxneili)-tonumber(mark.neili)
			addlog("吃到菩提子，增加最大内力 "..tostring(c).."点")
		end
		wait.time(5);_f()
	end)
end
_tb={"你吃下一颗菩提子，顿然间只觉一股浩荡无比的真气直冲顶门",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	run("hp")
	mark.neili=tonumber(hp.maxneili)
	alias.flytonpc("渡难")
end
_tb={"这里没有 chanshi 这个人。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
_tb={"你向道象禅师打听有关「大还丹」的消息。\\n道象禅师说道：对不起，大还丹已经发完了\\Z",}
maketri("fj_other_dosth",_tb,"fj_other",_ft,2)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	closeclass("fj_other")
	alias.close_gps()
	alias.startworkflow()
end
_tb={"你身上有血腥味，目前不允许进入该房间。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	run("fu dan")
	closeclass("fj_other")
	alias.startworkflow()
end
_tb={"你向道象禅师打听有关「大还丹」的消息。\\n你获得一颗大还丹。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft,2)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	alias.resetidle()
	closeclass("fj_other")
	alias.startworkflow()	
end
_tb={"你向道象禅师打听有关「大还丹」的消息。\\n道象禅师说道：.+你是不是刚吃过药，怎么又来要了？ 灵药多吃有害无宜，过段时间再来吧。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft,2)
_tb={"渡难说道：菩提子乃天地之灵物，采集艰难无比，我这里现在可没有。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)
_tb={"这里没有 nan 这个人。",}
maketri("fj_other_dosth",_tb,"fj_other",_ft)

closeclass("fj_other")
------------------------------------------------------------------------------------
-- fj_watch
------------------------------------------------------------------------------------
maketri_num=1
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"一个.+弟子走了过来,对你报拳道：“在下奉(.+)之命，请你速回.+处晋见”。")
	if c~=nil and c==me.fjmasternick then
		fjwaittime=os.time()-fjend
		print("本次fj间隔时间"..fjwaittime)
		if havefj~=nil and havefj~=1 then havefj=1;looknpc=0 end
		fjzone=""
		fjroom=""
		fjarea=""
		fjroomid=0
		set_neili=tonumber(set_neili_job)
		alias.setstatus()
	end
end
_tb={"一个.+弟子走了过来,对你报拳道：“在下奉(.+)之命，请你速回.+处晋见”。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"[> ]*(.+)已传令要召见你，你还是快点去吧。")
	if c~=nil and c==me.fjmasternick then
		if havefj~=nil and havefj~=1 then havefj=1;looknpc=0 end
		fjzone=""
		fjroom=""
		fjarea=""
		fjroomid=0
		set_neili=tonumber(set_neili_job)
	end
end
_tb={"(.+)已传令要召见你，你还是快点去吧。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	havefj=1
	fjzone=""
	fjroom=""
	fjarea=""
	fjroomid=0
end
_tb={"任务已经完成，赶快回去复命吧。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
		fjend=os.time()
		havefj=0
		fjzone=""
		fjroom=""
		fjarea=""
		fjroomid=0
end
_tb={"唉！你耽误的时间太久了，这次任务取消了。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"[> ]*(.+)已派你去(.+)附近完成重要任务，赶快去执行吧。")
	if c~=nil and d~=nil and c==me.fjmasternick then
		if havefj~=nil and havefj~=1 then havefj=1;looknpc=0 end
		fjarea=d
		alias.fjarea(fjarea)
	end
	
end
_tb={"(.+)已派你去(.+)附近完成重要任务，赶快去执行吧。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d,e=string.find(w[0],".+说道：“(.-)，.+\n(.+)说道:“近日在(.+)附近.*")
	if c~=nil and d~=nil and e~=nil and c==me.charname and d==me.fjmaster then
		if me.menpai=="dl" then alias.count_qiankun() end
		fjroomid=0
		fjarea=e
		alias.fjarea(fjarea)
		if me.menpai=="mj" and always.where=="光明圣火厅" and isopen("fj_start") then 
			--nextJobGodazuobase=1
			--alias.dz(set_neili_global)
			alias.flytonpc("吴劲草")
		end
	end
end
--_tb={"(.+)(对你点了点头|拍了拍你的头|回过头看了你一眼|拍拍你的肩|对你「嘿嘿嘿」奸笑了几声).+说道：“(.+)，.+\\n(.+)说道:“近日在(.+)附近.*\\Z",}
_tb={".+说道：“(.+)，.+\\n.+说道:“近日在(.+)附近.*\\Z",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft,2)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"[> ]*(.+)对你说道：目前我.+的贡献度为(.+)点。")
	if c~=nil and d~=nil and c==me.fjmaster then
		gxd.mp=ctonum(d)
	end
end
_tb={"(.+)对你说道：目前我.+的贡献度为(.+)点。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"[> ]*(.+)对你说道：你为.+所做的贡献为(.+)点。你要继续努力，争取在下次.+大会上得到最佳评定。")
	if c~=nil and d~=nil and c==me.fjmaster then
		gxd.me=ctonum(d)
	end
end
_tb={"(.+)对你说道：你为.+所做的贡献为(.+)点。你要继续努力，争取在下次.+大会上得到最佳评定。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"[> ]*(.+)说道:“辛苦你了，(.+)，你为.+立下了一功。”")
	if c~=nil and d~=nil and c==me.fjmaster and d==me.charname then
		fjend=os.time()
		havefj=0
		set_neili=tonumber(set_neili_global)
	end
end
_tb={"(.+)说道:“辛苦你了，(.+)，你为.+立下了一功。”",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c,d=string.find(l,"[> ]*(.+)说道:“干得好，(.+)，老仙我越来越欣赏你了。”")
	if c~=nil and d~=nil and c==me.fjmaster and d==me.charname then
		fjend=os.time()
		havefj=0
		set_neili=tonumber(set_neili_global)
	end
end
_tb={"(.+)说道:“干得好，(.+)，老仙我越来越欣赏你了。”",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
local function _ft(n,l,w)
	local _tb,a,b,c,d,_f
	a,b,c=string.find(l,"你的经验上升了(%d+)点。")
	if c~=nil then
		fjexp=tonumber(c)
	end
end
_tb={"你的经验上升了(\\d+)点。",}
maketri("fj_watch_dosth",_tb,"fj_watch",_ft)
openclass("fj_watch")
