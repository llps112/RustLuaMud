function zjd_buylist()
	aoyao={
		yaoName="紫金通脉丹",
		yaoid="dan",
		buyNameList="老山参|鹿茸|麝香|雪莲|茯苓",
		buyidList="lao shanshen|lurong|shexiang|xuelian|fuling",
		buyno=1,
		needgold=401,
	}
end
zjd_buylist()
------------------------------------------------------------------------------------
-- login
------------------------------------------------------------------------------------
function login.dosomething1(n,l,w)
	local _f,a,b,c
		if findstring(l,"你目前还没有任何为 check=jifa 的变量设定。") then
			if setting~="dm" and setting~="keep" then
				if me.menpai=="em" then run("put fuling in yaodai")
				elseif me.menpai=="bt" then run("put fuling in yaodai;convert she")
				elseif me.menpai=="dl" or me.menpai=="mj" then run("drop pao")
				elseif me.menpai=="th" then run("drop robe")
				elseif me.menpai=="xs" and tonumber(roomno_now)==439 then openclass("mp_xs_npc1");alias.startlianwu() 
				elseif me.menpai=="xx" then alias.flytoid(1282) 
				else print("重连检查结束")
				end
			end
			run("drop cloth")
			run("wear all")
			alias.startworkflow()
		end
		if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
			alias.startworkflow()
		end
		a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
		if c~=nil then
			alias.resetidle()
			if tonumber(c)==1282 then
				run("mo bi")
				--if workflow.fj>0 and me.menpai~="gm" then alias.flytoid(me.fjbaseid) else alias.startworkflow() end
				if workflow.fj>0 and me.menpai~="gm" then alias.flytoid(me.fjbaseid) else alias.checkitems() end
			elseif tonumber(c)==me.fjbaseid then
				run("h;ask "..me.fjmasterid.." about 门派任务")
				alias.startworkflow()
			end
		end
		if findstring(l,"您要将另一个连线中的相同人物赶出去，取而代之吗？") then
			if accessing>0 then accessing=0;login.time=os.time() end
		end		
		if findstring(l,"您目前的权限是：","重新连线完毕。","从您上次退出到现在，侠客行没有任何官方新闻。") then
			if accessing>0 then 
			accessing=0
			allcmd={}
			if me.menpai=="gb" then run("get all from dai") end
			alias.gg()
			--alias.ch()
			run("score;cha;jifa;hp")
			if setting_resetidle>0 then run("set check=jifa") end
			login.time=os.time()
			end
		end				
		if findstring(l,"请您输入密码") then
			Execute(me.pwd)
			Execute("yes")
			--run(me.pwd..";yes")
		end
		if findstring(l,"对不起，由於连接过於频繁，你的地址被暂时封锁。") then
			Disconnect()
		end
	--end)
end
------------------------------------------------------------------------------------
-- aoyao
------------------------------------------------------------------------------------
function aoyao.dosomething1(n,l,w)
	local _f,_tb
	if findstring(l,"药炉下正燃着火。") then
		aoyao.fire=1
	end
	if findstring(l,".+深吸一口气，停了下来。") then
		alias.resetidle()
		DeleteTimer("aoyao_timer")
		alias.checkbusy("miehuo")
	end
	if findstring(l,"炭火渐渐明亮，看来可以开始了。") then
		alias.resetidle()
		run("aoyao;unset brief")
	end
	if findstring(l,".+将炭火熄灭。") then
		aoyao.fire=0
	end
	if findstring(l,"你熬这么多药干吗？") then
		alias.resetidle()
		run("set aoyao=false")
		closeclass("close_aoyao")
	end
	if findstring(l,"你开炉一看，炉中之物象一团浆糊一样，看来没什么用。","你取出药材一看，已经烧成一团焦炭。") then
		alias.checkbusy("false")
	end
	if findstring(l,"哟，抱歉啊，我这儿正忙着呢……您请稍候。") then
		alias.resetidle()
		wait.make(function()
			_f=function()
				_tb=Split(aoyao.buyidList)
				run("buy ".._tb[aoyao.buyno])
			end
			wait.time(1)
			_f()
		end)
	end
	if findstring(l,"这里没有 wang tongzhi 这个人。") then
		run("set aoyao=flase")
		alias.close_aoyao()
	end
	if findstring(l,"你打开了自己的谣言频道。") then
		run("tune rumor")
	end
	if findstring(l,"你目前还没有任何为 busyover=false 的变量设定。") then
		_tb=Split(aoyao.buyidList,"|")
		for k,v in ipairs(_tb) do
			run("drop "..v)
		end
		run("set aoyao=false")
		alias.close_aoyao()
	end
	if findstring(l,"你目前还没有任何为 busyover=miehuo 的变量设定。") then
		alias.resetidle()
		run("mie huo;open lip;qu yao")
	end
	if findstring(l,"你目前还没有任何为 busyover=quyao 的变量设定。") then
		run("set aoyao=true")
		if pxj_needget_yyc>0 then run("eat buyin wan") end
		pxj_needget_yyc=0
		alias.close_aoyao()
		alias.startworkflow()
	end
	if findstring(l,"你目前还没有任何为 checkfire=yes 的变量设定。") then
		alias.resetidle()
		if aoyao.fire>0 then
			wait.make(function()
				_f=function()
					run("look lu;set checkfire=yes")
					aoyao.fire=0
				end
				wait.time(1);_f()
			end)
		else
			run("open lip")
			_tb=Split(aoyao.buyidList,"|")
			for k,v in ipairs(_tb) do
				run("add "..v.." in lu")
			end
			run("pour water;close lip;burn coal")
			AddTimer("aoyao_timer", 0, 0, 5, "", timer_flag.Enabled + timer_flag.Replace, "alias.resetidle")
			SetTimerOption("aoyao_timer", "group", "aoyao")
		end
	end
	if findstring(l,"你向王通治打听有关「你妈可好？」的消息。") then
		alias.resetidle()
		_tb=Split(aoyao.buyidList,"|")
		run("buy ".._tb[aoyao.buyno])
	end
	if findstring(l,"数码世界，数字地图，[6|2057]就是这里！") then
		alias.resetidle()
		run("look lu;set checkfire=yes")
		aoyao.fire=0
	end
	if findstring(l,"有一天，你踩着七色云彩来迎娶『王通治』") then
		alias.resetidle()
		run("ask wang tongzhi about 你妈可好？")
	end
	if findstring(l,"你从药炉中取出一.+") then
		--if w[3]==aoyao.yaoName then alias.checkbusy("quyao") end
		alias.checkbusy("quyao")
	end
	if findstring(l,"你从王通治那里买下了一") then
		_tb=Split(aoyao.buyNameList,"|")
		if w[4]==_tb[aoyao.buyno] then
			aoyao.buyno=aoyao.buyno+1
			_tb=Split(aoyao.buyidList,"|")
			if aoyao.buyno<=#_tb then
				wait.make(function()
					_f=function() run("buy ".._tb[aoyao.buyno]) end
					wait.time(1);_f()
				end)
			else
				if aoyao.address=="wai" then
					aoyao.address="nei"
					alias.flytoid(2057)
				else
					aoyao.address="wai"
					alias.flytoid(6)
				end
			end
		end
	end
	if findstring(l,"你把一棵阴阳草放进药炉。") then
		yinyangcao_num=yinyangcao_num-1
	end
	if findstring(l,"你把一钱葵花粉放进药炉。") then
		kuihuafen_num=kuihuafen_num-1
	end
	if findstring(l,"你把一钱无花果放进药炉。") then
		wuhuaguo_num=wuhuaguo_num-1
	end
end
------------------------------------------------------------------------------------
-- bidu
------------------------------------------------------------------------------------
function bidu.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=bidu 的变量设定。") then run("hp;yun bidu") end
	if findstring(l,"你闭目而坐，急呼缓吸，过了一顿饭工夫，脸色略复红润。","你无法在战斗中运功疗毒") then 
		alias.checkbusy("bidu") 
	end
	if findstring(l,"你运功一阵，祗感神困力疲，没料到体内.+毒如此厉害，竟然驱之不出。") then 
		closeclass("bidu")
		openclass("liaoshang")
		if me.menpai=="th" then for i=1,3,1 do run("fu qingxin san") end end
		alias.flytonpc("何红药")
	end
	if findstring(l,"你并未中毒") then
		closeclass("bidu")
		stat.havedu=0
		alias.startworkflow()
		--Execute("/alias.start"..workflow.nowjob.."()")
	end
end
------------------------------------------------------------------------------------
-- xuan
------------------------------------------------------------------------------------
function xuan.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=xuan 的变量设定。") then run("hp;yun xuan") end
	if findstring(l,"不久，你头顶散发出一阵似气似烟的白雾，久久不能散去，接着“哇”的一声吐出一口绿水！","你刚刚催动「玄阴真气」玄真气强行将内伤压制，如在强行压制，只怕会当场倒毙！","你并非性命垂危，无需催动玄真气救命！") then 
		alias.checkbusy("xuan") 
	end
	if findstring(l,"你的内力不够！","你的内力修为不够！") then 
		closeclass("xuan")
		openclass("liaoshang")
		stat.havedu=1
		alias.flytonpc("何红药")
	end
	if findstring(l,"你并未中寒冰毒！") then
		closeclass("xuan")
		stat.havehbdu=0
		alias.startworkflow()
	end
end
------------------------------------------------------------------------------------
-- cure
------------------------------------------------------------------------------------
function cure.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=cure 的变量设定。") then run("hp;yun cure") end
	if findstring(l,"你所学的内功中没有这种功能。","你现在不须要疗精！") then
		closeclass("cure")
		stat.havedu=0
		--alias.startworkflow()
		alias.dz(set_neili_job)
	end
	if findstring(l,"你在身上划一道伤口，挤出一些淤血，气沉丹田，开始凝神疗精。") then
		wait.make(function()
			local _f=function() run("yun cure") end
			wait.time(0.5);_f()
		end)
	end
end
------------------------------------------------------------------------------------
-- boat
------------------------------------------------------------------------------------
function boat.dosomething1(n,l,w)
	local _f,a,b,c
	wait.make(function()
		if findstring(l,"说“到啦，上岸吧”，随即把一块踏脚板搭上堤岸。","船夫扳桨划船，在湖中行了数里，缓缓停泊在岸边，将一块踏脚板搭上了堤岸。") then
			alias.resetidle()
			boatDirection="out"
			alias.tt()
			run("halt")
			alias.trymove(boatDirection)
		end
		if findstring(l,"练内功要有间隙，太劳累会走火入魔的。","你现在身体状况太差了，无法集中精神！") then
		--	wait.make(function()
			if tunanum>0 then
				_f=function() run("tuna "..tunanum) end
				wait.time(1);_f()
			end
		--	end)
		end
		if findstring(l,"你的内力不够，无法施展一苇渡江绝技！") then
			alias.resetidle()
		--	wait.make(function()
			if me.menpai=="sl" then
				_f=function() run("yun du") end
				wait.time(2);_f()
			end
		--	end)
		end
		if findstring(l,"你刚刚压制住身上伤势，还是不要妄动真气。") then
			alias.resetidle()
			yunbusy=1
		end
		if findstring(l,"你猛吸几口大气，站了起来。") then
			run("yun regenerate")
		end
		if findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			alias.resetidle()
			--if workflow.nowjob=="xue" and usepot=="lingwu" then closeclass("skills_lingwu") else alias.startlianwu() end
			alias.startlianwu()
		end
		if findstring(l,"你目前还没有任何为 lian=over 的变量设定。") then
			alias.resetidle()
			if tuna~=nil and tonumber(tuna)>0 then
				-- 所有技能练满，吐纳了
				tunanum=math.ceil(tonumber(hp.maxjing/2))
				run("tuna "..tunanum)
			end
		end
		if findstring(l,"松花江化冻了，你喊") then
			alias.resetidle()
			checkyell=1
			if skillslist["shaolin-shenfa"]==nil then skillslist["shaolin-shenfa"]={} end
			if skillslist["shaolin-shenfa"]["lvl"]==nil then skillslist["shaolin-shenfa"]["lvl"]=1 end
			if skillslist["hunyuan-yiqi"]==nil then skillslist["hunyuan-yiqi"]={} end
			if skillslist["hunyuan-yiqi"]["lvl"]==nil then skillslist["hunyuan-yiqi"]["lvl"]=1 end
			if me.menpai=="sl" and me.master=="觉心" and tonumber(skillslist["shaolin-shenfa"]["lvl"])>=200 and tonumber(skillslist["hunyuan-yiqi"]["lvl"])>=160 and tonumber(hp.maxneili)>=2000 and jifa["forcename"]=="hunyuan-yiqi" then run("yun du") else run("yell boat") end
		end
		if findstring(l,"接著你一跃而起，脚尖在苇枝上一点，两袖飘飘，箭一般地在水面上穿了过去。") then
			alias.movefinish()
		end
		if findstring(l,"你目前还没有任何为 boat=out 的变量设定。") then
			alias.resetidle()
			if always.where=="汉水畔" then 
				run("se")
				--print("汉水南岸补偿一个se方向，减少走错路的几率")
			elseif always.where=="码头" then 
				run("w")
				--print("归云庄补偿一个w方向，减少走错路的几率")
			end
			--closeclass("boat")
			alias.close_boat()
			alias.close_dz()
			if workflow.nowjob=="xue" and usepot=="lingwu" then
				openclass("skills_lingwu")
			else
				if _G[workflow.nowjob.."weapon"]~=nil and string.len(_G[workflow.nowjob.."weapon"])>0 then
					alias.wi(_G[workflow.nowjob.."weapon"])
				else
					alias.uw()
				end
			end
			if tunanum~=nil and tunanum>0 then run("yun regenerate") end
			if gps_gyz_go_e_boat==1 then
				run("w")
				gps_gyz_go_e_boat=0
			end
			alias.movefinish()
		end
		if findstring(l,"你目前还没有任何为 boat=enter 的变量设定。") then
			alias.resetidle()
			run("yell boat")
			--if isopen("dazuo") then run("set checkhp="..type_dz)
			if isopen("dazuo") then 
				run("dazuo "..dz())
			else
				if not isopen("skills_lian") then alias.dz(set_neili_global)
				else run("hp;set lian") end
			end
		end
		if findstring(l,"你目前还没有任何为 checkmove=yes 的变量设定。") then
			if trymovesuccess then run("set boat="..boatDirection)
			else
			--	wait.make(function()
				_f=function() run("halt");alias.trymove(boatDirection) end
				wait.time(0.3);_f()
			--	end)
			end
		end
		if findstring(l,"你目前还没有任何为 checkyell=yes 的变量设定。") then
			if checkyell==0 then
				gpserrnum=1
				run("set walk off")
			end
		end
		if findstring(l,"你目前还没有任何为 checkyunbusy=yes 的变量设定。") then
			if yunbusy>0 and me.menpai=="sl" then
				yunbusy=0
				_f=function() run("yun du;set checkyunbusy=yes") end
				wait.time(2);_f()
			end
		end
		if findstring(l,"你鼓足中气，长啸一声：“船家！”","你使出吃奶的力气喊了一声：“船家”","你吸了口气，一声“船家”，声音中正平和地远远传了出去。") then
			alias.resetidle()
			checkyell=1
			openclass("boat_yell")
		end
		if findstring(l,"你见江面结冻，便壮起胆子踩冰而过。") then
			alias.resetidle()
			checkyell=1
			if gps_dmkz_cc==0 then run("e") else run("w") end
			alias.close_boat()
			alias.close_gps_dealwith()
			alias.movefinish()
		end
		if findstring(l,"一叶扁舟缓缓地驶了过来") then
			alias.resetidle()
			openclass("boat_yell")
		end
		if findstring(l,"你的动作还没有完成，不能移动。") then
			trymovesuccess=false
		end
		--[[if findstring(l,"临阵脱逃可是得受军法处置，你还是先帮忙力据蒙古大军吧。") then
			print("来自common的拦截")
			alias.close_fj()
			alias.close_mp()
			alias.startwar() 
			war.waring=1
	    end]]--
	end)
end
------------------------------------------------------------------------------------
-- boat_yell
------------------------------------------------------------------------------------
function boat_yell.dosomething1(n,l,w)
	local _f,a,b,c
	wait.make(function()
		if findstring(l,"湖面上的船家来来往往，一无反应……") then
			alias.resetidle()
			closeclass("boat_yell")
			roomno_now=0
			if gps_gyz_go_e_boat==0 then
				if daytimes>0 then --白天，换个码头继续yell
					run("h;e")
					gps_gyz_go_e_boat=1
				elseif not isopen("skills_lian") then --晚上原地打坐练功
					alias.startlianwu()
				end
				_f=function() run("yell boat") end
				wait.time(0.5);_f()
			else
				run("h;w")
				gps_gyz_go_e_boat=0
				_f=function() run("yell boat") end
				wait.time(0.5);_f()
			end
		end
		if findstring(l,"可是这时侯夜色已深，湖面上的船家大都歇息了，祗有西边的湖岸还有扁舟往返。") then
			alias.resetidle()
			roomno_now=0
			closeclass("boat_yell")
			gps_gyz_go_e_boat=0
			daytimes=0 --
			_f=function() run("w;yell boat") end
		--	DoAfterSpecial(0.5, 'run("w;yell boat")', 12)
			wait.time(0.5);_f()
		end
		a,b,c=string.find(l,"只听得(.+)面上隐隐传来：“别急嘛，这儿正忙着呐……”")
		if c~=nil then
			alias.resetidle()
			closeclass("boat_yell")
			roomno_now=0
			if string.find(c,"湖") then
				if havefj>0 and fjroom=="" and always.where=="码头" and me.menpai=="th" and isopen("mp_th_pre") then
					alias.startfj() 
					print("判断要不要回去拿fj") 
				elseif gps_gyz_go_e_boat==0 then
					if daytimes>0 then --白天，换个码头继续yell
						run("h;e")
						gps_gyz_go_e_boat=1
					elseif not isopen("skills_lian") then --晚上原地打坐练功
						alias.startlianwu()
					end
					_f=function() run("yell boat") end
				--	DoAfterSpecial(0.5, 'run("yell boat")', 12)
					wait.time(0.5);_f()
				else
					run("h;w")
					gps_gyz_go_e_boat=0
					_f=function() run("yell boat") end
				--	DoAfterSpecial(0.5, 'run("yell boat")', 12)
					wait.time(0.5);_f()
				end
			else
				if not isopen("dazuo") and not isopen("skills_lian") then alias.dz(set_neili_global) end
				if always.where=="汉水南岸" then run("h;nw")
				elseif always.where=="汉水北岸" then run("h;w;sw") 
				elseif roomname=="汉水畔" then 
					if always.exit=="southeast" then 
						run("h;se") 
					elseif always.exit=="northeast" then
						run("h;ne;e") 
					end
				end
				_f=function() run("yell boat") end
			--	DoAfterSpecial(1, 'run("yell boat")', 12)
				wait.time(0.5);_f()
			end
		end
		if findstring(l,"岸边一只渡船上的老艄公说道：正等着你呢，上来吧。","岸边一只渡船上的船夫说道：正等着你呢，上来吧。","一条渔船应声慢慢驶了过来","一叶扁舟缓缓地驶了过来") then
			alias.resetidle()
			closeclass("boat_yell")
			if havefj>0 and fjroom=="" and always.where=="码头" and me.menpai=="th" and isopen("mp_th_pre") then
				alias.startfj() 
				print("判断要不要回去拿fj")
			else
				boatDirection="enter"
				run("halt")
				alias.trymove(boatDirection)
			end
		end
	end)
end
------------------------------------------------------------------------------------
-- dazuo
------------------------------------------------------------------------------------
function dazuo.dosomething1(n,l,w)
	local _f,_t,a,b,c
		-- bt会处理成飞到欧阳峰处打坐，所以这里通过class判断排除bt
		if not isopen("mp_bt_watch") and findstring(l,"这里空气不好，不能打坐。") then run(safego..";dazuo "..dz()) end
		if findstring(l,"你在倒立中，怎么还能分出心神来做其它事情？！") then run("release yuanshi;dazuo "..dz()) end
		if findstring(l,"你还是老老实实地跪著吧，别做其他事了。","你正在用心领悟功夫，没闲暇做其它事情！") then run("stand;dazuo "..dz()) end
		if findstring(l,"你是来作客还是来练功啊？") then run("se;e;dazuo "..dz()) end
		if findstring(l,"呆在武庙里，你只觉得心慌意乱，怎么也集中不起精神来！") then run("e;dazuo "..dz()) end
		if findstring(l,"来这是来打麻将而不是打坐。") then alias.flytoid(960) end
		if hp.neili<hp.maxneili/3 and me.menpai=="gb" and os.time()-always.sleeptimes>180 and not findstring(always.where,"船") and not isopen("war_pre") then alias.resetidle();always.sleeptimes=os.time();run("sleep") end
		if findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。") then
			alias.resetidle()
			run("hp;dazuo "..dz())
		end
		if findstring(l,"你现在精不够，无法控制内息的流动！") then
			alias.et()
			if have.swjing>0 then run("fu shouwu jing;hp") end
			if hp.healthjing<80 and not findstring(always.where,"船") and not isopen("war_pre") then alias.startliaoshang() else run("hp;yun regenerate") end
		end
		if findstring(l,"你现在的气太少了，无法产生内息运行全身经脉。") then 
			alias.et()
			if jifa.force<100 then 
				wait.make(function()
					_f=function() run("hp;dazuo "..dz()) end
					wait.time(3);_f()
				end)
			else 
				run("yun recover")
			end  
		end
		if findstring(l,"你刚刚压制住身上伤势，还是不要妄动真气。","你把正在运行的真气强行压回丹田","练内功要有间隙","你的内力不够","你现在精不够","你现在的气太少了","你.+忽觉内息後继乏力","你刚刚压制住身上伤势","你体内的真气不够","你上一个动作还没有完成","你现在正忙着呢","你已经受伤过重","你并未受到内伤") then
			openclass("dazuo_resetidle")
			if always["bei"][1]=="六脉神剑" and #always.bei==1 then
				run("jiali "..fjjiali)
			end
		end
		if findstring(l,"战斗中不能练内功","战斗中运功疗伤？","你缓缓坐起身来调匀呼吸","你就地盘坐.+疗伤","你盘膝坐下.+运气在周身大穴运转。","你潜运内力.+流转疗伤","你全身放松.+开始运功疗伤。","你一运气.+丹田中一股暖意升将上来。","你脚下缓缓踏著八卦方位.+潜运碧涛玄功调理伤势。","你大周天搬运完毕，将内力合于丹田，入窍归元。","你催运摩天云气疗伤片刻，体内真气运转无碍，内伤已经平复，当即站起身来。") then
			openclass("dazuo_resetidle")
		end
		if findstring(l,"看起来.+想杀死你！") then 
			run("halt")
			openclass("dazuo_resetidle")
		end
		if findstring(l,"你一声长啸，脚下踩著奇门步法，趋前抢后，尤如天神行法，鬼魅遁影，瞬间只见数十个身影飞射而出，游走不定！") then 
			run("halt")
		end
		a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
		if c~=nil and tonumber(c)==me.dazuobaseid then
		    if me.menpai=="xs" and have.lxj<1 then run("get longxiang jing") end
			alias.dz(type_dz)
		end
		a,b,c=string.find(l,"你目前还没有任何为 checkhp=(.+) 的变量设定。")
		if c~=nil then
			alias.resetidle()
			type_dz=c
			if setting=="dm" and jifa.forcename=="taiji-shengong" then run("yun taiji") end
			if stat.havedu>0 and hp.healthjing<80 and not findstring(always.where,"船") and not isopen("war_pre") then alias.startliaoshang()
			else
				if hp.healthqi<100 and hp.neili>=hp.maxneili*set_neili_job/100 then 
					alias.yunheal()
				else
					if hp.qi<(hp.maxqi/2) then --jifaforce不达标,不运气等3秒自然恢复
						if jifa.force<100  then
							wait.make(function()
								if tonumber(type_dz)~=nil and hp.neili>(hp.maxneili*type_dz/100) then
									_f=function() run("hp;set checkhp="..type_dz) end
									wait.time(3);_f()
								else
									_f=function() run("dazuo "..dz()) end
									wait.time(3);_f()						
								end
							end)
						else 
							run("yun recover;dazuo "..dz()) 
						end 
					else
						if roomno_now==2077 and me.menpai=="gm" then run("sit chuang") end
						if roomno_now==1801 and me.menpai=="bt" and (stat.reverse==nil or stat.reverse==0) then run("yun reverse") end
						if tonumber(type_dz)~=nil and tonumber(type_dz)>0 then
							if hp.neili>(hp.maxneili*tonumber(type_dz)/100) then 
								closeclass("dazuo_resetidle")
								closeclass("dazuo")
								alias.tdz() 
							else 
								run("dazuo "..dz()) 
							end
						else
							if (hp.maxneili*2-hp.neili)<dz() then
								if (hp.maxneili*2-hp.neili+1)<10 then _t=10 else _t=hp.maxneili*2-hp.neili+1 end
								run("dazuo ".._t)
							else
								run("dazuo "..dz())
							end
						end
					end
				end
			end
		end
		if findstring(l,"你运功良久","你运功完毕，深深吸了口气，站了起来。","你催运.+内伤已经平复，当即站起身来。","你依法盘旋得数下","你只觉内息运转顺畅","你缓步行走多时") then
			alias.resetidle()
			closeclass("dazuo_resetidle")
			if me.menpai=="gm" and roomno_now==2077 then run("xiachuang") end
			if type_dz==nil then type_dz=tonumber(set_neili) end
			if (hp.food<hp.maxfood and hp.water<hp.maxwater) then alias.et() end
			if (hp.water<30) then 
				if me.menpai=="xs" then
					run("drink lubo")
				else
					run("drink jiudai") 
				end
			end
			if hp.neili>(hp.maxneili*set_neili_global/100) and type_dz=="addneili" and not isopen("fj_pre") then
				if de_bug>0 then print("在增加内力模式，当内力快满前发生一次检查job的触发，在其他模块里面进行触发处理") end
				if (havefj>0 or (mpJobLimited==0 and hp.neili>(hp.maxneili*195/100))) and not isopen("mp_xs_npc1") and not findstring(always.where,"船") then
					alias.startworkflow()
				else
					if string.len(resumejob)>0 then
						run(resumejob)
						resumejob=""
					end
				end
			end
			run("hp;set checkhp="..type_dz)	
		end
end
------------------------------------------------------------------------------------
-- dazuo_resetidle
------------------------------------------------------------------------------------
function dazuo_resetidle.timer()
		if jifa.force==nil or tonumber(type_dz)==nil then return end
		if hp.neili<(hp.maxneili*tonumber(type_dz)/100) then 
			alias.resetidle()
			openclass("dazuo")
			run("hp;dazuo "..dz()) 
		end
end
------------------------------------------------------------------------------------
-- fang
------------------------------------------------------------------------------------
function fang.dosomething1(n,l,w)
	local a,b,c
	a,b,c=string.find(l,"[> ]*(.+)倒在地上，挣扎了几下就死了。")
	if c~=nil and c==killname then
		--run("jiajin basic")
		if always["bei"][1]=="六脉神剑" and #always.bei==1 then	run("jiali "..fjjiali) end
		npcfaint=true
		alias.checkbusy("killover")
	end	
	if findstring(l,"你的眼前一黑，接著什么也不知道了") then
		print("他妈的，被干翻了～～")
		closeclass("fang")
	end
	if findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
		closeclass("fang")
		Execute("/alias.start"..workflow.nowjob.."()")
	end
end
------------------------------------------------------------------------------------
-- liaoshang
------------------------------------------------------------------------------------
function liaoshang.dosomething1(n,l,w)
	--local _f
	--wait.make(function()
		if findstring(l,"沉思了一会说道：阁下所中的.+已并无异样","沉思了一会说道：.+请容在下为您医治。","说道：先看看你的脉象吧。","便提起你的手把了一会脉。","你身不由几的微微一跳，只觉的一股热气从顶门直透下来。","你突然觉得一股暖流自顶而入，口中吐出几口黑血，眼前一黑就什么也看不见了！") then alias.resetidle() end
		if findstring(l,"慢慢地一阵眩晕感传来，你终于又有了知觉") then
			alias.resetidle()
			run("yun refresh;yun regenerate;yun recover;hp")
			alias.checkbusy("wakeup")
			run("tell "..dummy.id.." 回去吧 thank you")
		end
		if findstring(l,"你目前还没有任何为 busyover=wakeup 的变量设定。") then
			alias.resetidle()
			run("yun refresh;yun regenerate;yun recover;hp")
			alias.checkbusy("liaoshang")
		end
		if findstring(l,"你目前还没有任何为 busyover=liaoshang 的变量设定。") then
			alias.resetidle()
			if have.swjing>0 then run("fu shouwu jing;hp") end
			run("yun refresh;yun regenerate;yun recover;hp")
			if hp.neili<hp.maxneili/2 then 
				run("sleep")
			elseif hp.healthjing<85 then 
				alias.flytonpc("何红药")
				--if me.menpai=="th" then alias.flytonpc("武眠风") else alias.flytonpc("何红药") end
			else
				alias.startworkflow()
			end
		end
		if findstring(l,"有一天，你踩着七色云彩来迎娶『何红药』") then
			alias.resetidle()
			run("buy shouwu jing;fu shouwu jing;hp")
			if stat.havedu>0 then 
				alias.flyto("武馆休息室") 
			else 
				alias.startworkflow() 
			end
		end
		--if findstring(l,"你从何红药那里买下了一棵首乌精。") then
		--	alias.resetidle()
		--	if stat.havedu>0 then alias.flyto("武馆休息室") else run("fu shouwu jing;hp");alias.startworkflow() end
		--end
		--if findstring(l,"你想买的东西我这里没有。","穷光蛋，一边呆着去！","^(> > > |> > |> |)什么？$") then
		--	alias.resetidle()
		--	if stat.havedu>0 then alias.flyto("武馆休息室")
		--	else
		--		if me.menpai=="th" and hp.healthjing<85 then alias.flytonpc("武眠风") else alias.startworkflow() end
		--	end
		--end
		if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『武馆休息室』立马到达！") then
			alias.resetidle()
			run("hp;tell "..dummy.id.." 疗伤 thank you")
		end
		if findstring(l,"你一觉醒来，只觉精力充沛。该活动一下了。","沉思了一会说道：阁下所中的.+已并无异样",".+回答你：你没有中毒","没有这个人....。","你突然觉得一股暖流自顶而入，口中吐出几口黑血，眼前一黑就什么也看不见了！") then
			alias.resetidle()
			--print("等死吧11")
			stat.havedu=0
			if hp.healthjing<85 then 
				alias.close_gps()
				alias.flytonpc("何红药")
				--if me.menpai=="th" then alias.flytonpc("武眠风") else alias.flytonpc("何红药") end
			else
				alias.startworkflow()
			end
		end
		if findstring(l,"有一天，你踩着七色云彩来迎娶『武眠风』") then
			alias.resetidle()
			run("ask wu mianfeng about 九花玉露丸")
			--if roomno_now==1470 then run("ask lu chengfeng about 九花玉露丸") else run("ask wu mianfeng about 九花玉露丸") end
		end
		if findstring(l,"武眠风给你一粒九花玉露丸","武眠风说道：抱歉，你来得不是时候","武眠风说道：我不是才给过你药吗") then
			alias.resetidle()
			--print("等死吧22")
			stat.havedu=0
			run("fu yulu wan")
			--if roomno_now==1470 then alias.flytonpc("武眠风")
			--else
				closeclass("liaoshang")
				alias.startworkflow()
			--end
		end
	--end)
end
------------------------------------------------------------------------------------
-- qudu
------------------------------------------------------------------------------------
function qudu.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=qudu 的变量设定。") then
		run("hp;yun qudu")
	end
	if findstring(l,"你并未中毒") then
		closeclass("qudu")
		stat.havedu=0
		alias.startworkflow()
		--Execute("/alias.start"..workflow.nowjob.."()")
	end
	if findstring(l,"你头下脚上，倒运气息，气血逆行，想让","你无法在战斗中运功疗毒") then
		alias.checkbusy("qudu")
	end
end
------------------------------------------------------------------------------------
-- quit
------------------------------------------------------------------------------------
function quit.dosomething1(n,l,w)
	if findstring(l,"欢迎下次再来！") then
		cmd.nums=0
		closeclass("quit")
		alias.initialize_variable()
		wait.make(function()
			--local _tf=function() Connect() end
			wait.time(5);Connect()
		end)
	end
	if findstring(l,"开始退出游戏，进行中……") then
		stat.quiting=1
		cmd.nums=0
	end
end
function quit.timer()
	alias.resetidle()
	if stat.quiting==nil or stat.quiting==0 then run("halt;quit") end
	run("yun recover")
	alias.yjl()
	run("hp")
end
------------------------------------------------------------------------------------
-- quitdis
------------------------------------------------------------------------------------
function quitdis.dosomething1(n,l,w)
	if findstring(l,"开始退出游戏，进行中……") then
		notconnect=1
		Disconnect()
	end
end
------------------------------------------------------------------------------------
-- shizhe
------------------------------------------------------------------------------------
function shizhe.dosomething1(n,l,w)
	if findstring(l,"你的眼前一黑，接著什么也不知道了") then
		haveshizhe=0
		print("他妈的，被干翻了～～")
		closeclass("shizhe")
	end
	if findstring(l,"日月神教使者倒在地上，手脚几下抽动便死了！","日月神教使者突然卖一破绽，跳出战圈，逃了！","日月神教使者悻然说道：算你够狠！老子先不奉陪了！咱们走着瞧！") then
		haveshizhe=0
		run("jiajin basic")
		if #always.bei==1 and always["bei"][1]=="六脉神剑" or #always.bei==2 and (always["bei"][1]=="六脉神剑" or always["bei"][2]=="六脉神剑") then
			run("jiali "..killjiali)
		else
			run("jiali 0")
		end
		npcfaint=true
		alias.checkbusy("killover")
	end
	if findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
		closeclass("shizhe")
		alias.startworkflow()
		--Execute("/alias.start"..workflow.nowjob.."()")
	end
end
------------------------------------------------------------------------------------
-- tongmai
------------------------------------------------------------------------------------
function tongmai.timer()
	stat.haveyyz=0
end
function tongmai.timer1()
	DeleteTimer("tongmai_timer")
end
function tongmai.dosomething1(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"在你的耳边悄声说道：没有内力治疗！") then
			closeclass("tongmai")
			stat.haveyyz=0
			AddTimer("tongmai_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "tongmai.timer")
			AddTimer("tongmai_timer1", 0, 0, 120, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "tongmai.timer1")
			Execute("/alias.start"..workflow.nowjob.."()")
		end
		if findstring(l,"在你的耳边悄声说道：你的一阳指已治愈！") then
			closeclass("tongmai")
			stat.haveyyz=0
			run("e")
			Execute("/alias.start"..workflow.nowjob.."()")
		end
		if findstring(l,"在你的耳边悄声说道：小样！我不是这么随便的人～～","这里没有 ") then
			closeclass("tongmai")
			stat.haveyyz=0
			AddTimer("tongmai_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "tongmai.timer")
			AddTimer("tongmai_timer1", 0, 0, 300, "", timer_flag.Enabled + timer_flag.Replace + timer_flag.OneShot, "tongmai.timer1")
			Execute("/alias.start"..workflow.nowjob.."()")
		end
		if findstring(l,"你忙着呢，你等会儿在问话吧。") then
			alias.resetidle()
			_f=function() run("ask "..dummy.id.." about tongmai") end
		--	DoAfterSpecial(2, 'run("ask "..dummy.id.." about tongmai")', 12)
			wait.time(2)
			_f()
		end
		if findstring(l,"你感到一股劲力直侵你身上要穴，隐隐生疼。","你突然觉得身体一轻，各路要穴似乎都被打通，不再疼痛。","五指轻抚下，只见你不住口吐鲜血，但是气色却比方才好了许多。") then
			alias.resetidle()
		end
		if findstring(l,"数码世界，数字地图，950就是这里！") then
			alias.resetidle()
			run("ask "..dummy.id.." about tongmai")
		end
	end)
end
------------------------------------------------------------------------------------
-- yinyun
------------------------------------------------------------------------------------
function yinyun.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=yinyun 的变量设定。") then
		if roomno_now==91 then run("s") end
		run("hp;yun yinyun")
	end
	if findstring(l,"你并未中毒","你现在的真气不足") then
		closeclass("yinyun")
		stat.havedu=0
		alias.startworkflow()
		--Execute("/alias.start"..workflow.nowjob.."()")
	end
	if findstring(l,"你将内力循环一周，身子如灌甘露，丹田里的真气似香烟缭绕","你无法在战斗中运功疗毒") then
		alias.checkbusy("yinyun")
	end
end
------------------------------------------------------------------------------------
-- 熬制buyinwan
------------------------------------------------------------------------------------

function addxyzq.dosomething1(n,l,w)
	if findstring(l,"数码世界，数字地图，461就是这里！") then 
		alias.resetidle()
		run("jump tan")
		alias.checkbusy("jumptan")
	end
	if findstring(l,"你目前还没有任何为 busyover=jumptan 的变量设定。") then
		alias.resetidle()
		run("swim down")
		alias.checkbusy("swimdown")
	end
	if findstring(l,"你目前还没有任何为 busyover=swimdown 的变量设定。") then
		alias.resetidle()
		run("lianxi strike")
		alias.checkbusy("lianxistrike")
	end
	if findstring(l,"你目前还没有任何为 busyover=lianxistrike 的变量设定。") then
		alias.resetidle()
		run("hp;cha;jifa;up;jump up")
		alias.checkbusy("jumpup")
	end
	if findstring(l,"你目前还没有任何为 busyover=jumpup 的变量设定。") then
		alias.resetidle()
		closeclass("addxyzq")
		alias.startworkflow()
	end
end
function buyinwan.dosomething1(n,l,w)
	if findstring(l,"数码世界，数字地图，1494就是这里！") then
		alias.resetidle()
		run("search cao")
	end
	if findstring(l,"数码世界，数字地图，1084就是这里！") then
		alias.resetidle()
		_tb=Split(pxj_no,"|")
		local whg_no=0
		for i=1,#_tb,1 do 
			if _tb[i]=="wuhua guo" then whg_no=whg_no+1 end
		end
		run("buy "..whg_no.." wuhua guo")
	end
	if findstring(l,"数码世界，数字地图，4就是这里！","哟，抱歉啊，我这儿正忙着呢……您请稍候。") then
		alias.resetidle()
		_tb=Split(pxj_no,"|")
		local khf_no=0
		for i=1,#_tb,1 do 
			if _tb[i]=="kuihua fen" then khf_no=khf_no+1 end
		end
		if khf_no>0 then
			run("buy "..khf_no.." kuihua fen")
		else
		aoyao.buyidList=pxj_no
		aoyao.fire=0
		openclass("aoyao")
		closeclass("buyinwan")
		run("e;look lu;set checkfire=yes")
		end
	end
	if findstring(l,"你慢慢的爬过去，小心翼翼的摘下几颗小草放在身上。") then
		alias.resetidle()
		yinyangcao_num=0
		wuhuaguo_num=0
		kuihuafen_num=0
		run("i;search cao")
	end
	if findstring(l,"你仔细寻找了半天，却什么都没找到。") then   --没草就重置采草的时间，重启任务流程
		alias.resetidle()
		yinyangcao_time=0
		if yinyangcao_num<3 then
			wait.make(function()
				_f=function() alias.startworkflow() end
				wait.time(3);_f()
			end)
		else
			if findstring(pxj_no,"wuhua guo") then 
				alias.flytoid("1084")  --天街买无花果
			else
				alias.flytoid("4")   --药方没有无花果，直接去泉州
			end
		end
	end
	if findstring(l,"你从小贩那里买下了.+钱无花果。") then
		alias.resetidle()
		alias.flytoid("4")
	end
	if findstring(l,"你从王通治那里买下了.+钱葵花粉。") then
		alias.resetidle()
		aoyao.buyidList=pxj_no
		aoyao.fire=0
		openclass("aoyao")
		closeclass("buyinwan")
		run("e;look lu;set checkfire=yes")
	end
end
function buyinwan.aoyao() ---根据自己的药方熬药
	AddTriggerEx ("ay", ".+深吸一口气，停了下来。$", "alias.checkbusy('quyao');EnableTrigger('ay', false)", trigger_flag.RegularExpression + trigger_flag.Replace, custom_colour.NoChange, 0, "", "", 12, 151);
	EnableTrigger("ay", true)
end
--你从药炉中取出一粒补阴丸
------------------------------------------------------------------------------------
function eating.dosomething1(n,l,w)
	local a,b,c,d,e,_f
	if findstring(l,"数码世界，数字地图，682就是这里！") then	--武当食堂
		alias.resetidle()
		run("sit chair;knock table;get tao")
		for i=1,4,1 do 
			run("drink tea;drink wan")
		end
		run("eat tao")
		alias.checkbusy("eating")
	elseif findstring(l,"数码世界，数字地图，288就是这里！") then	--大理食堂
		run("serve;get guoqiao mixian;get guoqiao heiyu;get ye er ba")
		for i=1,4,1 do 
			run("drink qiguo ji;drink puer cha")
		end
		run("hp;drop kaoya;drop jiuping;eat ye er ba;eat guoqiao heiyu;eat guoqiao mixian")
		alias.checkbusy("eating")
	elseif findstring(l,"数码世界，数字地图，280就是这里！") then	--雪山食堂
		alias.resetidle()
		run("buy ji;drink ji;drink ji;drink ji")
		alias.checkbusy("eating")
	elseif findstring(l,"你已经吃太饱了，再也塞不下了！","你目前还没有任何为 busyover=tao 的变量设定。") then
		if me.menpai=="wd" then run("drink jiudai;drop tao;drop tao;drop tea;drop wan;hp") 
		elseif me.menpai=="dl" then run("drop qiguo ji;drop puer cha;drop guoqiao mixian;drop guoqiao heiyu;drop ye er ba;hp")
		end
		--alias.checkbusy("eating")
	elseif findstring(l,"你目前还没有任何为 busyover=eating 的变量设定。") then
		run("hp")
		if me.menpai=="wd" then	--武当检查有没有吃饱
			--run("drop tao")
			if hp.food<hp.maxfood then 
				run("sit chair;knock table;get tao;eat tao;drink wan")
				alias.checkbusy("eating")
				return
			elseif hp.water<hp.maxwater then 
				run("sit chair;knock table;drop tao")
				for i=1,4,1 do
				run("drink tea;drink wan")
				end
			else 
			    run("hp;drop tea;drop wan;drop tao;drop tao;drop tao")
			end
		elseif me.menpai=="dl" then
			if hp.food<hp.maxfood and hp.water<hp.maxwater then
				run("drop qiguo ji;drop puer cha;drop guoqiao mixian;drop guoqiao heiyu;drop ye er ba;serve;drink qiguo ji;drink puer cha;drink puer cha;drink jiudai;get ye er ba;get guoqiao mixian;get guoqiao heiyu;eat ye er ba;eat guoqiao mixian;eat guoqiao heiyu")
				alias.checkbusy("eating")
				return
			else
				for i=1,2,1 do
					run("drop qiguo ji;drop puer cha;drop guoqiao mixian;drop guoqiao heiyu;drop ye er ba")
				end
				run("hp")
			end
		else
			run("drop ji;drop ji;hp") --其他门派扔掉汽锅鸡走人
		end
		alias.startworkflow()
	end
end
--各门派吃饭
function checkbusy.dosomething1(n,l,w)
	local a,b,c
	if check_battleidle~=nil and check_battleidle<=180 then alias.resetidle() end
	if findstring(l,"你身上没有 "..setbusy.." 这样食物。") then 
		run("set busyover="..setbusy)
		closeclass("checkbusy")
	elseif findstring(l,"你正忙着呢，先忍忍吧。") then
		wait.make(function()
			wait.time(0.2)
			run("eat "..setbusy)
		end)
	end
end
------------------------------------------------------------------------------------
function common.update()
	local _tb
	_tb={
		"你目前还没有任何为 busyover=yinyun 的变量设定。",
		"你并未中毒",
		"你现在的真气不足",
		"你将内力循环一周，身子如灌甘露，丹田里的真气似香烟缭绕",
		"你无法在战斗中运功疗毒",
	}
	local  yinyun_triggerlist={
	       {name="yinyun_dosth1",regexp=linktri(_tb),script=function(n,l,w)    yinyun.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(yinyun_triggerlist) do
		addtri(v.name,v.regexp,"yinyun",v.script,v.line)
	end
	closeclass("yinyun")
	_tb={
		"数码世界，数字地图，461就是这里！",
		"你目前还没有任何为 busyover=.+ 的变量设定。",
	}
	local addxyzq_triggerlist={
		  {name="addxyzq_dosth1",regexp=linktri(_tb),script=function(n,l,w)    addxyzq.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(addxyzq_triggerlist) do
		addtri(v.name,v.regexp,"addxyzq",v.script,v.line)
	end
	closeclass("addxyzq")
	_tb={
		"数码世界，数字地图，1494就是这里！",
		"你仔细寻找，发现山崖上有几颗深绿色的小草。",
		"你慢慢的爬过去，小心翼翼的摘下几颗小草放在身上。",
		"你仔细寻找了半天，却什么都没找到。",
		"数码世界，数字地图，1084就是这里！",
		"数码世界，数字地图，4就是这里！",
		"你从小贩那里买下了.+钱无花果。",
		"你从王通治那里买下了.+钱葵花粉。",
		"药炉下正燃着火。",
		"你目前还没有任何为 busyover=quyao 的变量设定。",
		"你目前还没有任何为 busyover=gowork 的变量设定。",
		"你目前还没有任何为 checkfire=yes 的变量设定。",
		"你从药炉中取出一.+",
		"你开炉一看，炉中之物象一团浆糊一样，看来没什么用。",
		"你取出药材一看，已经烧成一团焦炭。",
		"炭火渐渐明亮，看来可以开始了。",
	}
	local buyinwan_triggerlist={
		  {name="buyinwan_dosth1",regexp=linktri(_tb),script=function(n,l,w)    buyinwan.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(buyinwan_triggerlist) do
		addtri(v.name,v.regexp,"buyinwan",v.script,v.line)
	end
	closeclass("buyinwan")
	_tb={
		dummy.name.."在你的耳边悄声说道：没有内力治疗！",
		dummy.name.."在你的耳边悄声说道：你的一阳指已治愈！",
		dummy.name.."在你的耳边悄声说道：小样！我不是这么随便的人～～",
		"你忙着呢，你等会儿在问话吧。",
		"你感到一股劲力直侵你身上要穴，隐隐生疼。",
		"你突然觉得身体一轻，各路要穴似乎都被打通，不再疼痛。",
		"数码世界，数字地图，950就是这里！",
		"在"..dummy.name.."五指轻抚下，只见你不住口吐鲜血，但是气色却比方才好了许多。",
		"这里没有 "..dummy.id.." 这个人。",
	}
	local  tongmai_triggerlist={
	       {name="tongmai_dosth1",regexp=linktri(_tb),script=function(n,l,w)    tongmai.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(tongmai_triggerlist) do
		addtri(v.name,v.regexp,"tongmai",v.script,v.line)
	end
	closeclass("tongmai")
	
	_tb={
		"你的眼前一黑，接著什么也不知道了....",
		"日月神教使者倒在地上，手脚几下抽动便死了！",
		"日月神教使者突然卖一破绽，跳出战圈，逃了！",
		"日月神教使者悻然说道：算你够狠！老子先不奉陪了！咱们走着瞧！",
		"你目前还没有任何为 killover=yes 的变量设定。",
	}
	local  shizhe_triggerlist={
	       {name="shizhe_dosth1",regexp=linktri(_tb),script=function(n,l,w)    shizhe.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(shizhe_triggerlist) do
		addtri(v.name,v.regexp,"shizhe",v.script,v.line)
	end
	closeclass("shizhe")
	
	_tb={
		"欢迎下次再来！",
		"开始退出游戏，进行中……",
	}
	local  quit_triggerlist={
	       {name="quit_dosth1",regexp=linktri(_tb),script=function(n,l,w)    quit.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(quit_triggerlist) do
		addtri(v.name,v.regexp,"quit",v.script,v.line)
	end
	AddTimer("quit_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "quit.timer")
	SetTimerOption("quit_timer", "group", "quit")
	closeclass("quit")
	
	_tb={
		"开始退出游戏，进行中……",
	}
	local  quitdis_triggerlist={
	       {name="quitdis_dosth1",regexp=linktri(_tb),script=function(n,l,w)    quitdis.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(quitdis_triggerlist) do
		addtri(v.name,v.regexp,"quitdis",v.script,v.line)
	end
	closeclass("quitdis")
	
	_tb={
		"你目前还没有任何为 busyover=qudu 的变量设定。",
		"你并未中毒",
		"你头下脚上，倒运气息，气血逆行，想让.+从进入身子之处回出。",
		"你无法在战斗中运功疗毒",
	}
	local  qudu_triggerlist={
	       {name="qudu_dosth1",regexp=linktri(_tb),script=function(n,l,w)    qudu.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(qudu_triggerlist) do
		addtri(v.name,v.regexp,"qudu",v.script,v.line)
	end
	closeclass("qudu")
	
	_tb={
		dummy.name.."沉思了一会说道：阁下所中的.+已并无异样",
		dummy.name.."沉思了一会说道：阁下所中的.+请容在下为您医治。",
		dummy.name.."说道：先看看你的脉象吧。",
		"说着"..dummy.name.."便提起你的手把了一会脉。",
		"你身不由几的微微一跳，只觉的一股热气从顶门直透下来。",
		"你突然觉得一股暖流自顶而入，口中吐出几口黑血，眼前一黑就什么也看不见了！",
		"慢慢地一阵眩晕感传来，你终于又有了知觉....",
		"你目前还没有任何为 .+ 的变量设定。",
		"你一觉醒来，只觉精力充沛。该活动一下了。",
		"你口念咒语『神马都是浮云,虾米都是尘土』，『武馆休息室』立马到达！",
		"有一天，你踩着七色云彩来迎娶『何红药』",
		--"你从何红药那里买下了一棵首乌精。",
		--"你想买的东西我这里没有。",
		--"穷光蛋，一边呆着去！",
		--"^(> > > |> > |> |)什么？$",
		".+回答你：你没有中毒",
		"没有这个人....。",
		"你突然觉得一股暖流自顶而入，口中吐出几口黑血，眼前一黑就什么也看不见了！",
		"有一天，你踩着七色云彩来迎娶『[陆乘风|武眠风]+』",
		".+给你一粒九花玉露丸",".+说道：抱歉，你来得不是时候",".+说道：我不是才给过你药吗",
	}
	local  liaoshang_triggerlist={
	       {name="liaoshang_dosth1",regexp=linktri(_tb),script=function(n,l,w)    liaoshang.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(liaoshang_triggerlist) do
		addtri(v.name,v.regexp,"liaoshang",v.script,v.line)
	end
	closeclass("liaoshang")
	
	_tb={
		"(.+)倒在地上，挣扎了几下就死了。",
		"你的眼前一黑，接著什么也不知道了....",
		"你目前还没有任何为 killover=yes 的变量设定。",
	}
	local  fang_triggerlist={
	       {name="fang_dosth1",regexp=linktri(_tb),script=function(n,l,w)    fang.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(fang_triggerlist) do
		addtri(v.name,v.regexp,"fang",v.script,v.line)
	end
	closeclass("fang")
	
	_tb={
		"这里空气不好，不能打坐。",
		"你在倒立中，怎么还能分出心神来做其它事情？！",
		"你还是老老实实地跪著吧，别做其他事了。","你正在用心领悟功夫，没闲暇做其它事情！",
		"你是来作客还是来练功啊？",
		"呆在武庙里，你只觉得心慌意乱，怎么也集中不起精神来！",
		"来这是来打麻将而不是打坐。",
		"你一觉醒来，只觉精力充沛。该活动一下了。",
		"你现在精不够，无法控制内息的流动！",
		"你现在的气太少了，无法产生内息运行全身经脉。",
		"看起来.+想杀死你！","你刚刚压制住身上伤势，还是不要妄动真气。","你把正在运行的真气强行压回丹田","练内功要有间隙","你的内力不够","你现在精不够","你现在的气太少了","你.+忽觉内息後继乏力","你刚刚压制住身上伤势","战斗中不能练内功","战斗中运功疗伤？","你体内的真气不够","你上一个动作还没有完成","你现在正忙着呢","你已经受伤过重","你并未受到内伤","你催运.+内伤已经平复，当即站起身来。","你依法盘旋得数下","你只觉内息运转顺畅","你缓步行走多时","你缓缓坐起身来调匀呼吸","你就地盘坐.+疗伤","你盘膝坐下.+运气在周身大穴运转。","你潜运内力.+流转疗伤","你全身放松.+开始运功疗伤。","你一运气.+丹田中一股暖意升将上来。","你脚下缓缓踏著八卦方位.+潜运碧涛玄功调理伤势。","你大周天搬运完毕，将内力合于丹田，入窍归元。","你催运摩天云气疗伤片刻，体内真气运转无碍，内伤已经平复，当即站起身来。",
		"你一声长啸，脚下踩著奇门步法，趋前抢后，尤如天神行法，鬼魅遁影，瞬间只见数十个身影飞射而出，游走不定！",
		"数码世界，数字地图，.+就是这里！",
		"你目前还没有任何为 .+ 的变量设定。",
		"你运功良久","你运功完毕，深深吸了口气，站了起来。",
	}
	local  dazuo_triggerlist={
	       {name="dazuo_dosth1",regexp=linktri(_tb),script=function(n,l,w)    dazuo.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(dazuo_triggerlist) do
		addtri(v.name,v.regexp,"dazuo",v.script,v.line)
	end
	closeclass("dazuo")
	AddTimer("dazuo_resetidle_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "dazuo_resetidle.timer")
	SetTimerOption("dazuo_resetidle_timer", "group", "dazuo_resetidle")
	closeclass("dazuo_resetidle")
	
	_tb={
		".+说“到啦，上岸吧”，随即把一块踏脚板搭上堤岸。",
		"练内功要有间隙，太劳累会走火入魔的。",
		"你现在身体状况太差了，无法集中精神！",
		"你的内力不够，无法施展一苇渡江绝技！",
		"你刚刚压制住身上伤势，还是不要妄动真气。",
		"你猛吸几口大气，站了起来。",
		"你目前还没有任何为 dazuo=over 的变量设定。",
		"你目前还没有任何为 lian=over 的变量设定。",
		"松花江化冻了，你喊\\(yell\\)条船过江吧。",
		"船夫扳桨划船，在湖中行了数里，缓缓停泊在岸边，将一块踏脚板搭上了堤岸。",
		"接著你一跃而起，脚尖在苇枝上一点，两袖飘飘，箭一般地在水面上穿了过去。",
		"你目前还没有任何为 boat=enter 的变量设定。",
		"你目前还没有任何为 boat=out 的变量设定。",
		"你目前还没有任何为 checkmove=yes 的变量设定。",
		"你目前还没有任何为 checkyell=yes 的变量设定。",
		"你目前还没有任何为 checkyunbusy=yes 的变量设定。",
		"你鼓足中气，长啸一声：“船家！”",
		"你见江面结冻，便壮起胆子踩冰而过。",
		"你使出吃奶的力气喊了一声：“船家”",
		"你吸了口气，一声“船家”，声音中正平和地远远传了出去。",
		"一叶扁舟缓缓地驶了过来",
		"你的动作还没有完成，不能移动。",
		"临阵脱逃可是得受军法处置，你还是先帮忙力据蒙古大军吧。",
	}
	local  boat_triggerlist={
	       {name="boat_dosth1",regexp=linktri(_tb),script=function(n,l,w)    boat.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(boat_triggerlist) do
		addtri(v.name,v.regexp,"boat",v.script,v.line)
	end
	closeclass("boat")
	
	_tb={
		"湖面上的船家来来往往，一无反应……",
		"可是这时侯夜色已深，湖面上的船家大都歇息了，祗有西边的湖岸还有扁舟往返。",
		"只听得(.+)面上隐隐传来：“别急嘛，这儿正忙着呐……”",
		"岸边一只渡船上的(老艄公|船夫)说道：正等着你呢，上来吧。",
		"(一条渔船应声慢慢|一叶扁舟缓缓地)驶了过来",
	}
	local  boat_yell_triggerlist={
	       {name="boat_yell_dosth1",regexp=linktri(_tb),script=function(n,l,w)    boat_yell.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(boat_yell_triggerlist) do
		addtri(v.name,v.regexp,"boat_yell",v.script,v.line)
	end
	closeclass("boat_yell")
	
	_tb={
		"你目前还没有任何为 busyover=cure 的变量设定。",
		"你所学的内功中没有这种功能。",
		"你现在不须要疗精！",
		"你在身上划一道伤口，挤出一些淤血，气沉丹田，开始凝神疗精。",
	}
	local  cure_triggerlist={
	       {name="cure_dosth1",regexp=linktri(_tb),script=function(n,l,w)    cure.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(cure_triggerlist) do
		addtri(v.name,v.regexp,"cure",v.script,v.line)
	end
	closeclass("cure")
	
	_tb={
		"你目前还没有任何为 busyover=bidu 的变量设定。",
		"你闭目而坐，急呼缓吸，过了一顿饭工夫，脸色略复红润。",
		"你并未中毒",
		"你无法在战斗中运功疗毒",
		"你运功一阵，祗感神困力疲，没料到体内.+毒如此厉害，竟然驱之不出。"
	}
	local  bidu_triggerlist={
	       {name="bidu_dosth1",regexp=linktri(_tb),script=function(n,l,w)    bidu.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(bidu_triggerlist) do
		addtri(v.name,v.regexp,"bidu",v.script,v.line)
	end
	closeclass("bidu")
	
	_tb={
		"你目前还没有任何为 busyover=xuan 的变量设定。",
		"不久，你头顶散发出一阵似气似烟的白雾，久久不能散去，接着“哇”的一声吐出一口绿水！",
		"你并未中寒冰毒！",
		"你刚刚催动「玄阴真气」玄真气强行将内伤压制，如在强行压制，只怕会当场倒毙！",
		"你的内力不够！",
		"你并非性命垂危，无需催动玄真气救命！",
		"你的内力修为不够！",
		"只见你睁开双眼，一股淤血从口中流出，身上的内伤居然被强行压下！"
	}
	local  xuan_triggerlist={
	       {name="xuan_dosth1",regexp=linktri(_tb),script=function(n,l,w)    xuan.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(xuan_triggerlist) do
		addtri(v.name,v.regexp,"xuan",v.script,v.line)
	end
	closeclass("xuan")
	
	_tb={
		"药炉下正燃着火。",
		".+深吸一口气，停了下来。",
		"炭火渐渐明亮，看来可以开始了。",
		".+将炭火熄灭。",
		"你熬这么多药干吗？",
		"你开炉一看，炉中之物象一团浆糊一样，看来没什么用。",
		"你取出药材一看，已经烧成一团焦炭。",
		"哟，抱歉啊，我这儿正忙着呢……您请稍候。",
		"这里没有 wang tongzhi 这个人。",
		"你打开了自己的谣言频道。",
		"你目前还没有任何为 busyover=false 的变量设定。",
		"你目前还没有任何为 busyover=miehuo 的变量设定。",
		"你目前还没有任何为 busyover=quyao 的变量设定。",
		"你目前还没有任何为 checkfire=yes 的变量设定。",
		"你向王通治打听有关「你妈可好？」的消息。",
		"数码世界，数字地图，[6|2057]就是这里！",
		"有一天，你踩着七色云彩来迎娶『王通治』",
		"你从药炉中取出一.+",
		"你从王通治那里买下了一.{2}(.+)。",
		"你把一棵阴阳草放进药炉。",
		"你把一钱葵花粉放进药炉。",
		"你把一钱无花果放进药炉。",
	}
	local  aoyao_triggerlist={
	       {name="aoyao_dosth1",regexp=linktri(_tb),script=function(n,l,w)    aoyao.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(aoyao_triggerlist) do
		addtri(v.name,v.regexp,"aoyao",v.script,v.line)
	end
	closeclass("aoyao")
	
	_tb={
		"你目前还没有任何为 check=jifa 的变量设定。",
		"你目前还没有任何为 dealwithitems=over 的变量设定。",
		"您目前的权限是：",
		"从您上次退出到现在，侠客行没有任何官方新闻。",
		"请您输入密码",
		"数码世界，数字地图，(\\d+)就是这里！",
		".+重新连线完毕。",
		".+对不起，由於连接过於频繁，你的地址被暂时封锁。",
		"您要将另一个连线中的相同人物赶出去，取而代之吗？",
	}
	local  login_triggerlist={
	       {name="login_dosth1",regexp=linktri(_tb),script=function(n,l,w)    login.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(login_triggerlist) do
		addtri(v.name,v.regexp,"login",v.script,v.line)
	end
	closeclass("login")
	
	_tb={
		"数码世界，数字地图，(.+)就是这里！",
		"你拿起水蜜桃咬了几口。",
		"你已经吃太饱了，再也塞不下了！",
		"你目前还没有任何为 .+ 的变量设定。",
		--"你目前还没有任何为 check=eating 的变量设定。",
		"你将剩下的水蜜桃吃得乾乾净净。",
	}
	local  eating_triggerlist={
	       {name="eating",regexp=linktri(_tb),script=function(n,l,w)    eating.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(eating_triggerlist) do
		addtri(v.name,v.regexp,"eating",v.script,v.line)
	end
	closeclass("eating")
	
	
	--你身上没有 "..setbusy.." 这样食物。|你正忙着呢，先忍忍吧。
	_tb={
		"你身上没有 .+ 这样食物。","你正忙着呢，先忍忍吧。",
	}
	local  checkbusy_triggerlist={
	       {name="checkbusy",regexp=linktri(_tb),script=function(n,l,w)    checkbusy.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(checkbusy_triggerlist) do
		addtri(v.name,v.regexp,"checkbusy",v.script,v.line)
	end
	closeclass("checkbusy")
end

common.update()
