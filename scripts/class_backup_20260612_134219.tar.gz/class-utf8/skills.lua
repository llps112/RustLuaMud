--if skillslist["jingang-chu"]["lvl"]==nil then skillslist["jingang-chu"]["lvl"]=0 end
--if skillslist["tianshan-zhang"]["lvl"]==nil then skillslist["tianshan-zhang"]["lvl"]=0 end
------------------------------------------------------------------------------------
-- skills_xue_cls
------------------------------------------------------------------------------------
function skills_xue_cls.dosomething1(n,l,w)
	local _f,_tb,a,b,c,d
	wait.make(function()
		if findstring(l,"你向"..me.master.."打听有关「好好学习，天天向上！」的消息。","你向"..me.litmaster.."打听有关「好好学习，天天向上！」的消息。","数码世界，数字地图，2078就是这里！") then
			openclass("skills_xue2")
			alias.xuemaster()
		elseif findstring(l,"双飞，三飞，大家一起飞，先×%d+ 个『 "..me.master.." 』中的第 %d+ 个～～") then
			skills_num=1
			openclass("skills_xue2")
			if me.masterid==nil or string.len(me.masterid)==0 then
				run("id here;set check=masterid")
			else 
				run("h;ask "..me.masterid.." about 好好学习，天天向上！") 
			end
		elseif findstring(l,"有一天，你踩着七色云彩来迎娶『"..tostring(me.master).."』") then
			skills_num=1
			wx.taiji=0
			wx.zhixin=0
			openclass("skills_xue2")
			if me.masterid==nil or string.len(me.masterid)==0 then
				run("id here;set check=masterid")
			else
				run("h;ask "..me.masterid.." about 好好学习，天天向上！")
			end
		elseif findstring(l,"数码世界，数字地图，"..tostring(me.masterroom).."就是这里！") then
			skills_num=1
			wx.taiji=0
			wx.zhixin=0
			openclass("skills_xue2")
			if me.masterid==nil or string.len(me.masterid)==0 then
				run("id here;set check=masterid")
			else
				run("h;ask "..me.masterid.." about 好好学习，天天向上！")
			end
		elseif findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『武馆休息室』立马到达！") then
			skills_num=1
			openclass("skills_xue2")
			alias.xuemaster()
		elseif findstring(l,"数码世界，数字地图，"..me.litmasterroom.."就是这里！") then
			wx.taiji=0
			wx.zhixin=0
			openclass("skills_xue2")
			if me.litmasterid=="zhu" then daytime=true end
			run("h;n;ask "..me.litmasterid.." about 好好学习，天天向上！")
		end
	end)
end

function skills_xue_cls.dosomething2(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"你把正在运行的真气强行压回丹田，站了起来。") then
			if havefj>0 or mj_need_yudi() then
				alias.close_dz()
				alias.uw()
				run("set startworkflow=yes")
			else
				run("yun regenerate;hp;set check=neili")
			end
		elseif findstring(l,"你吐气纳息，硬生生地将内息压了下去，缓缓站了起来。","你现在精神不佳","你的精太低了","你的内力太低了") then
			if havefj>0 or mj_need_yudi() then
				alias.uw()
				run("yun regenerate;set startworkflow=yes")
			else
				run("yun regenerate;hp;set check=neili")
			end
		elseif findstring(l,"你的潜能不够","你的潜能不足","学习知识需要在书院方能静心学习。") then
			--alias.ch()
			closeclass("skills_ask")
			run("hp;set xue=over")
		elseif findstring(l,"你听了.+的讲解，似乎有所理解，却又不能完全体会其中的深意。","你听了老半天，绞尽了脑汁也无法体会.+所讲关于.+的精要。","你仔细听着.+的讲解，细心领悟着其中的奥妙所在。","你开始向.+请教有关「.+」的疑问。") then
			alias.resetidle()
		elseif findstring(l,"你向杨逍打听有关","你潜心苦思","你心浮气躁","你只觉得灵台一片清明","你左思右想") then
			alias.resetidle()
		elseif me.menpai=="gm" and findstring(l,"你开始对着石壁琢磨.+","你目前还没有任何为 guanmotime 的变量设定。") then
			alias.resetidle()
			guanmotime=os.time()
			wait.time(50)
			if os.time()-guanmotime>20 and isopen("skills_xue") then
			run("set guanmotime")
			--print("观摩时间太长了，重置一下发呆参数")
			end
		elseif findstring(l,"你在奇门遁甲上的应用不足，难以继续领会。") then
			alias.resetidle()
			if roomno_now==1735 then
				alias.flyto("香冢","桃花岛")
			else
				skills_num=skills_num+1
				_tb=Split(skills_xue,"|")
				if skills_num>#_tb or (xuelit>0 and daytime) then
					skillsfull=1
					if xuelit>0 then havegoldxuelit=0;xuelit=0 end
					run("set xue=over")
				else 
					alias.xuemaster() 
				end
			end
		elseif findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『香冢』立马到达！") then
			alias.resetidle()
			run("yun regenerate;yun refresh;yun recover;yun buzhen;yun regenerate;yun refresh;yun recover;yun pozhen")
			alias.flytonpc(me.master)
		elseif findstring(l,"你的密宗心法修为不够，无法领会更高深的龙象般若功。","你的实战经验还不足，不能继续学习这项技能！","你的侠义正气太低了。","这项技能你的程度已经不输你师父了。","这项技能你恐怕必须找别人学了。","你体内不同内力互相冲撞，难以领会更高深的内功。","你的内功水平已无法借由学习提升。","你对毒术缺乏实际应用，难以继续提高。","你体内聚毒过多，难以继续提高。","学化功大法，要心狠手辣，奸恶歹毒，你可做得不够呀！","不能传授你这项武功","也许是缺乏实战经验","这项技能你已经不输与我","你对着石壁琢磨了一回儿，觉得石壁上对.+的记载对你来说太浅显了。","你悟性有限，难以领会音律中更高的意境。","奇门遁甲对你来说太深奥了。","你的.+火候不够") then
			alias.resetidle()
			skills_num=skills_num+1
			_tb=Split(skills_xue,"|")
			if skills_num>#_tb or (xuelit>0 and daytime) then
				skillsfull=1
				if xuelit>0 then havegoldxuelit=0;xuelit=0 end
				run("set xue=over")
			else alias.xuemaster() end
		elseif findstring(l,"你目前还没有任何为 busyover=taijiover 的变量设定。") then
			run("yun regenerate;hp;set check=neili")
		elseif findstring(l,"你目前还没有任何为 busyover=taijistart 的变量设定。") then
			alias.xuemaster()
		elseif findstring(l,"你目前还没有任何为 busyover=ask 的变量设定。") then
			if havefj>0 or mj_need_yudi() then 
				alias.startworkflow()
			else
				--run("ask "..me.masterid.." about "..mj.ask)
				run("ask yang xiao about "..mj.ask)
			end
		--elseif findstring(l,"你向.+打听有关「"..mj.ask.."」的消息。") then 
		elseif findstring(l,"你与杨逍共同参悟〖.+〗的精要之处。") then
			alias.resetidle()
			run("ask yang xiao about force")
			--alias.checkbusy("ask") 
		elseif findstring(l,"你聚精会神的听杨逍讲解乾坤大挪移的精妙，似乎有所领会。") then
			alias.checkbusy("ask")
		elseif findstring(l,"你目前还没有任何为 check=masterid 的变量设定。") then
			if me.masterid==nil or string.len(me.masterid)==0 then
				print("未获取到师傅的id，设置为领悟模式")
				usepot="lingwu"
				alias.startxue()
			else
				alias.xuemaster()
			end
		elseif findstring(l,".+教导完毕，见你若有所悟，会心地点了点头。","你听了.+的指导，似乎有些心得。","你领悟完毕，深深吸了口气，站了起来。") then
		    print("学完触发")
			if me.menpai=="th" then run("huan all") end
			if havefj>0 or mj_need_yudi() then
				alias.uw()
				run("set startworkflow=yes")
			else
				if me.menpai=="em" then alias.yunem() 
				elseif me.menpai=="xx" and hp.pot<hp.maxpot then run("give ling to ding chunqiu")
				elseif me.menpai=="gm" then 
					if hp.jing<hp.maxjing/3 and have.swjing>0 then
						run("fu shouwu jing;hp")
					elseif hp.jing<hp.maxjing/2 and have.swjing<1 then
						run("yun regenerate")
					end
				end
				run("hp;set check=neili")
			end
		elseif findstring(l,".+说：钱财乃身外之物也～～～") then
			xuelit=0
			--alias.ch()
			run("set xue=over")
		elseif findstring(l,"你要向谁求教？") then
			if dummy.laopo~=nil and dummy.laopo~="" then dummy.laopo="" end
			alias.startworkflow()
		elseif findstring(l,"你目前还没有任何为 checkhp=addneili 的变量设定。") then
			if (havefj>0 or mj_need_yudi()) and hp.neili>(hp.maxneili*set_neili_job/100) then alias.tdz() end
		elseif findstring(l,"这里没有 "..tostring(me.masterid).." 这个人。","这里没有 "..tostring(me.litmasterid).." 这个人。") then
			if xuelit>0 and not daytime then
				-- 走到书院天黑
				alias.startworkflow()
			else
				--if me.menpai=="th" and roomno_now==1463 then alias.flytonext() else alias.dz("addneili") end
				--师傅挂了
				alias.dz("addneili")
			end
		elseif not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			if dummy.laopo~=nil and dummy.laopo~="" and roomname=="武馆休息室" then
			    print(dummy.laopo)
				wait.make(function()
					_f=function()					
						run("w");alias.xuemaster()
					end
					wait.time(2);_f()
				end)
			elseif xuelit>0 and (daytime or skillslist["literate"]["lvl"]<100) then
				run("h;ask "..me.litmasterid.." about 好好学习，天天向上！")
			elseif me.menpai=="gm" then
				wait.make(function()
					wait.time(2)
					if roomno_now==2077 then run("east") end
					alias.xuemaster()
				end)
			elseif me.menpai=="mj" and always.where=="光明圣火厅" and mj.lvl==5 then
				run("ask yang xiao about "..mj.ask)
			else
				run("h;ask "..me.masterid.." about 好好学习，天天向上！")
			end
		elseif findstring(l,"你目前还没有任何为 xue=over 的变量设定。") then
			alias.close_xue()
			if dummy.laopo~=nil and dummy.laopo~="" then run("tell "..dummy.laopo.." over") end
			if have.jingyao>0 and hp.pot>0 then
				openclass("skills_jingyao")
				alias.dujingyao()
			else
				_tb=Split(skills_xue,"|")
				if skills_num>#_tb and hp.pot>50 then
					usepot="lingwu"
					alias.startxue()
				elseif hp.pot<=50 then
					alias.startworkflow()
				else
					alias.startxue()
				end
			end
		elseif findstring(l,"书院晚上不开，请天亮了再来！") then
			daytime=false
		elseif findstring(l,"一个.+弟子走了过来,对你报拳道：“在下奉"..me.fjmasternick.."之命，请你速回.+处晋见”。") then
			run("halt")
		elseif findstring(l,"你摇了摇头，看起来脑子里一团浆糊，需要休息一下。") then
			alias.resetidle()
			if me.menpai=="wd" and jifa.forcename=="taiji-shengong" then alias.checkbusy("taijiover")
			else
				if hp.jing<(hp.maxjing/3) and have.swjing>0 then 
					run("fu shouwu jing;hp") 
				else
					run("yun regenerate") 
				end
				run("hp;set check=neili") 
			end
		elseif findstring(l,"你目前还没有任何为 check=neili 的变量设定。") then
			alias.resetidle()
			if hp.jing<hp.maxjing/3 and have.swjing>0 then
				run("fu shouwu jing;hp")
			elseif hp.jing<hp.maxjing/2 and have.swjing<1 then
				run("yun regenerate")
			end
			--alias.setmpLimitedMark()  --检查经验上限时间是否已经到了
			if havefj>0 --fj来了，终止学习流程
			or mj_need_yudi() --需要去做御敌job，终止学习流程
			or (pdfjsj()>mpdrutime and mpJobLimited==0 and xuefirst==0 and me.menpai~="wd" and me.menpai~="mj") --经验优先模式，门派任务未达上限(判断fj时间)，终止学习流程 
			then
				alias.startworkflow()
			elseif hp.neili>(hp.maxneili*set_neili_job/100) then 
				alias.xuemaster() 
			else 
				if roomno_now==2078 then run("west");roomno_now=2077 end
				alias.dz1() 
			end
		elseif findstring(l,"你目前还没有任何为 startworkflow=yes 的变量设定。") then
			alias.resetidle()
			alias.close_dz()
			mark.setpot=1
			if havefj>0 or (me.menpai=="mj" and mj.yudi>0 and mj.haveyd>0 and workflow.mp>0) then alias.startworkflow() else run("set xue=over") end
			--alias.startworkflow()
		elseif findstring(l,"练.+必须空手。","蛤蟆从不手持兵刃，所以练.+也必须空手。","修行枯荣禅功必须空手静坐。") then
			alias.resetidle()
			alias.uw()
			alias.checkbusy("taijistart")
		elseif findstring(l,"你已经将太极心法融会入武功之中。","你现在无法将太极心法融会在武功内。","你尚未领会到太极","你的.+无法领.+心法。","你微微一笑，身子缓缓右转，左手持剑向上提起，剑身横於胸前","你缓缓站起身来，双手下垂，手背向外") then
			wx.taiji=1
		elseif findstring(l,"你大周天搬运完毕，将内力合于丹田，入窍归元。") then
			wx.taiji=0
		end
		a,b,c=string.find(l,tostring(me.master).."%s+=%s+%w+%s+%w+,%s+(%w+)")
		if c~=nil then me.masterid=string.lower(c) end
		a,b,c=string.find(l,"(.+)摇了摇头，不想继续教了。")
		if c~=nil and (c==me.master or c==me.litmaster) then
			_f=function() alias.xuemaster() end
			wait.time(2);_f()
		end
		a,b,c=string.find(l,"(.+)现在正忙着呢。")
		if c~=nil and (c==me.master or c==me.litmaster) then
			_f=function() alias.xuemaster() end
			wait.time(2);_f()
		end
	end)
end
------------------------------------------------------------------------------------
-- skills_lian
------------------------------------------------------------------------------------
function skills_lian.dosomething1(n,l,w)
	local _f,_tb
	wait.make(function()
		if findstring(l,"练.+必.+空手","修行枯荣禅功必须空手静坐。") then
			alias.resetidle()
			alias.uw()
			if me.master=="风清扬" then run("jifa dodge dugu-jiujian") end
			alias.lianskills() 
		elseif findstring(l,"玄铁剑法艰深难懂，你琢磨了半天都弄不明白。","你必须有特殊武功方能与基本武技参照领悟！","你不能通过练习招架来提高这项技能","寒冰绵掌必须通过特殊的法门才能修炼。","你的.+修为不够，只能用学","你体内不同内力互相冲撞，难以领会更高深的内功。","你手中没有龙象般若经做参照，再怎么练也没用！","化功大法只能用学.+的来增加熟练度。","你的潜能不够","辟邪剑法乃武林瑰宝，你只能通过研习《葵花宝典》来学习。","你阴柔之气不足，无法练习更高等级的辟邪剑法。","多与别人切磋切磋，在实战中提高你的天地风雷剑法的修为吧。") then
			alias.resetidle()
			skills_num=skills_num+1
			alias.lianskills()
		elseif findstring(l,"已经练习到顶峰了，必须先打好基础才能继续提高") then
			alias.resetidle()
			--if me.menpai=="gm" and roomno_now==2077 then run("n;w;w;w;enter guan;turn left");roomno_now=2065 end
			_tb=Split(skills_lingwu,"|")
			if isopen("skills_lingwu") and skillslist[_tb[skills_num]]["lvl"]>=me.maxlvl then
				if _tb[skills_num]=="force" then
					addforce=1
					skills_num=skills_num+1
				end
				
				run("cha;jifa;set check=skills")
				if me.menpai=="bt" and roomno_now==me.menpailingwuid then run("hold yuanshi")
				elseif me.menpai=="xx" and roomno_now==me.menpailingwuid then run("kneel hassock")
				elseif me.menpai=="xs" and roomno_now==me.menpailingwuid then run("sit lianzuo")
				else alias.lingwuskills() end
			else
				skills_num=skills_num+1
				alias.lianskills()
			end
		elseif findstring(l,"你的内力不够练","你的内力太低了。","你体内的真气不够。") then
			alias.resetidle()
			alias.tlw()
		elseif findstring(l,"你使用的武器不对。","你必须先找一条鞭子才能.+法。") then 
			_f=function()
				alias.uw()
				_tb=Split(skills_lingwu,"|")
				if _tb[skills_num]=="sword" then
					if me.menpai=="th" and have.xiao>0 then
						alias.wi("xiao")
					elseif have.jian>0 then
						alias.wi("jian") 
					else 
						skills_num=skills_num+1
					end
				elseif _tb[skills_num]=="blade" then
					if have.dao>0 then alias.wi("dao") else skills_num=skills_num+1 end
				elseif _tb[skills_num]=="staff" then
					if have.staff>0 then alias.wi(staffid) else skills_num=skills_num+1 end
				elseif _tb[skills_num]=="whip" then
					if have.whip>0 then alias.wi("bian") else skills_num=skills_num+1 end
				elseif _tb[skills_num]=="stroke" then
					if have.bi>0 then alias.wi("bi") else skills_num=skills_num+1 end
				elseif _tb[skills_num]=="hammer" then
					if have.lun~=nil and have.lun>0 then alias.wi("lun") else skills_num=skills_num+1 end
				elseif _tb[skills_num]=="stick" then
					if have.stick>0 then alias.wi("bang") else skills_num=skills_num+1 end
				end
				alias.lianskills()
			end
			wait.time(0.5);_f()
		elseif findstring(l,"你修习完毕，深深吸了一口气，闭目而") then
			alias.resetidle()
			if me.menpai=="em" then alias.yunem() end
			if me.menpai~="dl" and roomno_now~=194 or jifa.forcename~="kurong-changong" then alias.yjl() end
			_tb=Split(skills_lingwu,"|")
			if _tb[skills_num]=="force" then run("yun recover") end
			if me.menpai=="dl" and roomno_now==194 then
				run("w;se;ask duan zhengchun about 调阅")
			elseif isopen("mp_xs_lzjob") or isopen("mp_gb_pre") or isopen("ftb_pre") then 
				run("set lian=over") 
			else 
				run("hp;set lian") 
			end
		elseif findstring(l,"你的精力不够练习.+。") then
			alias.resetidle()
			alias.yjl()
			run("hp;set lian")			
		elseif findstring(l,"你只能练习用 enable 指定的特殊技能") then
			alias.resetidle()
			if isopen("mp_gb_pre") then
				closeclass("skills_lian")
				alias.uw()
				run("u")
				--lianwunum=0
				roomno_now=1116
				run("set lian=full")
			else run("set lian=over") end
		elseif findstring(l,"你目前还没有任何为 lian 的变量设定。") then
			alias.resetidle()
			if roomno_now==2065 and me.menpai=="gm" then run("u;e;e;e;s");roomno_now=2077 end
			if hp.neili<(hp.maxneili*set_neili/100) then
				if me.menpai=="xx" and not isopen("boat") and lingwuat=="menpai" then
					alias.startmp()
				else
					closeclass("skills_lian")
					alias.dz1()
				end
			else
				if (havefj>0 or mj_need_yudi()) and isopen("skills_lingwu") and not isopen("boat") then
					alias.uw()
					run("set startworkflow=yes")
				else
	                closeclass("dazuo_resetidle")
					closeclass("dazuo")
					alias.lianskills()
				end
			end
		elseif findstring(l,"金花杖法只能在实战中提高") then
			--if skillslist["jingang-chu"]["lvl"]~=nil and skillslist["jingang-chu"]["lvl"]>0 then
			--	run("jifa staff jingang-chu")
			--	reEnableSkills=1
			--else
				--alias.uw()
				--skills_num=skills_num+1
				run("jifa staff jingang-chu;jifa staff tianshan-zhang")
				alias.lianskills()
			--end
		elseif findstring(l,"你一挥手中的.+，开始练习.+。","你手中.+，几招后接着一招「.+」使出，如同行云流水。","你反复练习着.+中的「.+」，但却总是不得要领。","你舞着手中的.+, 如行云流水般地演练著.+中几个招式，完全不见滞怠。","你将.+一招一式的演练下来，虽然不见新意，但对招数的基本应用上又有所悟。","你顺著.+气息运行路线，将体内真气缓缓搬运了一个大周天。","你暗自气运丹田，聚精会神地修练着.+。") then
			alias.resetidle()
		end
	end)
end
------------------------------------------------------------------------------------
-- skills_lingwu_cls
------------------------------------------------------------------------------------
function skills_lingwu_cls.dosomething1(n,l,w)
	local _f,_tb,a,b,c,d,_t
	--wait.make(function()
		if findstring(l,"你没有这么多潜能") then
			run("set lingwu=over")
		elseif findstring(l,"你把正在运行的真气强行压回丹田，站了起来。") then
			if havefj>0 or mj_need_yudi() then
				alias.close_dz()
				alias.uw()
				if me.menpai=="bt" then run("release yuanshi") end
				if me.menpai=="qz" then run("return book") end
				if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
				if me.menpai=="dl" then run("dismiss") end
				--run("set startworkflow=yes")
				alias.startworkflow()
			else 
				run("yun regenerate;hp;set check=neili") 
			end
		elseif findstring(l,"你眉头紧锁，看来是领悟不得要领，拍拍衣袖站了起来。","你硬生生收回招式，不继续练习了。","你吐气纳息，硬生生地将内息压了下去，缓缓站了起来。","你硬生生将内息压回丹田，不继续修习了。") then
			if havefj>0 or mj_need_yudi() then
				alias.uw()
				if me.menpai=="bt" then run("release yuanshi") end
				if me.menpai=="qz" then run("return book") end
				if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
				if me.menpai=="dl" then run("dismiss") end
				--run("set startworkflow=yes")
				alias.startworkflow()
			else 
				if hp.jing<(hp.maxjing/3) and have.swjing>0 then 
					run("fu shouwu jing;hp") 
				elseif hp.jing<(hp.maxjing/2) and have.swjing==0 then
					run("yun regenerate") 
				end
				run("hp;set check=neili")
			end
		elseif findstring(l,"你目前还没有任何为 lingwu=over 的变量设定。") then
			if have.jingyao>0 and hp.pot>0 then
				alias.uw()
				alias.close_xue()
				openclass("skills_jingyao")
				alias.dujingyao()
			else
				if me.menpai=="bt" then run("release yuanshi") end
				if me.menpai=="qz" then run("return book") end
				if me.menpai=="em" or me.menpai=="xx" or me.menpai=="xs" then run("stand") end
				if me.menpai=="dl" then run("dismiss") end
				run("set startworkflow=yes")
			end
		elseif findstring(l,"文颖倒在地上，挣扎了几下就死了。") then
			if killwenying>0 then
				run("get jingyao from corpse;sit hassock;drop wuxue jingyao")
				killwenying=0
			end
		elseif findstring(l,"此地无什特别之处，有什么好领悟的？") then
			checkmove.NotGPSMove=1
			if me.menpai=="wd" and lingwuat=="menpai" then
				run("look feng;look feng;look feng")
				alias.lingwuskills()
			--elseif me.menpai=="xs" and lingwuat=="menpai" then
			--	run("sit lianzuo")
			--	alias.lingwuskills()
			else
				--_f=function() 
					if havefj>0 or mj_need_yudi() then
						alias.startworkflow() 
					else 
						alias.startxue() 
					end 
				--end
				--wait.time(2);_f()
			end
		elseif findstring(l,"先解散%(dismiss%)广场上的兵将再离开吧。") then
			run("dismiss")
		elseif findstring(l,"站起来再走吧。","坐着走？") then
			run("stand")
		elseif findstring(l,"一个.+弟子走了过来,对你报拳道：“在下奉"..me.fjmasternick.."之命，请你速回.+处晋见”。") then
			run("halt")
		elseif findstring(l,"数码世界，数字地图，194就是这里") then
			alias.resetidle()
			alias.startlianwu()
		elseif findstring(l,"你要先坐下才能参悟。") then
			run("ask wenying about 武学精要;sit hassock;give wenying wuxue jingyao")
		elseif findstring(l,"你拿了一本《武学大全》，放在桌上准备领悟","你拿著武学精要，在一旁的蒲团上坐了下来，准备开始领悟","你已经坐在一个蒲团上了。") then
			alias.lingwuskills()
		elseif findstring(l,"你深思着所学的.+，潜心领悟有关.+的武学问题。","你坐立不安，潜心苦思.+上的难解之处。","你只觉得体内真气乱窜，.+中的招式象走马灯一般在面前显现！","你的大脑中一片空白。对.+是越想越糊涂。","你心中说不出的烦燥，对.+始终不得一解。","你拿手比划着，似乎对.+中的几个招数有所体会。","你你冥思苦想，对.+渐渐加深一层体会！") then
			alias.resetidle()
		elseif findstring(l,"你的实战经验还不足，不能继续领悟这项技能","你这项基本技能已经炉火纯青，在这里领悟不到什么了。","你只能参悟本派的武功。","你不能自行修炼基本内功！") then
			alias.resetidle()
			skills_num=skills_num+1
			alias.lingwuskills()
		elseif findstring(l,"你的基本功火候未到，必须先打好基础才能继续提高。") then
			alias.resetidle()
			if isopen("skills_lingwu") then 
				alias.lingwuskills()
			else
				skills_num=skills_num+1
				alias.lianskills()
			end
		elseif findstring(l,"玉女心经只能通过相互修炼才能继续提高。","你体内不同内力互相冲撞，难以领会更高深的武功。") then
			alias.resetidle()
			skills_num=skills_num+1
			alias.lianwu()
		elseif findstring(l,"地上已经没有剩余的圆石可供你倒立练功了。","已经坐在上面了！") then
			alias.resetidle()
			alias.lianwu() 
		elseif findstring(l,"已经跪在上面了！") then
			if roomno_now==2112 then alias.flytoid(2113)
			elseif roomno_now==2113 then alias.flytoid(2114)
			elseif roomno_now==2114 then alias.flytoid(2115)
			elseif roomno_now==2115 then alias.flytoid(2112)
			end
		elseif findstring(l,"上乘功夫要颠倒过来练。你站得直直地怎么领悟功夫？") then
			alias.resetidle()
			run("use fire;hold yuanshi")
		elseif findstring(l,"你已经跪在蒲团上面了。","你跪在大蒲团上，望著老仙的画像，若有所思。") then
			alias.resetidle()
			run("ketou hassock")
			alias.lingwuskills()
		elseif findstring(l,"你的.+造诣不够，无法领悟更深一层的.+") then
			alias.resetidle()
			skills_num=skills_num+1
			alias.lingwuskills()
		elseif findstring(l,"你左、右手各抓了块圆石，以手代脚，整个人倒立了起来。","香木不点自燃，你作明空想念，具正念正知，度化园满，入四禅定而般涅磐。") then
			alias.resetidle()
			alias.lingwuskills()
		elseif findstring(l,"你必须有特殊武功方能与基本武技参照领悟") then
			alias.resetidle()
			skillsfull=1
			--alias.ch()
			run("set check=lingwufull")
		elseif findstring(l,"你目前还没有任何为 check=skills 的变量设定。") then
			alias.resetidle()
			if skillslist["hunyuan-yiqi"]==nil then skillslist["hunyuan-yiqi"]={} end
			if skillslist["hunyuan-yiqi"]["lvl"]==nil then skillslist["hunyuan-yiqi"]["lvl"]=0 end
			if skillslist["hunyuan-yiqi"]["sld"]==nil then skillslist["hunyuan-yiqi"]["sld"]=0 end
			if (skillslist["hunyuan-yiqi"]["lvl"]~=nil and skillslist["hunyuan-yiqi"]["lvl"]<me.maxlvl) and (skillslist["hunyuan-yiqi"]["sld"]~=nil and skillslist["hunyuan-yiqi"]["sld"]>=((skillslist["hunyuan-yiqi"]["lvl"]+1)*(skillslist["hunyuan-yiqi"]["lvl"]+1))) then
				zuochan=1
			end
		elseif findstring(l,"你目前还没有任何为 check=neili 的变量设定。") and not isopen("boat") then
			alias.resetidle()
			if havefj>0 --fj来了，终止学习流程
			or mj_need_yudi() --需要去做御敌job，终止学习流程
			or (me.menpai=="gm" and mpJobLimited==0 and xuefirst==0) --经验优先模式，古墓没有fj，判断是否能够采蜜，终止学习流程
			or (pdfjsj()>mpdrutime and mpJobLimited==0 and xuefirst==0 and me.menpai~="wd" and me.menpai~="mj") --经验优先模式，门派任务未达上限(判断fj时间)，终止学习流程 
			then
				alias.uw()
				--run("set startworkflow=yes")
				alias.startworkflow()
			else
				if hp.jing<hp.maxjing/3 and have.swjing>0 then
					run("fu shouwu jing;hp")
				elseif hp.jing<hp.maxjing/2 and have.swjing<1 then
					run("yun regenerate")
				end
				if hp.neili>(hp.maxneili*set_neili_job/100) then 
					alias.lingwuskills() 
				else
					if me.menpai=="xx" then alias.startmp() else alias.dz1() end
				end
			end
		elseif findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") and not isopen("boat") then
			alias.resetidle()
			if havefj>0 or mj_need_yudi() then 
				print("lingwu_cls")
				alias.startworkflow()
			else 				
				wait.make(function()
					_f=function()
						alias.lingwuskills()
					end
					wait.time(2);_f()
				end)
			end
		elseif findstring(l,"数码世界，数字地图，"..tostring(me.menpailingwuid).."就是这里！","数码世界，数字地图，2113就是这里！","数码世界，数字地图，2114就是这里！","数码世界，数字地图，2115就是这里！") then
			alias.resetidle()
			if havefj>0 or mj_need_yudi() then 
			--	alias.close_xue()
				alias.startworkflow()
			else
				skills_num=1
				--_f=function()
					--alias.ch()
					if me.menpai=="dl" then run("ask duan about 调阅;jifa")
					elseif me.menpai=="xx" then run("kneel hassock")
					elseif me.menpai=="hs" then --华山门派领悟需要检测busy状态
						alias.checkbusy("climb")
						if me.master=="风清扬" then run("jifa dodge dugu-jiujian") end
					elseif me.menpai=="qz" then	run("take book")
					elseif me.menpai=="xs" then	run("sit lianzuo")
					elseif me.menpai=="em" then
							killwenying=0
							run("ask wenying about 武学精要;sit hassock;give wenying wuxue jingyao")
					else alias.lingwuskills()
					end
				--end
				--wait.time(3);_f()
			end
		elseif findstring(l,"你目前还没有任何为 busyover=climb 的变量设定。") then  --华山爬崖领悟
			alias.lingwuskills()
		elseif findstring(l,"你目前还没有任何为 check=lingwufull 的变量设定。") then
			alias.resetidle()
			if havefj>0 or mj_need_yudi() then
				alias.uw()
				--run("set startworkflow=yes")
				alias.startworkflow()
			else
				if skillsfull==0 then
					skills_num=1
					alias.lingwuskills()
				else
					if me.menpai=="hs" and me.master=="风清扬" then
						run("jifa dodge huashan-shenfa;jifa sword huashan-jianfa")
						skills_num=1
						reEnableSkills=1
						alias.lianwu()
					else run("set lingwu=over")
					end
				end
			end
		elseif findstring(l,"你领悟完毕，拍拍衣袖站起身来。") then
			alias.resetidle()
			if me.menpai=="em" then alias.yunem() end
			if me.menpai=="dl" then run("dismiss") end
			if hp.jing<(hp.maxjing/3) then
				if have.swjing>0 then run("fu shouwu jing;hp") end 
			end
			run("yun regenerate")
			run("hp;set check=neili")
		elseif findstring(l,"你目前还没有任何为 startworkflow=yes 的变量设定。") then
			alias.resetidle()
			mark.setpot=1
			alias.close_dz()
			--if me.menpai~="th" then usepot="xue" end
			if havefj>0 or mj_need_yudi() then alias.startworkflow() else alias.dz("addneili") end
		elseif findstring(l,"你目前还没有任何为 lian=over 的变量设定。") and not isopen("boat") then
			alias.resetidle()
			skillsfull=1
			--alias.ch()
			--run("set check=lingwufull")
			alias.startworkflow()
		elseif findstring(l,"练.+必须空手。","蛤蟆从不手持兵刃，所以练.+也必须空手。","修行枯荣禅功必须空手静坐。") then
			alias.resetidle()
			alias.uw()
			--weapon_id=weapon_id+1
			if me.master=="风清扬" then run("jifa dodge dugu-jiujian") end
			--_f=function() 
			alias.lianskills() 
			--end
			--wait.time(1);_f()
		elseif findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『达摩院二楼』立马到达！") then
			alias.resetidle()
			skills_num=1
			if lingwu_jf~=nil and lingwu_jf~="" then 
				run(lingwu_jf)
			elseif fjjf~=nil and fjjf~="" then 
				run(fjjf) 
			end
			--alias.ch()
			alias.lingwuskills() 
		elseif findstring(l,"你还没将《武学大全》归还%(return%)，就想溜？") then
			run("return book;set lingwu=over")
		elseif findstring(l,"数码世界，数字地图，213就是这里！") then
			_tb=Split(skills_lingwu,"|")
			if _tb[skills_num]=="force" then skills_num=skills_num+1 end
			run("set check=neili")
		elseif findstring(l,"你还没拿书呢！") then
			run("take book")
		elseif findstring(w[0],"对方正忙着呢，你等会儿在问话吧。\n[> ]*你又没有武学精要，坐下来占位置啊！？") then
			alias.resetidle()
			killwenying=1
			run("kill wenying")
		elseif findstring(w[0],"这里没有 wenying 这个人。\n[> ]*你又没有武学精要，坐下来占位置啊！？") then
			alias.resetidle()
			run("get wuxue jingyao;sit hassock;drop wuxue jingyao")
		elseif findstring(w[0],"你向文颖打听有关「武学精要」的消息。\n文颖说道：啊！你来晚了，四本《武学精要》都被借走了。") then
			--,"对方正忙着呢，你等会儿在问话吧。"
			alias.resetidle()
			killwenying=1
			run("kill wenying")
		elseif findstring(w[0],"你附近没有这样东西。\n[> ]*你又没有武学精要，坐下来占位置啊！？") then
			alias.resetidle()
			run("set lingwu=over")
		elseif findstring(w[0],"此书乃吾留予后代峨嵋聪慧弟子，\n还忘.+能把书留在此处以便他人阅读参悟。") then
			run("give wenying wuxue jingyao;drop wuxue jingyao;set lingwu=over")
		elseif findstring(w[0],"段正淳对着你点了点头。\n段正淳说道：好吧，你就拿此金牌替朕调阅兵将吧。") then
			alias.resetidle()
			skills_num=1
			if lingwu_jf~=nil and lingwu_jf~="" then run(lingwu_jf) else run(fjjf) end
			alias.flytoid(213)
		elseif findstring(w[0],"段正淳对着你摇了摇头。\n段正淳说道：不劳.+费心，朕已派人去调阅了。") then
			alias.resetidle()
			skills_num=1
			alias.flytoid(194) 
		elseif findstring(w[0],"你目前还没有任何为 dealwithitems=over 的变量设定。") then
			alias.startxue()
		end
	--end)
end
------------------------------------------------------------------------------------
-- skills_jingyao
------------------------------------------------------------------------------------
function skills_jingyao.dosomething1(n,l,w)
	local a,b,c
	a,b,c=string.find(l,"数码世界，数字地图，(%d+)就是这里！")
	if c~=nil and (tonumber(c)==me.jingyaoBaseid or tonumber(c)==me.fjbaseid) then
		alias.resetidle()
		if me.menpai=="xs" and have.lxj<1 then run("get longxiang jing") end
		alias.dujingyao()
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 check=neili 的变量设定。","你目前还没有任何为 dazuo=over 的变量设定。","数码世界，数字地图，1020就是这里！") then
		alias.resetidle()
		if havefj>0 --fj来了，终止学习流程
		or mj_need_yudi() --需要去做御敌job，终止学习流程
		or (pdfjsj()>mpdrutime and mpJobLimited==0 and xuefirst==0 and me.menpai~="wd" and me.menpai~="mj") --经验优先模式，门派任务未达上限(判断fj时间)，终止学习流程
		then 
		    print("skills_jingyao")
			alias.startworkflow() 
		else 
			if hp.jing<hp.maxjing/3 and have.swjing>0 then
				run("fu shouwu jing;hp")
			elseif hp.jing<hp.maxjing/2 and have.swjing<1 then
				run("yun regenerate")
			end
			alias.dujingyao() 
		end
	end
	if findstring(l,"你研读完毕，把.+收了起来。") then
		alias.resetidle()
		if me.menpai=="wd" and wx.taiji==0 and jifa.forcename=="taiji-shengong" then alias.checkbusy("taijiover")
		--elseif me.menpai=="em" then alias.yunem() end
		elseif me.menpai=="em" then run("yun zhixin") end
		if hp.jing<(hp.maxjing/3) then
			if have.swjing>0 then run("fu shouwu jing;hp") end
			run("yun regenerate") 
		end
		run("hp;set check=neili")
	end
	if findstring(l,"你正翻看着这.+精要，却一不小心扯破了。","你正要翻看这.+精要，却一不小心扯破了。") then
		alias.resetidle()
		have.jingyao=have.jingyao-1
		if have.jingyao>0 then alias.dujingyao() else run("set dujingyao=over") end
	end
	if findstring(l,"你觉得头上仿佛少了点什麽，读得头昏眼花。","你觉得身上仿佛少了点什麽，读得头昏眼花。","你觉得手中仿佛少了点什麽，读得头昏眼花。") then
		alias.uw()
		run("remove all;wear kulou guan;wear rentou lian;wield lubo")
		alias.startxue()
	end
	if findstring(l,"你的潜能不够，没有办法再成长了。") then
		alias.resetidle()
		run("set dujingyao=over")
	end
	if findstring(l,"你研读着.+中所记载的内容，一下子想通了好几个难点。","你仔细研读着.+，但却百思不得其解。","你思考着.+中所写的内容，忽然对.+大有领悟。","你开始专心研读.+。","你昂起头默默背诵着.+所记录的内容，似乎对.+有些心得。") then
		alias.resetidle()
		if (gxd.type==1 and havefj>0) or ((have.cstlnj>0 or have.lxj>0) and (havefj>0 or (mpJobLimited==0 and xuefirst==0 and pdfjsj()>mpdrutime)))  then run("halt") end --雪山读持世陀罗尼经或者龙象经的时候判断是否去fj或烧尸体
	end
	if findstring(l,"你目前还没有任何为 checkhp=addneili 的变量设定。") then
		if (havefj>0 or mj_need_yudi()) and hp.neili>(hp.maxneili*set_neili_job/100) then alias.tdz() end
	end
	if findstring(l,"你目前还没有任何为 dujingyao=over 的变量设定。") then
		alias.resetidle()
		mark.setpot=1
		alias.uw()
		alias.checkbusy("jyover")
	end
	if findstring(l,"你已经将太极心法融会入武功之中。","你现在无法将太极心法融会在武功内。","你尚未领会到太极","你的.+无法领.+心法。","你微微一笑，身子缓缓右转，左手持剑向上提起，剑身横於胸前","你缓缓站起身来，双手下垂，手背向外") then
		wx.taiji=1
	end
	if findstring(l,"你大周天搬运完毕，将内力合于丹田，入窍归元。") then
		wx.taiji=0
	end
	if findstring(l,"你目前还没有任何为 busyover=taijistart 的变量设定。") then
		if have.jyzj>0 then 
			run("du jiuyin zhenjing 10") 
		else 
			if gxd.type==1 then run("du book 1") else run("du book 10") end
		end
	end
	if findstring(l,"你目前还没有任何为 busyover=taijiover 的变量设定。") then
		run("yun regenerate;hp;set check=neili")
	end
	if findstring(l,"你收起手上的.+，不继续看了。") then
		alias.resetidle()
		if me.menpai=="wd" and wx.taiji==0 and jifa.forcename=="taiji-shengong" then alias.checkbusy("taijiover")
		else run("yun regenerate;hp;set check=neili") end
	end
	if findstring(l,"也许是缺乏实战经验，你对.+上面所说的东西总是无法领会。","你研读了一会儿，但是发现上面所说的对你而言都太") then
		alias.resetidle()
		if have.cstlnj>0 then
			have.cstlnj=0
			run("drop shu")
			alias.startworkflow()
		elseif have.lxj>0 then
			have.lxj=0
			run("drop longxiang jing")
			alias.startworkflow()
		else
			have.nousejy=1
			run("set dujingyao=over")
		end
	end
	if findstring(l,"学习知识需要在书院方能静心学习。") then
		alias.resetidle()
		--if daytime then alias.flytonpc("朱熹") else run("set dujingyao=over") end
		if daytime then alias.flytoid(1020) else run("set dujingyao=over") end
	end
	if findstring(l,"你目前还没有任何为 busyover=jyover 的变量设定。") then
		alias.resetidle()
		run("set startworkflow=yes")
	end
	if findstring(l,"你目前还没有任何为 startworkflow=yes 的变量设定。") then
		alias.resetidle()
		alias.close_dz()
		mark.setpot=1
		if havefj>0 or mj_need_yudi() then alias.startworkflow() else alias.dz("addneili") end
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function skills.update()
	local _tb
	_tb={
	"数码世界，数字地图，.+就是这里！",
	"你目前还没有任何为 .+ 的变量设定。",
	"你研读完毕，把.+收了起来。",
	"你正翻看着这.+精要，却一不小心扯破了。","你正要翻看这.+精要，却一不小心扯破了。",
	"你觉得头上仿佛少了点什麽，读得头昏眼花。","你觉得身上仿佛少了点什麽，读得头昏眼花。","你觉得手中仿佛少了点什麽，读得头昏眼花。",
	"你的潜能不够，没有办法再成长了。",
	"你研读着.+中所记载的内容，一下子想通了好几个难点。","你仔细研读着.+，但却百思不得其解。","你思考着.+中所写的内容，忽然对.+大有领悟。","你开始专心研读.+。","你昂起头默默背诵着.+所记录的内容，似乎对.+有些心得。",
	"你已经将太极心法融会入武功之中。","你现在无法将太极心法融会在武功内。","你尚未领会到太极","你的.+无法领.+心法。","你微微一笑，身子缓缓右转，左手持剑向上提起，剑身横於胸前","你缓缓站起身来，双手下垂，手背向外",
	"你大周天搬运完毕，将内力合于丹田，入窍归元。",
	"你收起手上的.+，不继续看了。",
	"也许是缺乏实战经验，你对.+上面所说的东西总是无法领会。","你研读了一会儿，但是发现上面所说的对你而言都太",
	"学习知识需要在书院方能静心学习。",
	}
	local skills_jingyao_triggerlist={
	       {name="skills_jingyao_dosth1",regexp=linktri(_tb),script=function(n,l,w)    skills_jingyao.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(skills_jingyao_triggerlist) do
		addtri(v.name,v.regexp,"skills_jingyao",v.script,v.line)
	end
	closeclass("skills_jingyao")

	_tb={
		"对方正忙着呢，你等会儿在问话吧。\\n(> > > |> > |> |)你又没有武学精要，坐下来占位置啊！？\\Z",
		"这里没有 wenying 这个人。\\n(> > > |> > |> |)你又没有武学精要，坐下来占位置啊！？\\Z",
		"你向文颖打听有关「武学精要」的消息。\\n文颖说道：啊！你来晚了，四本《武学精要》都被借走了。\\Z",
		"你附近没有这样东西。\\n(> > > |> > |> |)你又没有武学精要，坐下来占位置啊！？\\Z",
		"此书乃吾留予后代峨嵋聪慧弟子，\\n还忘.+能把书留在此处以便他人阅读参悟。\\Z",
		"段正淳对着你点了点头。\\n段正淳说道：好吧，你就拿此金牌替朕调阅兵将吧。\\Z",
		"段正淳对着你摇了摇头。\\n段正淳说道：不劳.+费心，朕已派人去调阅了。\\Z",
	}
	local  skills_lingwu_m_triggerlist={
	       {name="skills_lingwu_m_triggerlist",line=2,regexp=linktri(_tb),script=function(n,l,w)    skills_lingwu_cls.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(skills_lingwu_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"skills_lingwu",v.script,v.line)
	end

	_tb={
	"你没有这么多潜能",
	"你把正在运行的真气强行压回丹田，站了起来。",
	"你眉头紧锁，看来是领悟不得要领，拍拍衣袖站了起来。","你硬生生收回招式，不继续练习了。","你吐气纳息，硬生生地将内息压了下去，缓缓站了起来。","你硬生生将内息压回丹田，不继续修习了。",
	"你目前还没有任何为 .+ 的变量设定。",
	"文颖倒在地上，挣扎了几下就死了。",
	"此地无什特别之处，有什么好领悟的？",
	"先解散.+广场上的兵将再离开吧。",
	"站起来再走吧。","坐着走？",
	"一个.+弟子走了过来,对你报拳道：“在下奉.+之命，请你速回.+处晋见”。",
	"数码世界，数字地图，.+就是这里",
	"你要先坐下才能参悟。",
	"你拿了一本《武学大全》，放在桌上准备领悟","你拿著武学精要，在一旁的蒲团上坐了下来，准备开始领悟","你已经坐在一个蒲团上了。",
	"你深思着所学的.+，潜心领悟有关.+的武学问题。","你坐立不安，潜心苦思.+上的难解之处。","你只觉得体内真气乱窜，.+中的招式象走马灯一般在面前显现！","你的大脑中一片空白。对.+是越想越糊涂。","你心中说不出的烦燥，对.+始终不得一解。","你拿手比划着，似乎对.+中的几个招数有所体会。","你你冥思苦想，对.+渐渐加深一层体会！",
	"你的实战经验还不足，不能继续领悟这项技能","你这项基本技能已经炉火纯青，在这里领悟不到什么了。","你只能参悟本派的武功。","你不能自行修炼基本内功！",
	"你的基本功火候未到，必须先打好基础才能继续提高。",
	"玉女心经只能通过相互修炼才能继续提高。","你体内不同内力互相冲撞，难以领会更高深的武功。",
	"地上已经没有剩余的圆石可供你倒立练功了。",".+已经坐在上面了！",
	".+已经跪在上面了！",
	"上乘功夫要颠倒过来练。你站得直直地怎么领悟功夫？",
	"你已经跪在蒲团上面了。","你跪在大蒲团上，望著老仙的画像，若有所思。",
	"你的.+造诣不够，无法领悟更深一层的.+",
	"你左、右手各抓了块圆石，以手代脚，整个人倒立了起来。","香木不点自燃，你作明空想念，具正念正知，度化园满，入四禅定而般涅磐。",
	"你必须有特殊武功方能与基本武技参照领悟",
	"你领悟完毕，拍拍衣袖站起身来。",
	"练.+必须空手。","蛤蟆从不手持兵刃，所以练.+也必须空手。","修行枯荣禅功必须空手静坐。",
	"你口念咒语『神马都是浮云,虾米都是尘土』，『达摩院二楼』立马到达！",
	"你还没将《武学大全》归还.+，就想溜？",
	"你还没拿书呢！",
	"你目前还没有任何为 dealwithitems=over 的变量设定。",
	}
	local skills_lingwu_triggerlist={
	       {name="skills_lingwu_dosth1",regexp=linktri(_tb),script=function(n,l,w)    skills_lingwu_cls.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(skills_lingwu_triggerlist) do
		addtri(v.name,v.regexp,"skills_lingwu",v.script,v.line)
	end
	closeclass("skills_lingwu")
	
	_tb={
	"练.+必.+空手","修行枯荣禅功必须空手静坐。",
	"玄铁剑法艰深难懂，你琢磨了半天都弄不明白。","你必须有特殊武功方能与基本武技参照领悟！","你不能通过练习招架来提高这项技能","寒冰绵掌必须通过特殊的法门才能修炼。","你的.+修为不够，只能用学","你体内不同内力互相冲撞，难以领会更高深的内功。","你手中没有龙象般若经做参照，再怎么练也没用！","化功大法只能用学.+的来增加熟练度。","你的潜能不够","辟邪剑法乃武林瑰宝，你只能通过研习《葵花宝典》来学习。","你阴柔之气不足，无法练习更高等级的辟邪剑法。","多与别人切磋切磋，在实战中提高你的天地风雷剑法的修为吧。",
	".+已经练习到顶峰了，必须先打好基础才能继续提高",
	"你的内力不够练","你的内力太低了。","你体内的真气不够。",
	"你使用的武器不对。","你必须先找一条鞭子才能练鞭法。",
	"你修习完毕，深深吸了一口气，闭目而",
	"你的精力不够练习.+。",
	"你只能练习用 enable 指定的特殊技能",
	"你目前还没有任何为 .+ 的变量设定。",
	"金花杖法只能在实战中提高",
	"你一挥手中的.+，开始练习.+。","你手中.+，几招后接着一招「.+」使出，如同行云流水。","你反复练习着.+中的「.+」，但却总是不得要领。","你舞着手中的.+, 如行云流水般地演练著.+中几个招式，完全不见滞怠。","你将.+一招一式的演练下来，虽然不见新意，但对招数的基本应用上又有所悟。","你顺著.+气息运行路线，将体内真气缓缓搬运了一个大周天。","你暗自气运丹田，聚精会神地修练着.+。",
	"你必须先找一条鞭子才能练.+鞭法。",
	}
	local skills_lian_triggerlist={
	       {name="skills_lian_dosth1",regexp=linktri(_tb),script=function(n,l,w)    skills_lian.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(skills_lian_triggerlist) do
		addtri(v.name,v.regexp,"skills_lian",v.script,v.line)
	end
	closeclass("skills_lian")
	
	_tb={
	"你向.+打听有关「好好学习，天天向上！」的消息。",
	"数码世界，数字地图，.+就是这里！",
	"双飞，三飞，大家一起飞，先.+ 个『 .+ 』中的第 .+ 个～～",
	"有一天，你踩着七色云彩来迎娶『.+』",
	"你口念咒语『神马都是浮云,虾米都是尘土』，『.+』立马到达！",
	}
	local skills_xue_triggerlist={
	       {name="skills_xue_dosth1",regexp=linktri(_tb),script=function(n,l,w)    skills_xue_cls.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(skills_xue_triggerlist) do
		addtri(v.name,v.regexp,"skills_xue",v.script,v.line)
	end
	closeclass("skills_xue")
	
	_tb={
		"你把正在运行的真气强行压回丹田，站了起来。",
		"你吐气纳息，硬生生地将内息压了下去，缓缓站了起来。",
		"你现在精神不佳",
		"你的精太低了",
		"你的内力太低了",
		"你的潜能不够",
		"你的潜能不足",
		"学习知识需要在书院方能静心学习。",
		"你听了.+的讲解，似乎有所理解，却又不能完全体会其中的深意。",
		"你听了老半天，绞尽了脑汁也无法体会.+所讲关于.+的精要。",
		"你仔细听着.+的讲解，细心领悟着其中的奥妙所在。",
		"你开始向.+请教有关「.+」的疑问。",
		"你与杨逍共同参悟","你潜心苦思","你聚精会神的听杨逍讲解乾坤大挪移的精妙，似乎有所领会。",
		"你心浮气躁",
		"你只觉得灵台一片清明",
		"你左思右想",
		"你开始对着石壁琢磨.+","你目前还没有任何为 .+ 的变量设定。",
		"你在奇门遁甲上的应用不足，难以继续领会。",
		"你口念咒语『神马都是浮云,虾米都是尘土』，『香冢』立马到达！",
		"你的密宗心法修为不够，无法领会更高深的龙象般若功。",
		"你的实战经验还不足，不能继续学习这项技能！",
		"你的侠义正气太低了。",
		"这项技能你的程度已经不输你师父了。",
		"这项技能你恐怕必须找别人学了。",
		"你体内不同内力互相冲撞，难以领会更高深的内功。",
		"你的内功水平已无法借由学习提升。",
		"你对毒术缺乏实际应用，难以继续提高。",
		"你体内聚毒过多，难以继续提高。",
		"学化功大法，要心狠手辣，奸恶歹毒，你可做得不够呀！",
		"不能传授你这项武功",
		"也许是缺乏实战经验",
		"这项技能你已经不输与我",
		"你对着石壁琢磨了一回儿，觉得石壁上对.+的记载对你来说太浅显了。",
		"你悟性有限，难以领会音律中更高的意境。",
		"奇门遁甲对你来说太深奥了。",
		"你的.+火候不够",
		"你向.+打听有关「.+」的消息。",
		--"你与杨逍共同参悟〖.+〗的精要之处。",
		".+教导完毕，见你若有所悟，会心地点了点头。",
		"你听了.+的指导，似乎有些心得。",
		"你领悟完毕，深深吸了口气，站了起来。",
		".+说：钱财乃身外之物也～～～",
		"你要向谁求教？",
		".+摇了摇头，不想继续教了。",
		".+现在正忙着呢。",
		"这里没有 .+ 这个人。",
		"书院晚上不开，请天亮了再来！",
		"一个.+弟子走了过来,对你报拳道：“在下奉.+之命，请你速回.+处晋见”。",
		"你摇了摇头，看起来脑子里一团浆糊，需要休息一下。",
		"练.+必须空手。","蛤蟆从不手持兵刃，所以练.+也必须空手。","修行枯荣禅功必须空手静坐。",
		"你已经将太极心法融会入武功之中。",
		"你现在无法将太极心法融会在武功内。",
		"你尚未领会到太极","你的.+无法领.+心法。",
		"你微微一笑，身子缓缓右转，左手持剑向上提起，剑身横於胸前",
		"你缓缓站起身来，双手下垂，手背向外",
		"你大周天搬运完毕，将内力合于丹田，入窍归元。",
		"\\S+\\s+\\=\\s+\\w+\\s+\\w+\\,\\s+\\w+",
	}
	local skills_xue_triggerlist={
	       {name="skills_xue_dosth2",regexp=linktri(_tb),script=function(n,l,w)    skills_xue_cls.dosomething2(n,l,w)  end,},
	}
	for k,v in pairs(skills_xue_triggerlist) do
		addtri(v.name,v.regexp,"skills_xue2",v.script,v.line)
	end
	closeclass("skills_xue2")
	--AddTimer("skills_ask_timer", 0, 0, 0.5, "", timer_flag.Enabled + timer_flag.Replace, "skills_ask.timer")
	--SetTimerOption("skills_ask_timer", "group", "skills_ask")
	--closeclass("skills_ask")
end
skills.update()
