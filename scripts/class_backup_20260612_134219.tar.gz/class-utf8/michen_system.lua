
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
flag_base=1064-------KeepEvaluating = 8,RegularExpression = 32,Replace = 1024
flag_base_enable=1065-------KeepEvaluating = 8,RegularExpression = 32,Replace = 1024,Enabled = 1
flag_base_temp=1065+trigger_flag.Temporary-------Temporary = 16384

function ltrim (r, s)
  if s == nil then
    s, r = r, "%s+"
  end
  return (r.gsub (s, "^" .. r, ""))
end

function rtrim (r, s)
  if s == nil then
    s, r = r, "%s+"
  end
  return (r.gsub (s, r .. "$", ""))
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
table_getn=function(a)
	local _f
	if type(a)~="table" then 
		print("table_get函数变量类型错误")
		return 0
	end
	_f=0
	for k,v in pairs(a) do 
		_f=_f+1
	end
	return _f
end
maketri=function(name,tb,group,ft,line)
	local a
	a=name.."_"..maketri_num
	--print(ft)
	local triggerlist={
		   {name=a,regexp=linktri(tb),script=ft,},
	}
	if tonumber(line)==nil then
		for k,v in pairs(triggerlist) do
			addtri(v.name,v.regexp,group,v.script,v.line)
		end
	else
		for k,v in pairs(triggerlist) do
			addtri_multiline(v.name,v.regexp,group,v.script,line)
		end
	end
	maketri_num=maketri_num+1
end
addtri=function(triname,trimatch,trigroup,triscript,triflag,trisequence)
		local 	flag_base=1064-------KeepEvaluating = 8,RegularExpression = 32,Replace = 1024
		local 	flag_base_enable=1065-------KeepEvaluating = 8,RegularExpression = 32,Replace = 1024,Enabled = 1
		local 	flag_base_temp=1065+trigger_flag.Temporary-------Temporary = 16384

			if triflag==nil or triflag=="" then triflag=flag_base_enable end
			if trisequence==nil then trisequence=10 end
			if type(triscript)=="string" then
				tri_returnvalue=check(AddTriggerEx(triname, trimatch, "", triflag, -1, 0, "",  triscript, 0, trisequence))
			end
			if type(triscript)=="function"	then
				local Addtri_fun = "addtri_" .. GetUniqueNumber ()
				_G [Addtri_fun] = triscript
				tri_returnvalue=check(AddTriggerEx(triname, trimatch, "", triflag, -1, 0, "",  Addtri_fun, 0, trisequence))
			end	
			SetTriggerOption(triname,"group",trigroup)
			return tri_returnvalue
end

addtri_multiline=function(triname,trimatch,trigroup,triscript,multiline)

			if triflag==nil or triflag=="" then triflag=flag_base_enable end
			if trisequence==nil then trisequence=10 end
			if type(triscript)=="string"	then
						tri_returnvalue=check(AddTriggerEx(triname, trimatch, "", triflag, -1, 0, "",  triscript, 0, trisequence))
			end
			if type(triscript)=="function"	then
		
				local Addtri_fun = "addtri_" .. GetUniqueNumber ()
				_G [Addtri_fun] = triscript
				tri_returnvalue=check(AddTriggerEx(triname, trimatch, "", triflag, -1, 0, "",  Addtri_fun, 0, trisequence))
			end	
			SetTriggerOption(triname,"group",trigroup)
			SetTriggerOption(triname,"multi_line", true)
			SetTriggerOption(triname,"lines_to_match", multiline)
			return tri_returnvalue
end

addtri_noecho=function(triname,trimatch,trigroup,triscript)

			local triflag=flag_base_enable
			local trisequence=10
			if type(triscript)=="string"	then
						tri_returnvalue=check(AddTriggerEx(triname, trimatch, "", triflag, -1, 0, "",  triscript, 0, trisequence))
			end
			if type(triscript)=="function"	then
		
				local Addtri_fun = "addtri_" .. GetUniqueNumber ()
				_G [Addtri_fun] = triscript
				tri_returnvalue=check(AddTriggerEx(triname, trimatch, "", triflag, -1, 0, "",  Addtri_fun, 0, trisequence))
			end	
			SetTriggerOption(triname,"group",trigroup)
			SetTriggerOption(triname,"omit_from_output",1)
			return tri_returnvalue
end
isopen=function(trigroup)
	if GetTriggerList() ~= nil then
		for k,v in pairs(GetTriggerList()) do
			if GetTriggerInfo(v,26)==trigroup then
				return GetTriggerInfo(v,8)
			end
		end
	end
	return false
end
isopen_timer=function(TimerGroup)
	if GetTimerList() ~= nil then
		for k,v in pairs(GetTimerList()) do
			if GetTimerInfo(v,19)==TimerGroup then
				return GetTimerInfo(v,6)
			end
		end
	end
	return false
end
function openclass(a)
	-- print("Open class：'"..a.."'")
	EnableTriggerGroup(a,true)
	EnableTimerGroup(a,true)
end
function closeclass(a)
	-- print("Close class：'"..a.."'")
	EnableTriggerGroup(a,false)
	EnableTimerGroup(a,false)
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
linktri=function(triggerlist)
----说明：连接数字项表格个各个值成为trigger。
----此函数默认占用w[1]="",w[2]=全部表达式，列表中的参数从w[3]开始。
----括号开始的变量为w[2]=("..rtrim("|",_str)..")"，里面有()则为w[3]，第一个w[1]=""
	local _str=""
	--if triggerlist~=nil then
	if type(triggerlist)=="table" then
		for k,v in pairs(triggerlist) do
			_str=_str..v.."\\w*|"
		end
		_str="^(> > > |> > |> |)("..rtrim("|",_str)..")"----括号开始的变量为w[2]=("..rtrim("|",_str)..")"，里面有()则为w[3]，第一个w[1]=""
		----_str="^(> |)"..rtrim("|",_str)
		----_str="^(.+|)("..rtrim("|",_str)..")"
	elseif type(triggerlist)=="string" then
		_str="^(> > > |> > |> |)"..triggerlist
		--_str="^(> > > |> > |> |)("..rtrim("|",_str)..")"----括号开始的变量为w[2]=("..rtrim("|",_str)..")"，里面有()则为w[3]，第一个w[1]=""
	else
		print("[::System::]>>Error: function-->linktri arg 'triggerlist' is nil!!<<")
		return nil
	end
	return _str
end
linktri2=function(triggerlist)
----说明：连接数字项表格个各个值成为trigger。
----此函数默认占用w[1]="",w[2]=全部表达式，列表中的参数从w[3]开始。
----括号开始的变量为w[2]=("..rtrim("|",_str)..")"，里面有()则为w[3]，第一个w[1]=""
	local _str=""
	if triggerlist~=nil then
		for k,v in pairs(triggerlist) do
			_str=_str..v.."|"
		end

		_str="^(> > > |> > |> |)("..rtrim("|",_str)..")"----括号开始的变量为w[2]=("..rtrim("|",_str)..")"，里面有()则为w[3]，第一个w[1]=""
		----_str="^(> |)"..rtrim("|",_str)
		----_str="^(.+|)("..rtrim("|",_str)..")"
	else
		print("[::System::]>>Error: function-->linktri arg 'triggerlist' is nil!!<<")
		return nil
	end
	return _str
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function GetStyle(styleRuns,wantedColumn)
local currentColumn=1
   -- check arguments
   assert (type (styleRuns) == "table", "First argument to GetStyle must be table of style runs")

   assert (type (wantedColumn) == "number" and wantedColumn >= 1, "Second argument to GetStyle must be column number to find")

   -- go through each style
   for item, style in ipairs (styleRuns) do
     local position = wantedColumn - currentColumn + 1  -- where letter is in style
     currentColumn = currentColumn + style.length       -- next style starts here
     if currentColumn > wantedColumn then  -- if we are within this style
        return style, string.sub(style.text, position, position), item  -- done
     end -- if found column
   end -- for each style

   -- if not found: result is nil

end -- function GetStyle
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function findstring(str,...)
	----useage:
	----stings="abcde"
	-----findstring(strings,"a","b")===>return true
	if str==nil then return false end

	local compare_str=false
	for _, v in ipairs{...} do
		compare_str=compare_str or string.find(str,v)
	end --for
	return compare_str
end

function findstrlist(str,list)
-----print("::system::Debughere::")
	----useage:
	----stings="abcde"
	----list={"abcde","abadf"}
	-----findstring(strings,"abcde","abadf")===>return true
	if str==nil then return false end
	if list==nil then return false end
	
	local compare_str=false
	for _, v in pairs(list) do
		
		compare_str=compare_str or string.find(str,v)
		if compare_str==nil then compare_str=false end
		------print("compare_str in for ::",compare_str,v)
	end --for
	------print("compare_str",compare_str)
	return compare_str
end

function findstrlist2(str,list)
	if str==nil then return false end
	if list==nil then return false end
	local compare_str=false
	for _, v in pairs(list) do
		
		compare_str=compare_str or tostring(str)==tostring(v)
		if compare_str==nil then compare_str=false end
	end --for
	return compare_str
end
--str为需要分割字符串， p 为分割符
function strexplit(str, delim, maxNb)   
    -- Eliminate bad cases...   
    if string.find(str, delim) == nil then  
        return { str }  
    end  
    if maxNb == nil or maxNb < 1 then  
        maxNb = 0    -- No limit   
    end  
    local result = {}  
    local pat = "(.-)" .. delim .. "()"   
    local nb = 0  
    local lastPos   
    for part, pos in string.gmatch(str, pat) do  
        nb = nb + 1  
        result[nb] = part   
        lastPos = pos   
        if nb == maxNb then break end  
    end  
    -- Handle the last field   
    if nb ~= maxNb then  
        result[nb + 1] = string.sub(str, lastPos)   
    end  
    return result   
end

invDirection=function(dir)
	result=nil
	if dir=="east" then
		result="west"
	elseif dir=="south" then
		result="north"
	elseif dir=="west" then
		result="east"
	elseif dir=="north" then
		result="south"
	elseif dir=="southeast" then
		result="northwest"
	elseif dir=="southwest" then
		result="northeast"
	elseif dir=="northwest" then
		result="southeast"
	elseif dir=="northeast" then
		result="southwest"
	elseif dir=="northup" then
		result="southdown"
	elseif dir=="southdown" then
		result="northup"
	elseif dir=="southup" then
		result="northdown"
	elseif dir=="northdown" then
		result="southup"
	elseif dir=="eastup" then
		result="westdown"
	elseif dir=="eastdown" then
		result="westup"
	elseif dir=="westup" then
		result="eastdown"
	elseif dir=="westdown" then
		result="eastup"
	elseif dir=="up" then
		result="down"
	elseif dir=="down" then
		result="up"
	elseif dir=="enter" then
		result="out"
	elseif dir=="out" then
		result="enter"
	end
	return result
end

local function ctonum(str)
    local _nums = {
        ["一"] = 1,
        ["二"] = 2,
        ["三"] = 3,
        ["四"] = 4,
        ["五"] = 5,
        ["六"] = 6,
        ["七"] = 7,
        ["八"] = 8,
        ["九"] = 9
    }

    local length = #str
    if length % 2 == 1 then
        return 0
    end

    local result = 0
    local unit = 1
    local wan = 1

    for i = length, 1, -2 do
        local char = string.sub(str, i - 1, i)
        if char == "十" then
            unit = 10 * wan
            if i == 2 then
                result = result + unit
            elseif _nums[string.sub(str, i - 3, i - 2)] == nil then
                result = result + unit
            end
        elseif char == "百" then
            unit = 100 * wan
        elseif char == "千" then
            unit = 1000 * wan
        elseif char == "万" then
            unit = 10000 * wan
            wan = 10000
        else
            if _nums[char] ~= nil then
                result = result + _nums[char] * unit
            end
        end
    end

    return tonumber(result)
end
-- 设置 ctonum 函数为全局函数
_G.ctonum = ctonum

runre=rex.new("([^;*\\\\]+)")
walkecho=true
allcmd={}
cmd_time=os.time()
cmd_flag=true

function cmd.numsdecrease() 
	if cmd.nums>0 then cmd.nums=cmd.nums-2 
	elseif cmd.nums<0 then cmd.nums=0
	else
		closeclass("cmdcount") 
	end
end
run=function(str)
	local i=0
	local _cmd,_tb,_f
	if not IsConnected() then Connect();return else openclass("cmdcount") end
	if str==nil then 
		if #allcmd>0 then
			str="" 
			if isopen("gps_start") and allcmd[1]~="halt" and not isopen("kill") then --走路间隙插入halt，减少被自动攻击的NPC拦住几率
				table.insert(allcmd,"halt") 
			end
		else
			--print("命令表单已经")
			return
		end
	end
	n=runre:gmatch(str,function (m, t)
		i=i+1
		--print("插入的命令:"..m)
		if m~="" then 
			table.insert(allcmd,1,m) 
		else
			print("放弃插入空白命令")
		end
	end)
	if (allcmd==nil) or #allcmd<1 then return end
	if cmd.nums>=cmd.setnums and #allcmd>0 then
		cmd_flag=false
		wait.make(function()
		_f=function()
		cmd_flag=true;run("")
		end
		wait.time(0.7);_f()
		end)
		return
	end
	-----------------------------
	--if (allcmd==nil) or #allcmd<1 then return end
	while cmd.nums<=cmd.setnums and #allcmd>0 do
		_cmd=table.remove(allcmd)
		--print("开始执行命令:".._cmd.." "..cmd.nums)
		if _cmd==nil then break end
		local _t=string.gsub(_cmd,"-","")
		if findstring(_cmd,"xxpfm") then
			_tb=Split(_cmd," ")
			pcall(alias.xxpfm,_tb[2])
		elseif aliasStepNum[_t]~=nil then 
			--print("/alias.".._t.."()")
			Execute("/alias.".._t.."()")
			cmd.nums=cmd.nums+aliasStepNum[_t]
		else 
			Execute(_cmd)
			cmd.nums=cmd.nums+1	
		end
	end
	run()
end
function additem(a,b)
	if b==nil or a==nil then return end
	if a==nil or a=="" then return b end
	if findstring(a,b) then return a end
	return a.."|"..b
end
function in_array(b,list)
	if not list then
		return false   
	end 
	if list then
		for k, v in pairs(list) do
			if v.tableName ==b then
				return true
			end
		end
	end
end
   
function addlog(a)
	local path,msg,f
	--path=GetInfo(56).."\\"..GetInfo(58)
	path=GetInfo(58)
	f=io.open(path.."account_"..me.charid.."_log.txt","a+")									--先打开文件a.lua（文件不存在会创建），
	if f~=nil then
		msg="["..os.date("%Y-%m-%d %H:%M:%S", os.time()).."]"..a
		f:write(tostring(msg).."\n")				--写到文件中
		f:close()
	end
	--AppendToNotepad("watching", tostring(me.charname)..tostring(msg).."\r\n")
	-- Info(tostring(me.charname)..tostring(msg))
end
function addlog2(a)
	local path,msg,f
	--path=GetInfo(56).."\\"..GetInfo(58)
	path=GetInfo(58)
	f=io.open(path.."table"..me.charid..".lua","a+")	--先打开文件a.lua（文件不存在会创建），
	if type(a)=="table" then
		if f~=nil then
			msg="table={"
			
			f:write(tostring(msg).."\n")				--写到文件中
			--f:close()
			for k,v in ipairs(a) do
				msg="{"
				if type(v)=="table" then
					for kk,vv in ipairs(v) do
						msg=msg.."{"
						if type(vv)=="table" then
							--msg=""
							for kkk,vvv in ipairs(vv) do
								--print(vvv)	
								msg=msg.."'"..vvv.."',"
							end
						msg=msg.."},"
						end
					end
					--f=io.open(path.."table"..me.charid..".lua","a+")	--先打开文件a.lua（文件不存在会创建），
					f:write(tostring(msg).."},\n")				--写到文件中
					--f:close()
				end
			end
		end
		--f=io.open(path.."table"..me.charid..".lua","a+")	--先打开文件a.lua（文件不存在会创建），
		f:write(tostring("}").."\n")				--写到文件中
		f:close()
	end
end
--[[
function save_config()
	local path=string.gsub(GetInfo(35),"michen_xkx.lua","conf_"..me.charid..".lua")
	local f=io.open(path,"w+")
	local _tb={
		"setting",
		me={
			"lun",
			"drugbusy",
			"expadd",
		},
	}
	for k,v in pairs(_tb) do
		print(k,v)
		f:write(write_config_type(k,v).."\n")
	end
	f:close()
end
function write_config_type(k,v)
	if tonumber(_G[v])~=nil or type(_G[v])=="boolean" then
		return k.."="..tostring(_G[v])
	end
	if type(_G[v])=="string" then
		return k.."=\"".._G[v].."\""
	end
	if type(_G[v])=="table" then
		local msg=""
		msg=k.."={\n"
		for i,j in v do
			msg=msg.."\t"..write_config_type(i,j)..","
		end
		msg=msg.."}"
	end
end
save_config()
]]




