------------------------------------------------------------------------------------
-- mp_xx_pre
------------------------------------------------------------------------------------
function mp_xx_pre.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
		alias.resetidle()
		alias.flytoid(me.menpaiJobStart)
	end
	if findstring(l,"数码世界，数字地图，"..me.menpaiJobStart.."就是这里！") then
		alias.resetidle()
		if hp.neili<500 or jifa.forcename~="huagong-dafa" then alias.dz(set_neili) else alias.checkbusy("pre") end
	end
	if not isopen("boat") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。","你目前还没有任何为 busyover=pre 的变量设定。") then
		alias.resetidle()
		if xx.sucknow>#xxsuck_list then xx.sucknow=1 end
		run("hp;set checkhp")
	end
	if findstring(l,"你目前还没有任何为 checkhp 的变量设定。") then
		alias.resetidle()
		if xx_xrd~=nil and xx_xrd>0 then run("w;out") end
		--if de_bug>0 then print("开始检查状态,中毒或状态不好就去suck npc") end
		--if jifa.forcename=="huagong-dafa" and (stat.havedu>0 or hp.healthqi<95 or hp.neili<(hp.maxneili*set_neili_global/100)) then
		if jifa.forcename=="huagong-dafa" and (hp.healthjing<70 or hp.healthqi<75 or hp.neili<(hp.maxneili*set_neili_global/100)) then
			print("开始suck内力")
			xx.suckid=xxsuck_list[xx.sucknow]["suckid"]
			xx.suckname=xxsuck_list[xx.sucknow]["suckname"]
			xx.suckroom=xxsuck_list[xx.sucknow]["suckroom"]
			alias.flytoid(xx.suckroom)
		elseif hp.neili<(hp.maxneili*set_neili_global/100) and usepot=="lingwu" and hp.pot>hp.maxpot/2 and xuefirst>0 then
			print("suck neili force lingwu")
			xx.suckid=xxsuck_list[xx.sucknow]["suckid"]
			xx.suckname=xxsuck_list[xx.sucknow]["suckname"]
			xx.suckroom=xxsuck_list[xx.sucknow]["suckroom"]
			alias.flytoid(xx.suckroom)
		else
			run("yun regenerate;yun refresh;yun recover")
			if havefj>0 then alias.startworkflow()
			else
				closeclass("mp_xx_pre")
				closeclass("mp_xx_pre_suck")
				closeclass("mp_xx_pre_sandu")
				--if xx.needsandu>0 and hp.exp>150000 then
				if xx_mmr~=nil and xx_mmr>0 or hp.exp<150000 then
					print("开始kmmr")
					openclass("mp_xx_kmmr")
					alias.flytoid(841)				
				elseif hp.pot>hp.maxpot/2 and xx.needsandu==0 and xuefirst>0 then 
					alias.startxue()
				else
					print("开始search bug")
					openclass("mp_xx_start")
					alias.flytoid(1442)
				end
			end
		end
	end
	if findstring(l,"数码世界，数字地图，"..xx.suckroom.."就是这里！") then
		alias.resetidle()
		run("ask "..xx.suckid.." about 吸吸大法")
	end
	if findstring(l,"你向"..xx.suckname.."打听有关「吸吸大法」的消息。","你忙着呢，你等会儿在问话吧。","对方正忙着呢，你等会儿在问话吧。") then
		alias.resetidle()
		run("yield yes;kill "..xx.suckid)
		if hp.healthjing<100 or hp.healthqi<100 then run("yun jixin "..xx.suckid) else run("yun jiemai "..xx.suckid) end
		suckwhat="yun jiemai "..xx.suckid
		openclass("mp_xx_pre_suck")
	end
	if findstring(l,"^[> ]*"..xx.suckname.."已经.+涣散，你已经无法从他体内吸取","截.+只能在战斗中对对手使用。","你吸取的内力充塞全身，无法再吸取内力！") then
		alias.resetidle()
		suckwhat="yun jiexin "..xx.suckid
		run("yield no")
	end
	if findstring(l,"这里没有 "..xx.suckid) then
		alias.resetidle()
		if xx.sucknow>#xxsuck_list then xx.sucknow=1 else xx.sucknow=xx.sucknow+1 end
		run("yield no")
		alias.checkbusy("pre")
	end
	if findstring(l,"^[> ]*"..xx.suckname.."脚下一个不稳，跌在地上昏了过去。") then
		if stat.havedu>0 then
			print("需要散毒")
			alias.resetidle()
		    closeclass("mp_xx_pre_suck")
			run("yield yes;bei none;bei chousui-zhang;bei sanyin-zhua")
			openclass("mp_xx_pre_sandu")
		else 
		    run("yield no") 
		end
	end
	if findstring(l,"^[> ]*"..xx.suckname.."倒在地上，挣扎了几下就死了。") then
		alias.resetidle()
		closeclass("mp_xx_pre_suck")
		closeclass("mp_xx_pre_sandu")
		if xx.sucknow>#xxsuck_list then xx.sucknow=1 else xx.sucknow=xx.sucknow+1 end
		run("yield no")
		alias.checkbusy("pre")
	end
end
------------------------------------------------------------------------------------
-- mp_xx_pre_sandu
------------------------------------------------------------------------------------
function mp_xx_pre_sandu.timer()
	alias.resetidle()
	alias.uw()
	run("perform sandu")
end
------------------------------------------------------------------------------------
-- mp_xx_pre_suck
------------------------------------------------------------------------------------
function mp_xx_pre_suck.timer()
	alias.resetidle()
	--run("yun jiemai "..tostring(xx.suckid)..";yun jiexin "..tostring(xx.suckid))
	--run("yun jiemai "..tostring(xx.suckid))
	run(suckwhat)
end
------------------------------------------------------------------------------------
-- mp_xx_start
------------------------------------------------------------------------------------
function mp_xx_start.dosomething1(n,l,w)
	local _tb,_f,a,b,c,d
	if findstring(l,"你目前还没有任何为 killover=yes 的变量设定。") then
		if have.suck==nil or have.suck=="" then have.suck=0 end
		if have.suck>0 then alias.checkexp("mp") else alias.checkbusy("sb") end
	end
	if findstring(l,"眼看"..killname.."咬紧了牙关，苦苦地抵抗着化功大法的侵袭！") then
		have.suck=1
		--suckLimited=0
	end
	if findstring(l,"你目前还没有任何为 checkexpover=mp 的变量设定。") then
		alias.resetidle()
		if add.exp>10 and mpLimited.MarkExp<me.menpaiLimited then mpLimited.MarkExp=tonumber(me.menpaiLimited) end
		if have.suck==nil then have.suck=0 end
		if add.exp<10 and have.suck>0 then
			if workflow.cm>0 then 
				mpJobLimited=1
			else
				suckLimited=1
			end
			print("统计到的SUCK上限为："..mpLimited.mpexp)
			mpLimited.MarkExp=tonumber(mpLimited.mpexp)
			if mpLimited.MarkTime<(os.time()-3600) then
				if de_bug>0 then print("到suck时间却仍然busy，推迟2分钟") end
				mpLimited.MarkTime=tonumber(os.time()-3600+120)
			end
		elseif add.exp>10 and have.suck>0 then
			suckLimited=0
		end
		alias.checkbusy("sb")
	end
	if findstring(l,"你目前还没有任何为 busyover=goquit 的变量设定。") then
		alias.flytoid(1436)
	end
	if findstring(l,"数码世界，数字地图，1442就是这里！") then
		alias.resetidle()
		if xx_xiulian>0 then
			run("give du dan to ding chunqiu;give du dan to ding chunqiu;give du dan to ding chunqiu")
		end
		run("give ling pai to ding chunqiu;hp;set check=giveling")		
	end
	if findstring(l,"数码世界，数字地图，1456就是这里！") then
		alias.resetidle()
		run("climb feng;use fire;zuan")	
		closeclass("mp_xx_start_sandu")
		openclass("mp_xx_start_search")		
	end
	if findstring(l,"你目前还没有任何为 check=giveling 的变量设定。") then
		if xx.lingpaierr>0 then run("drop ling pai") end
		if xx.havelingpai>0 then 
			run("give ling pai to ding chunqiu;hp;set check=giveling")
			xx.havelingpai=0
			xx.lingpaierr=0
			if sum.xxlingpai==nil then sum.xxlingpai=0 end
			if xx.gived>0 then
				add.exp=hp.exp-mark.exp
				mark.exp=hp.exp
				sum.xxlingpai=sum.xxlingpai+add.exp
				sum.mp=sum.mp+add.exp
				xx.gived=0
				print("这块令牌得到"..add.exp.."经验")
			end
			return
		end
		if havefj>0 then 
			alias.startworkflow()
		elseif xuefirst>0 and hp.pot>hp.maxpot/2 and xx.needsandu==0 then
			alias.startxue()
		elseif xx_xrd~=nil and xx_xrd>0 then
			alias.resetidle()
			closeclass("mp_xx_start_sandu")	
			xx.npcname=""	
			if string.len(mpweapon)>0 then
				if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
			else 
				alias.uw() 
			end
			alias.flytoid(1456)  --去仙人洞
		else
			run("ask ding about job")
		end
	end
	if findstring(l,"你目前还没有任何为 killnpc 的变量设定。") then
		alias.resetidle()
		check_battleidle=0
		openclass("kill")
		openclass("kill_pfm")
		closeclass("kill_run")
		AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
		SetTimerOption("kill_timer", "group", "kill")
		xx.suck=0
		reyun=1
		runaway=false
		npcfaint=false
		killRunSuccess=false
		killid=xx.npcid
		killname=xx.npcname
		killskill=mpweapon
		killpfm=mppfm
		killyun=mpyun
		killjiali=mpjiali
		killjiajin=mpjiajin
		run("unset no_parry;yield no;jiali "..killjiali..";jiajin "..killjiajin)
		if string.len(mpweapon)>0 then
			if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
		else alias.uw() end
		_tb=Split(mpyun,"|")
		for k,v in ipairs(_tb) do run(v) end
		--run("kill "..tostring(killid))
		rekill=1
		alias.pfm()
	end
	if findstring(l,"^[> ]*"..tostring(xx.bugname).."突然钻到一片树叶下面，踪影全无。","这东西最好不要抓。","别人找出来的，你好意思抓吗？","这里没有这个生物。") then
		if not isopen("kill") then
			alias.resetidle()
			closeclass("mp_xx_start_catch")
			openclass("mp_xx_start_search")
			run("yield no")
			xx.bugname=""
			xx.bugout=0
		end
	end
	if findstring(l,"你最好先回去复命，别让老仙等急了。") then
		alias.resetidle()
		closeclass("mp_xx_start_catch")
		openclass("mp_xx_xiulian")
		alias.checkbusy("xiulian")
	end
	if findstring(l,"你举起手中的瓦罐猛地将"..tostring(xx.bugname).."扣住，然后小心翼翼地将瓦罐翻起来盖住。","已经有毒虫了，修炼吧。") then
		alias.resetidle()
		closeclass("mp_xx_start_catch")
		openclass("mp_xx_xiulian")
		run("yield no")
		xx.havebug=1
		alias.checkbusy("xiulian")
	end
	if findstring(l,"你找到虫子用什么来盛呢？") then
		alias.resetidle()
		closeclass("mp_xx_start_sandu")
		closeclass("mp_xx_start_search")
		print("瓦罐摔破了，需要relogin")
		run("get gold")
		alias.checkbusy("goquit")
	end
	if findstring(l,"^[> ]*"..tostring(xx.npcname).."脚下一个不稳，跌在地上昏了过去。") then
		alias.resetidle()
		closeclass("mp_xx_start_sandu")
		closeclass("mp_xx_start_search")
		--如果在仙人洞sandu，为了防止npc被冻死，要搬起来往west走一步，sandu完了再回来
		if xx.needsandu>0 then
			print("需要散毒")
			run("halt;yield yes;bei none;bei chousui-zhang;bei sanyin-zhua")
			openclass("mp_xx_start_sandu")			
			if xx_xrd~=nil and xx_xrd>0 then 
				wait.make(function()
					_f=function() run("get ke;get armor from ke;drop armor;get ke;w;drop ke;kill ke") end
					wait.time(2);_f()
				end)
			end
		else 
			run("yield no")
		end
		--rekill=1
	end
	if findstring(l,"^[> ]*"..tostring(xx.npcname).."倒在地上，挣扎了几下就死了。") then
		alias.resetidle()
		closeclass("mp_xx_start_sandu")
		closeclass("mp_xx_start_search")
		run("yield no")
	end
	if findstring(l,"你目前还没有任何为 busyover=sb 的变量设定。") then
		alias.resetidle()
		have.suck=0
		closeclass("mp_xx_start_sandu")
		closeclass("mp_xx_start_search")
		if string.len(mpweapon)>0 then
			if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
		else 
			alias.uw() 
		end
		run("get ling pai;yun regenerate;yun refresh;yun recover")		
		if xx_xrd~=nil and xx_xrd>0 then run("e") end
		--alias.startworkflow()
		--if havefj>0 then alias.startworkflow() else openclass("mp_xx_start_search") end
		if havefj>0 or (xuefirst>0 and hp.pot>hp.maxpot/2) then 
			if xx_xrd~=nil and xx_xrd>0 then run("w;out") end
			alias.flytoid(1442) 
		else 
			xx.npcname="";openclass("mp_xx_start_search") 
		end
	end
	if findstring(l,"数码世界，数字地图，1436就是这里！") then
		alias.resetidle()
		run("n;give du dan to ding chunqiu;give du dan to ding chunqiu;give du dan to ding chunqiu;give ling pai to ding chunqiu;set check=quit")
		xx.havelingpai=0
		xx.lingpaierr=0
		--openclass("quit")
	end
	if findstring(l,"你给丁春秋一块令牌。") then
		xx.havelingpai=1
		xx.gived=1
		xx.lingpaierr=0
	end
	if findstring(l,"对方不接受这样东西。") then
		xx.lingpaierr=1
		xx.havelingpai=1
	end
	if findstring(l,"你目前还没有任何为 check=quit 的变量设定。") then
		if xx.lingpaierr>0 then run("drop ling pai") end
		if xx.havelingpai>0 then 
			run("give ling pai to ding chunqiu;set check=quit")
			xx.havelingpai=0
			xx.lingpaierr=0
			return
		end
		run("s")
		openclass("quit")
		stat.quiting=0
	end
	a,b,c=string.find(l,"看起来(.+)想杀死你！")
	if c~=nil and findstring(c,"星宿毒蛛","绿竹蝎","朱睛蛙","毒蛾","七心甲虫","野蜂","蓝鼎蜘蛛") then
		alias.resetidle()
		xx.bugname=c
		if xx.bugname=="星宿毒蛛" then xx.bugid="zhu" end
		if xx.bugname=="绿竹蝎" then xx.bugid="xie" end
		if xx.bugname=="朱睛蛙" then xx.bugid="wa" end
		if xx.bugname=="毒蛾" then xx.bugid="e" end
		if xx.bugname=="七心甲虫" then xx.bugid="chong" end
		if xx.bugname=="野蜂" then xx.bugid="bee" end
		if xx.bugname=="蓝鼎蜘蛛" then xx.bugid="bee" end
		if xx_xiulian>0 then
			closeclass("mp_xx_start_search")
			openclass("mp_xx_start_catch")
			run("yield yes")
		else
			run("yield no")
		--	run("yield no;kill "..tostring(xx.bugid))
		end
	end
	if c~=nil and findstring(c,"白衫怪客","叶三山","高克新","静慈","刘志修","觉慈","觉兴","觉欲","正派侠客") then
		alias.resetidle()
		xx.npcname=c
	end
	if findstring(w[0],"你向丁春秋打听有关「job」的消息。\n丁春秋说道：“老仙我最近练功需要一些毒丹，你到后山拿些来给我吧。”","你向丁春秋打听有关「job」的消息。\n丁春秋说道：好小子，上一个工作没有完成就敢来问我工作。") then
		alias.resetidle()
		--alias.et()
		if string.len(mpweapon)>0 then
			if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
		else 
			alias.uw() 
		end
		run("yield no;s;ne;nw;n")
		xx.npcname=""
		closeclass("mp_xx_start_sandu")
		openclass("mp_xx_start_search")
	end
	if findstring(l,"你中毒了！") then
		stat.havedu=1
	end
	a,b,c,d=string.find(l,tostring(xx.npcname).."%s+=%s+(%w+)%s+(%w+),%s+")
	if c~=nil and d~=nil then
		xx.npcid=string.lower(c).." "..string.lower(d)
	end
	a,b,c=string.find(l,tostring(xx.npcname).."%s+=%s+(%w+),%s+")
	if c~=nil then
		xx.npcid=string.lower(c)
	end
end
------------------------------------------------------------------------------------
-- mp_xx_start_catch
------------------------------------------------------------------------------------
function mp_xx_start_catch.timer()
	alias.resetidle()
	run("kou "..tostring(xx.bugid))
end
------------------------------------------------------------------------------------
-- mp_xx_start_sandu
------------------------------------------------------------------------------------
function mp_xx_start_sandu.timer()
	alias.resetidle()
	alias.uw()
	--run("kill "..xx.npcid..";perform sandu")
	run("perform sandu")
end
------------------------------------------------------------------------------------
-- mp_xx_start_search
------------------------------------------------------------------------------------
function mp_xx_start_search.timer()
	alias.resetidle()
	if xx.npcname~="" then
		closeclass("mp_xx_start_search")
		run("id here;set killnpc")
	elseif havefj>0 then 
		if xx_xrd~=nil and xx_xrd>0 then run("w;out") end
		wait.make(function()		--延迟5秒去接fj，以免正在busy引起GPS bug
			_f=function()
				alias.flytoid(1442)
			end
			wait.time(5);_f()
		end)
	else
		if xx_xrd~=nil and xx_xrd>0 then run ("tan icicle;dig") else run("search bug") end
	end
end
------------------------------------------------------------------------------------
-- mp_xx_watch
------------------------------------------------------------------------------------
function mp_xx_watch.dosomething1(n,l,w)
	if findstring(l,"你一掌拍在.+胸口，不料.+内力太弱，你反不能把毒气逼出去，功力受损。") then
		stat.havedu=0
		rekill=1
		run("yield no")
	end
	if findstring(l,"你一掌拍在.+胸口，待其运内力抵抗，顺势把周身毒气尽数逼进.+体内。") then
		stat.havedu=0
		--rekill=1
		run("yield no")
		xx.needsandu=0
	end
	if findstring(l,"截脉只能在战斗中对对手使用。","截心只能在战斗中对对手使用。") then
		rekill=1
	end
end
------------------------------------------------------------------------------------
-- mp_xx_xiulian
------------------------------------------------------------------------------------
function mp_xx_xiulian.dosomething1(n,l,w)
	if findstring(l,"你目前还没有任何为 busyover=xiulian 的变量设定。") then
		alias.resetidle()
		if havefj>0 then alias.startworkflow() else run("xiulian") end
	end
	if findstring(l,"你将死"..tostring(xx.bugname).."拿出瓦罐，将其肚子剖开，拿出一粒腥如血的丹丸来。","没有毒虫，你想要用空气修行吗？") then
		alias.resetidle()
		closeclass("mp_xx_xiulian")
		xx.bugname=""
		if xx.havebug>0 then
			closeclass("mp_xx_start_sandu")
			closeclass("mp_xx_start_search")
			print("需要relogin")
			alias.checkbusy("goquit")
		else
			--alias.uw()
			run("yun regenerate;yun refresh;yun recover")
			alias.startworkflow()
		end
	end
	if findstring(l,"你正忙着呢。") then
		alias.resetidle()
		alias.checkbusy("xiulian")
	end
	if findstring(l,"^[> ]*"..tostring(xx.bugname).."肚子高高涨起，啪地一身掉进罐底。") then
		alias.resetidle()
		run("xiulian")
	end
	if findstring(l,"你运起内力护住全身大穴，然后闭上眼睛将手指伸入瓦罐。") then
		xx.havebug=0
	end
end
------------------------------------------------------------------------------------
-- mp_xx_kmmr
------------------------------------------------------------------------------------
function mp_xx_kmmr.dosomething1(n,l,w)
	local _f,_tb,_t,a,b,c,d,e,f
	if findstring(l,"数码世界，数字地图，841就是这里！") then
		alias.resetidle()
		mmr.findmmr=0
		mmr.searchid=1
		mmr.err=0
		run("yun recover")
		if me.shen<(0-(hp.exp/3)) then
			run("set searchmmr=yes")
		else
			xx.needsandu=1
			alias.startworkflow()
		end
	end
	if findstring(l,"数码世界，数字地图，856就是这里！") then
		alias.resetidle()
		mmr.findmmr=0
		mmr.err=0
		run("drop "..mmr.id..";drop corpse;drop skeleton;yun recover")
		alias.checkexp("mp")
	end
	if findstring(l,"yunbusy严重","受伤严重") then
		closeclass("kill")
		alias.flytoid(856)
	end
	a,b,c=string.find(l,"[> ]*"..mmr.name.."+(.+)")
	if c~=nil and findstring(c,"跌在地上昏了过去","挣扎了几下就死了","急步往.-离开","突然卖一破绽") then
		alias.resetidle()
		alias.close_kill()
		run("halt")
		alias.checkbusy("killover")
	end
	if findstring(l,"你目前还没有任何为 busyover=killover 的变量设定。") then
		alias.resetidle()
		run("get silver;get silver from corpse;get silver from "..mmr.id..";get "..mmr.id)
		alias.flytoid(856)
	end
	if findstring(l,"你目前还没有任何为 checkexpover=mp 的变量设定。") then
		alias.resetidle()
		if add.exp>10 and mpLimited.MarkExp<me.menpaiLimited then mpLimited.MarkExp=tonumber(me.menpaiLimited) end
		if add.exp<10 then
			mpJobLimited=1
			print("统计到的suck上限为："..mpLimited.mpexp)
			mpLimited.MarkExp=tonumber(mpLimited.mpexp)
			if mpLimited.MarkTime<(os.time()-3600) then
				if de_bug>0 then print("到suck时间却仍然busy，推迟2分钟") end
				mpLimited.MarkTime=tonumber(os.time()-3600+120)
			end
		end
		alias.startworkflow()
	end
	if findstring(l,"你目前还没有任何为 searchmmr=yes 的变量设定。") then
		alias.resetidle()
		safego="/alias.flytoid(841)"
		SaveBack="south"
		if mmr.err>0 then
			alias.flytoid(841)
		else
			if mmr.findmmr>0 then
				alias.yjl()
				run("set checkmmrid=yes")
			else
				_tb=Split(mmr.searchlist,"|")
				if mmr.searchid>#_tb then mmr.searchid=1 end
				run(_tb[mmr.searchid])
				_tb=Split(mmr.searchroomno,"|")
				roomno_now=_tb[mmr.searchid]
				mmr.searchid=mmr.searchid+1
				--if cmd.nums<20 then
					run("set searchmmr=yes")
				--else
				--	alias.yjl()
				--	_f=function() run("set searchmmr=yes") end
				--	wait.time(2);_f()
				--end
			end
		end
	end
	a,b,c=string.find(l,"看起来(.+)想杀死你！")
	if c~=nil then
		mmr.name=c
		mmr.findmmr=1
	end
	a,b,c,d,e=string.find(l,"「.+」(%S+)%((%w+) (%w+)%)")
	if c~=nil and d~=nil and e~=nil and c==mmr.name then mmr.id=string.lower(d).." "..string.lower(e) end
	if findstring(l,"你目前还没有任何为 checkmmrid=yes 的变量设定。") then
		alias.resetidle()
		check_battleidle=0
		_tb=Split(mpyun,"|")
		for k,v in ipairs(_tb) do run(v) end
		openclass("kill")
		openclass("kill_pfm")
		closeclass("kill_run")
		AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
		SetTimerOption("kill_timer", "group", "kill")
		xx.suck=2
		reyun=1
		runaway=false
		npcfaint=false
		killRunSuccess=false
		killid=mmr.id
		killname=mmr.name
		killskill=mpweapon
		killpfm=mppfm
		killyun=mpyun
		killjiali=mpjiali
		killjiajin=mpjiajin
		run("unset no_parry;yield no;jiali "..killjiali..";jiajin "..killjiajin)
		if string.len(mpweapon)>0 then
			if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
		else alias.uw() end
		_tb=Split(mpyun,"|")
		for k,v in ipairs(_tb) do run(v) end
		run("kill "..tostring(killid))
		alias.pfm()
	end
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function mp_xx.update()
	local _tb
	local  mp_xx_pre_triggerlist={
	       {name="mp_xx_pre_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xx_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xx_pre_triggerlist) do
		addtri(v.name,v.regexp,"mp_xx_pre",v.script,v.line)
	end
	closeclass("mp_xx_pre")
	
	AddTimer("mp_xx_pre_sandu_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_xx_pre_sandu.timer")
	SetTimerOption("mp_xx_pre_sandu_timer", "group", "mp_xx_pre_sandu")
	closeclass("mp_xx_pre_sandu")
	
	AddTimer("mp_xx_pre_suck_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_xx_pre_suck.timer")
	SetTimerOption("mp_xx_pre_suck_timer", "group", "mp_xx_pre_suck")
	closeclass("mp_xx_pre_suck")
	
	local  mp_xx_start_triggerlist={
	       {name="mp_xx_start_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xx_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xx_start_triggerlist) do
		addtri(v.name,v.regexp,"mp_xx_start",v.script,v.line)
	end	
	local _tb2={
		"突然间从树后越出一个人，高喊一声：“星宿奸人，拿命来！”\\n看起来(.+)想杀死你！\\Z",
		"你向丁春秋打听有关「job」的消息。\\n丁春秋说道：“老仙我最近练功需要一些毒丹，你到后山拿些来给我吧。”\\Z",
		"你向丁春秋打听有关「job」的消息。\\n丁春秋说道：好小子，上一个工作没有完成就敢来问我工作。\\Z",
	}
	local  mp_xx_start_m_triggerlist={
	       {name="mp_xx_start_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_xx_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xx_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_xx_start",v.script,v.line)
	end
	closeclass("mp_xx_start")
	
	AddTimer("mp_xx_start_catch_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_xx_start_catch.timer")
	SetTimerOption("mp_xx_start_catch_timer", "group", "mp_xx_start_catch")
	closeclass("mp_xx_start_catch")
	
	AddTimer("mp_xx_start_sandu_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_xx_start_sandu.timer")
	SetTimerOption("mp_xx_start_sandu_timer", "group", "mp_xx_start_sandu")
	closeclass("mp_xx_start_sandu")
	
	AddTimer("mp_xx_start_search_timer", 0, 0, 1, "", timer_flag.Enabled + timer_flag.Replace, "mp_xx_start_search.timer")
	SetTimerOption("mp_xx_start_search_timer", "group", "mp_xx_start_search")
	closeclass("mp_xx_start_search")
	
	local  mp_xx_watch_triggerlist={
	       {name="mp_xx_watch_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xx_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xx_watch_triggerlist) do
		addtri(v.name,v.regexp,"mp_xx_watch",v.script,v.line)
	end	
	closeclass("mp_xx_watch")
	
	local  mp_xx_xiulian_triggerlist={
	       {name="mp_xx_xiulian_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xx_xiulian.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xx_xiulian_triggerlist) do
		addtri(v.name,v.regexp,"mp_xx_xiulian",v.script,v.line)
	end	
	closeclass("mp_xx_xiulian")

	local  mp_xx_kmmr_triggerlist={
	       {name="mp_xx_kmmr_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_xx_kmmr.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_xx_kmmr_triggerlist) do
		addtri(v.name,v.regexp,"mp_xx_kmmr",v.script,v.line)
	end	
	closeclass("mp_xx_kmmr")
end
mp_xx.update()

