count_force={
["hunyuan-yiqi"]=8,
["linji-zhuang"]=8,
["taiji-shengong"]=8,
["huntian-qigong"]=7,
["huagong-dafa"]=4,
['bitao-xuangong']=7,
['hamagong']=7,
['longxiang-banruo']=6,
['zixia-gong']=7,
['dulong-dafa']=5,
['kurong-changong']=7,
['xiantian-gong']=8,
['guangming-shenghuo']=7,
['diandao-gong']=5,
['mile-gong']=5,
['motian-yunqi']=6,
['hunyuan-gong']=6,
['xiuling-yaozhi']=5,
['xuanmen-daoyin']=5,
['xuanyin-zhenqi']=6,
['yunu-xinjing']=8,
['jiuyang-shengong']=10,
['taixuan-gong']=7,
}
------------------------------------------------------------------------------------
-- dummy大米cls
------------------------------------------------------------------------------------
function dm.dosomething1(n,l,w)	--回答各种问题
	local _f,a,b,c,d,e,f
	wait.make(function()
	if findstring(l,"【闲聊】.+：(%S+) (%S+)") and dummy.answer~=nil then
		if chattime==nil then chattime=0 end
		a,b,c=string.find(l,"skills (%d+)")
		if c~=nil then
			if os.time()-chattime>10 then 
			if tonumber(c)<5000 then 
			    run("chat "..c.."级技能，需要["..(c^3/10).."]经验支持")
			else 
			    run("chat 武功这么高，还是快点准备结了金丹准备渡劫去吧！")
			end
			chattime=os.time()
			end
			return
		end
		a,b,c=string.find(l,"exp (%d+)")
		if c~=nil then
			if os.time()-chattime>10 then 
			if tonumber(c)<9999999999 then
			    run("chat "..c.."点经验，可以支持["..math.floor(math.pow(c*10,1/3)).."]级技能")
			else
			    run("chat 哇，你又要升天了！咦？我为什么要说又？")
			end
			chattime=os.time()
			end
			return
		end
		a,b,c,d=string.find(l,"：(%S+) (%d+)")
		--print(c,d)
		if count_force[c]~=nil and tonumber(d)~=nil then
			if os.time()-chattime>10 then 
			chattime=os.time()
			_t=math.floor(math.pow(d/1.618,1+count_force[c]/100)*20+1)
			run("chat ["..d.."]级["..c.."]支持[".._t.."]点最大内力（不含冲脉）。")
			--print("本次计算占用了老子"..os.time()-chattime.."时间")
			end
		end
	end
	if findstring(l,"【谣言】") and dummy.answer~=nil and not findstring(l,"以后你再也看不到这个人了。") then
		local path,msg,f
		path=GetInfo(58)
		f=io.open(path.."aaa_rumor_log.txt","a+")									--先打开文件a.lua（文件不存在会创建），
		if f~=nil then
			msg="["..os.date("%Y-%m-%d %H:%M:%S", os.time()).."]"..l
			f:write(tostring(msg).."\n")				--写到文件中
			f:close()
		end
	end
	if findstring(l,"数码世界，数字地图，1983就是这里！","数码世界，数字地图，282就是这里！","数码世界，数字地图，"..dm.saveroom.."就是这里！") then
		dm.id=""
		dm.place=""
		dm.zeiid=""
		if findstring(l,"1983","282") then alias.checkitems()
		elseif findstring(l,dm.saveroom) then run("halt;yun lifesave corpse "..corpseid)	
		end
	end
	if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then 
		alias.resetidle()
		if hp.healthqi<50 then
			run("yun kurong")
		elseif roomno_now==1983 and roomname=="树洞内部" then
			alias.dz(200)
			run("say 天堂有路你不走呀")
		elseif roomno_now==282 and roomname=="药铺" then
			alias.dz(200)
		else
			if me.menpai=="gb" then
				alias.flytoid(1983)
			else
				alias.flytoid(282)
			end
		end
	end
	if findstring(l,"这里没有 corpse","你突然突然大吼一声，将余下真力全力送出！","你突然停顿下来，显然内力受到极大损伤！","此人的魂魄马上就要飞散了，还是快转世为先吧！","已经活过来了,用不着你救。") then 
		run("hp")
		if me.menpai=="gb" then
			alias.flytoid(1983)
		else
			alias.flytoid(282)
		end
		dm.saveroom=0
	elseif findstring(l,".+的鬼魂不在。","这具尸体已经腐烂，无法救转了！") then corpseid=corpseid+1;run("halt;yun lifesave corpse "..corpseid)
	elseif findstring(l,"小木门悄悄的关上了。") then run("say 天堂有路你不走呀") end
	a,b,c,d,e,f=string.find(l,"(%w+)%)告诉你：(%S+) (%w+) (%w+)$")
	--a,b,c,d,e,f=string.find(l,"(%w+)%)在你的耳边悄声说道：(%S+) (%w+) (%w+)$")
	--话事人在你的耳边悄声说道：回去吧 thank you
	if c~=nil and d~=nil and e~=nil and f~=nil and not isopen("liaoshang") and not isopen("gps_start") and dummy.trust_liaoshang~=nil and findstring(dummy.trust_liaoshang,"|"..c.."|")then
		alias.resetidle()
		alias.close_dz()
		if dm.helplist==nil then dm.helplist={} end
		run("unset brief")
		dm.id=c
		dm.place=d
		dm.zeiid=e.." "..f
		alias.tdz()
		if findstring(d,"回去吧") then 
			run("halt;yun recover;hp")
			if me.menpai=="gb" then
				alias.flytoid(1983)
			else
				alias.flytoid(282)
			end
		elseif findstring(d,"疗伤") then alias.flyto("武馆休息室");if dm["helplist"][c]==nil then dm["helplist"][c]=1 else dm["helplist"][c]=dm["helplist"][c]+1 end
		elseif findstring(d,"救命") then alias.flytoid(string.gsub(d,"救命",""));dm.saveroom=string.gsub(d,"救命","");corpseid=1
		elseif hp.healthqi<100 then run("hp")
		else run("halt;yun kurong;yun recover");alias.flyto(d,"云南大理") end
	end
	if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『武馆休息室』立马到达！") then
		alias.resetidle()
		run("unset no_accept;yun liaoshang "..dm.id)
		dm.liaoshangtimes=dm.liaoshangtimes+1
	end
	if findstring(l,".+身体并无异样","你所学的内功中没有这种功能") then run("reply 你没有中毒") end
	if findstring(l,"你[说道|沉思了一会|忽然的跃起|一指点过]") then alias.resetidle() end
	if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『"..dm.place.."』立马到达！","浮云朵朵飘，飘到了 %d+ 个『"..dm.place.."』中的第 %d+ 个～～") then
		alias.resetidle()
		--run("yun recover;throw coin at "..dm.zeiid)
		run("yun recover;yield yes;kill "..dm.zeiid)
	end
	a,b,c=string.find(l,"你手一扬，将铜钱对准(.+)掷去。")
	if c~=nil then dm.place=c end
	a,b,c=string.find(l,"你对著(.+)喝道：「臭贼！今日不是你死就是我活！」")
	if c~=nil then dm.place=c;dm.throwtimes=dm.throwtimes+1 end
	if dm.zeiid~="" and dm.zeiid~="thank you" and findstring(l,"你手一扬，将铜钱对准.+掷去。","你前一个动作还没有做完。") then
		alias.resetidle()
		_f=function() run("h;throw coin at "..dm.zeiid) end
		wait.time(1);_f()
	end
	if dm.zeiid~="" and dm.zeiid~="thank you" and findstring(l,"这里没有你的目标。","这里没有这个人") then
		alias.resetidle()
		if flytoidx<flytosum then alias.flytonext() else run("reply 没找到哇!")	end
	end
	if findstring(l,"你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑") then
		alias.resetidle()
		dm.id=""
		dm.place=""
		dm.zeiid=""
		run("halt;yun recover;hp")
		if me.menpai=="gb" then
			alias.flytoid(1983)
		else
			alias.flytoid(282)
		end
	end
	if findstring(l,"看起来"..dm.place.."想杀死你") then
		alias.resetidle()
		dm.id=""
		dm.place=""
		dm.zeiid=""
		wait.time(2)
		run("halt;yun kurong;yun recover;hp")
		if me.menpai=="gb" then
			alias.flytoid(1983)
		else
			alias.flytoid(282)
		end
	end
	end)
end
function keep.dosomething1(n,l,w)
	local a,b,c,d,_f
	a,b,c,d=string.find(l,".+%((%w+)%)告诉你：give me (.+)")
	if c~=nil and d~=nil and setting=="keep" and dummy.trust~=nil and findstring(dummy.trust,"|"..c.."|") then
		if d~=nil and d=="xueteng" and have.xueteng<=0 then 
			run("whisper "..c.." 没血藤了")
		else
			run("give "..c.." "..d..";whisper "..c.." 补充完毕")
		end
	end
	a,b,c=string.find(l,".+%((%w+)%)告诉你：有没有冲脉丹")
	if c~=nil and findstring(dummy.trust,"|"..c.."|") then
		trust_tongmai=c --记录提问者
		have.tongmaidan=0
		run("look tongmai dan;set check=tongmaidan")
	end
	if findstring(l,"你给.+一棵大血藤。","你吃下一棵大血藤，顿时血气翻涌血脉膨胀，气力大长。") then
		alias.resetidle()
		run("inventory")
	elseif findstring(l,"你捡起一棵大血藤。") then
		alias.resetidle()
		run("inventory;yun refresh;yun regenerate;yun recover")
	elseif findstring(l,".+给你一棵大血藤。") then
		alias.resetidle()
		if have.items>=49 then 
			if dummy.xueteng_spare~=nil and dummy.xueteng_spare~="" then
				run("give "..dummy.xueteng_spare.." da xueteng")
			else
				run("drop Da xueteng") 
			end
		end
		run("inventory;drop jiuping;drop ya")
	end
	if findstring(l,".+从泥里挖出一个大血藤！") then 
		alias.resetidle()
		alias.checkdrugbusy("da xueteng")
		if have.items<50 then
			wait.make(function()
				_f=function() run("get xueteng") end
				wait.time(1.5)
				_f()
			end)	
		end			
	end
	a,b,c=string.find(l,"[> ]*(.+)丢下一棵大血藤。")
		if c~=nil and c~="你" and have.items<50	then run("get xueteng");alias.resetidle() end
	if findstring(l,"通体暗紫色的丹药，散发着浓浓的药味，是用麝香、雪莲、人参等名贵药材炼制而成，服用可以使经络通畅。") then
		have.tongmaidan=1
	elseif findstring(l,"你目前还没有任何为 check=tongmaidan 的变量设定。") and trust_tongmai~=nil then
		if have.tongmaidan>0 then
			run("tell "..trust_tongmai.." 有通脉丹")
		else
			run("tell "..trust_tongmai.." 没有通脉丹")
		end
		--=nil
	elseif findstring(l,"【谣言】","【表决】","某人纵声长啸","【公告】","【闲聊】") then
		local path,msg,f
		path=GetInfo(58)
		f=io.open(path.."aaa_chat_log.txt","a+")									--先打开文件a.lua（文件不存在会创建），
		if f~=nil then
			msg="["..os.date("%Y-%m-%d %H:%M:%S", os.time()).."]"..l
			f:write(tostring(msg).."\n")				--写到文件中
			f:close()
		end
	end
end
function dm.wargetweapon(n,l,w)
	local a,b,c,d,_f
	wait.make(function()
	if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『"..dummy['jyroom'].."』立马到达！") then
		run("unset no_accept;tell "..dummy.jy.." give me "..war.weapon)
		run("tell "..dummy.jy.." give me "..war.weapon)
		wait.time(5)
		closeclass("dm_war_getweapon")
		alias.startwar()
	end
	end)
end
------------------------------------------------------------------------------------
-- update
------------------------------------------------------------------------------------
function dm.update()
	local _tb
	_tb={
	"【闲聊】.+",
	"【谣言】",
	"数码世界，数字地图，.+就是这里！",
	"你目前还没有任何为 dealwithitems=over 的变量设定。",
	"这里没有 corpse","你突然突然大吼一声，将余下真力全力送出！","你突然停顿下来，显然内力受到极大损伤！","此人的魂魄马上就要飞散了，还是快转世为先吧！","已经活过来了,用不着你救。",
	".+的鬼魂不在。","这具尸体已经腐烂，无法救转了！",
	"小木门悄悄的关上了。",
	".+告诉你：.+",
	"你口念咒语『神马都是浮云,虾米都是尘土』，『.+』立马到达！",
	"浮云朵朵飘，飘到了 .+ 个『.+』中的第 .+ 个～～",
	".+身体并无异样","你所学的内功中没有这种功能",
	"你[说道|沉思了一会|忽然的跃起|一指点过]",
	"你手一扬，将铜钱对准.+掷去。",
	"你对著.+喝道：「臭贼！今日不是你死就是我活！」",
	"你前一个动作还没有做完。",
	"这里没有你的目标。","这里没有这个人",
	"你受伤过重","你已经受伤过重","你已经陷入半昏迷状态","你受了相当重的伤","你伤重之下已经难以支撑",
	"看起来.+想杀死你",
	}
	local  dm_triggerlist={
	       {name="dm_dosth1",regexp=linktri(_tb),script=function(n,l,w)    dm.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(dm_triggerlist) do
		addtri(v.name,v.regexp,"dm",v.script,v.line)
	end
	closeclass("dm")
	
	_tb={
	"你口念咒语『神马都是浮云,虾米都是尘土』，『.+』立马到达！",
	}
	local wardm_triggerlist={
		{name="war_getweapon_dosth1",regexp=linktri(_tb),script=function(n,l,w)    dm.wargetweapon(n,l,w)  end,},
	}
	for k,v in pairs(wardm_triggerlist) do
		addtri(v.name,v.regexp,"dm_war_getweapon",v.script,v.line)
	end
	closeclass("dm_war_getweapon")
	
	_tb={
	".+告诉你：give me.+",
	".+告诉你：有没有冲脉丹",
	"通体暗紫色的丹药，散发着浓浓的药味，是用麝香、雪莲、人参等名贵药材炼制而成，服用可以使经络通畅。",
	"你目前还没有任何为 check\\=tongmaidan 的变量设定。",
	".+丢下一棵大血藤。","你捡起一棵大血藤。","你给.+一棵大血藤。",	".+从泥里挖出一个大血藤！",".+给你一棵大血藤。","你吃下一棵大血藤，顿时血气翻涌血脉膨胀，气力大长。",
	".+用手去拔草挖泥，搞的满手是刺，鲜血淋淋。",
	"【谣言】",
	"【闲聊】",
	"【公告】",
	"某人纵声长啸",
	"【表决】",
	}
	local  keep_triggerlist={
	       {name="keep_dosth1",regexp=linktri(_tb),script=function(n,l,w)    keep.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(keep_triggerlist) do
		addtri(v.name,v.regexp,"keep",v.script,v.line)
	end
	closeclass("keep")
end
dm.update()
function addgetzhongjiantimer()
	AddTimer("zhongjian_timer", 0, 0, 10, "get zhongjian", timer_flag.Enabled + timer_flag.Replace, "")
	SetTimerOption("zhongjian_timer", "group", "zhongjian")
	openclass("zhongjian")
end
------------------------------------------------------------------------------------
-- anniu
------------------------------------------------------------------------------------
require "InfoBox"
anniu={
	win=nil,
}
anniu.button={
	{"扬州","gyz",},
	{"三不管","gsbg",},
	{"祁连山","gqls",},
	{"华山","ghs",},
	{"泰山","gts",},
	{"泉州","gqz",},
	{"佛山","gfs",},
	{"大理","gdl",},
	{"兰州","glz",},
	{"星宿","gxx",},
	{"西夏","gxixia",},
	{"少林","gsl",},
	{"杭州","ghz",},
	{"南阳","gny",},
	{"全真","gzn",},
	{"长白","gcb",},
	{"峨嵋","gem",},
	{"白驼","gbt",},
	{"明教","gkl",},
	{"舟山","gzs",},
}
function anniukai()
	anniu.win = anniu.win or InfoBox:New("anniu")
	anniu.win.columns=5
	anniu.win:WindowPosition(anniu.win.windowPositions.SE)
	anniu.win.Bar.barStyle = InfoBox.barStyles.flat
	for k,v in pairs(anniu.button) do
		local tw = anniu.win.Bars[k] or anniu.win:AddBar(v[1])
		tw.barStyle = InfoBox.barStyles.flat
		tw.button={mouseDown=v[2],tooltipText=v[3],cursor=1}
	end
	anniu.win:Update()
end
--anniukai()
function anniuguan()
	anniu.win:CloseWindow()
end
function gyz()
	alias.flytoid(960)
end
function gsbg()
	alias.flytoid(608)
end
function gqls()
	alias.flytoid(1345)
end
function ghs()
	alias.flytoid(872)
end
function gts()
	alias.flytoid(1070)
end
function gqz()
	alias.flytoid(1)
end
function gfs()
	alias.flytoid(108)
end
function gdl()
	alias.flytoid(208)
end
function glz()
	alias.flytoid(1376)
end
function gxx()
	alias.flytoid(1444)
end
function gxixia()
	alias.flytoid(1365)
end
function gsl()
	alias.flytoid(1552)
end
function ghz()
	alias.flytoid(1200)
end
function gny()
	alias.flytoid(1942)
end
function gzn()
	alias.flytoid(782)
end
function gcb()
	alias.flytoid(1474)
end
function gem()
	alias.flytoid(356)
end
function gbt()
	alias.flytoid(1811)
end
function gkl()
	alias.flytoid(556)
end
function gzs()
	alias.flytoid(1274)
end
function gth()
	alias.flytoid(1730)
end
function gls()
	alias.flytoid(1772)
end
