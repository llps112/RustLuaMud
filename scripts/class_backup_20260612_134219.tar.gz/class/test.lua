maketri_num=1
local function _f1(n,l,w)
	print("test1")
end
_tb={
		"���������ﲻ֪����˵Щʲô��",
	}
	maketri("test",_tb,"test",_f1)
	--[[local  mp_gb_watch_triggerlist={
	       {name="test1",regexp=linktri(_tb),script=function(n,l,w)    _f1()  end,},
	}
	for k,v in pairs(mp_gb_watch_triggerlist) do
		addtri(v.name,v.regexp,"test",v.script,v.line)
	end]]
	
local _f1=function(n,l,w)
	print("test2")
end
_tb={
		"��˫�ֱ�ȭ�����˸�Ҿ������λӢ�����ˣ�",
	}
	maketri("test",_tb,"test",_f1)
	--[[local  mp_gb_watch_triggerlist={
	       {name="test2",regexp=linktri(_tb),script=function(n,l,w)    _f1()  end,},
	}
	for k,v in pairs(mp_gb_watch_triggerlist) do
		addtri(v.name,v.regexp,"test",v.script,v.line)
	end]]
openclass("test")