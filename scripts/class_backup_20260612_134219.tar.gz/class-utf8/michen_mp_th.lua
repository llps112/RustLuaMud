
function alias.checkthjob()
	alias.initialize_trigger()
	if stat.havedu>0 then alias.startliaoshang()
	--elseif fjroom~=nil and string.len(fjroom)>0 and fjzone~=nil and string.len(fjzone)>0 then --改为先mp后fj
		--print("有fj优先做完")
		--if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
		--workflow.nowjob="fj"
		--closeclass("fj_pre")
		--openclass("fj_start")
		--fjarrived=0
		--if fjjf~=nil and fjjf~="" then alias.jf(fjjf) end
		--if fjroomid>0 then alias.flytoid(fjroomid) else alias.flytoname(fjroom,fjzone) end
	else
		xkxGPS.setEntranceCondition("condition is null")
		alias.startmp()
	end
end
function alias.searchyp_fs1()
	-- #say 到flyto 608 集合
	yp.where="608|609|610|611|612|611|610|613|610|609|608|620|621|620|630|620|622|623|624|625|626|627|628|627|626|629|626|625|648|107|104|107"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=96
	run("look;sw;w;wu;wu;ed;ed;s;n;e;ne;se;w;e;s;n;se;s;s;s;w;w;w;e;e;su;nd;e;su;sd;s;n;set searchyp=step1")
end
function alias.searchyp_fs2()
-- #say 到flyto 96 集合
	yp.where="96|97|98|99|100|101|100|102|103|102|104|107|648|625|648|107|104|105|106|105|104|108|109|108|110|111|110|112|113|114|115|114|113|112|110|108|104|107"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=1
	run("look;e;e;e;e;n;s;e;s;n;e;n;nu;nd;su;sd;s;s;u;d;n;e;n;s;e;s;n;e;e;e;e;w;w;w;w;w;w;n;set searchyp=step1")
end
function alias.searchyp_fs3()
-- #say 到flyto 1 集合
	yp.where="1|2|3|4|6|4|5|4|3|7|8|7|3|120|119|118|117|115|116|115|114|113|112|110|111|110|108|109|108|104|107|648|625|626|627|628"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=628
	run("look;w;w;s;e;w;enter;out;n;n;n;s;s;w;w;sw;sw;sw;se;nw;w;w;w;w;s;n;w;n;s;w;n;nu;nd;w;w;w;set searchyp=step1")
end
function alias.searchyp_fs3_2()
-- #say 到flyto 628 集合
	yp.where="628|627|626|629|626|625|624|623|622|620|608|620|621|620|630|620|622|623|624|625|648|625|648|107|104|102|103|102|100|101|100|99|98|97|96|95|94|93|92|408|143"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=608
	run("look;e;e;su;nd;e;n;n;n;nw;nw;se;w;e;s;n;se;s;s;s;su;nd;su;sd;s;w;s;n;w;n;s;w;w;w;w;nw;sw;w;w;nw;nw;set searchyp=step1")
end
function alias.searchyp_hh()
-- #say 到flyto 1115 集合
	yp.where="1115|1056|1057|1058|1059|1060|1061|1062|1063|1062|1061|1060|1321|1304|1303|1305|1303|1304|1321|1320|1319|1318|1314|1313|1306|1307|1306|1313|1314|1423|1397|1423|1314|1315|1316|1317"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	run("look;e;e;ne;n;n;nu;nu;nu;sd;sd;sd;w;ne;ne;ne;sw;sw;sw;sw;w;w;w;s;sw;w;e;ne;n;n;n;s;s;w;w;w;set searchyp=step1")
	--run("look;e;e;ne;n;n;nu;nu;nu;sd;sd;sd;w;ne;ne;ne;sw;sw;sw;sw;w;w;w;s;sw;w;e;ne;n;n;n;s;s;w;w;w;set searchyp=step1")
end
function alias.searchyp_hz1()
-- #say 到flyto 1200 集合
	yp.where="1200|1199|1247|1199|1198|1255|1198|1197|1256|1197|1196|1257|1196|1192|1259|1192|1193|1194|1195|1194|1193|1192|1189|1185|1188|1185|1186|1187|1186|1185|1184|1183|1181|1183|1184|1162|1184|1185|1189|1190|1191|1263|1161|1160|1156|1157|1156|1158|1159|1158|1277"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	run("look;s;e;w;s;e;w;s;e;w;s;e;w;sw;e;w;w;w;ne;sw;e;e;sw;w;nu;sd;s;enter;out;n;w;n;n;s;s;w;e;e;e;sw;wu;wu;wd;wd;w;w;e;s;wu;ed;e;set searchyp=step1")
end
function alias.searchyp_hz2()
-- #say 到flyto 1196 集合
	yp.where="1196|1192|1259|1192|1193|1194|1195|1194|1193|1192|1189|1185|1188|1185|1186|1187|1186|1185|1184|1185|1189|1190|1191|1263|1161|1160|1156|1157|1156|1155|1154|1162|1154|1153|1154|1155|1156|1158|1159|1158|1277|1278|1277|1264|1265|1266|1267|1268、"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	run("look;sw;e;w;w;w;ne;sw;e;e;sw;w;nu;sd;s;enter;out;n;w;e;e;sw;wu;wu;wd;wd;w;w;e;n;ne;ne;sw;w;e;sw;s;s;wu;ed;e;e;w;ne;e;ne;n;ne;set searchyp=step1")
end
function alias.searchyp_hz3()
-- #say 到flyto 1125 集合
	yp.where="1125|1262|1172|1169|1170|1171|1170|1169|1167|1166|1167|1169|1173|1260|1261|1260|1173|1174|1175|1176|1177|1176|1175|1178|1179|1180|1181|1182|1181|1183|1184|1185|1188|1185|1186|1187"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	--yp.goto=1200
	run("look;e;e;ne;wu;w;e;ed;s;s;n;n;e;n;n;s;s;s;s;w;enter;out;e;s;s;s;s;w;e;s;s;e;nu;sd;s;enter;set searchyp=step1")
end
function alias.searchyp_hz4()
-- #say 到flyto 1200 集合
yp.where="1200|1199|1247|1199|1198|1255|1198|1197|1256|1197|1196|1257|1196|1192|1259|1192|1193|1194|1195|1194|1193|1192|1189|1185|1188|1185|1186|1187|1186|1185|1184|1185|1189|1190|1191|1263|1161|1160|1156|1157|1156|1155|1154|1162|1154|1153|1154|1155|1156|1158|1159|1158|1277"
yp.findyp=0
yp.roomno=0
yp.roomnum=1
yp.roomnolist=""
--yp.goto=1125
run("look;s;e;w;s;e;w;s;e;w;s;e;w;sw;e;w;w;w;ne;sw;e;e;sw;w;nu;sd;s;enter;out;n;w;e;e;sw;wu;wu;wd;wd;w;w;e;n;ne;ne;sw;w;e;sw;s;s;wu;ed;e;set searchyp=step1")
end
function alias.searchyp_hz5()
-- #say 到flyto 1125 集合
yp.where="1125|1147|1146|1145|1144|1148|1149|1148|1144|1143|1142|1143|1144|1295|1279|1295|1144|1150|1151|1152|1153|1154|1162|1163|1164|1163|1165|1166|1165|1163|1162|1184|1183|1181|1183|1184|1185|1188|1185|1186|1185|1189|1185|1184|1162|1154|1155|1156|1157|1156|1160|1161|1160|1156|1158|1159|1158|1277"
yp.findyp=0
yp.roomno=0
yp.roomnum=1
yp.roomnolist=""
--yp.goto=1124
run("look;su;sd;sw;sw;n;e;w;s;wu;wu;ed;ed;s;s;n;n;e;ed;ed;ed;e;ne;n;w;e;n;ne;sw;s;s;e;n;n;s;s;e;nu;sd;s;n;e;w;w;w;sw;sw;s;w;e;e;eu;wd;w;s;wu;ed;e;set searchyp=step1")
end
function alias.searchyp_hz6()
-- #say 到flyto 1124 集合
yp.where="1124|1298|1297|1125|1262|1172|1262|1125|1147|1146|1145|1144|1143|1142|1141|1140|1139|1138|1137|1126|1127|1132|1135|1136|1135|1132|1133|1134|1133|1132|1127|1128|1129|1130|1131"
yp.findyp=0
yp.roomno=0
yp.roomnum=1
yp.roomnolist=""
--yp.goto=1200
run("look;s;s;se;e;e;w;w;su;sd;sw;sw;wu;wu;nd;nd;nd;nd;nd;nd;w;s;eu;eu;wd;wd;wu;nw;se;ed;n;wu;enter;n;enter;set searchyp=step1")
end
function alias.searchyp_qz1()
-- #say 到flyto 1125 集合
	yp.where="1125|1147|1146|1145|1144|1148|1149|1148|1144|1143|1142|1143|1144|1150|1151|1152|1151|1150|1144|1295|1279|1280|1281|1282|1283|1284|1285|1286|1294|1286|1287|1288|1289|1290|1291|1292|1293|1296|22|17|18|1"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=115
	run("look;su;sd;sw;sw;n;e;w;s;wu;wu;ed;ed;e;ed;ed;wu;wu;w;s;s;su;wu;wd;sd;se;se;ed;nu;sd;sd;su;su;sd;su;sd;sd;s;s;s;s;s;set searchyp=step1")
end
function alias.searchyp_qz2()
-- #say 到flyto 115 集合
	yp.where="115|117|118|119|120|3|4|6|4|5|4|3|7|3|2|1|87|89|90|89|87|88|87|1|28|85|84|82|83|82|81"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=81
	run("look;ne;ne;ne;e;e;s;e;w;enter;out;n;n;s;e;e;e;e;n;s;w;n;s;w;s;e;e;s;w;e;sw;set searchyp=step1")
end
function alias.searchyp_qz2_2()
-- #say 到flyto 81 集合
	yp.where="81|46|44|45|44|43|31|32|33|32|31|29|30|29|28|1|18|19|21|19|18|17|16|15|16|17|22|23|24|23|22|1296"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=1
	run("look;w;w;s;n;w;ne;w;w;e;e;n;w;e;e;n;n;e;e;w;w;n;nw;nw;se;se;n;e;e;w;w;n;set searchyp=step1")
end
function alias.searchyp_qz3()
-- #say 到flyto 1 集合
	yp.where="1|2|3|4|6|4|5|4|3|7|8|7|3|120|119|118|117|115|116|115|114|113|112|113|114|115|117|118|119|120|3|2|1"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=80
	run("look;w;w;s;e;w;enter;out;n;n;n;s;s;w;w;sw;sw;sw;se;nw;w;w;w;e;e;e;ne;ne;ne;e;e;e;e;set searchyp=step1")
end
function alias.searchyp_qz4()
-- #say 到flyto 80 集合
	yp.where="80|79|75|76|77|78|77|76|75|74|49|70|71|70|69|72|73|72|69|62|63|64|68|64|65|66|67|64|63|61|60|50|51|59|51|52|58|52|57|52|51|50|49|48|47|46|44|45|44|43|31|29|30|29|28|85|84|82|83|82|81|46|28|1"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=1125
	run("look;w;w;s;s;s;n;n;n;w;w;s;e;w;s;e;u;d;w;s;sw;se;e;w;se;s;w;n;nw;n;n;n;w;s;n;w;n;s;s;n;e;e;e;n;n;nw;w;s;n;w;ne;n;w;e;e;e;e;s;w;e;sw;w;n;n;set searchyp=step1")
end
function alias.searchyp_ts()
-- #say 到flyto 1115 集合
	yp.where="1115|1056|1057|1058|1059|1060|1321|1304|1303|1305|1303|1304|1321|1320|1319|1318|1314|1318|1319|1320|1321|1060|1061|1062|1063|1064|1065|1066|1067"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=1068
	run("look;e;e;ne;n;n;w;ne;ne;ne;sw;sw;sw;sw;w;w;w;e;e;e;ne;e;nu;nu;nu;eu;nu;nu;nu;set searchyp=step1")
end
function alias.searchyp_ts1()
	yp.where="1068|1069|1070|1084|1085|1086|1087|1085|1084|1088|1089|1088|1084|1070|1071|1072|1073|1072|1071|1081|1082|1083"
	yp.findyp=0
	yp.roomno=0
	yp.roomnum=1
	yp.roomnolist=""
	yp.goto=1115
	run("look;nu;nu;eu;eu;e;ed;wu;wd;ed;nu;sd;wu;wd;ask jiang baisheng about 上山;nu;w;nu;sd;e;ed;eu;e;set searchyp=step1")
end
------------------------------------------------------------------------------------
-- mp_th_pre
------------------------------------------------------------------------------------
function mp_th_pre.dosomething1(n,l,w)
	local _f
	wait.make(function()
		if findstring(l,"你目前还没有任何为 dealwithitems=over 的变量设定。") then
			alias.flytoid(me.menpaiJobStart)
		end
		if findstring(l,"数码世界，数字地图，"..me.menpaiJobStart.."就是这里！") then
			alias.resetidle()
			if yp.goto==0 then 
				alias.setmpLimitedMark()
				yp.faint=0
				yp.findyp=0
				yp.roomno=0
				yp.roomnum=1
				yp.roomnolist=""
				yp.place=""
				yp.name=""
				yp.id=""
				yp.goto=0
				yp.stay_room=0
				yp.searchjs=0
				yp.killed=0
				run("halt")
				if workflow.fj>0 then run("ask lu chengfeng about 门派任务") end
				yp.killed=0
				closeclass("dazuo_resetidle")
				closeclass("dazuo")
				run("ask lu chengfeng about abandon;ask lu chengfeng about yapu")
			--	alias.dz(set_neili_job)
			else
				alias.startworkflow()
			end
		end
		if not isopen("boat") and not isopen("gps_watch") and findstring(l,"你目前还没有任何为 dazuo=over 的变量设定。") then
			alias.resetidle()				
			closeclass("dazuo_resetidle")
			closeclass("dazuo")
			if havefj>0 and fjzone~="" and roomno_now==me.fjbaseid then 
				yp.killed=0
				if yp.goto==0 then run("e;ask lu chengfeng about yapu") else alias.startworkflow() end
			elseif yp.stay_room>0 then 
				alias.flytoid(yp.stay_room) 
			elseif yp.goto>0 then 
				xkxGPS.setEntranceCondition("condition is null")
				alias.flytoid(yp.goto)
			else 
			    print("mp_th_pre")
				alias.startworkflow() 
			end
		end
		a,b,c=string.find(w[0],"你向陆乘风打听有关「yapu」的消息。\n陆乘风(.+)")
		if c~=nil and findstring(c,"最近有个.+一带为恶") then 
			yp.name="" 
			run("halt;w")
			for i=1,3,1 do run("ask ding "..i.." about yapu") end
		end
		if c~=nil and findstring(c,"还是请先稍事歇息罢") then 
			yp.name="" 
			if havefj>0 then
				alias.startworkflow()
			else
				alias.dz(set_neili_job)
			end
		end
		if c~=nil and findstring(c,"皱了皱眉") then 
			yp.name="" 
			if havefj>0 then
				roomno_now=1463
				alias.startfj()
			elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then --哑仆任务失败，优先押镖
				alias.startyb()
			elseif workflow.cm>0 then
				alias.startcm()
			else
				alias.dz()
			end
		end
		if c~=nil and findstring(c,"你还没找到吧") then 
			yp.name="" 
			if havefj>0 then
				roomno_now=1463
				alias.startfj()
			elseif workflow.yb>0 and ybjob.needfangqi==0 and ybLimited==0 then --哑仆任务失败，优先押镖
				alias.startyb()
			elseif workflow.cm>0 then
				alias.startcm()
			else
				alias.dz()
			end
		end
		if c~=nil and findstring(c,"鼓起掌来","竖起了右手大拇指") then 
			yp.name="" 
			wait.make(function()
				_f=function()
					alias.dz(set_neili_global)
				end
				wait.time(2);_f()
			end)
		end
		if findstring(l,"你目前还没有任何为 checkexpover=mp 的变量设定。") then
			alias.resetidle()
			yp.killed=1 --加上成功击杀的标记
			if add.exp>10 and mpLimited.MarkExp<me.menpaiLimited then mpLimited.MarkExp=me.menpaiLimited end
			if add.exp<10 or mpLimited.mpexp>7000 then
				mpJobLimited=1
				print("统计到的yapu上限为："..mpLimited.mpexp)
				mpLimited.MarkExp=mpLimited.mpexp
				if mpLimited.MarkTime<(os.time()-3600) then
					if de_bug>0 then print("到yapu时间却仍然busy，推迟2分钟") end
					mpLimited.MarkTime=tonumber(os.time()-3600+120)
				end
			end
			alias.uw()
			run("cun all;taohua")
			--alias.checkthjob()
			if stat.havedu>0 then
				alias.startliaoshang()
			elseif ybLimited==0 and ybjob.waitlimit>0 then
				alias.startyb()
			elseif fjfinished>0 then 
				alias.close_mp()
				openclass("fj_start")
				alias.flytoid(me.fjbaseid)
			elseif fjroom~=nil and string.len(fjroom)>0 and fjzone~=nil and string.len(fjzone)>0 then --改为先mp后fj
		        print("有fj优先做完")
		        if set_GbSecretWay>0 then xkxGPS.setEntranceCondition("(condition is null or condition='dong') and id<>3247") end
		        workflow.nowjob="fj"
				closeclass("mp_th_pre")
		        closeclass("fj_pre")
		        openclass("fj_start")
		        fjarrived=0
		        if fjjf~=nil and fjjf~="" then alias.jf(fjjf) end
		        if fjroomid>0 then alias.flytoid(fjroomid) else alias.flytoname(fjroom,fjzone) end
			else
				alias.flytoid(1470)
			end
		end
		local a,b,c,d,e=string.find(w[0],"你向家丁打听有关「yapu」的消息。\n家丁说道：我在(.+)见到那(.+)时，看来是个寻常(.+)模样")
		if c~=nil and d~=nil and e~=nil then
			yp.refind=0
			yp.place=c
			yp.name=e
			if th_yapu_abandon~=nil and th_yapu_abandon~="" and findstring(th_yapu_abandon,e) then
				yp.findyp=0
				yp.roomno=0
				yp.roomnum=1
				yp.roomnolist=""
				yp.place=""
				yp.name=""
				yp.id=""
				yp.goto=0
				yp.stay_room=0
				yp.searchjs=0
				alias.startworkflow()
				return
			end
			if yp.place=="福建泉州港口路" or yp.place=="福建泉州市舶司" or yp.place=="福建泉州永宁港" or findstring(yp.place,"偶") or yp.place=="福建泉州土地庙" then
				yp.goto=80
			elseif yp.place=="福建泉州西门吊桥" or yp.place=="福建泉州济世堂老店" then
				yp.goto=1
			elseif yp.place=="福建泉州恩怨巷" or yp.place=="福建泉州中心广场" then
				yp.goto=115
			elseif yp.place=="福建泉州山路" then
				yp.goto=1125
			elseif yp.place=="广东佛山林间道" then
				yp.goto=1
			elseif yp.place=="广东佛山北帝庙" or yp.place=="广东佛山佛山镇街" then
				yp.goto=96
			elseif yp.place=="广东佛山林间大道" or yp.place=="广东佛山麻溪铺" then
				yp.goto=608
			elseif yp.place=="杭州黄泥岭" or yp.place=="杭州灵隐寺" then
				yp.goto=1124
			elseif yp.place=="杭州满觉陇" or yp.place=="杭州石屋洞" or yp.place=="杭州水乐洞" or yp.place=="杭州烟霞洞" then
				yp.goto=1125
			elseif yp.place=="杭州玉皇山" or yp.place=="杭州玉皇山脚" or yp.place=="杭州玉皇山顶" or yp.place=="杭州山路" then
				yp.goto=1200
			elseif yp.place=="杭州苏堤" then
				yp.goto=1125
			elseif yp.place=="杭州钱塘江畔" then
				yp.goto=1196
			elseif yp.place=="杭州天外天客店" then
				yp.goto=1200
			elseif yp.place=="黄河边黄河岸边" or findstring(yp.place,"黄河边黄河入") then
				yp.goto=1115
			elseif yp.place=="山东泰山岱宗坊" or yp.place=="山东泰山一天门" then
				yp.goto=1115
			end
			addlog("接到yapu任务"..yp.place)
			--if havefj>0 then 
				--alias.startfj() 
			--else 
				xkxGPS.setEntranceCondition("condition is null")
				alias.flytoid(yp.goto) 
			--end
		end
		if findstring(l,"[> ]*你摇着家丁试着把.+叫醒，大声在.+耳边叫道：「 懒猪！起来了！」 ") and findstring(yp.place,"泰山") then
			alias.searchyp_ts1()
		end
		if findstring(l,"你要对谁做 wake 这个动作？") and findstring(yp.place,"泰山") then
			run("sd;sd;sd;sd;wd;sd;sd;sd;nu;nu;nu;eu;nu;nu;nu")
			wait.time(2)
			run("nu;wake jia ding")
		end
		if findstring(l,"数码世界，数字地图，"..yp.stay_room.."就是这里！") then
			run("order follow")
			xkxGPS.setEntranceCondition("condition is null")
			yp.stay_room=0
			alias.flytoid(yp.goto)
		end
		if findstring(l,"数码世界，数字地图，"..yp.goto.."就是这里！") then
			alias.resetidle()
			addlog("当前扫描起点"..yp.goto)
			run("kick4 jia ding")
			if yp.runfailj==0 then
				yp.searchjs=yp.searchjs+1
			end
			yp.runfailj=0
			always.where_No=1
			if yp.searchjs>5 then
				print("找不到哇,放弃")
				addlog("yapu任务失败"..yp.place.." "..yp.goto)
				yp.goto=0
				yp.stay_room=0
				alias.startworkflow()
				run("order stay")
				--alias.checkthjob()
				--_f=function() alias.checkthjob() end
				--wait.time(1);_f()
			else
				closeclass("mp_th_pre")
				openclass("mp_th_start")
				if yp.goto==80 then alias.searchyp_qz4() --end
				elseif yp.goto==1 and string.sub(yp.place,1,8)=="福建泉州" then alias.searchyp_qz3() --end
				elseif yp.goto==1125 and string.sub(yp.place,1,8)=="福建泉州" then alias.searchyp_qz1() --end
				elseif yp.goto==115 then alias.searchyp_qz2() --end --#say searchyp_qz2 2条 searchyp_qz2_2
				elseif yp.goto==1 and findstring(yp.place,"佛山") then alias.searchyp_fs3() --end --#say searchyp_fs3 2条，要去flyto 628 searchyp_fs3_2
				elseif yp.goto==96 then alias.searchyp_fs2() --end
				elseif yp.goto==608 then alias.searchyp_fs1() --end
				elseif yp.goto==628 then alias.searchyp_fs3_2() --end
				elseif yp.goto==1124 then alias.searchyp_hz6() --end
				elseif yp.goto==1125 and (findstring(yp.place,"洞") or findstring(yp.place,"满觉陇")) then alias.searchyp_hz5() --end
				elseif yp.goto==1200 then alias.searchyp_hz4() --end
				elseif yp.goto==1125 and findstring(yp.place,"苏堤") then alias.searchyp_hz3() --end
				elseif yp.goto==1196 then alias.searchyp_hz2() --end
				elseif yp.goto==1115 and string.sub(yp.place,1,6)=="黄河边" then alias.searchyp_hh() --end
				elseif yp.goto==1115 and string.sub(yp.place,1,8)=="山东泰山" then alias.searchyp_ts() --end
			--	elseif yp.goto==1068 then alias.searchyp_ts1()
				elseif yp.goto==1068 then run("wake jia ding")
				elseif yp.goto==81 then alias.searchyp_qz2_2() end
			end
		end
	end)
end
------------------------------------------------------------------------------------
-- mp_th_start
------------------------------------------------------------------------------------
function mp_th_start.dosomething1(n,l,w)
	local a,b,c,d,e,_tb,_f
	wait.make(function()
	a,b,c=string.find(l,"[>|]*%s+"..yp.name.."%((%w+)%)") --一位单名疑似yapu npc
	if c~=nil then
		if yp.where~="" then
		_tb=Split(yp.where,"|")
		yp.roomnolist=additem(yp.roomnolist,_tb[always.where_No])
		end
	--	yp.findyp=1
		yp.npccount=1
		print("此处有【"..yp.npccount.."】个同名npc")
		yp.id=string.lower(c)
	end
	a,b,c,d=string.find(l,"[>|]*%s+(.+)位"..yp.name.."%((%w+)%)") --多位单名疑似yapu npc
	if d~=nil then
		if yp.where~="" then
		_tb=Split(yp.where,"|")
		yp.roomnolist=additem(yp.roomnolist,_tb[always.where_No])
		end
	--	yp.findyp=1
		yp.npccount=ctonum(c)
		print("此处有【"..yp.npccount.."】个同名npc")
		yp.id=string.lower(d)
	end
	a,b,c,d=string.find(l,"[>|]*%s+"..yp.name.."%((%w+) (%w+)%)") --一位复名疑似yapu npc
	if c~=nil and d~=nil then
		if yp.where~="" then
		_tb=Split(yp.where,"|")
		yp.roomnolist=additem(yp.roomnolist,_tb[always.where_No])
		end
	--	yp.findyp=1
		yp.npccount=1
		print("此处有【"..yp.npccount.."】个同名npc")
		yp.id=string.lower(c).." "..string.lower(d)
	end
	a,b,c,d,e=string.find(l,"[>|]*%s+(.+)位"..yp.name.."%((%w+) (%w+)%)") --多位复名疑似yapu npc
	if d~=nil and e~=nil then
		if yp.where~="" then
		_tb=Split(yp.where,"|")
		yp.roomnolist=additem(yp.roomnolist,_tb[always.where_No])
		end
	--	yp.findyp=1
		yp.npccount=ctonum(c)
		print("此处有【"..yp.npccount.."】个同名npc")
		yp.id=string.lower(d).." "..string.lower(e)
	end
	if findstring(l,"这里没有这个人。") then
		alias.resetidle()
		print("yapu跑了,重新搜索")
		closeclass("mp_th_start")
		openclass("mp_th_pre")
		for i=1,3,1 do run("ask ding "..i.." about yapu") end
	end
	if findstring(l,"你无法确定.+是不是你要捉的对象。","你惊讶的对.+说道：“噢！是吗？”") then
		alias.resetidle()
		if yp.refind==nil or yp.refind==0 then
			print("不是这个npc 去下一个room")
			yp.roomnum=yp.roomnum-1
			_tb=Split(yp.roomnolist,"|")
			yp.roomno=tonumber(_tb[yp.roomnum])
			yp.refind=1
			if yp.roomnum>0 then 
				alias.checkbusy("refind")
				--alias.flytoid(yp.roomno)
			else
				print("这条路径发现的疑似哑仆NPC找完都不是,放弃")
				addlog("yapu任务失败")
				run("order stay")
				yp.goto=0  --2017.8.24修复yapu任务失败之后一直飞陆乘风bug
				yp.faint=0  --2017.8.24修复yapu任务失败之后一直飞陆乘风bug
				yp.stay_room=0  --2017.8.24修复yapu任务失败之后一直飞陆乘风bug
				_f=function() alias.checkthjob() end
				wait.time(1);_f()
			end
		end
	end
	if findstring(l,"你目前还没有任何为 searchyp=step1 的变量设定。") then
		alias.resetidle()
		--addlog("yapu任务 在"..tostring(yp.roomnolist).."发现哑仆")
		if string.len(yp.roomnolist)>0 then
			yp.where=""
			_tb=Split(yp.roomnolist,"|")
			yp.roomnum=tonumber(#_tb)
			yp.roomno=tonumber(_tb[yp.roomnum])
			print("目标房间："..yp.roomno.." 共"..yp.roomnum.."个")
			alias.flytoid(yp.roomno)
		else
			closeclass("mp_th_start")
			openclass("mp_th_pre")
			alias.flytoid(yp.goto)
			--if yp.goto==115 then
			--	print("qz2的第二条路径qz2_2")
			--	closeclass("mp_th_start")
			--	openclass("mp_th_pre")
			--	alias.flytoid(81)
			--end
			--if yp.goto==1 and yp.place=="广东佛山林间道" then
			--	print("fs3的第二条路径fs3_2")
			--	closeclass("mp_th_start")
			--	openclass("mp_th_pre")
			--	alias.flytoid(628)
			--end
		end
	end
	if findstring(l,"数码世界，数字地图，"..tostring(yp.roomno).."就是这里！") then
		alias.resetidle()
		yp.rencount=1
		if mpjf~=nil and mpjf~="" then run(mpjf) end
		_tb=Split(mpyun,"|")
		for k,v in ipairs(_tb) do run(v) end
		run("halt;ren "..yp.id)
	end
	a,b,c=string.find(l,"[> ]*"..yp.name.."+(.+)")
	if c~=nil and findstring(c,"跌在地上昏了过去","挣扎了几下就死了") then
		alias.resetidle()
		alias.close_kill()
		if findstring(c,"挣扎了几下就死了") then yp.id="corpse" end
		if findstring(yp.name,"大盗","蒙古武将","护法喇嘛","苗疆巫女","杀手","恶霸","破戒僧") then
			--run("halt")
			--wait.time(3)
			run("halt;bring "..yp.id..";cun all;set ypbring")
			yp.faint=1
		end
	end
	if findstring(l,"你得先打昏.+才行！") then
		yp.faint=0
	end
	--if findstring(l,"你目前还没有任何为 busyover=killover 的变量设定。") then
	--	alias.resetidle()
	--	if yp.name=="苗疆巫女" then run("halt;get san from "..tostring(yp.id)) end
	--	run("yield no;halt;bring "..tostring(yp.id))
	--end
	--if findstring(l,"你无法确定.+是不是你要捉的对象。") then
	if findstring(l,"你目前还没有任何为 ypbring 的变量设定。") and yp.faint>0 then
		alias.resetidle()
		_f=function() run("halt;bring "..yp.id..";set ypbring") end
		wait.time(0.5);_f()
	--	run("halt;ren "..yp.id)
	end
	if findstring(l,"家丁将"..yp.name..".+背在背上，走掉了。") then
		alias.resetidle()
		closeclass("mp_th_start")
		openclass("mp_th_pre")
		yp.goto=0
		yp.faint=0
		yp.stay_room=0
		alias.checkexp("mp")
	end
	if findstring(l,"这个方向没有出路。","糟糕，你逃跑失败了！") then
		yp.runfail=1
	end
	if findstring(w[0],"你低声在家丁耳边说道：是不是这个"..yp.name.."？\n家丁把头摇得跟拨浪鼓似的。") then
		alias.resetidle()
		if yp.rencount>=yp.npccount then
			if yp.refind==nil or yp.refind==0 then
				yp.refind=1
				print("不是这个npc 去下一个room")
				yp.roomnum=yp.roomnum-1
				_tb=Split(yp.roomnolist,"|")
				yp.roomno=tonumber(_tb[yp.roomnum])
			end
		end
		alias.checkbusy("refind")
	end
	if findstring(l,"你目前还没有任何为 busyover=refind 的变量设定。") then
		yp.refind=0
		if yp.rencount>=yp.npccount then
			if yp.roomnum>0 then 
				alias.flytoid(yp.roomno)
			else
				closeclass("mp_th_start")
				openclass("mp_th_pre")
				alias.flytoid(yp.goto)
			end
		else
			yp.rencount=yp.rencount+1
			run("halt;ren "..yp.id.." "..yp.rencount)
		end
	end
	if findstring(w[0],"你低声在家丁耳边说道：是不是这个"..yp.name.."？\n家丁惊讶地「啊！」了一声。") or findstring(w[0],"你低声在家丁耳边说道：是不是这个"..yp.name.."？\n\n.+慢慢睁开眼睛，清醒了过来。\n\n家丁惊讶地「啊！」了一声。") then
		alias.resetidle()
		check_battleidle=0
		yp.refind=0
		yp.goto=0
		yp.stay_room=0
		--addlog("yapu任务 在"..tostring(yp.roomnolist).."发现哑仆")
		run("hp;unset no_parry;order stay;huan all")
		if yp.name=="小贩" then
			yp.id="da dao"
			yp.name="大盗"
		elseif yp.name=="胡人" then
			yp.id="menggu wujiang"
			yp.name="蒙古武将"
		elseif yp.name=="穷汉" then
			yp.id="hufa lama"
			yp.name="护法喇嘛"
		elseif yp.name=="女孩" then
			yp.id="miaojiang wunu"
			yp.name="苗疆巫女"
		elseif yp.name=="书生" then
			yp.id="shashou"
			yp.name="杀手"		
		elseif yp.name=="趟子手" then
			yp.id="e ba"
			yp.name="恶霸"
		elseif yp.name=="僧人" then
			yp.id="pojie seng"
			yp.name="破戒僧"
		end
		if needzhongjian()==0 and (yp.name=="杀手" or yp.name=="书生") then run("set no_parry 1") end
		openclass("kill")
		openclass("kill_pfm")
		--openclass("kill_"..me.menpai)
		closeclass("kill_run")
		AddTimer("kill_timer", 0, 0, 2, "", timer_flag.Enabled + timer_flag.Replace, "kill.timer")
		SetTimerOption("kill_timer", "group", "kill")
		reyun=1
		pfmid=1
		rekill=0
		runaway=false
		npcfaint=false
		killRunSuccess=false
		killaction=""
		killid=yp.id
		killname=yp.name
		killskill=mpweapon
		killpfm=mppfm
		killyun=mpyun
		killjiali=mpjiali
		killjiajin=mpjiajin
		run("yield no;jiali "..killjiali..";jiajin "..killjiajin)
		if string.len(mpweapon)>0 then
			wieldweapon=1
			if mpweapon=="staff" then alias.wi(staffid) else alias.wi(mpweapon) end
		else 
			alias.uw() 
		end
		alias.pfm()
	end
	end)
end
------------------------------------------------------------------------------------
-- mp_th_watch
------------------------------------------------------------------------------------
function mp_th_watch.dosomething1(n,l,w)
end
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
function mp_th.update()
	local _tb
	local  mp_th_pre_triggerlist={
	       {name="mp_th_pre_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_th_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_th_pre_triggerlist) do
		addtri(v.name,v.regexp,"mp_th_pre",v.script,v.line)
	end
	local _tb2={
		"你向陆乘风打听有关「yapu」的消息。\\n(.+)\\Z",
		"你向家丁打听有关「yapu」的消息。\\n(.+)\\Z",
		"你目前还没有任何为 busyover=refind 的变量设定。",
	}
	local  mp_th_pre_m_triggerlist={
	       {name="mp_th_pre_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_th_pre.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_th_pre_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_th_pre",v.script,v.line)
	end
	closeclass("mp_th_pre")
	
	local  mp_th_start_triggerlist={
	       {name="mp_th_start_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_th_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_th_start_triggerlist) do
		addtri(v.name,v.regexp,"mp_th_start",v.script,v.line)
	end
	local _tb2={
		"你低声在家丁耳边说道：是不是这个.+？\\n(.+)\\Z",
	}
	local  mp_th_start_m_triggerlist={
	       {name="mp_th_start_m_dosth2",line=2,regexp=linktri2(_tb2),script=function(n,l,w)    mp_th_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_th_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_th_start",v.script,v.line)
	end
	local _tb2={
		"你低声在家丁耳边说道：是不是这个.+？\\n\\n.+慢慢睁开眼睛，清醒了过来。\\n\\n(.+)\\Z",
	}
	local  mp_th_start_m_triggerlist={
	       {name="mp_th_start_m_dosth5",line=5,regexp=linktri2(_tb2),script=function(n,l,w)    mp_th_start.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_th_start_m_triggerlist) do
		addtri_multiline(v.name,v.regexp,"mp_th_start",v.script,v.line)
	end
	closeclass("mp_th_start")
	
	local  mp_th_watch_triggerlist={
	       {name="mp_th_watch_dosth1",regexp="^(> > > |> > |> |)(.+)$",script=function(n,l,w)    mp_th_watch.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(mp_th_watch_triggerlist) do
		addtri(v.name,v.regexp,"mp_th_watch",v.script,v.line)
	end
	closeclass("mp_th_watch")
end
mp_th.update()
