godie={
npc_no=0,
}
function godie.dosomething1(n,l,w)
	local _f,_tb
	if findstring(l,"数码世界，数字地图，2008就是这里！") then
		alias.resetidle()
		godie.npc_no=0
		run("halt;w;halt;e;set godie;kill ha jiongcheng")
	end
	if findstring(l,"你口念咒语『神马都是浮云,虾米都是尘土』，『镇岳宫』立马到达！") then
		alias.resetidle()
		run("set no_protection 1;jump jing")
	end
	if findstring(l,"你目前还没有任何为 godie 的变量设定。") then
		alias.resetidle()
		godie.npc_no=0
		wait.make(function()
			_f=function() godie.run() end
			wait.time(1);_f()
		end)
	end
	if findstring(l,"看起来.+想杀死你！") then
		godie.npc_no=godie.npc_no+1
	end
	if findstring(l,"慢慢地一阵眩晕感传来，你终于又有了知觉") then
		alias.resetidle()
		godie.npc_no=0
		alias.flytoid(2008)
	end
	if findstring(l,"你的眼前一黑，接著什么也不知道了") then
		godie.npc_no=10
	end
	if findstring(l,"绳子「啪！」的一声断了，你重重地摔到地上。") then
		run("hang rope")
	end
end
function godie.run()
	if godie.npc_no>0 then run("hang rope");return
	else run("halt;w;halt;e;halt;w;halt;e;set godie;kill feng huchang")
	end
end
function godie_update()
		_tb={
		"数码世界，数字地图，2008就是这里！",
		"你目前还没有任何为 godie 的变量设定。",
		"看起来.+想杀死你！",
		"慢慢地一阵眩晕感传来，你终于又有了知觉",
		"你的眼前一黑，接著什么也不知道了",
		"绳子「啪！」的一声断了，你重重地摔到地上。",
		"你口念咒语『神马都是浮云,虾米都是尘土』，『镇岳宫』立马到达！",
	}
	local  login_triggerlist={
	       {name="godie_dosth1",regexp=linktri(_tb),script=function(n,l,w)    godie.dosomething1(n,l,w)  end,},
	}
	for k,v in pairs(login_triggerlist) do
		addtri(v.name,v.regexp,"godie",v.script,v.line)
	end
	closeclass("godie")
end
godie_update()